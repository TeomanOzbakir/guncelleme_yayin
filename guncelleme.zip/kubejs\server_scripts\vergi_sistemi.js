// =====================================================================
//  VERGİ SİSTEMİ  -  kubejs/server_scripts/vergi_sistemi.js
//  Hedef: NeoForge 1.21.1 | KubeJS 2101.7.2 | Create Numismatics 1.1.0
//         Open Parties and Claims 0.33.0
//
//  - Arazi vergisi: günlük, banka hesabından otomatik kesilir (veya
//    oyuncu /vergi ode ile önceden öder). Ödenen para "kredi" olarak
//    durur ve o anki chunk sayısına göre dakika dakika harcanır; chunk
//    eklemek kalan süreyi kısaltır. Ödenmezse 24 gerçek saat ek
//    süre, sonra claim'ler askıya alınır (silinir + kaydedilir),
//    ödeme yapılınca geri yüklenir.
//  - Ölüm vergisi: ölünce banka bakiyesinin %5'i.
//  - Tescil: /tescil komutu ücreti keser, belge verir.
//  - Devlet hazinesi: kesilen tüm vergiler ayrı bir Numismatics hesabına
//    yatar. OP'lar /devlet ile bakiyeyi ve hareketleri görür, oyunculara
//    aktarım yapar; /devlet kart ile Bank Terminal'de hazineyi açar.
//
//  Doğrulama (mod JAR'larına karşı): kullanılan tüm Numismatics, OPAC ve
//  KubeJS sınıf/fonksiyon adları ve parametreleri bu sürümlerde var.
//  Düzeltilenler: tescil belgesi için withName -> withCustomName
//  (KubeJS 2101'de withName yok); askiyaAl içindeki gereksiz
//  Object.assign kaydı kaldırıldı.
//  !! Gerçek bir oyunda ÇALIŞTIRILARAK TEST EDİLMEDİ.
// =====================================================================

// ----------------------------- AYARLAR -------------------------------
const VERGI = {
  GUNLUK_UCRET_CHUNK: 25,     // spur / claim edilmiş chunk / gün
  OLUM_VERGISI_ORAN: 0.05,    // bankadaki paranın %5'i
  TESCIL_UCRETI: 500,         // spur (YER TUTUCU - istediğiniz değeri yazın)
  EK_SURE_SAAT: 24,           // ödenmezse claim kapanmadan önce bekleme
  MUAF_UUID: []               // vergiden muaf oyuncu UUID'leri (string)
}

const GUN_MS = 24 * 60 * 60 * 1000
const KONTROL_ARALIGI_TICK = 1200   // 1200 tick = 1 dakika

// ----------------------------- SINIFLAR ------------------------------
const JUUID = Java.loadClass('java.util.UUID')
const ResLoc = Java.loadClass('net.minecraft.resources.ResourceLocation')
const Numismatics = Java.loadClass('dev.ithundxr.createnumismatics.Numismatics')
const ReasonHolder = Java.loadClass('dev.ithundxr.createnumismatics.content.backend.ReasonHolder')
const OpenPACServerAPI = Java.loadClass('xaero.pac.common.server.api.OpenPACServerAPI')
const OzelSahipler = Java.loadClass('xaero.pac.common.claims.api.SpecialClaimOwners')

// ----------------------------- VERİ ----------------------------------
function yukle(server) {
  const s = server.persistentData.getString('vergi_veri')
  if (!s) return { kayitlar: {} }
  try { return JSON.parse(s) } catch (e) { return { kayitlar: {} } }
}
function kaydet(server, d) {
  server.persistentData.putString('vergi_veri', JSON.stringify(d))
}
// Arazi vergisi "kredi" ile işler: ödenen para spur olarak rec.kredi'de
// durur ve her dakika O ANKİ chunk sayısına göre eriyerek harcanır.
// Chunk sayısı artarsa kalan süre aynı oranda kısalır (1 chunk için 2 gün
// ödenmişse 30 chunk'ta bu ~1.6 saate iner). İlk gün ücretsiz: yeni
// kayda, o anki chunk sayısı için 1 günlük kredi verilir.
const MAX_ADIM_MS = 5 * 60 * 1000   // sunucu kapalıyken geçen süre sayılmaz
function yeniKayit(simdi, n) {
  return { kredi: (n || 0) * VERGI.GUNLUK_UCRET_CHUNK, son: simdi, grace: 0, askida: false, auto: true, snapshot: [], bekleyen: [] }
}
function krediHazirla(rec, n, simdi) {
  if (rec.kredi == null) {   // eski (bitiş zamanlı) kayıttan çevir
    const kalanMs = Math.max(0, (rec.paidUntil || simdi) - simdi)
    rec.kredi = kalanMs / GUN_MS * Math.max(n, 1) * VERGI.GUNLUK_UCRET_CHUNK
    delete rec.paidUntil
  }
  if (rec.son == null) rec.son = simdi
}
function krediTuket(rec, n, simdi) {
  const gecen = Math.min(Math.max(0, simdi - rec.son), MAX_ADIM_MS)
  rec.son = simdi
  if (n > 0) rec.kredi -= n * VERGI.GUNLUK_UCRET_CHUNK * gecen / GUN_MS
}
function kalanSure(rec, n) {
  if (n <= 0) return 'claim yok'
  if (!(rec.kredi > 0)) return 'bitti'
  return kalan(rec.kredi / (n * VERGI.GUNLUK_UCRET_CHUNK) * GUN_MS)
}

// ----------------------------- BANKA ---------------------------------
function hesap(uuid) { return Numismatics.BANK.getAccount(uuid) }   // hesap yoksa null
function bakiye(uuid) {
  const h = hesap(uuid)
  return h ? h.getBalance() : 0
}
function kes(uuid, miktar) {
  miktar = Math.floor(miktar)
  if (miktar <= 0) return true
  const h = hesap(uuid)
  if (!h) return false
  const ok = h.deduct(miktar, ReasonHolder.IGNORED)   // bakiye yetmezse false
  if (ok) h.markDirty()
  return !!ok
}

// ----------------------------- DEVLET HAZİNESİ -----------------------
// Kesilen tüm vergiler bu Numismatics hesabına yatar. Hesap "Blaze Banker"
// türündedir: başlangıç parası almaz ve yetkili listesi (trust list) vardır.
// /devlet kart ile verilen karta bağlıdır; kartla Bank Terminal'e sağ
// tıklayan yetkili, hazinenin kendi banka ekranını açar.
const HAZINE_UUID = JUUID.fromString('5f0c2d1e-7a3b-4e9c-8d6f-1b2a3c4d5e6f')
const BankType = Java.loadClass('dev.ithundxr.createnumismatics.content.backend.BankAccount$Type')
const CardItem = Java.loadClass('dev.ithundxr.createnumismatics.content.bank.CardItem')
const NumUtils = Java.loadClass('dev.ithundxr.createnumismatics.util.Utils')
const TUR_AD = {
  arazi: 'Arazi vergisi', olum: 'Ölüm vergisi', tescil: 'Tescil',
  cinayet: 'Cinayet cezası', savas: 'Savaş ilanı',
  borc: 'Borç tahsilatı', kredi: 'Kredi verildi', kredi_odeme: 'Kredi ödemesi',
  aktarim: 'Aktarım', cekim: 'Çekim', yatirma: 'Yatırma'
}

function hazine() {
  const h = Numismatics.BANK.getOrCreateAccount(HAZINE_UUID, BankType.BLAZE_BANKER)
  if (h.getLabel() != 'Devlet Hazinesi') { h.setLabel('Devlet Hazinesi'); h.markDirty() }
  return h
}
function ad(server, uuid) {
  const p = server.playerList.getPlayer(uuid)
  if (p != null) return String(p.username)
  const prof = server.getProfileCache().get(uuid)
  return prof.isPresent() ? String(prof.get().getName()) : String(uuid).substring(0, 8)
}
function hazineVeri(server) {
  const s = server.persistentData.getString('hazine_veri')
  let d = null
  if (s) { try { d = JSON.parse(s) } catch (e) { d = null } }
  if (!d) d = {}
  if (!d.gelir) d.gelir = { arazi: 0, olum: 0, tescil: 0 }
  if (!d.hareket) d.hareket = []
  return d
}
function hazineKayit(server, tur, miktar, kim) {
  const d = hazineVeri(server)
  if (d.gelir[tur] != null) d.gelir[tur] += miktar
  d.hareket = d.hareket.concat([{ t: Date.now(), tur: tur, m: miktar, k: kim }]).slice(-30)
  server.persistentData.putString('hazine_veri', JSON.stringify(d))
}
// Oyuncudan vergi keser ve hazineye yatırır
function vergiKes(server, uuid, miktar, tur) {
  miktar = Math.floor(miktar)
  if (miktar <= 0) return true
  if (!kes(uuid, miktar)) return false
  const h = hazine()
  h.deposit(miktar)
  h.markDirty()
  hazineKayit(server, tur, miktar, ad(server, uuid))
  return true
}

// ----------------------------- CLAIM ---------------------------------
function claimYonetici(server) {
  return OpenPACServerAPI.get(server).getServerClaimsManager()
}
function claimSayisi(server, uuid) {
  const m = claimYonetici(server)
  return m.hasPlayerInfo(uuid) ? m.getPlayerInfo(uuid).getClaimCount() : 0
}
function claimOlcekle(server, uuid) {
  // Oyuncunun tüm claim'lerini [{d,x,z,s,f}] listesi olarak döndürür
  const m = claimYonetici(server)
  const liste = []
  if (!m.hasPlayerInfo(uuid)) return liste
  const info = m.getPlayerInfo(uuid)
  const boyutlar = m.getDimensionStream().toArray()
  for (let i = 0; i < boyutlar.length; i++) {
    const rl = boyutlar[i].getDimension()
    const pd = info.getDimension(rl)
    if (pd == null) continue
    const listeler = pd.getStream().toArray()
    for (let j = 0; j < listeler.length; j++) {
      const durum = listeler[j].getClaimState()
      const s = durum.getSubConfigIndex()
      const f = durum.isForceloadable()
      const pozlar = listeler[j].getStream().toArray()
      for (let k = 0; k < pozlar.length; k++) {
        liste.push({ d: String(rl), x: pozlar[k].x, z: pozlar[k].z, s: s, f: f })
      }
    }
  }
  return liste
}
function askiyaAl(server, id, rec) {
  // rec, cagiran tarafin veri nesnesinin icinde; kayit ana dongunun sonunda yapilir
  const uuid = JUUID.fromString(id)
  const snap = claimOlcekle(server, uuid)
  if (snap.length === 0) return 0
  rec.snapshot = (rec.snapshot || []).concat(snap)
  rec.askida = true
  const m = claimYonetici(server)
  for (let i = 0; i < snap.length; i++) {
    m.unclaim(ResLoc.parse(snap[i].d), snap[i].x, snap[i].z)
  }
  return snap.length
}
function geriYukle(server, id, rec) {
  // Başkası claim ettiyse o chunk'ın üzerine yazmaz, atlar.
  const uuid = JUUID.fromString(id)
  const m = claimYonetici(server)
  let ok = 0, atlanan = 0
  const liste = rec.snapshot || []
  for (let i = 0; i < liste.length; i++) {
    const c = liste[i]
    const rl = ResLoc.parse(c.d)
    if (m.get(rl, c.x, c.z) != null) { atlanan++; continue }
    try { m.claim(rl, uuid, c.s, c.x, c.z, c.f); ok++ } catch (e) { atlanan++ }
  }
  rec.snapshot = []
  rec.askida = false
  return { ok: ok, atlanan: atlanan }
}

// ----------------------------- MESAJ ---------------------------------
function bildir(server, id, rec, mesaj) {
  const p = server.playerList.getPlayer(JUUID.fromString(id))
  if (p != null) { p.tell(mesaj); return }
  rec.bekleyen = (rec.bekleyen || []).concat([mesaj]).slice(-5)
}
function kalan(ms) {
  const dk = Math.max(0, Math.floor(ms / 60000))
  return Math.floor(dk / 60) + ' saat ' + (dk % 60) + ' dk'
}

// ----------------------------- ANA DÖNGÜ -----------------------------
function vergiIsle(server) {
  const d = yukle(server)
  const simdi = Date.now()
  const m = claimYonetici(server)
  const sahipler = {}

  const bilgiler = m.getPlayerInfoStream().toArray()
  for (let i = 0; i < bilgiler.length; i++) {
    const uuid = bilgiler[i].getPlayerId()
    if (uuid.equals(OzelSahipler.SERVER) || uuid.equals(OzelSahipler.EXPIRED)) continue
    const id = String(uuid)
    if (VERGI.MUAF_UUID.indexOf(id) >= 0) continue
    const n = bilgiler[i].getClaimCount()
    if (n > 0) sahipler[id] = n
  }

  // 1) Claim'i olan oyuncular
  Object.keys(sahipler).forEach(function (id) {
    const n = sahipler[id]
    let rec = d.kayitlar[id]
    if (!rec) {
      rec = d.kayitlar[id] = yeniKayit(simdi, n)
      bildir(server, id, rec, 'Arazi vergisi başladı: chunk başına günlük ' + VERGI.GUNLUK_UCRET_CHUNK +
        ' spur. İlk gün ücretsiz. Chunk eklersen kalan süren kısalır. Detay: /vergi durum')
      return
    }
    krediHazirla(rec, n, simdi)
    krediTuket(rec, n, simdi)
    if (rec.kredi > 0) { rec.grace = 0; return }

    const ucret = n * VERGI.GUNLUK_UCRET_CHUNK
    if (rec.auto !== false && vergiKes(server, JUUID.fromString(id), ucret, 'arazi')) {
      rec.kredi += ucret
      rec.grace = 0
      bildir(server, id, rec, 'Arazi vergisi bankandan kesildi: ' + ucret + ' spur (' + n + ' chunk).')
      return
    }
    if (!rec.grace) {
      rec.grace = simdi + VERGI.EK_SURE_SAAT * 3600 * 1000
      bildir(server, id, rec, 'Arazi vergisi ÖDENEMEDİ (' + ucret + ' spur). ' + VERGI.EK_SURE_SAAT +
        ' saat içinde ödemezsen claim\'ların kapatılacak. Bankana para yatır veya /vergi ode gun')
      return
    }
    if (simdi >= rec.grace) {
      const adet = askiyaAl(server, id, rec)
      rec.grace = 0
      rec.kredi = 0   // arazi elinden alındı, birikmiş borç silinir
      bildir(server, id, rec, 'Vergi ödenmediği için ' + adet + ' chunk claim\'in askıya alındı. ' +
        'Ödeme yapınca geri yüklenir: /vergi ode gun')
    }
  })

  // 2) Askıdaki claim'ler: otomatik ödeme açıksa, para yetince geri yükle
  Object.keys(d.kayitlar).forEach(function (id) {
    const rec = d.kayitlar[id]
    if (!rec.askida || rec.auto === false || sahipler[id]) return
    const ucret = (rec.snapshot || []).length * VERGI.GUNLUK_UCRET_CHUNK
    if (ucret > 0 && vergiKes(server, JUUID.fromString(id), ucret, 'arazi')) {
      const s = geriYukle(server, id, rec)
      rec.kredi = Math.max(rec.kredi || 0, 0) + ucret
      rec.son = simdi
      rec.grace = 0
      bildir(server, id, rec, 'Vergi ödendi, claim\'ler geri yüklendi (' + s.ok + ' chunk, atlanan: ' + s.atlanan + ').')
    }
  })

  kaydet(server, d)
}

ServerEvents.tick(function (event) {
  if (event.server.tickCount % KONTROL_ARALIGI_TICK !== 0) return
  try { vergiIsle(event.server) } catch (err) { console.error('[Vergi] hata: ' + err) }
})

// Giriş yapınca bekleyen mesajları ilet
PlayerEvents.loggedIn(function (event) {
  const server = event.server
  const d = yukle(server)
  const rec = d.kayitlar[String(event.player.uuid)]
  if (!rec || !rec.bekleyen || rec.bekleyen.length === 0) return
  rec.bekleyen.forEach(function (msg) { event.player.tell(msg) })
  rec.bekleyen = []
  kaydet(server, d)
})

// ----------------------------- ÖLÜM VERGİSİ --------------------------
EntityEvents.death('minecraft:player', function (event) {
  const p = event.entity
  if (!p || !p.isPlayer()) return
  // Oyuncuyu başka bir oyuncu öldürdüyse ölüm vergisini savas_sistemi.js ele alır
  const katil = event.source.getEntity()
  if (katil != null && katil.isPlayer() && !katil.getUUID().equals(p.getUUID())) return
  const b = bakiye(p.uuid)
  const vergi = Math.floor(b * VERGI.OLUM_VERGISI_ORAN)
  if (vergi < 1) return
  if (vergiKes(event.server, p.uuid, vergi, 'olum')) {
    p.tell('Ölüm vergisi: bankandan ' + vergi + ' spur kesildi (%' + (VERGI.OLUM_VERGISI_ORAN * 100) + ').')
  }
})

// ----------------------------- KOMUTLAR ------------------------------
function ode(server, player, gun) {
  const d = yukle(server)
  const id = String(player.uuid)
  const simdi = Date.now()
  const aktif = claimSayisi(server, player.uuid)
  const rec = d.kayitlar[id] || (d.kayitlar[id] = yeniKayit(simdi, aktif))
  const n = aktif + (rec.askida ? (rec.snapshot || []).length : 0)
  if (n === 0) { player.tell('Vergi ödenecek claim\'in yok.'); return 0 }
  krediHazirla(rec, n, simdi)
  const ucret = n * VERGI.GUNLUK_UCRET_CHUNK * gun
  if (!vergiKes(server, player.uuid, ucret, 'arazi')) {
    player.tell('Bankanda yeterli para yok. Gerekli: ' + ucret + ' spur.')
    return 0
  }
  if (rec.askida) {
    const s = geriYukle(server, id, rec)
    player.tell('Claim\'ler geri yüklendi (' + s.ok + ' chunk, atlanan: ' + s.atlanan + ').')
    rec.kredi = Math.max(rec.kredi || 0, 0)
    rec.son = simdi
  }
  rec.kredi += ucret
  rec.grace = 0
  kaydet(server, d)
  player.tell(gun + ' günlük vergi ödendi: ' + ucret + ' spur (' + n + ' chunk). Kalan süre: ' + kalanSure(rec, n) +
    '. Chunk eklersen süre kısalır.')
  return 1
}

ServerEvents.commandRegistry(function (event) {
  const Commands = event.commands

  event.register(Commands.literal('vergi')
    .then(Commands.literal('durum').executes(function (ctx) {
      const p = ctx.source.player
      const server = p.server
      const d = yukle(server)
      const rec = d.kayitlar[String(p.uuid)]
      const n = claimSayisi(server, p.uuid)
      p.tell('Claim: ' + n + ' chunk | Günlük vergi: ' + (n * VERGI.GUNLUK_UCRET_CHUNK) + ' spur')
      p.tell('Banka bakiyesi: ' + bakiye(p.uuid) + ' spur')
      if (rec) {
        const simdi = Date.now()
        krediHazirla(rec, n, simdi)
        p.tell('Ön ödeme: ' + Math.max(0, Math.floor(rec.kredi)) + ' spur | Bu chunk sayısıyla kalan süre: ' + kalanSure(rec, n) +
          ' | Otomatik ödeme: ' + (rec.auto !== false ? 'açık' : 'kapalı'))
        if (rec.grace) p.tell('Ek süre bitimine: ' + kalan(rec.grace - simdi))
        if (rec.askida) p.tell('Askıdaki chunk: ' + (rec.snapshot || []).length + ' (ödeme yapınca geri gelir)')
      }
      return 1
    }))
    .then(Commands.literal('ode')
      .then(Commands.literal('gun').executes(function (ctx) { const p = ctx.source.player; return ode(p.server, p, 1) }))
      .then(Commands.literal('hafta').executes(function (ctx) { const p = ctx.source.player; return ode(p.server, p, 7) }))
      .then(Commands.literal('ay').executes(function (ctx) { const p = ctx.source.player; return ode(p.server, p, 30) })))
    .then(Commands.literal('otomatik')
      .then(Commands.literal('ac').executes(function (ctx) {
        const p = ctx.source.player
        const d = yukle(p.server)
        const rec = d.kayitlar[String(p.uuid)] || (d.kayitlar[String(p.uuid)] = yeniKayit(Date.now(), claimSayisi(p.server, p.uuid)))
        rec.auto = true; kaydet(p.server, d)
        p.tell('Otomatik ödeme açıldı.'); return 1
      }))
      .then(Commands.literal('kapat').executes(function (ctx) {
        const p = ctx.source.player
        const d = yukle(p.server)
        const rec = d.kayitlar[String(p.uuid)] || (d.kayitlar[String(p.uuid)] = yeniKayit(Date.now(), claimSayisi(p.server, p.uuid)))
        rec.auto = false; kaydet(p.server, d)
        p.tell('Otomatik ödeme kapatıldı. Süre bitmeden /vergi ode ile kendin ödemelisin.'); return 1
      }))))

  event.register(Commands.literal('tescil').executes(function (ctx) {
    const p = ctx.source.player
    if (!vergiKes(p.server, p.uuid, VERGI.TESCIL_UCRETI, 'tescil')) {
      p.tell('Tescil için bankanda ' + VERGI.TESCIL_UCRETI + ' spur olmalı.')
      return 0
    }
    p.give(Item.of('minecraft:paper').withCustomName(Text.of('Tescil Belgesi - ' + p.username).gold()))
    p.tell('Tescil ücreti (' + VERGI.TESCIL_UCRETI + ' spur) kesildi, belgen verildi.')
    return 1
  }))

  // --------------------------- /devlet (sadece OP) ---------------------
  const Arguments = event.arguments
  const yetkili = function (src) { return src.hasPermission(2) }
  const miktarAl = function (ctx) { return Arguments.INTEGER.getResult(ctx, 'miktar') }
  const yaz = function (ctx, msg) { ctx.source.sendSystemMessage(Text.ofString(msg)) }

  // Hazineden bir hesaba para aktarır
  function hazinedenAktar(ctx, hedefUuid, miktar, tur) {
    if (miktar <= 0) { yaz(ctx, 'Miktar 0\'dan büyük olmalı.'); return 0 }
    const h = hazine()
    if (h.getBalance() < miktar) { yaz(ctx, 'Hazinede yeterli para yok. Bakiye: ' + h.getBalance() + ' spur.'); return 0 }
    const hedef = Numismatics.BANK.getOrCreateAccount(hedefUuid, BankType.PLAYER)
    if (!h.deduct(miktar, ReasonHolder.IGNORED)) { yaz(ctx, 'Aktarım yapılamadı.'); return 0 }
    h.markDirty()
    hedef.deposit(miktar)
    hedef.markDirty()
    hazineKayit(ctx.source.server, tur, miktar, ad(ctx.source.server, hedefUuid))
    return 1
  }

  event.register(Commands.literal('devlet').requires(yetkili)
    .then(Commands.literal('durum').executes(function (ctx) {
      const h = hazine()
      const d = hazineVeri(ctx.source.server)
      const simdi = Date.now()
      yaz(ctx, '=== Devlet Hazinesi: ' + h.getBalance() + ' spur ===')
      yaz(ctx, 'Toplam gelir - arazi: ' + (d.gelir.arazi || 0) + ' | ölüm: ' + (d.gelir.olum || 0) + ' | tescil: ' + (d.gelir.tescil || 0) +
        ' | cinayet: ' + (d.gelir.cinayet || 0) + ' | savaş ilanı: ' + (d.gelir.savas || 0))
      const son = d.hareket.slice(-10).reverse()
      if (son.length === 0) yaz(ctx, 'Henüz hareket yok.')
      son.forEach(function (x) {
        const yon = (x.tur === 'aktarim' || x.tur === 'cekim' || x.tur === 'kredi') ? '-' : '+'
        yaz(ctx, yon + x.m + ' spur  ' + (TUR_AD[x.tur] || x.tur) + '  ' + x.k + '  (' + kalan(simdi - x.t) + ' önce)')
      })
      return 1
    }))
    .then(Commands.literal('aktar')
      .then(Commands.argument('oyuncu', Arguments.PLAYER.create(event))
        .then(Commands.argument('miktar', Arguments.INTEGER.create(event)).executes(function (ctx) {
          const hedef = Arguments.PLAYER.getResult(ctx, 'oyuncu')
          const miktar = miktarAl(ctx)
          if (!hazinedenAktar(ctx, hedef.getUUID(), miktar, 'aktarim')) return 0
          yaz(ctx, hedef.getName().getString() + ' oyuncusunun bankasına ' + miktar + ' spur aktarıldı. Hazine: ' + hazine().getBalance())
          hedef.tell('Devlet hazinesinden bankana ' + miktar + ' spur yatırıldı.')
          return 1
        }))))
    .then(Commands.literal('cek')
      .then(Commands.argument('miktar', Arguments.INTEGER.create(event)).executes(function (ctx) {
        const p = ctx.source.player
        if (p == null) { yaz(ctx, 'Bu komutu oyun içinden kullanın.'); return 0 }
        const miktar = miktarAl(ctx)
        if (!hazinedenAktar(ctx, p.uuid, miktar, 'cekim')) return 0
        yaz(ctx, 'Hazineden kendi bankana ' + miktar + ' spur çekildi. Hazine: ' + hazine().getBalance())
        return 1
      })))
    .then(Commands.literal('yatir')
      .then(Commands.argument('miktar', Arguments.INTEGER.create(event)).executes(function (ctx) {
        const p = ctx.source.player
        if (p == null) { yaz(ctx, 'Bu komutu oyun içinden kullanın.'); return 0 }
        const miktar = miktarAl(ctx)
        if (miktar <= 0) { yaz(ctx, 'Miktar 0\'dan büyük olmalı.'); return 0 }
        if (!kes(p.uuid, miktar)) { yaz(ctx, 'Bankanda yeterli para yok.'); return 0 }
        const h = hazine(); h.deposit(miktar); h.markDirty()
        hazineKayit(ctx.source.server, 'yatirma', miktar, p.username)
        yaz(ctx, 'Hazineye ' + miktar + ' spur yatırıldı. Hazine: ' + h.getBalance())
        return 1
      })))
    .then(Commands.literal('ac').executes(function (ctx) {
      const p = ctx.source.player
      if (p == null) { yaz(ctx, 'Bu komutu oyun içinden kullanın.'); return 0 }
      const h = hazine()
      NumUtils.openScreen(p, h, function (buf) { h.sendToMenu(buf) })
      return 1
    }))
    .then(Commands.literal('kart').executes(function (ctx) {
      const p = ctx.source.player
      if (p == null) { yaz(ctx, 'Bu komutu oyun içinden kullanın.'); return 0 }
      const h = hazine()
      const u = p.getUUID()
      h.updateTrustList(function (liste) { if (!liste.contains(u)) liste.add(u) })
      const kart = CardItem.set(Item.of('numismatics:yellow_card'), HAZINE_UUID)
      p.give(kart.withCustomName(Text.ofString('Devlet Hazinesi Kartı').gold()))
      yaz(ctx, 'Hazine kartı verildi. Bank Terminal\'e kartla sağ tıklayınca hazine açılır. Kartı shift+sağ tıklama ile kullanma, bağlantısı silinir.')
      return 1
    }))
    .then(Commands.literal('yetki')
      .then(Commands.literal('ekle').then(Commands.argument('oyuncu', Arguments.PLAYER.create(event)).executes(function (ctx) {
        const hedef = Arguments.PLAYER.getResult(ctx, 'oyuncu')
        const u = hedef.getUUID()
        hazine().updateTrustList(function (liste) { if (!liste.contains(u)) liste.add(u) })
        yaz(ctx, hedef.getName().getString() + ' artık hazine kartını Bank Terminal\'de kullanabilir.')
        return 1
      })))
      .then(Commands.literal('kaldir').then(Commands.argument('oyuncu', Arguments.PLAYER.create(event)).executes(function (ctx) {
        const hedef = Arguments.PLAYER.getResult(ctx, 'oyuncu')
        const u = hedef.getUUID()
        hazine().updateTrustList(function (liste) { liste.remove(u) })
        yaz(ctx, hedef.getName().getString() + ' hazine yetkisi kaldırıldı.')
        return 1
      })))))
})

console.info('[Vergi] yuklendi: gunluk ' + VERGI.GUNLUK_UCRET_CHUNK + ' spur/chunk, olum vergisi %' + (VERGI.OLUM_VERGISI_ORAN * 100))
