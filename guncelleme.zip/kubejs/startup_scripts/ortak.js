// Sunucu betikleri arasında paylaşılan fonksiyonlar. KubeJS'te server/client betikleri global'e ATAMA YAPAMAZ
// ('global' cannot be assigned to): kutu burada (startup) bir kez kurulur, diğerleri sadece put/get yapar.
//   koyan:  global.ortak.put('vergiOrani', function (server, ad) { ... })
//   okuyan: var f = global.ortak.get('vergiOrani'); if (f) f(server, 'kdv')
try { if (typeof global !== 'undefined' && !global.ortak) global.ortak = new (Java.loadClass('java.util.concurrent.ConcurrentHashMap'))() } catch (e) { console.error('[Ortak] kurulamadi: ' + e) }
