// =====================================================================
//  ARAYÜZ  -  kubejs/startup_scripts/arayuz.js
//  LDLib2 (ldlib2-neoforge-1.21.1-2.2.46) arayüz sistemi üzerine, Meal Mastery tarzı:
//  koyu panel, üst başlık çubuğu, solda bölüm menüsü, sağda kartlar
//  (başlık + açıklama + sağda değer + altta ilerleme çubuğu).
//
//  - Dosya startup_scripts'te: LDLib2 aynı ekranı sunucuda (veri) ve oyuncuda
//    (görüntü) kurar. OYUNCULARDA DA AYNI DOSYA OLMALI (guncelle.bat ile gelir).
//  - Açmak: /menu  veya  /menu <bölüm>   (server_scripts/arayuz_komut.js)
//  - Değişiklikten sonra sunucu ve oyunlar YENİDEN BAŞLATILMALI.
//
//  KubeJS/Rhino kuralları (canlı sunucuda öğrenildi):
//  - Fonksiyon içinde const/let yok, hep var.
//  - Aşırı yüklenmiş Java metotları (UI.of, width...) imzasıyla açıkça seçilir: l['width(float)'](420)
//  - Yön/hizalama: l.set(LP.FLEX_DIRECTION, TFD.ROW) (flexDirection vb. @HideFromJS, çağrılamıyor)
//  - Kök tam ekran ve şeffaf: JEI menüde gizlenir (bkz. ekranKur).
//  - Ekran kurulamazsa hataEkrani() açılır; oyun çökmez.
//  - Tıklamalar oyuncu tarafında çalışır ve komut gönderir (sunucu tıklaması çalışmıyor);
//    hata oyunu çökertmesin diye guvenli() ile sarılır. Player.closeContainer -> closeMenu.
//  - Sunucudan gelen veri sadece Component olarak bağlanır (sayı bağlamada Double/Float sorunu).
//
//  YENİ BÖLÜM: BOLUMLER listesine ekle + bolum('kimlik', [...öğeler]).
//  Öğeler:
//    { t: 'kart',  baslik: 'Başlık', alt: 'Açıklama', deger: f(p) -> yazı, oran: f(p) -> 0..1 (isteğe bağlı) }
//    { t: 'yazi',  metin: 'Sabit yazı' }
//    { t: 'giris', ad: 'miktar', ipucu: 'Miktar', min: 1, max: 1000000 }   (min yoksa serbest yazı)
//    { t: 'dugme', yazi: 'Kredi çek', komut: 'kredi cek {miktar}' }       (oyuncunun yetkisiyle)
//    { t: 'dugmeler', liste: [ {yazi, komut}, ... ] }                    (yan yana düğmeler)
//      komutta {ad?} = isteğe bağlı kutu (boşsa atlanır); acik: true = menü kapanmaz
//  f(p) fonksiyonları SADECE sunucuda çalışır ve her tick güncellenir.
//  Bölüm içeriği oyuncuya göre değişmemeli; yetkiye göre farklılık f(p) içinde yapılır.
//
//  !! Gerçek bir oyunda ÇALIŞTIRILARAK TEST EDİLMEDİ.
// =====================================================================

;(function () {
  var ModularUI = Java.loadClass('com.lowdragmc.lowdraglib2.gui.ui.ModularUI')
  var UI = Java.loadClass('com.lowdragmc.lowdraglib2.gui.ui.UI')
  var UIElement = Java.loadClass('com.lowdragmc.lowdraglib2.gui.ui.UIElement')
  var Label = Java.loadClass('com.lowdragmc.lowdraglib2.gui.ui.elements.Label')
  var TextField = Java.loadClass('com.lowdragmc.lowdraglib2.gui.ui.elements.TextField')
  var DataBindingBuilder = Java.loadClass('com.lowdragmc.lowdraglib2.gui.sync.bindings.impl.DataBindingBuilder')
  var ColorRectTexture = Java.loadClass('com.lowdragmc.lowdraglib2.gui.texture.ColorRectTexture')
  // LDLib2, LayoutStyle'ın Taffy türlü flexDirection/justifyContent sürümlerini @HideFromJS ile
  // gizliyor; JavaScript'ten sadece Yoga türlü sürümler görünür. Bu yüzden Yoga sabitleri kullanılır.
  // Açık imzayla seçim, gizli sürümü olan metotlarda da çalışmadı. Çözüm: LDLib2'nin içeride
  // kullandığı Style.set(Property, değer) (tek iki parametreli sürüm, gizli değil).
  var LP = Java.loadClass('com.lowdragmc.lowdraglib2.gui.ui.layout.LayoutProperties')
  var TFD = Java.loadClass('dev.vfyjxf.taffy.style.FlexDirection')
  var TAI = Java.loadClass('dev.vfyjxf.taffy.style.AlignItems')
  var TAC = Java.loadClass('dev.vfyjxf.taffy.style.AlignContent')
  var Component = Java.loadClass('net.minecraft.network.chat.Component')
  var JUUID = Java.loadClass('java.util.UUID')
  var ArrayList = Java.loadClass('java.util.ArrayList')
  var StylesheetManager = null
  function tema() { if (StylesheetManager == null) StylesheetManager = Java.loadClass('com.lowdragmc.lowdraglib2.gui.ui.style.StylesheetManager'); return StylesheetManager }

  // ----------------------------- RENKLER (Meal Mastery) -------------------
  function renk(rgb, alfa) { return (((alfa == null ? 0xFF : alfa) << 24) | rgb) | 0 }
  var R = {
    cerceve: renk(0x6B5530),   // ince altın çerçeve
    panel: renk(0x16130F, 0xEE),
    ust: renk(0x221B13, 0xF5),
    yan: renk(0x1B1712, 0xF5),
    secili: renk(0xC57B2A),
    cizgi: renk(0x3A3227),
    dugme: renk(0x2E261C),
    baslik: renk(0xE9A23B),    // turuncu-altın başlık
    acik: renk(0xE6DCC8),      // kart başlığı
    gri: renk(0x8F8676),       // açıklama
    koyu: renk(0x1A1208),      // seçili menü yazısı
    dolu: 0xE39B2E, bos: 0x4A3F31  // çubuk renkleri (RGB)
  }

  // ----------------------------- YARDIMCILAR ------------------------------
  function E() { return new UIElement() }
  function zemin(el, argb) { el.style(function (s) { s.background(new ColorRectTexture(argb)) }); return el }
  // Her düzen ayarı ayrı korunur: tutmazsa sadece o ayar atlanır, ekran yine açılır.
  var uyarilan = {}
  function duzen(el, ad, fn) {
    try { el.layout(function (l) { fn(l) }) } catch (err) {
      if (!uyarilan[ad]) { uyarilan[ad] = true; console.warn('[Arayuz] duzen ayari atlandi (' + ad + '): ' + err) }
    }
    return el
  }
  function yatay(el) { return duzen(el, 'yatay', function (l) { l.set(LP.FLEX_DIRECTION, TFD.ROW) }) }
  function ortala(el) { return duzen(el, 'ortala', function (l) { l.set(LP.ALIGN_ITEMS, TAI.CENTER) }) }
  function iki_uca(el) { return duzen(el, 'iki_uca', function (l) { l.set(LP.JUSTIFY_CONTENT, TAC.SPACE_BETWEEN) }) }
  function buyu(el) { return duzen(el, 'buyu', function (l) { try { l['flexGrow(float)'](1) } catch (eg) { l.flexGrow(1) } }) }
  // Sayı alan ayarlar (genişlik, boşluk...) önceki sürümde çalıştı; yine de korumalı.
  function olcu(el, fn) { return duzen(el, 'olcu', fn) }
  function yazi(metin, r) {
    var lb = new Label()
    lb.setText(Component.literal(metin))
    lb.textStyle(function (s) { s.textColor(r).textShadow(false) })
    return lb
  }
  // f() düz metin döner; hazirBilesen=true ise f() zaten bir Component döner (ör. renkli çubuk)
  function bagliYazi(r, sunucuda, f, hazirBilesen) {
    var lb = new Label()
    lb.textStyle(function (s) { s.textColor(r).textShadow(false) })
    lb.bind(DataBindingBuilder.componentS2C(function () {
      if (!sunucuda) return Component.literal('')
      try { return hazirBilesen ? f() : Component.literal(String(f())) } catch (err) { return Component.literal('?') }
    }).build())
    return lb
  }
  // Sunucudan gelen yazı, ekran kurulurken boş olduğu için LDLib ona 0 genişlik veriyor ve
  // yazı gelince sağa taşıyordu. Çözüm: sabit genişlik + sağa hizalı yazı.
  var Horizontal = Java.loadClass('com.lowdragmc.lowdraglib2.gui.ui.data.Horizontal')
  function hizala(lb, yon) {
    try { lb.textStyle(function (s) { s['textAlignHorizontal(com.lowdragmc.lowdraglib2.gui.ui.data.Horizontal)'](yon) }) } catch (err) {
      if (!uyarilan.hiza) { uyarilan.hiza = true; console.warn('[Arayuz] yazi hizalama atlandi: ' + err) }
    }
    return lb
  }
  function sagaYasla(lb, en) {
    olcu(lb, function (l) { l['width(float)'](en) })
    duzen(lb, 'kuculme', function (l) { l['flexShrink(float)'](0) })
    return hizala(lb, Horizontal.RIGHT)
  }
  // Metin çubuğu: turuncu dolu + koyu boş kareler (ProgressBar sayı bağlaması Double/Float yüzünden kullanılmıyor)
  // Panel genişliği: yan menü 78, içerik = PANEL_EN - 88. Çubuk karakteri ~9 px, 22 adet ~200 px.
  var PANEL_EN = 420
  var CUBUK_UZ = 22
  function cubuk(oran) {
    var o = Math.max(0, Math.min(1, Number(oran) || 0))
    var n = Math.round(o * CUBUK_UZ)
    var dolu = Component.literal(new Array(n + 1).join('▬')).withColor(R.dolu)
    var bos = Component.literal(new Array(CUBUK_UZ - n + 1).join('▬')).withColor(R.bos)
    return dolu['append(net.minecraft.network.chat.Component)'](bos)
  }

  // ----------------------------- SUNUCU VERİLERİ --------------------------
  var HAZINE = '5f0c2d1e-7a3b-4e9c-8d6f-1b2a3c4d5e6f'
  var Numismatics = null, OPAC = null
  function banka(uuid) {
    if (Numismatics == null) Numismatics = Java.loadClass('dev.ithundxr.createnumismatics.Numismatics')
    var h = Numismatics.BANK.getAccount(uuid)
    return h ? h.getBalance() : 0
  }
  function claimSayisi(p) {
    if (OPAC == null) OPAC = Java.loadClass('xaero.pac.common.server.api.OpenPACServerAPI')
    var m = OPAC.get(p.server).getServerClaimsManager()
    return m.hasPlayerInfo(p.getUuid()) ? m.getPlayerInfo(p.getUuid()).getClaimCount() : 0
  }
  function veriOku(p, anahtar) {
    var s = p.server.persistentData.getString(anahtar)
    if (!s) return {}
    try { return JSON.parse(s) } catch (e) { return {} }
  }
  function borcKaydi(p) { var d = veriOku(p, 'borc_veri'); return (d.o || {})[String(p.getUuid())] || null }
  function vergiKaydi(p) { return (veriOku(p, 'vergi_veri').kayitlar || {})[String(p.getUuid())] || null }
  function para(n) { return String(Math.floor(n)).replace(/\B(?=(\d{3})+(?!\d))/g, '.') + ' spur' }
  function sure(ms) { var dk = Math.max(0, Math.floor(ms / 60000)); var g = Math.floor(dk / 1440); return (g > 0 ? g + ' g ' : '') + Math.floor((dk % 1440) / 60) + ' sa ' + (dk % 60) + ' dk' }
  function yetkili(p) { return p.createCommandSourceStack().hasPermission(2) }
  function baskanMi(p) { var b = p.server.persistentData.getString('baskan'); return !!b && b === String(p.getUuid()) }
  function oyuncuAdi(p, uuid) {
    var o = p.server.playerList.getPlayer(uuid)
    if (o != null) return String(o.username)
    var prof = p.server.getProfileCache().get(uuid)
    return prof.isPresent() ? String(prof.get().getName()) : String(uuid).substring(0, 8)
  }
  // Arazi: günlük ücret ve kategori dağılımı vergi_sistemi.js tarafından her dakika kayda yazılır
  var YERLESKE = 35
  var KAT_AD = { yerleske: 'Yerleşke', dukkan: 'Dükkan', fabrika: 'Fabrika', arac: 'Araç' }
  // Claim kalmadıysa (askıda değilse) kayıttaki eski değer gösterilmez
  function claimYok(p, r) { return claimSayisi(p) === 0 && !(r && (r.askida || (r.dg && r.dg.a > 0))) }
  function araziGunluk(p) { var r = vergiKaydi(p); if (claimYok(p, r)) return 0; return r && r.g != null ? r.g : claimSayisi(p) * YERLESKE }
  function araziDagilim(p) {
    var r = vergiKaydi(p)
    if (claimYok(p, r)) return 'Claim yok'
    if (!r || !r.dg) return 'Yerleşke ' + claimSayisi(p)
    return 'Y ' + r.dg.y + ' · D ' + r.dg.d + ' · F ' + r.dg.f + ' · A ' + (r.dg.a || 0)
  }
  // Oyuncunun durduğu chunk: sahip + kategori (teftiş)
  function teftis(p) {
    if (OPAC == null) OPAC = Java.loadClass('xaero.pac.common.server.api.OpenPACServerAPI')
    var boyut = String(p.level.getDimension())
    var x = Math.floor(p.getX() / 16), z = Math.floor(p.getZ() / 16)
    var c = OPAC.get(p.server).getServerClaimsManager().get(p.level.getDimension(), x, z)
    var sahip = c == null ? null : c.getPlayerId()
    var kat = veriOku(p, 'arazi_kategori')[boyut + '|' + x + '|' + z]
    if (!kat || sahip == null || kat.o !== String(sahip)) kat = { k: 'yerleske', f: YERLESKE }
    return { x: x, z: z, sahip: sahip, kat: kat }
  }

  // ----------------------------- KAYIT SAYFALARI -------------------------
  // Satışlar (satis_kayit.js) ve hazine hareketleri, en yeni üstte, sayfa başına 10 satır.
  // Sayfa no oyuncunun persistentData'sında (menu_sayfa_<ad>); /menu sayfa <ad> <+1|-1|0>.
  var SAYFA = 10
  var onbellek = {}
  var HAREKET_AD = { arazi: 'Arazi vergisi', olum: 'Ölüm vergisi', tescil: 'Tescil', cinayet: 'Cinayet cezası',
    savas: 'Savaş ilanı', borc: 'Borç tahsilatı', kredi: 'Kredi verildi', kredi_odeme: 'Kredi ödemesi',
    aktarim: 'Aktarım', cekim: 'Çekim', yatirma: 'Yatırma' }
  function iki(n) { return (n < 10 ? '0' : '') + n }
  function zaman(t) { var d = new Date(t); return iki(d.getDate()) + '.' + iki(d.getMonth() + 1) + ' ' + iki(d.getHours()) + ':' + iki(d.getMinutes()) }
  function kisalt(s, n) { s = String(s); return s.length > n ? s.substring(0, n - 1) + '…' : s }
  function kayitYetkisi(p, ad) { return ad !== 'hazine' || yetkili(p) || baskanMi(p) }
  function sayfaVerisi(p, ad) {
    var k = ad + '|' + String(p.getUuid())
    var tick = p.server.tickCount
    var c = onbellek[k]
    if (c && c.tick === tick) return c
    var liste = []
    if (kayitYetkisi(p, ad)) {
      if (ad === 'satis') { var s = veriOku(p, 'satis_kayit'); liste = Array.isArray(s) ? s : [] }
      else liste = veriOku(p, 'hazine_veri').hareket || []
    }
    liste = liste.slice().reverse()
    var top = Math.max(1, Math.ceil(liste.length / SAYFA))
    var no = Math.min(Math.max(0, p.persistentData.getInt('menu_sayfa_' + ad)), top - 1)
    c = { tick: tick, satirlar: liste.slice(no * SAYFA, no * SAYFA + SAYFA), no: no, top: top, toplam: liste.length }
    onbellek[k] = c
    return c
  }
  function satisSatiri(e) {
    return kisalt(zaman(e.t) + '  ' + e.a + (e.y === 'al' ? ' aldı ' : ' sattı ') + e.n + 'x ' + e.i + ' · ' + e.m + ' · ' + e.s, 64)
  }
  function hazineSatiri(e) {
    var gider = e.tur === 'aktarim' || e.tur === 'cekim' || e.tur === 'kredi'
    return kisalt(zaman(e.t) + '  ' + (gider ? '-' : '+') + para(e.m) + '  ' + (HAREKET_AD[e.tur] || e.tur) + '  ' + e.k, 64)
  }
  function kayitBolumu(ad, baslik, alt, bicim) {
    var ogeler = [
      { t: 'kart', baslik: baslik, alt: alt,
        deger: function (p) {
          if (!kayitYetkisi(p, ad)) return 'Yetkili değil'
          var c = sayfaVerisi(p, ad); return 'Sayfa ' + (c.no + 1) + '/' + c.top + ' · ' + c.toplam + ' kayıt'
        } }
    ]
    for (var i = 0; i < SAYFA; i++) {
      ogeler.push({ t: 'satir', sira: i, f: function (p, sira) {
        var e = sayfaVerisi(p, ad).satirlar[sira]
        return e ? bicim(e) : (sira === 0 ? 'Henüz kayıt yok.' : '')
      } })
    }
    ogeler.push({ t: 'dugmeler', liste: [
      { yazi: '◀ Yeniler', komut: 'menu sayfa ' + ad + ' -1', acik: true },
      { yazi: 'En yeni', komut: 'menu sayfa ' + ad + ' 0', acik: true },
      { yazi: 'Eskiler ▶', komut: 'menu sayfa ' + ad + ' 1', acik: true }
    ] })
    return ogeler
  }

  // ----------------------------- BÖLÜMLER ---------------------------------
  var BOLUMLER = [
    { id: 'ana', ad: 'Genel' },
    { id: 'kredi', ad: 'Kredi & Borç' },
    { id: 'vergi', ad: 'Arazi Vergisi' },
    { id: 'savas', ad: 'Savaş' },
    { id: 'teftis', ad: 'Teftiş' },
    { id: 'satislar', ad: 'Satışlar' },
    { id: 'hazine', ad: 'Hazine' },
    { id: 'devlet', ad: 'Devlet' }
  ]
  var ICERIK = {}
  function bolum(id, ogeler) { ICERIK[id] = ogeler }

  bolum('ana', [
    { t: 'kart', baslik: 'Banka', alt: 'Numismatics hesabındaki para', deger: function (p) { return para(banka(p.getUuid())) } },
    { t: 'kart', baslik: 'Kredi Notu', alt: 'Limitini ve faizini belirler',
      deger: function (p) { var r = borcKaydi(p); return (r ? r.not : 500) + ' / 1000' },
      oran: function (p) { var r = borcKaydi(p); return (r ? r.not : 500) / 1000 } },
    { t: 'kart', baslik: 'Borç', alt: 'Ödenmeyen cezalar, günlük %2 faiz',
      deger: function (p) { var r = borcKaydi(p); return r && r.borc > 0 ? para(Math.ceil(r.borc)) : 'Yok' } },
    { t: 'kart', baslik: 'Arazi', alt: 'Claim edilen chunk ve günlük vergi',
      deger: function (p) { return claimSayisi(p) + ' chunk · ' + para(araziGunluk(p)).replace(' spur', '') + '/gün' } },
    { t: 'kart', baslik: 'Savaşlar', alt: 'Aktif ve hazırlıktaki savaşlar',
      deger: function (p) { return String((veriOku(p, 'savas_veri').savaslar || []).length) } }
  ])

  bolum('kredi', [
    { t: 'kart', baslik: 'Kredi Notu', alt: '300 altı: kredi yok · 900+: 50.000 spur, %3',
      deger: function (p) { var r = borcKaydi(p); return (r ? r.not : 500) + ' / 1000' },
      oran: function (p) { var r = borcKaydi(p); return (r ? r.not : 500) / 1000 } },
    { t: 'kart', baslik: 'Aktif Kredi', alt: '7 günlük taksit, bankadan otomatik',
      deger: function (p) { var r = borcKaydi(p); return r && r.kredi ? 'Kalan ' + para(r.kredi.kalan) : 'Yok' },
      oran: function (p) { var r = borcKaydi(p); if (!r || !r.kredi) return 0; var top = r.kredi.taksit * 7; return 1 - r.kredi.kalan / top } },
    { t: 'kart', baslik: 'Borç', alt: 'Borç varken kredi çekilemez',
      deger: function (p) { var r = borcKaydi(p); return r && r.borc > 0 ? para(Math.ceil(r.borc)) : 'Yok' } },
    { t: 'giris', ad: 'miktar', ipucu: 'Miktar (spur)', min: 1, max: 1000000 },
    { t: 'dugmeler', liste: [
      { yazi: 'Kredi çek', komut: 'kredi cek {miktar}' },
      { yazi: 'Krediyi kapat', komut: 'kredi ode' },
      { yazi: 'Ayrıntı', komut: 'kredi durum' }
    ] }
  ])

  bolum('vergi', [
    { t: 'kart', baslik: 'Arazi', alt: 'Yerleşke 35 · dükkan/fabrika: başkan',
      deger: function (p) { return claimSayisi(p) + ' chunk · ' + para(araziGunluk(p)).replace(' spur', '') + '/gün' } },
    { t: 'kart', baslik: 'Kategoriler', alt: 'Yerleşke · Dükkan · Fabrika · Araç claim',
      deger: function (p) { return araziDagilim(p) } },
    { t: 'kart', baslik: 'Ön Ödeme', alt: 'Kalan süre (çubuk = 1 hafta)',
      deger: function (p) {
        var r = vergiKaydi(p); var g = araziGunluk(p)
        if (!r) return 'Kayıt yok'
        if (r.askida) return 'ASKIDA'
        if (g <= 0) return para(Math.max(0, r.kredi || 0))
        return sure(Math.max(0, r.kredi || 0) / g * 86400000)
      },
      oran: function (p) { var r = vergiKaydi(p); var g = araziGunluk(p); if (!r || g <= 0) return 0; return (Math.max(0, r.kredi || 0) / g) / 7 } },
    { t: 'kart', baslik: 'Otomatik Ödeme', alt: 'Süre bitince bankadan 1 gün kesilir',
      deger: function (p) { var r = vergiKaydi(p); return r && r.auto === false ? 'Kapalı' : 'Açık' } },
    { t: 'dugmeler', liste: [
      { yazi: '1 gün', komut: 'vergi ode gun' },
      { yazi: '1 hafta', komut: 'vergi ode hafta' },
      { yazi: '1 ay', komut: 'vergi ode ay' }
    ] },
    { t: 'dugmeler', liste: [
      { yazi: 'Otomatik aç', komut: 'vergi otomatik ac' },
      { yazi: 'Otomatik kapat', komut: 'vergi otomatik kapat' }
    ] }
  ])

  function savasKarti(i) {
    return { t: 'kart',
      baslik: '',
      basF: function (p) { var s = (veriOku(p, 'savas_veri').savaslar || [])[i]; return s ? s.a.ad + '  vs  ' + s.b.ad : (i === 0 ? 'Savaş yok' : '') },
      altF: function (p) { var s = (veriOku(p, 'savas_veri').savaslar || [])[i]; if (!s) return ''; return s.durum === 'hazirlik' ? 'Hazırlık: ' + sure(s.baslangic - Date.now()) : 'Aktif · kalan ' + sure(s.son - Date.now()) },
      deger: function (p) { var s = (veriOku(p, 'savas_veri').savaslar || [])[i]; return s ? s.skor.a + ' - ' + s.skor.b : '' },
      oran: function (p) { var s = (veriOku(p, 'savas_veri').savaslar || [])[i]; return s ? Math.max(s.skor.a, s.skor.b) / 10 : null } }
  }
  bolum('savas', [
    savasKarti(0), savasKarti(1),
    { t: 'giris', ad: 'oyuncu', ipucu: 'Karşı oyuncu adı' },
    { t: 'dugmeler', liste: [
      { yazi: 'Savaş ilan et', komut: 'savas ilan {oyuncu}' },
      { yazi: 'Barış', komut: 'savas baris {oyuncu}' },
      { yazi: 'Teslim ol', komut: 'savas teslim {oyuncu}' }
    ] }
  ])

  // Teftiş: başkan arazinin üstünde durur, kategoriyi ve (isteğe bağlı) fiyatı seçer.
  // {fiyat?} boş bırakılırsa varsayılan fiyat kullanılır (dükkan 100, fabrika 150).
  bolum('teftis', [
    { t: 'kart', baslik: '', basF: function (p) { var t = teftis(p); return 'Chunk ' + t.x + ', ' + t.z },
      alt: 'Durduğun chunk ve sahibi',
      deger: function (p) { var t = teftis(p); return t.sahip == null ? 'Sahipsiz' : oyuncuAdi(p, t.sahip) } },
    { t: 'kart', baslik: 'Kategori', alt: 'Harita: dükkan mavi, fabrika turuncu',
      deger: function (p) { var t = teftis(p); return t.sahip == null ? '-' : KAT_AD[t.kat.k] + ' · ' + t.kat.f + '/gün' } },
    { t: 'kart', baslik: 'Yetki', alt: 'Kategoriyi başkan belirler',
      deger: function (p) { return baskanMi(p) ? 'Başkansın' : (yetkili(p) ? 'OP' : 'Yetkin yok') } },
    { t: 'giris', ad: 'fiyat', ipucu: 'Günlük fiyat (boş: dükkan 100, fabrika 150)', min: 1, max: 100000, istege: true },
    { t: 'dugmeler', liste: [
      { yazi: 'Yerleşke', komut: 'arazi kategori yerleske', acik: true },
      { yazi: 'Dükkan', komut: 'arazi kategori dukkan {fiyat?}', acik: true },
      { yazi: 'Fabrika', komut: 'arazi kategori fabrika {fiyat?}', acik: true }
    ] },
    // Araçlar chunk değil: Aeronautics Claims'teki her aero claim (250 blok) başına tek fiyat
    { t: 'kart', baslik: 'Araç Vergisi', alt: 'Aero claim (250 blok) başına, tüm araçlar',
      deger: function (p) { var f = p.server.persistentData.getInt('arac_fiyat'); return (f > 0 ? f : 35) + '/gün' } },
    { t: 'giris', ad: 'aracfiyat', ipucu: 'Araç vergisi (aero claim başına günlük)', min: 1, max: 100000 },
    { t: 'dugme', yazi: 'Araç vergisini kaydet', komut: 'arazi aracfiyat {aracfiyat}', acik: true }
  ])

  bolum('satislar', kayitBolumu('satis', 'Vendor Satışları', 'Tüm Vendor alım-satımları (son 500)', satisSatiri))
  bolum('hazine', kayitBolumu('hazine', 'Hazine Hareketleri', 'Devlete giren/çıkan para (son 500)', hazineSatiri))

  bolum('devlet', [
    { t: 'kart', baslik: 'Devlet Hazinesi', alt: 'Vergiler, cezalar ve savaş ilanları',
      deger: function (p) { return yetkili(p) ? para(banka(JUUID.fromString(HAZINE))) : 'Yetkili değil' } },
    { t: 'kart', baslik: 'Toplam Gelir', alt: 'Arazi + ölüm + tescil + cinayet + savaş',
      deger: function (p) { if (!yetkili(p)) return '-'; var g = veriOku(p, 'hazine_veri').gelir || {}; return para((g.arazi || 0) + (g.olum || 0) + (g.tescil || 0) + (g.cinayet || 0) + (g.savas || 0)) } },
    { t: 'giris', ad: 'oyuncu', ipucu: 'Oyuncu adı' },
    { t: 'giris', ad: 'miktar', ipucu: 'Miktar (spur)', min: 1, max: 100000000 },
    { t: 'dugmeler', liste: [
      { yazi: 'Aktar', komut: 'devlet aktar {oyuncu} {miktar}' },
      { yazi: 'Bankama çek', komut: 'devlet cek {miktar}' },
      { yazi: 'Hareketler', komut: 'menu hazine' }
    ] }
  ])

  // ----------------------------- TIKLAMA (oyuncu tarafı) -----------------
  function istemci() { return Java.loadClass('net.minecraft.client.Minecraft').getInstance() }
  function durumMesaji(m) { var mc = istemci(); if (mc.player != null) mc.player.displayClientMessage(Component.literal(m), true) }
  function istemciKomut(komut, kapat) {
    var mc = istemci()
    if (mc.player == null) return
    if (kapat) { try { mc.player.closeMenu() } catch (e1) { mc.setScreen(null) } }
    mc.player.connection.sendCommand(komut)
  }
  function guvenli(fn) {
    return function (ev) {
      try { fn(ev) } catch (err) {
        console.error('[Arayuz] tiklama hatasi: ' + err)
        try { durumMesaji('Arayüz hatası: ' + err) } catch (e2) { }
      }
    }
  }
  function tiklaninca(el, fn) { el.addEventListener('mouseDown', guvenli(fn)); return el }
  function komutHazirla(sablon, durum, ogeler) {
    var hata = null
    var komut = sablon.replace(/\{(\w+)(\??)\}/g, function (m, ad, istege) {
      var v = String(durum[ad] == null ? '' : durum[ad]).trim()
      var tanim = ogeler.filter(function (o) { return o.t === 'giris' && o.ad === ad })[0]
      if (v === '' && istege) return ''
      if (v === '') { hata = (tanim && tanim.ipucu ? tanim.ipucu : 'Kutu') + ' boş.'; return '' }
      if (tanim && tanim.min != null && !/^\d+$/.test(v)) { hata = 'Kutuya sadece sayı yaz.'; return '' }
      if (!/^[A-Za-z0-9_]+$/.test(v)) { hata = 'Geçersiz karakter.'; return '' }
      return v
    })
    return hata ? { hata: hata } : { komut: komut.replace(/\s+/g, ' ').trim() }
  }

  // ----------------------------- PARÇALAR ---------------------------------
  function dugmeYap(metin, onTik) {
    var d = zemin(E(), R.dugme)
    olcu(d, function (l) { try { l['flexGrow(float)'](1) } catch (eg) { l.flexGrow(1) } }); olcu(d, function (l) { l['paddingAll(float)'](3) })
    olcu(d, function (l) { l['flexBasis(float)'](0) })   // düğmeler eşit genişlikte
    d.addChild(hizala(yazi(metin, R.baslik), Horizontal.LEFT))
    return tiklaninca(d, onTik)
  }
  function kartYap(o, sunucuda, p) {
    var kart = E()
    olcu(kart, function (l) { l['paddingAll(float)'](3) }); olcu(kart, function (l) { l['gapAll(float)'](1) })
    var ust = iki_uca(yatay(E()))
    olcu(ust, function (l) { l['gapAll(float)'](6) })
    var sol = E()
    duzen(sol, 'kucul', function (l) { l['flexShrink(float)'](1) })
    if (o.basF) sol.addChild(bagliYazi(R.acik, sunucuda, function () { var b = o.basF(p); return b ? '• ' + b : '' }))
    else sol.addChild(yazi('• ' + o.baslik, R.acik))
    if (o.altF) sol.addChild(bagliYazi(R.gri, sunucuda, function () { return o.altF(p) }))
    else sol.addChild(yazi(o.alt || '', R.gri))
    ust.addChild(sol)
    ust.addChild(sagaYasla(bagliYazi(R.baslik, sunucuda, function () { return o.deger(p) }), 130))
    kart.addChild(ust)
    // oran() null dönerse çubuk gizlenir (ör. boş savaş kartı)
    if (o.oran) kart.addChild(bagliYazi(R.acik, sunucuda, function () { var r = o.oran(p); return r == null ? Component.literal('') : cubuk(r) }, true))
    var cizgi = zemin(E(), R.cizgi)
    olcu(cizgi, function (l) { l['height(float)'](1) })
    kart.addChild(cizgi)
    return kart
  }

  // ----------------------------- EKRAN ------------------------------------
  function modularUI(kok, p) {
    var temalar = new ArrayList()
    var t = tema().INSTANCE.getStylesheet(tema().MC)
    if (t != null) temalar.add(t)
    var arayuz = UI['of(com.lowdragmc.lowdraglib2.gui.ui.UIElement,java.util.List,com.lowdragmc.lowdraglib2.gui.ui.UI$DynamicSizeProvider)'](kok, temalar, null)
    return ModularUI['of(com.lowdragmc.lowdraglib2.gui.ui.UI,net.minecraft.world.entity.player.Player)'](arayuz, p)
  }
  // Ekran kurulamazsa oyun ÇÖKMESİN: boş menü yerine basit bir hata ekranı açılır.
  function hataEkrani(p, err) {
    var kok = E()
    olcu(kok, function (l) { l['width(float)'](220) }); olcu(kok, function (l) { l['paddingAll(float)'](8) })
    kok.addChild(new Label().setText(Component.literal('Arayüz açılamadı.')))
    kok.addChild(new Label().setText(Component.literal(String(err).substring(0, 60))))
    return modularUI(kok, p)
  }

  BOLUMLER.forEach(function (bol) {
    LDLib2UI.player('arayuz:' + bol.id, function (e) {
      try { e.modularUI = ekranKur(e, bol) } catch (err) {
        console.error('[Arayuz] ekran kurulamadi (' + bol.id + '): ' + err)
        e.modularUI = hataEkrani(e.player, err)
      }
    })
  })

  function ekranKur(e, bol) {
    {
      var sunucuda = !e.level.isClientSide()
      var p = e.player
      var durum = {}
      var ogeler = ICERIK[bol.id] || []

      // Tam ekran şeffaf kök: LDLib görünen her elemanın alanını JEI'ye "dokunma" alanı olarak
      // bildiriyor; kök tüm ekranı kaplayınca JEI listesi yerleşemiyor -> menüde JEI görünmez.
      // Panel bu kökün ortasında durur. Yüzde ayarı tutmazsa eski hal (JEI görünür) devam eder.
      var ekran = E()
      olcu(ekran, function (l) { l['widthPercent(float)'](100) }); olcu(ekran, function (l) { l['heightPercent(float)'](100) })
      ortala(ekran); duzen(ekran, 'dikey_orta', function (l) { l.set(LP.JUSTIFY_CONTENT, TAC.CENTER) })

      // Dış çerçeve (1 px altın) > panel
      var kok = zemin(E(), R.cerceve)
      olcu(kok, function (l) { l['width(float)'](PANEL_EN) }); olcu(kok, function (l) { l['paddingAll(float)'](1) })
      ekran.addChild(kok)
      var panel = zemin(E(), R.panel)
      kok.addChild(panel)

      // Üst çubuk: solda başlık, sağda bölüm adı + banka
      var ust = ortala(iki_uca(yatay(zemin(E(), R.ust))))
      olcu(ust, function (l) { l['paddingAll(float)'](4) })
      ust.addChild(yazi('Sunucu Menüsü', R.baslik))
      ust.addChild(sagaYasla(bagliYazi(R.acik, sunucuda, function () { return bol.ad + '  ·  ' + para(banka(p.getUuid())) }), 180))
      panel.addChild(ust)

      // Gövde: solda menü, sağda içerik
      var govde = yatay(E())
      panel.addChild(govde)
      var yan = zemin(E(), R.yan)
      olcu(yan, function (l) { l['width(float)'](78) }); olcu(yan, function (l) { l['paddingAll(float)'](3) }); olcu(yan, function (l) { l['gapAll(float)'](1) })
      BOLUMLER.forEach(function (b2) {
        var secili = b2.id === bol.id
        var m = E()
        olcu(m, function (l) { l['paddingAll(float)'](2) })
        if (secili) zemin(m, R.secili)
        m.addChild(yazi(b2.ad, secili ? R.koyu : R.acik))
        if (!secili) tiklaninca(m, function () { istemciKomut('menu ' + b2.id, true) })
        yan.addChild(m)
      })
      govde.addChild(yan)

      var icerik = buyu(E())
      olcu(icerik, function (l) { l['paddingAll(float)'](4) }); olcu(icerik, function (l) { l['gapAll(float)'](2) })
      govde.addChild(icerik)

      ogeler.forEach(function (o) {
        if (o.t === 'kart') {
          icerik.addChild(kartYap(o, sunucuda, p))
        } else if (o.t === 'satir') {
          icerik.addChild(bagliYazi(R.acik, sunucuda, function () { return o.f(p, o.sira) }))
        } else if (o.t === 'yazi') {
          icerik.addChild(yazi(o.metin, R.gri))
        } else if (o.t === 'giris') {
          durum[o.ad] = ''
          if (o.ipucu) icerik.addChild(yazi(o.ipucu, R.gri))
          var tf = new TextField()
          if (o.min != null) tf.setNumbersOnlyInt(o.min, o.max); else tf.setAnyString()
          tf.setTextResponder(function (v) { durum[o.ad] = String(v) })
          icerik.addChild(tf)
        } else if (o.t === 'dugme' || o.t === 'dugmeler') {
          var sira = yatay(E())
          olcu(sira, function (l) { l['gapAll(float)'](3) })
          var liste = o.t === 'dugme' ? [o] : o.liste
          liste.forEach(function (d) {
            sira.addChild(dugmeYap(d.yazi, function () {
              var h = komutHazirla(d.komut, durum, ogeler)
              if (h.hata) { durumMesaji(h.hata); return }
              istemciKomut(h.komut, !d.acik)   // acik: menü kapanmaz (değer canlı güncellenir)
            }))
          })
          icerik.addChild(sira)
        }
      })

      return modularUI(ekran, p)
    }
  }

  console.info('[Arayuz] ' + BOLUMLER.length + ' bolum kaydedildi (Meal Mastery stili)')
})()
