// =====================================================================
//  ARAYÜZ  -  kubejs/startup_scripts/arayuz.js
//  LDLib2 (ldlib2-neoforge-1.21.1-2.2.46) arayüz sistemi üzerine, Meal Mastery tarzı:
//  koyu panel, üst başlık çubuğu, solda bölüm menüsü, sağda kartlar
//  (başlık + açıklama + sağda değer + altta ilerleme çubuğu).
//
//  - Dosya startup_scripts'te: LDLib2 aynı ekranı sunucuda (veri) ve oyuncuda
//    (görüntü) kurar. OYUNCULARDA DA AYNI DOSYA OLMALI (guncelle.bat ile gelir).
//  - Açmak: /menu (giriş menüsü, sadece bölüm listesi)  veya  /menu <bölüm> (o bölümün ayrı ekranı)
//    (server_scripts/arayuz_komut.js). Her bölüm ekranında "◀ Menü" giriş menüsüne döner.
//  - Değişiklikten sonra sunucu ve oyunlar YENİDEN BAŞLATILMALI.
//
//  KubeJS/Rhino kuralları (canlı sunucuda öğrenildi):
//  - Fonksiyon içinde const/let yok, hep var.
//  - Aşırı yüklenmiş Java metotları (UI.of, width...) imzasıyla açıkça seçilir: l['width(float)'](420)
//  - Yön/hizalama: l.set(LP.FLEX_DIRECTION, TFD.ROW) (flexDirection vb. @HideFromJS, çağrılamıyor)
//  - Kök tam ekran ve şeffaf: JEI menüde gizlenir (bkz. ekranKur).
//  - Ekran kurulamazsa hataEkrani() açılır; oyun çökmez.
//  - Tıklamalar oyuncu tarafında çalışır ve komut gönderir (sunucu tıklaması çalışmıyor);
//    hata oyunu çökertmesin diye guvenli() ile sarılır. Player.closeContainer -> closeMenu.
//  - Sunucudan gelen veri sadece Component olarak bağlanır (sayı bağlamada Double/Float sorunu).
//
//  YENİ BÖLÜM: BOLUMLER listesine ekle + bolum('kimlik', [...öğeler]).
//  Öğeler:
//    { t: 'kart',  baslik: 'Başlık', alt: 'Açıklama', deger: f(p) -> yazı, oran: f(p) -> 0..1 (isteğe bağlı) }
//    { t: 'yazi',  metin: 'Sabit yazı' }
//    { t: 'giris', ad: 'miktar', ipucu: 'Miktar', min: 1, max: 1000000 }   (min yoksa serbest yazı)
//    { t: 'dugme', yazi: 'Kredi çek', komut: 'kredi cek {miktar}' }       (oyuncunun yetkisiyle)
//    { t: 'dugmeler', liste: [ {yazi, komut}, ... ] }                    (yan yana düğmeler)
//      komutta {ad?} = isteğe bağlı kutu (boşsa atlanır); acik: true = menü kapanmaz
//  f(p) fonksiyonları SADECE sunucuda çalışır ve her tick güncellenir.
//  Bölüm içeriği oyuncuya göre değişmemeli; yetkiye göre farklılık f(p) içinde yapılır.
//
//  !! Gerçek bir oyunda ÇALIŞTIRILARAK TEST EDİLMEDİ.
// =====================================================================

;(function () {
  var ModularUI = Java.loadClass('com.lowdragmc.lowdraglib2.gui.ui.ModularUI')
  var UI = Java.loadClass('com.lowdragmc.lowdraglib2.gui.ui.UI')
  var UIElement = Java.loadClass('com.lowdragmc.lowdraglib2.gui.ui.UIElement')
  var Label = Java.loadClass('com.lowdragmc.lowdraglib2.gui.ui.elements.Label')
  var TextField = Java.loadClass('com.lowdragmc.lowdraglib2.gui.ui.elements.TextField')
  var DataBindingBuilder = Java.loadClass('com.lowdragmc.lowdraglib2.gui.sync.bindings.impl.DataBindingBuilder')
  var ColorRectTexture = Java.loadClass('com.lowdragmc.lowdraglib2.gui.texture.ColorRectTexture')
  // LDLib2, LayoutStyle'ın Taffy türlü flexDirection/justifyContent sürümlerini @HideFromJS ile
  // gizliyor; JavaScript'ten sadece Yoga türlü sürümler görünür. Bu yüzden Yoga sabitleri kullanılır.
  // Açık imzayla seçim, gizli sürümü olan metotlarda da çalışmadı. Çözüm: LDLib2'nin içeride
  // kullandığı Style.set(Property, değer) (tek iki parametreli sürüm, gizli değil).
  var LP = Java.loadClass('com.lowdragmc.lowdraglib2.gui.ui.layout.LayoutProperties')
  var TFD = Java.loadClass('dev.vfyjxf.taffy.style.FlexDirection')
  var TAI = Java.loadClass('dev.vfyjxf.taffy.style.AlignItems')
  var TAC = Java.loadClass('dev.vfyjxf.taffy.style.AlignContent')
  var Component = Java.loadClass('net.minecraft.network.chat.Component')
  var JUUID = Java.loadClass('java.util.UUID')
  var ArrayList = Java.loadClass('java.util.ArrayList')
  var StylesheetManager = null
  function tema() { if (StylesheetManager == null) StylesheetManager = Java.loadClass('com.lowdragmc.lowdraglib2.gui.ui.style.StylesheetManager'); return StylesheetManager }

  // ----------------------------- RENKLER (Meal Mastery) -------------------
  function renk(rgb, alfa) { return (((alfa == null ? 0xFF : alfa) << 24) | rgb) | 0 }
  var R = {
    cerceve: renk(0x6B5530),   // ince altın çerçeve
    panel: renk(0x16130F, 0xEE),
    ust: renk(0x221B13, 0xF5),
    yan: renk(0x1B1712, 0xF5),
    secili: renk(0xC57B2A),
    cizgi: renk(0x3A3227),
    dugme: renk(0x2E261C),
    baslik: renk(0xE9A23B),    // turuncu-altın başlık
    acik: renk(0xE6DCC8),      // kart başlığı
    gri: renk(0x8F8676),       // açıklama
    koyu: renk(0x1A1208),      // seçili menü yazısı
    dolu: 0xE39B2E, bos: 0x4A3F31  // çubuk renkleri (RGB)
  }

  // ----------------------------- YARDIMCILAR ------------------------------
  function E() { return new UIElement() }
  function zemin(el, argb) { el.style(function (s) { s.background(new ColorRectTexture(argb)) }); return el }
  // Her düzen ayarı ayrı korunur: tutmazsa sadece o ayar atlanır, ekran yine açılır.
  var uyarilan = {}
  function duzen(el, ad, fn) {
    try { el.layout(function (l) { fn(l) }) } catch (err) {
      if (!uyarilan[ad]) { uyarilan[ad] = true; console.warn('[Arayuz] duzen ayari atlandi (' + ad + '): ' + err) }
    }
    return el
  }
  function yatay(el) { return duzen(el, 'yatay', function (l) { l.set(LP.FLEX_DIRECTION, TFD.ROW) }) }
  function ortala(el) { return duzen(el, 'ortala', function (l) { l.set(LP.ALIGN_ITEMS, TAI.CENTER) }) }
  function iki_uca(el) { return duzen(el, 'iki_uca', function (l) { l.set(LP.JUSTIFY_CONTENT, TAC.SPACE_BETWEEN) }) }
  function buyu(el) { return duzen(el, 'buyu', function (l) { try { l['flexGrow(float)'](1) } catch (eg) { l.flexGrow(1) } }) }
  // Sayı alan ayarlar (genişlik, boşluk...) önceki sürümde çalıştı; yine de korumalı.
  function olcu(el, fn) { return duzen(el, 'olcu', fn) }
  function yazi(metin, r) {
    var lb = new Label()
    lb.setText(Component.literal(metin))
    lb.textStyle(function (s) { s.textColor(r).textShadow(false) })
    return lb
  }
  // f() düz metin döner; hazirBilesen=true ise f() zaten bir Component döner (ör. renkli çubuk)
  function bagliYazi(r, sunucuda, f, hazirBilesen) {
    var lb = new Label()
    lb.textStyle(function (s) { s.textColor(r).textShadow(false) })
    lb.bind(DataBindingBuilder.componentS2C(function () {
      if (!sunucuda) return Component.literal('')
      try { return hazirBilesen ? f() : Component.literal(String(f())) } catch (err) { return Component.literal('?') }
    }).build())
    return lb
  }
  // Sunucudan gelen yazı, ekran kurulurken boş olduğu için LDLib ona 0 genişlik veriyor ve
  // yazı gelince sağa taşıyordu. Çözüm: sabit genişlik + sağa hizalı yazı.
  var Horizontal = Java.loadClass('com.lowdragmc.lowdraglib2.gui.ui.data.Horizontal')
  function hizala(lb, yon) {
    try { lb.textStyle(function (s) { s['textAlignHorizontal(com.lowdragmc.lowdraglib2.gui.ui.data.Horizontal)'](yon) }) } catch (err) {
      if (!uyarilan.hiza) { uyarilan.hiza = true; console.warn('[Arayuz] yazi hizalama atlandi: ' + err) }
    }
    return lb
  }
  function sagaYasla(lb, en) {
    olcu(lb, function (l) { l['width(float)'](en) })
    duzen(lb, 'kuculme', function (l) { l['flexShrink(float)'](0) })
    return hizala(lb, Horizontal.RIGHT)
  }
  // Metin çubuğu: turuncu dolu + koyu boş kareler (ProgressBar sayı bağlaması Double/Float yüzünden kullanılmıyor)
  // Bölüm ekranı genişliği (yan menü yok, içerik = PANEL_EN - 10). Çubuk karakteri ~9 px, 22 adet ~200 px.
  // Giriş menüsü (arayuz:menu) ayrı ve dar: sadece bölüm listesi.
  var PANEL_EN = 342
  var MENU_EN = 140
  var CUBUK_UZ = 22
  function cubuk(oran) {
    var o = Math.max(0, Math.min(1, Number(oran) || 0))
    var n = Math.round(o * CUBUK_UZ)
    var dolu = Component.literal(new Array(n + 1).join('▬')).withColor(R.dolu)
    var bos = Component.literal(new Array(CUBUK_UZ - n + 1).join('▬')).withColor(R.bos)
    return dolu['append(net.minecraft.network.chat.Component)'](bos)
  }

  // ----------------------------- SUNUCU VERİLERİ --------------------------
  var HAZINE = '5f0c2d1e-7a3b-4e9c-8d6f-1b2a3c4d5e6f'
  var Numismatics = null, OPAC = null
  function banka(uuid) {
    if (Numismatics == null) Numismatics = Java.loadClass('dev.ithundxr.createnumismatics.Numismatics')
    var h = Numismatics.BANK.getAccount(uuid)
    return h ? h.getBalance() : 0
  }
  function claimSayisi(p) {
    if (OPAC == null) OPAC = Java.loadClass('xaero.pac.common.server.api.OpenPACServerAPI')
    var m = OPAC.get(p.server).getServerClaimsManager()
    return m.hasPlayerInfo(p.getUuid()) ? m.getPlayerInfo(p.getUuid()).getClaimCount() : 0
  }
  function veriOku(p, anahtar) {
    var s = p.server.persistentData.getString(anahtar)
    if (!s) return {}
    try { return JSON.parse(s) } catch (e) { return {} }
  }
  function borcKaydi(p) { var d = veriOku(p, 'borc_veri'); return (d.o || {})[String(p.getUuid())] || null }
  function vergiKaydi(p) { return (veriOku(p, 'vergi_veri').kayitlar || {})[String(p.getUuid())] || null }
  function para(n) { return String(Math.floor(n)).replace(/\B(?=(\d{3})+(?!\d))/g, '.') + ' spur' }
  function sure(ms) { var dk = Math.max(0, Math.floor(ms / 60000)); var g = Math.floor(dk / 1440); return (g > 0 ? g + ' g ' : '') + Math.floor((dk % 1440) / 60) + ' sa ' + (dk % 60) + ' dk' }
  function yetkili(p) { return p.createCommandSourceStack().hasPermission(2) }
  function baskanMi(p) { var b = p.server.persistentData.getString('baskan'); return !!b && b === String(p.getUuid()) }
  function oyuncuAdi(p, uuid) {
    var o = p.server.playerList.getPlayer(uuid)
    if (o != null) return String(o.username)
    var prof = p.server.getProfileCache().get(uuid)
    return prof.isPresent() ? String(prof.get().getName()) : String(uuid).substring(0, 8)
  }
  // Arazi: günlük ücret ve kategori dağılımı vergi_sistemi.js tarafından her dakika kayda yazılır
  var YERLESKE = 35
  var KAT_AD = { yerleske: 'Yerleşke', dukkan: 'Dükkan', fabrika: 'Fabrika', arac: 'Araç' }
  // Claim kalmadıysa (askıda değilse) kayıttaki eski değer gösterilmez
  function claimYok(p, r) { return claimSayisi(p) === 0 && !(r && (r.askida || (r.dg && r.dg.a > 0) || (r.kota || 1) > 1)) }
  function kotaYazi(p) { var r = vergiKaydi(p); var k = r && r.kota != null ? r.kota : 1; return claimSayisi(p) + ' / ' + k + ' hak' }
  function araziGunluk(p) { var r = vergiKaydi(p); if (claimYok(p, r)) return 0; return r && r.g != null ? r.g : claimSayisi(p) * YERLESKE }
  function araziDagilim(p) {
    var r = vergiKaydi(p)
    if (claimYok(p, r)) return 'Claim yok'
    if (!r || !r.dg) return 'Yerleşke ' + claimSayisi(p)
    return 'Y ' + r.dg.y + ' · D ' + r.dg.d + ' · F ' + r.dg.f + ' · A ' + (r.dg.a || 0)
  }
  // Oyuncunun durduğu chunk: sahip + kategori (teftiş)
  function teftis(p) {
    if (OPAC == null) OPAC = Java.loadClass('xaero.pac.common.server.api.OpenPACServerAPI')
    var boyut = String(p.level.getDimension())
    var x = Math.floor(p.getX() / 16), z = Math.floor(p.getZ() / 16)
    var c = OPAC.get(p.server).getServerClaimsManager().get(p.level.getDimension(), x, z)
    var sahip = c == null ? null : c.getPlayerId()
    var kat = veriOku(p, 'arazi_kategori')[boyut + '|' + x + '|' + z]
    if (!kat || sahip == null || kat.o !== String(sahip)) kat = { k: 'yerleske', f: YERLESKE }
    return { x: x, z: z, sahip: sahip, kat: kat }
  }

  // ----------------------------- KAYIT SAYFALARI -------------------------
  // Satışlar (satis_kayit.js) ve hazine hareketleri, en yeni üstte, sayfa başına 10 satır.
  // Sayfa no oyuncunun persistentData'sında (menu_sayfa_<ad>); /menu sayfa <ad> <+1|-1|0>.
  var SAYFA = 10
  var onbellek = {}
  var HAREKET_AD = { arazi: 'Arazi vergisi', olum: 'Ölüm vergisi', tescil: 'Tescil', cinayet: 'Cinayet cezası',
    savas: 'Savaş ilanı', borc: 'Borç tahsilatı', kredi: 'Kredi verildi', kredi_odeme: 'Kredi ödemesi',
    aktarim: 'Aktarım', cekim: 'Çekim', yatirma: 'Yatırma', zindan: 'Zindan girişi', kelle: 'Kelle ödülü', tazminat: 'Tazminat payı', yetenek: 'Sınıf/meslek ücreti', savas_gideri: 'Savaş gideri', savas_iade: 'Savaş ilanı iadesi',
    kelle_harci: 'Kelle harcı', kelle_emanet: 'Kelle ödülü emaneti', kelle_odeme: 'Kelle ödülü ödendi', kelle_iade: 'Kelle ödülü iadesi',
    kdv: 'Satış vergisi (KDV)', harc: 'Ticaret harcı', arazi_ceza: 'Arazi beyan cezası', banka_lisans: 'Banka lisansı' }
  function iki(n) { return (n < 10 ? '0' : '') + n }
  function zaman(t) { var d = new Date(t); return iki(d.getDate()) + '.' + iki(d.getMonth() + 1) + ' ' + iki(d.getHours()) + ':' + iki(d.getMinutes()) }
  function kisalt(s, n) { s = String(s); return s.length > n ? s.substring(0, n - 1) + '…' : s }
  function kayitYetkisi(p, ad) { return ad !== 'hazine' || yetkili(p) || baskanMi(p) }
  function sayfaVerisi(p, ad) {
    var k = ad + '|' + String(p.getUuid())
    var tick = p.server.tickCount
    var c = onbellek[k]
    if (c && c.tick === tick) return c
    var liste = []
    if (kayitYetkisi(p, ad)) {
      if (ad === 'satis') { var s = veriOku(p, 'satis_kayit'); liste = Array.isArray(s) ? s : [] }
      else liste = veriOku(p, 'hazine_veri').hareket || []
    }
    liste = liste.slice().reverse()
    var top = Math.max(1, Math.ceil(liste.length / SAYFA))
    var no = Math.min(Math.max(0, p.persistentData.getInt('menu_sayfa_' + ad)), top - 1)
    c = { tick: tick, satirlar: liste.slice(no * SAYFA, no * SAYFA + SAYFA), no: no, top: top, toplam: liste.length }
    onbellek[k] = c
    return c
  }
  function satisSatiri(e) {
    return kisalt(zaman(e.t) + '  ' + e.a + (e.y === 'al' ? ' aldı ' : ' sattı ') + e.n + 'x ' + e.i + ' · ' + e.m + ' · ' + e.s, 64)
  }
  function hazineSatiri(e) {
    var gider = e.tur === 'aktarim' || e.tur === 'cekim' || e.tur === 'kredi' || e.tur === 'kelle' || e.tur === 'savas_iade' || e.tur === 'kelle_odeme' || e.tur === 'kelle_iade'
    return kisalt(zaman(e.t) + '  ' + (gider ? '-' : '+') + para(e.m) + '  ' + (HAREKET_AD[e.tur] || e.tur) + '  ' + e.k, 64)
  }
  function kayitBolumu(ad, baslik, alt, bicim) {
    var ogeler = [
      { t: 'kart', baslik: baslik, alt: alt,
        deger: function (p) {
          if (!kayitYetkisi(p, ad)) return 'Yetkili değil'
          var c = sayfaVerisi(p, ad); return 'Sayfa ' + (c.no + 1) + '/' + c.top + ' · ' + c.toplam + ' kayıt'
        } }
    ]
    for (var i = 0; i < SAYFA; i++) {
      ogeler.push({ t: 'satir', sira: i, f: function (p, sira) {
        var e = sayfaVerisi(p, ad).satirlar[sira]
        return e ? bicim(e) : (sira === 0 ? 'Henüz kayıt yok.' : '')
      } })
    }
    ogeler.push({ t: 'dugmeler', liste: [
      { yazi: '◀ Yeniler', komut: 'menu sayfa ' + ad + ' -1', acik: true },
      { yazi: 'En yeni', komut: 'menu sayfa ' + ad + ' 0', acik: true },
      { yazi: 'Eskiler ▶', komut: 'menu sayfa ' + ad + ' 1', acik: true }
    ] })
    return ogeler
  }

  // ----------------------------- BÖLÜMLER ---------------------------------
  // komut'u olan bölüm LDLib ekranı değil: o komut çalışır. "Ekonomi" ekranı sunucu_piyasa
  // modunun kendi (Java) ekranıdır; aynı görünüm ve aynı sol menüyle açılır (/ekonomi).
  var BOLUMLER = [
    { id: 'ana', ad: 'Genel' },
    { id: 'ekonomi', ad: 'Ekonomi', komut: 'ekonomi' },
    { id: 'kredi', ad: 'Kredi & Borç' },
    { id: 'bankalar', ad: 'Bankalar' },
    { id: 'vergi', ad: 'Arazi Vergisi' },
    { id: 'savas', ad: 'Savaş' },
    { id: 'zindan', ad: 'Zindan' },
    { id: 'yetenek', ad: 'Sınıf & Meslek' },
    { id: 'teftis', ad: 'Teftiş' },
    { id: 'satislar', ad: 'Satışlar' },
    { id: 'hazine', ad: 'Hazine' },
    { id: 'devlet', ad: 'Devlet' }
  ]
  var ICERIK = {}
  function bolum(id, ogeler) { ICERIK[id] = ogeler }

  bolum('ana', [
    { t: 'kart', baslik: 'Banka', alt: 'Numismatics hesabındaki para', deger: function (p) { return para(banka(p.getUuid())) } },
    { t: 'kart', baslik: 'Kredi Notu', alt: 'Limitini ve faizini belirler',
      deger: function (p) { var r = borcKaydi(p); return (r ? r.not : 500) + ' / 1000' },
      oran: function (p) { var r = borcKaydi(p); return (r ? r.not : 500) / 1000 } },
    { t: 'kart', baslik: 'Borç', alt: 'Ödenmeyen cezalar, günlük %2 faiz',
      deger: function (p) { var r = borcKaydi(p); return r && r.borc > 0 ? para(Math.ceil(r.borc)) : 'Yok' } },
    { t: 'kart', baslik: 'Arazi', alt: 'Claim edilen chunk ve günlük vergi',
      deger: function (p) { return claimSayisi(p) + ' chunk · ' + para(araziGunluk(p)).replace(' spur', '') + '/gün' } },
    { t: 'kart', baslik: 'Savaşlar', alt: 'Aktif ve hazırlıktaki savaşlar',
      deger: function (p) { return String((veriOku(p, 'savas_veri').savaslar || []).length) } }
  ])

  bolum('kredi', [
    { t: 'kart', baslik: 'Kredi Notu', alt: '300 altı: kredi yok · 900+: 50.000 spur, %3',
      deger: function (p) { var r = borcKaydi(p); return (r ? r.not : 500) + ' / 1000' },
      oran: function (p) { var r = borcKaydi(p); return (r ? r.not : 500) / 1000 } },
    { t: 'kart', baslik: 'Aktif Kredi', alt: '7 günlük taksit, bankadan otomatik',
      deger: function (p) { var r = borcKaydi(p); return r && r.kredi ? 'Kalan ' + para(r.kredi.kalan) : 'Yok' },
      oran: function (p) { var r = borcKaydi(p); if (!r || !r.kredi) return 0; var top = r.kredi.taksit * 7; return 1 - r.kredi.kalan / top } },
    { t: 'kart', baslik: 'Borç', alt: 'Borç varken kredi çekilemez · günlük %2 faiz',
      deger: function (p) { var r = borcKaydi(p); return r && r.borc > 0 ? para(Math.ceil(r.borc)) : 'Yok' } },
    { t: 'kart', baslik: 'Yaptırım', alt: '2. gün satış %50 · 3. damga · 5. satış %100 · 7. kelle + haciz',
      deger: function (p) {
        var e = veriOku(p, 'borc_durum')[String(p.getUuid())]
        if (!e) return 'Yok'
        return Math.floor(e.g) + '. gün · ' + (['Ek süre', 'Satış %50', 'Damga · %50', 'Damga · %100', 'Kelle avı · haciz'][e.a] || '')
      },
      oran: function (p) { var e = veriOku(p, 'borc_durum')[String(p.getUuid())]; return e ? Math.min(1, e.g / 7) : 0 } },
    { t: 'giris', ad: 'miktar', ipucu: 'Miktar (spur)', min: 1, max: 1000000 },
    { t: 'dugmeler', liste: [
      { yazi: 'Kredi çek', komut: 'kredi cek {miktar}' },
      { yazi: 'Krediyi kapat', komut: 'kredi ode' },
      { yazi: 'Ayrıntı', komut: 'kredi durum' }
    ] },
    { t: 'dugmeler', liste: [
      { yazi: 'Borç öde', komut: 'borc ode {miktar}' },
      { yazi: 'Tamamını öde', komut: 'borc ode' },
      { yazi: 'Borçlular', komut: 'borclular' }
    ] }
  ])

  // ----------------------------- BANKALAR (banka_sistemi.js) -------------
  // Bankacılık elle yapılır; burada herkes bankaların kasasını, defter toplamlarını, duyurusunu ve
  // kendi defter satırını görür. Gösterilen banka: /banka sec <ad> (yoksa kendi bankan).
  function bankalar(p) { var b = veriOku(p, 'banka_veri').b || {}; return Object.keys(b).map(function (k) { return b[k] }) }
  function bankaKasa(b) { try { return banka(JUUID.fromString(b.hesap)) } catch (e) { return 0 } }
  function bankaToplam(b) { var m = 0, k = 0; Object.keys(b.defter || {}).forEach(function (u) { m += b.defter[u].m || 0; k += b.defter[u].k || 0 }); return { m: m, k: k } }
  function seciliBanka(p) {
    var hepsi = veriOku(p, 'banka_veri').b || {}
    var s = String(p.persistentData.getString('banka_secili') || '')
    if (s && hepsi[s]) return hepsi[s]
    var id = String(p.getUuid())
    return bankalar(p).filter(function (b) { return b.sahip === id })[0] || bankalar(p)[0] || null
  }
  var bankaOgeleri = [
    { t: 'yazi', metin: 'Bankalar (kasa · defterdeki mevduat · kasanın mevduatı karşılama oranı)' }
  ]
  for (var bs = 0; bs < 3; bs++) {   // ekran boyu sınırlı; tam liste: /banka liste
    bankaOgeleri.push({ t: 'satir', sira: bs, f: function (p, sira) {
      var b = bankalar(p)[sira]
      if (!b) return sira === 0 ? 'Henüz banka yok. Tacir mesleğindekiler kurabilir.' : ''
      var t = bankaToplam(b), k = bankaKasa(b)
      return kisalt(b.ad + ' · ' + oyuncuAdi(p, JUUID.fromString(b.sahip)) + ' · ' + para(k) + ' · mevduat ' + para(t.m) + ' · ' + (t.m > 0 ? Math.round(k / t.m * 100) + '%' : '-') + (b.donuk ? ' · DONUK' : ''), 64)
    } })
  }
  bankaOgeleri = bankaOgeleri.concat([
    { t: 'giris', ad: 'banka', ipucu: 'Banka adı' },
    { t: 'dugmeler', liste: [
      { yazi: 'Göster', komut: 'banka sec {banka}', acik: true },
      { yazi: 'Hareketler', komut: 'banka hareket {banka?}' },
      { yazi: 'Defterim', komut: 'banka defterim {banka?}' },
      { yazi: 'Tüm liste', komut: 'banka liste' }
    ] },
    { t: 'kart', baslik: '', basF: function (p) { var b = seciliBanka(p); return b ? b.ad + ' Bankası' : 'Seçili banka yok' },
      altF: function (p) { var b = seciliBanka(p); return b ? 'Sahibi ' + oyuncuAdi(p, JUUID.fromString(b.sahip)) + ' · kilitli sermaye ' + para(b.sermaye) + (b.donuk ? ' · DONDURULDU' : '') : 'Yukarıya banka adı yazıp Göster\'e bas' },
      deger: function (p) { var b = seciliBanka(p); return b ? para(bankaKasa(b)) : '' } },
    { t: 'kart', baslik: 'Defter', alt: 'Bankacının yazdığı toplam mevduat · verilen kredi',
      deger: function (p) { var b = seciliBanka(p); if (!b) return '-'; var t = bankaToplam(b); return para(t.m).replace(' spur', '') + ' · ' + para(t.k).replace(' spur', '') },
      oran: function (p) { var b = seciliBanka(p); if (!b) return null; var t = bankaToplam(b); return t.m > 0 ? Math.min(1, bankaKasa(b) / t.m) : null } },
    { t: 'kart', baslik: 'Senin Satırın', alt: 'Bu bankadaki mevduatın · kredi borcun',
      deger: function (p) { var b = seciliBanka(p); var r = b && b.defter ? b.defter[String(p.getUuid())] : null; return r ? para(r.m || 0).replace(' spur', '') + ' · ' + para(r.k || 0).replace(' spur', '') : 'Kayıt yok' } },
    { t: 'satir', sira: 0, f: function (p) { var b = seciliBanka(p); return b && b.duyuru ? kisalt('Duyuru: ' + b.duyuru, 64) : '' } },
    { t: 'satir', sira: 0, f: function (p) { var b = seciliBanka(p); return b && b.duyuru && b.duyuru.length > 58 ? kisalt(b.duyuru.substring(58), 64) : '' } },
    { t: 'yazi', metin: 'Bankacı: defter yaz (müşteri + yeni tutar) · duyuru: sohbete /banka duyuru <metin>' },
    { t: 'giris', ad: 'musteri', ipucu: 'Müşteri adı' },
    { t: 'giris', ad: 'miktar', ipucu: 'Yeni tutar (spur)', min: 0, max: 1000000000 },
    { t: 'dugmeler', liste: [
      { yazi: 'Mevduatı yaz', komut: 'banka defter {musteri} mevduat {miktar}', acik: true },
      { yazi: 'Krediyi yaz', komut: 'banka defter {musteri} kredi {miktar}', acik: true },
      { yazi: 'Kart al', komut: 'banka kart' }
    ] },
    { t: 'yazi', metin: 'Banka kur (sadece Tacir): 5.000 lisans + 20.000 kilitli sermaye' },
    { t: 'giris', ad: 'yeniad', ipucu: 'Yeni banka adı' },
    { t: 'dugmeler', liste: [
      { yazi: 'Banka kur', komut: 'banka kur {yeniad}' },
      { yazi: 'Bankamı kapat', komut: 'banka kapat' }
    ] }
  ])
  bolum('bankalar', bankaOgeleri)

  bolum('vergi', [
    { t: 'yazi', metin: 'Diğer vergiler: Selling Bin satışlarında %5 KDV · Vendor ve depozitöre gelen paradan %1 harç (otomatik, hazineye)' },
    { t: 'kart', baslik: 'Claim Hakkı (kira)', alt: '1 hak bedava · fazlası hak başı 35/gün · kullanmasan da ödersin',
      deger: function (p) { return kotaYazi(p) } },
    { t: 'kart', baslik: 'Günlük Kira', alt: 'Hak kirası + dükkan/fabrika farkları + araçlar',
      deger: function (p) { return para(araziGunluk(p)) + '/gün' } },
    { t: 'kart', baslik: 'Kategoriler', alt: 'Kendi chunk\'ını işaretle; yanlış beyana başkan ceza yazar',
      deger: function (p) { return araziDagilim(p) } },
    { t: 'giris', ad: 'kota', ipucu: 'Toplam claim hakkı (kira)', min: 1, max: 2000 },
    { t: 'dugmeler', liste: [
      { yazi: 'Hakkı ayarla', komut: 'arazi kota {kota}', acik: true },
      { yazi: 'Hakkım', komut: 'arazi kota' },
      { yazi: 'Fiyatlar', komut: 'arazi fiyat' }
    ] },
    { t: 'yazi', metin: 'Üstünde durduğun kendi chunk\'ın:' },
    { t: 'dugmeler', liste: [
      { yazi: 'Yerleşke', komut: 'arazi kategori yerleske', acik: true },
      { yazi: 'Dükkan', komut: 'arazi kategori dukkan', acik: true },
      { yazi: 'Fabrika', komut: 'arazi kategori fabrika', acik: true }
    ] },
    { t: 'giris', ad: 'oyuncu', ipucu: 'Kira sponsorluğu: oyuncu adı (kirasını sen ödersin)' },
    { t: 'dugmeler', liste: [
      { yazi: 'Sponsor ol', komut: 'arazi sponsor {oyuncu}' },
      { yazi: 'Sponsoru kabul et', komut: 'arazi sponsor kabul' },
      { yazi: 'Sponsoru bırak', komut: 'arazi sponsor birak' }
    ] },
    { t: 'kart', baslik: 'Ön Ödeme', alt: 'Kalan süre (çubuk = 1 hafta)',
      deger: function (p) {
        var r = vergiKaydi(p); var g = araziGunluk(p)
        if (!r) return 'Kayıt yok'
        if (r.askida) return 'ASKIDA'
        if (g <= 0) return para(Math.max(0, r.kredi || 0))
        return sure(Math.max(0, r.kredi || 0) / g * 86400000)
      },
      oran: function (p) { var r = vergiKaydi(p); var g = araziGunluk(p); if (!r || g <= 0) return 0; return (Math.max(0, r.kredi || 0) / g) / 7 } },
    { t: 'kart', baslik: 'Otomatik Ödeme', alt: 'Süre bitince bankadan 1 gün kesilir',
      deger: function (p) { var r = vergiKaydi(p); return r && r.auto === false ? 'Kapalı' : 'Açık' } },
    { t: 'dugmeler', liste: [
      { yazi: '1 gün', komut: 'vergi ode gun' },
      { yazi: '1 hafta', komut: 'vergi ode hafta' },
      { yazi: '1 ay', komut: 'vergi ode ay' }
    ] },
    { t: 'dugmeler', liste: [
      { yazi: 'Otomatik aç', komut: 'vergi otomatik ac' },
      { yazi: 'Otomatik kapat', komut: 'vergi otomatik kapat' }
    ] }
  ])

  function savasKarti(i) {
    return { t: 'kart',
      baslik: '',
      basF: function (p) {
        var s = (veriOku(p, 'savas_veri').savaslar || [])[i]
        if (!s) return i === 0 ? 'Savaş yok' : ''
        var m = function (l) { return l && l.length ? ' +' + l.length : '' }
        return '#' + s.id + '  ' + s.a.ad + m(s.ma) + '  vs  ' + s.b.ad + m(s.mb)
      },
      altF: function (p) {
        var s = (veriOku(p, 'savas_veri').savaslar || [])[i]
        if (!s) return ''
        if (s.durum === 'onay') return 'Başkan/OP onayı bekleniyor · otomatik onaya ' + sure(s.onaySon - Date.now())
        if (s.durum === 'hazirlik') return 'Hazırlık: ' + sure(s.baslangic - Date.now())
        return 'Aktif · ' + sure(Date.now() - (s.aktifBas || Date.now())) + 'dir · yağma açık'
      },
      deger: function (p) { var s = (veriOku(p, 'savas_veri').savaslar || [])[i]; return s ? s.skor.a + ' - ' + s.skor.b : '' } }
  }
  bolum('savas', [
    savasKarti(0), savasKarti(1),
    { t: 'yazi', metin: 'Süre sınırı yok: antlaşma, barış veya teslimle biter. Her gün savaş gideri kesilir.' },
    { t: 'giris', ad: 'oyuncu', ipucu: 'Karşı oyuncu adı' },
    { t: 'dugmeler', liste: [
      { yazi: 'Savaş ilan et', komut: 'savas ilan {oyuncu}' },
      { yazi: 'Barış', komut: 'savas baris {oyuncu}' },
      { yazi: 'Teslim ol', komut: 'savas teslim {oyuncu}' }
    ] },
    { t: 'giris', ad: 'no', ipucu: 'Savaş no (#)', min: 1, max: 100000 },
    { t: 'giris', ad: 'miktar', ipucu: 'Antlaşma parası (spur)', min: 0, max: 10000000, istege: true },
    { t: 'dugmeler', liste: [
      { yazi: 'Para iste', komut: 'savas antlasma {no} para al {miktar}', acik: true },
      { yazi: 'Para ver', komut: 'savas antlasma {no} para ver {miktar}', acik: true },
      { yazi: 'Teklifleri gör', komut: 'savas antlasma {no} goster' }
    ] },
    { t: 'dugmeler', liste: [
      { yazi: 'Bu chunk bize', komut: 'savas antlasma {no} chunk al', acik: true },
      { yazi: 'Bu chunk onlara', komut: 'savas antlasma {no} chunk ver', acik: true },
      { yazi: 'Teklifi gönder', komut: 'savas antlasma {no} gonder' }
    ] },
    { t: 'dugmeler', liste: [
      { yazi: 'Teklifi kabul et', komut: 'savas antlasma {no} kabul' },
      { yazi: 'Teklifi reddet', komut: 'savas antlasma {no} reddet' },
      { yazi: 'Savaşlar', komut: 'savas durum' }
    ] },
    { t: 'dugmeler', liste: [
      { yazi: 'Yanına katıl', komut: 'savas katil {no} {oyuncu}' },
      { yazi: 'Müttefiki kabul et', komut: 'savas kabul {no} {oyuncu}' },
      { yazi: 'Onayla (başkan)', komut: 'savas onayla {no}' }
    ] },
    { t: 'dugme', yazi: 'Reddet (başkan, ücret iade)', komut: 'savas reddet {no}' },
    { t: 'yazi', metin: 'Kelle ödülü: oyuncu + miktar (en az 1.000) · harç: servetinin %5\'i · 7 gün · kimliğin gizli' },
    { t: 'dugmeler', liste: [
      { yazi: 'Kelleye ödül koy', komut: 'kelle koy {oyuncu} {miktar}' },
      { yazi: 'Kelleler', komut: 'kelle liste' },
      { yazi: 'Kellemi satın al', komut: 'kelle temizle' }
    ] }
  ])

  // Teftiş: oyuncular kategorisini kendisi işaretler; başkan arazinin üstünde durup yanlış beyanı
  // düzeltir ve isteğe bağlı ceza yazar ({ceza?} boşsa cezasız). Kategori fiyatları da buradan.
  bolum('teftis', [
    { t: 'kart', baslik: '', basF: function (p) { var t = teftis(p); return 'Chunk ' + t.x + ', ' + t.z },
      alt: 'Durduğun chunk ve sahibi',
      deger: function (p) { var t = teftis(p); return t.sahip == null ? 'Sahipsiz' : oyuncuAdi(p, t.sahip) } },
    { t: 'kart', baslik: 'Beyan Edilen Kategori', alt: 'Harita: dükkan mavi, fabrika turuncu',
      deger: function (p) { var t = teftis(p); return t.sahip == null ? '-' : KAT_AD[t.kat.k] + (t.kat.b ? ' · ' + kisalt(t.kat.b, 14) : '') } },
    { t: 'kart', baslik: 'Yetki', alt: 'Düzeltme ve ceza başkanda',
      deger: function (p) { return baskanMi(p) ? 'Başkansın' : (yetkili(p) ? 'OP' : 'Yetkin yok') } },
    { t: 'giris', ad: 'ceza', ipucu: 'Yanlış beyan cezası (spur, boş: cezasız)', min: 1, max: 1000000, istege: true },
    { t: 'dugmeler', liste: [
      { yazi: 'Yerleşke yap', komut: 'arazi duzelt yerleske {ceza?}', acik: true },
      { yazi: 'Dükkan yap', komut: 'arazi duzelt dukkan {ceza?}', acik: true },
      { yazi: 'Fabrika yap', komut: 'arazi duzelt fabrika {ceza?}', acik: true }
    ] },
    { t: 'giris', ad: 'fiyat', ipucu: 'Kategori günlük fiyatı (en az 35)', min: 35, max: 100000 },
    { t: 'dugmeler', liste: [
      { yazi: 'Dükkan fiyatı', komut: 'arazi fiyat dukkan {fiyat}', acik: true },
      { yazi: 'Fabrika fiyatı', komut: 'arazi fiyat fabrika {fiyat}', acik: true },
      { yazi: 'Fiyatlar', komut: 'arazi fiyat' }
    ] },
    // Araçlar chunk değil: Aeronautics Claims'teki her aero claim (250 blok) başına tek fiyat
    { t: 'kart', baslik: 'Araç Vergisi', alt: 'Aero claim (250 blok) başına, tüm araçlar',
      deger: function (p) { var f = p.server.persistentData.getInt('arac_fiyat'); return (f > 0 ? f : 35) + '/gün' } },
    { t: 'giris', ad: 'aracfiyat', ipucu: 'Araç vergisi (aero claim başına günlük)', min: 1, max: 100000 },
    { t: 'dugme', yazi: 'Araç vergisini kaydet', komut: 'arazi aracfiyat {aracfiyat}', acik: true }
  ])

  // ----------------------------- ZİNDAN (sunucu_zindan modu) -------------
  var ZindanApi = undefined
  var zindanOnbellek = {}
  function zindanOzet(p) {
    var k = String(p.getUuid())
    var tick = p.server.tickCount
    var c = zindanOnbellek[k]
    if (c && c.tick === tick) return c.veri
    if (ZindanApi === undefined) { try { ZindanApi = Java.loadClass('tr.sunucu.zindan.ZindanApi') } catch (e) { ZindanApi = null } }
    var veri = {}
    if (ZindanApi != null) { try { veri = JSON.parse(String(ZindanApi.ozet(k))) } catch (e) { veri = {} } }
    zindanOnbellek[k] = { tick: tick, veri: veri }
    return veri
  }
  function dk(sn) { sn = Math.max(0, sn || 0); return Math.floor(sn / 60) + ':' + (sn % 60 < 10 ? '0' : '') + (sn % 60) }
  var zindanOgeleri = [
    { t: 'kart', baslik: 'Aktif Zindan',
      altF: function (p) { var a = zindanOzet(p).aktif; return a ? 'Ganimet ' + a.ganimet + ' · Canavar ' + a.canavar + ' · ' + a.oda + ' oda' : 'Seviye 1 sigilsiz girilir, ücret seviye × ' + (zindanOzet(p).ucret || 5) + ' spur' },
      deger: function (p) { var a = zindanOzet(p).aktif; return a ? 'Sv.' + a.seviye + (a.katSayisi > 1 ? ' · Kat ' + a.kat + '/' + a.katSayisi : '') + ' · Hak ' + a.hak + ' · ' + dk(a.kalan) : 'Yok' } },
    { t: 'kart', baslik: 'En Yüksek Seviye', altF: function (p) { var o = zindanOzet(p); return 'Bitirilen koşu ' + (o.bitirilen || 0) + (o.enYuksek ? ' · en iyi süre ' + dk(o.sure) : '') },
      deger: function (p) { return String(zindanOzet(p).enYuksek || 0) } },
    { t: 'kart', baslik: 'Ganimet Deposu', alt: 'Zindandan kazanılan her şey burada bekler',
      deger: function (p) { var n = zindanOzet(p).depo || 0; return n > 0 ? n + ' eşya' : 'Boş' } },
    { t: 'yazi', metin: 'Sıralama (en yüksek seviye, sonra en kısa süre)' }
  ]
  for (var zs = 0; zs < 5; zs++) {
    zindanOgeleri.push({ t: 'satir', sira: zs, f: function (p, sira) {
      var l = zindanOzet(p).liste || []
      var e = l[sira]
      return e ? (sira + 1) + '. ' + e.ad + '  ·  Sv.' + e.seviye + '  ·  ' + dk(e.sure) : (sira === 0 ? 'Henüz kimse bitirmedi.' : '')
    } })
  }
  zindanOgeleri.push({ t: 'dugmeler', liste: [
    { yazi: 'Seviye 1\'e gir', komut: 'zindan baslat' },
    { yazi: 'Depoyu aç', komut: 'zindan depo' },
    { yazi: 'Harita', komut: 'zindan harita' },
    { yazi: 'Ayrıl', komut: 'zindan ayril' }
  ] })
  zindanOgeleri.push({ t: 'giris', ad: 'seviye', ipucu: 'Sigilli seviye (envanterde o seviyenin sigili olmalı)', min: 1, max: 1000 })
  zindanOgeleri.push({ t: 'dugme', yazi: 'Sigille gir', komut: 'zindan baslat {seviye}' })
  bolum('zindan', zindanOgeleri)

  // ----------------------------- SINIF & MESLEK (yetenek_sistemi.js) ------
  var SINIF_AD = { savasci: 'Savaşçı', avci: 'Avcı', nisanci: 'Nişancı', buyucu: 'Büyücü', terbiyeci: 'Terbiyeci', duellocu: 'Düellocu' }
  var MESLEK_AD = { madenci: 'Madenci', zanaatkar: 'Zanaatkar', demirci: 'Demirci', simyaci: 'Simyacı', ciftci: 'Çiftçi', balikci: 'Balıkçı', tacir: 'Tacir' }
  var SINIF_ZINDAN = 5
  function yetenekKaydi(p) { return (veriOku(p, 'yetenek_veri').o || {})[String(p.getUuid())] || {} }
  bolum('yetenek', [
    { t: 'kart', baslik: 'Sınıf', altF: function (p) {
        var sv = zindanOzet(p).enYuksek || 0
        return sv >= SINIF_ZINDAN ? 'İlk seçim bedava, değiştirmek 2.000 spur' : 'Zindanda ' + SINIF_ZINDAN + '. seviyeyi bitirince açılır (sen: ' + sv + ')'
      },
      deger: function (p) { var r = yetenekKaydi(p); return r.sinif ? SINIF_AD[r.sinif] : 'Seçilmedi' } },
    { t: 'kart', baslik: 'Meslek', alt: 'Tek meslek · ilk seçim bedava, değiştirmek 2.000 spur',
      deger: function (p) { var r = yetenekKaydi(p); return r.meslek ? MESLEK_AD[r.meslek] : 'Seçilmedi' } },
    { t: 'yazi', metin: 'Sınıf seç (her sınıfta 2 dal, biri açılır)' },
    { t: 'dugmeler', liste: [
      { yazi: 'Savaşçı', komut: 'sinif sec savasci' }, { yazi: 'Avcı', komut: 'sinif sec avci' }, { yazi: 'Nişancı', komut: 'sinif sec nisanci' }
    ] },
    { t: 'dugmeler', liste: [
      { yazi: 'Büyücü', komut: 'sinif sec buyucu' }, { yazi: 'Terbiyeci', komut: 'sinif sec terbiyeci' }, { yazi: 'Düellocu', komut: 'sinif sec duellocu' }
    ] },
    { t: 'yazi', metin: 'Meslek seç' },
    { t: 'dugmeler', liste: [
      { yazi: 'Madenci', komut: 'meslek sec madenci' }, { yazi: 'Zanaatkar', komut: 'meslek sec zanaatkar' }, { yazi: 'Simyacı', komut: 'meslek sec simyaci' }
    ] },
    { t: 'dugmeler', liste: [
      { yazi: 'Çiftçi', komut: 'meslek sec ciftci' }, { yazi: 'Balıkçı', komut: 'meslek sec balikci' }, { yazi: 'Tacir', komut: 'meslek sec tacir' }
    ] },
    { t: 'dugme', yazi: 'Demirci (tamir ustası)', komut: 'meslek sec demirci' },
    { t: 'yazi', metin: 'Sıfırlama: harcanan puan × 50 spur, puanlar geri gelir (dal değiştirmek için de)' },
    { t: 'dugmeler', liste: [
      { yazi: 'Ağaçları aç', komut: 'yetenek ac' },
      { yazi: 'Sınıfı sıfırla', komut: 'yetenek sifirla sinif' },
      { yazi: 'Mesleği sıfırla', komut: 'yetenek sifirla meslek' }
    ] }
  ])

  bolum('satislar', kayitBolumu('satis', 'Vendor Satışları', 'Tüm Vendor alım-satımları (son 500)', satisSatiri))
  bolum('hazine', kayitBolumu('hazine', 'Hazine Hareketleri', 'Devlete giren/çıkan para (son 500)', hazineSatiri))

  bolum('devlet', [
    { t: 'kart', baslik: 'Devlet Hazinesi', alt: 'Vergiler, cezalar ve savaş ilanları',
      deger: function (p) { return yetkili(p) ? para(banka(JUUID.fromString(HAZINE))) : 'Yetkili değil' } },
    { t: 'kart', baslik: 'Toplam Gelir', alt: 'Arazi + ölüm + tescil + cinayet + savaş',
      deger: function (p) { if (!yetkili(p)) return '-'; var g = veriOku(p, 'hazine_veri').gelir || {}; return para((g.arazi || 0) + (g.olum || 0) + (g.tescil || 0) + (g.cinayet || 0) + (g.savas || 0) + (g.zindan || 0)) } },
    { t: 'giris', ad: 'oyuncu', ipucu: 'Oyuncu adı' },
    { t: 'giris', ad: 'miktar', ipucu: 'Miktar (spur)', min: 1, max: 100000000 },
    { t: 'dugmeler', liste: [
      { yazi: 'Aktar', komut: 'devlet aktar {oyuncu} {miktar}' },
      { yazi: 'Bankama çek', komut: 'devlet cek {miktar}' },
      { yazi: 'Hareketler', komut: 'menu hazine' }
    ] }
  ])

  // ----------------------------- TIKLAMA (oyuncu tarafı) -----------------
  function istemci() { return Java.loadClass('net.minecraft.client.Minecraft').getInstance() }
  function durumMesaji(m) { var mc = istemci(); if (mc.player != null) mc.player.displayClientMessage(Component.literal(m), true) }
  function istemciKomut(komut, kapat) {
    var mc = istemci()
    if (mc.player == null) return
    if (kapat) { try { mc.player.closeMenu() } catch (e1) { mc.setScreen(null) } }
    mc.player.connection.sendCommand(komut)
  }
  function guvenli(fn) {
    return function (ev) {
      try { fn(ev) } catch (err) {
        console.error('[Arayuz] tiklama hatasi: ' + err)
        try { durumMesaji('Arayüz hatası: ' + err) } catch (e2) { }
      }
    }
  }
  function tiklaninca(el, fn) { el.addEventListener('mouseDown', guvenli(fn)); return el }
  function komutHazirla(sablon, durum, ogeler) {
    var hata = null
    var komut = sablon.replace(/\{(\w+)(\??)\}/g, function (m, ad, istege) {
      var v = String(durum[ad] == null ? '' : durum[ad]).trim()
      var tanim = ogeler.filter(function (o) { return o.t === 'giris' && o.ad === ad })[0]
      if (v === '' && istege) return ''
      if (v === '') { hata = (tanim && tanim.ipucu ? tanim.ipucu : 'Kutu') + ' boş.'; return '' }
      if (tanim && tanim.min != null && !/^\d+$/.test(v)) { hata = 'Kutuya sadece sayı yaz.'; return '' }
      if (!/^[A-Za-z0-9_]+$/.test(v)) { hata = 'Geçersiz karakter.'; return '' }
      return v
    })
    return hata ? { hata: hata } : { komut: komut.replace(/\s+/g, ' ').trim() }
  }

  // ----------------------------- PARÇALAR ---------------------------------
  function dugmeYap(metin, onTik) {
    var d = zemin(E(), R.dugme)
    olcu(d, function (l) { try { l['flexGrow(float)'](1) } catch (eg) { l.flexGrow(1) } }); olcu(d, function (l) { l['paddingAll(float)'](3) })
    olcu(d, function (l) { l['flexBasis(float)'](0) })   // düğmeler eşit genişlikte
    d.addChild(hizala(yazi(metin, R.baslik), Horizontal.LEFT))
    return tiklaninca(d, onTik)
  }
  function kartYap(o, sunucuda, p) {
    var kart = E()
    olcu(kart, function (l) { l['paddingAll(float)'](3) }); olcu(kart, function (l) { l['gapAll(float)'](1) })
    var ust = iki_uca(yatay(E()))
    olcu(ust, function (l) { l['gapAll(float)'](6) })
    var sol = E()
    duzen(sol, 'kucul', function (l) { l['flexShrink(float)'](1) })
    if (o.basF) sol.addChild(bagliYazi(R.acik, sunucuda, function () { var b = o.basF(p); return b ? '• ' + b : '' }))
    else sol.addChild(yazi('• ' + o.baslik, R.acik))
    if (o.altF) sol.addChild(bagliYazi(R.gri, sunucuda, function () { return o.altF(p) }))
    else sol.addChild(yazi(o.alt || '', R.gri))
    ust.addChild(sol)
    ust.addChild(sagaYasla(bagliYazi(R.baslik, sunucuda, function () { return o.deger(p) }), 130))
    kart.addChild(ust)
    // oran() null dönerse çubuk gizlenir (ör. boş savaş kartı)
    if (o.oran) kart.addChild(bagliYazi(R.acik, sunucuda, function () { var r = o.oran(p); return r == null ? Component.literal('') : cubuk(r) }, true))
    var cizgi = zemin(E(), R.cizgi)
    olcu(cizgi, function (l) { l['height(float)'](1) })
    kart.addChild(cizgi)
    return kart
  }

  // ----------------------------- EKRAN ------------------------------------
  function modularUI(kok, p) {
    var temalar = new ArrayList()
    var t = tema().INSTANCE.getStylesheet(tema().MC)
    if (t != null) temalar.add(t)
    var arayuz = UI['of(com.lowdragmc.lowdraglib2.gui.ui.UIElement,java.util.List,com.lowdragmc.lowdraglib2.gui.ui.UI$DynamicSizeProvider)'](kok, temalar, null)
    return ModularUI['of(com.lowdragmc.lowdraglib2.gui.ui.UI,net.minecraft.world.entity.player.Player)'](arayuz, p)
  }
  // Ekran kurulamazsa oyun ÇÖKMESİN: boş menü yerine basit bir hata ekranı açılır.
  function hataEkrani(p, err) {
    var kok = E()
    olcu(kok, function (l) { l['width(float)'](220) }); olcu(kok, function (l) { l['paddingAll(float)'](8) })
    kok.addChild(new Label().setText(Component.literal('Arayüz açılamadı.')))
    kok.addChild(new Label().setText(Component.literal(String(err).substring(0, 60))))
    return modularUI(kok, p)
  }

  // Giriş menüsü: sadece bölüm listesi; seçilen bölümün kendi ekranı açılır (/menu <id>).
  // Bölümler ayrı ekran olduğu için ileride bir bloğa da bağlanabilir (blok -> "menu <id>").
  LDLib2UI.player('arayuz:menu', function (e) {
    try {
      var ekran = E()
      olcu(ekran, function (l) { l['widthPercent(float)'](100) }); olcu(ekran, function (l) { l['heightPercent(float)'](100) })
      ortala(ekran); duzen(ekran, 'dikey_orta', function (l) { l.set(LP.JUSTIFY_CONTENT, TAC.CENTER) })
      var kok = zemin(E(), R.cerceve)
      olcu(kok, function (l) { l['width(float)'](MENU_EN) }); olcu(kok, function (l) { l['paddingAll(float)'](1) })
      ekran.addChild(kok)
      var panel = zemin(E(), R.yan)
      kok.addChild(panel)
      var ust = zemin(E(), R.ust)
      olcu(ust, function (l) { l['paddingAll(float)'](4) })
      ust.addChild(yazi('Sunucu Menüsü', R.baslik))
      panel.addChild(ust)
      var liste = E()
      olcu(liste, function (l) { l['paddingAll(float)'](3) }); olcu(liste, function (l) { l['gapAll(float)'](1) })
      BOLUMLER.forEach(function (b) {
        var m = E()
        olcu(m, function (l) { l['paddingAll(float)'](3) })
        m.addChild(yazi(b.ad, R.acik))
        zemin(m, R.dugme)
        tiklaninca(m, function () { istemciKomut(b.komut || ('menu ' + b.id), true) })
        liste.addChild(m)
      })
      panel.addChild(liste)
      e.modularUI = modularUI(ekran, e.player)
    } catch (err) {
      console.error('[Arayuz] giris menusu kurulamadi: ' + err)
      e.modularUI = hataEkrani(e.player, err)
    }
  })

  BOLUMLER.forEach(function (bol) {
    if (bol.komut) return
    LDLib2UI.player('arayuz:' + bol.id, function (e) {
      try { e.modularUI = ekranKur(e, bol) } catch (err) {
        console.error('[Arayuz] ekran kurulamadi (' + bol.id + '): ' + err)
        e.modularUI = hataEkrani(e.player, err)
      }
    })
  })

  function ekranKur(e, bol) {
    {
      var sunucuda = !e.level.isClientSide()
      var p = e.player
      var durum = {}
      var ogeler = ICERIK[bol.id] || []

      // Tam ekran şeffaf kök: LDLib görünen her elemanın alanını JEI'ye "dokunma" alanı olarak
      // bildiriyor; kök tüm ekranı kaplayınca JEI listesi yerleşemiyor -> menüde JEI görünmez.
      // Panel bu kökün ortasında durur. Yüzde ayarı tutmazsa eski hal (JEI görünür) devam eder.
      var ekran = E()
      olcu(ekran, function (l) { l['widthPercent(float)'](100) }); olcu(ekran, function (l) { l['heightPercent(float)'](100) })
      ortala(ekran); duzen(ekran, 'dikey_orta', function (l) { l.set(LP.JUSTIFY_CONTENT, TAC.CENTER) })

      // Dış çerçeve (1 px altın) > panel
      var kok = zemin(E(), R.cerceve)
      olcu(kok, function (l) { l['width(float)'](PANEL_EN) }); olcu(kok, function (l) { l['paddingAll(float)'](1) })
      ekran.addChild(kok)
      var panel = zemin(E(), R.panel)
      kok.addChild(panel)

      // Üst çubuk: solda "◀ Menü" (giriş menüsüne döner) + bölüm adı, sağda banka
      var ust = ortala(iki_uca(yatay(zemin(E(), R.ust))))
      olcu(ust, function (l) { l['paddingAll(float)'](4) })
      var sol = ortala(yatay(E()))
      olcu(sol, function (l) { l['gapAll(float)'](6) })
      var geri = zemin(E(), R.dugme)
      olcu(geri, function (l) { l['paddingAll(float)'](2) })
      geri.addChild(yazi('◀ Menü', R.acik))
      tiklaninca(geri, function () { istemciKomut('menu', true) })
      sol.addChild(geri)
      sol.addChild(yazi(bol.ad, R.baslik))
      ust.addChild(sol)
      ust.addChild(sagaYasla(bagliYazi(R.acik, sunucuda, function () { return para(banka(p.getUuid())) }), 120))
      panel.addChild(ust)

      var govde = yatay(E())
      panel.addChild(govde)
      var icerik = buyu(E())
      olcu(icerik, function (l) { l['paddingAll(float)'](4) }); olcu(icerik, function (l) { l['gapAll(float)'](2) })
      govde.addChild(icerik)

      ogeler.forEach(function (o) {
        if (o.t === 'kart') {
          icerik.addChild(kartYap(o, sunucuda, p))
        } else if (o.t === 'satir') {
          icerik.addChild(bagliYazi(R.acik, sunucuda, function () { return o.f(p, o.sira) }))
        } else if (o.t === 'yazi') {
          icerik.addChild(yazi(o.metin, R.gri))
        } else if (o.t === 'giris') {
          durum[o.ad] = ''
          if (o.ipucu) icerik.addChild(yazi(o.ipucu, R.gri))
          var tf = new TextField()
          if (o.min != null) tf.setNumbersOnlyInt(o.min, o.max); else tf.setAnyString()
          tf.setTextResponder(function (v) { durum[o.ad] = String(v) })
          icerik.addChild(tf)
        } else if (o.t === 'dugme' || o.t === 'dugmeler') {
          var sira = yatay(E())
          olcu(sira, function (l) { l['gapAll(float)'](3) })
          var liste = o.t === 'dugme' ? [o] : o.liste
          liste.forEach(function (d) {
            sira.addChild(dugmeYap(d.yazi, function () {
              var h = komutHazirla(d.komut, durum, ogeler)
              if (h.hata) { durumMesaji(h.hata); return }
              istemciKomut(h.komut, !d.acik)   // acik: menü kapanmaz (değer canlı güncellenir)
            }))
          })
          icerik.addChild(sira)
        }
      })

      return modularUI(ekran, p)
    }
  }

  console.info('[Arayuz] giris menusu + ' + BOLUMLER.length + ' ayri bolum ekrani kaydedildi')
})()
