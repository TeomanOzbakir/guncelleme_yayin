// =====================================================================
//  ARAYÜZ  -  kubejs/startup_scripts/arayuz.js
//  LDLib2 (ldlib2-neoforge-1.21.1-2.2.46) arayüz sistemi üzerine, Meal Mastery tarzı:
//  koyu panel, üst başlık çubuğu, solda bölüm menüsü, sağda kartlar
//  (başlık + açıklama + sağda değer + altta ilerleme çubuğu).
//
//  - Dosya startup_scripts'te: LDLib2 aynı ekranı sunucuda (veri) ve oyuncuda
//    (görüntü) kurar. OYUNCULARDA DA AYNI DOSYA OLMALI (guncelle.bat ile gelir).
//  - Açmak: /menu  veya  /menu <bölüm>   (server_scripts/arayuz_komut.js)
//  - Değişiklikten sonra sunucu ve oyunlar YENİDEN BAŞLATILMALI.
//
//  KubeJS/Rhino kuralları (canlı sunucuda öğrenildi):
//  - Fonksiyon içinde const/let yok, hep var.
//  - Aşırı yüklenmiş Java metotları (enum alanlar, UI.of...) imzasıyla açıkça seçilir:
//      l['flexDirection(dev.vfyjxf.taffy.style.FlexDirection)'](FD.ROW)
//  - Tıklamalar oyuncu tarafında çalışır ve komut gönderir (sunucu tıklaması çalışmıyor);
//    hata oyunu çökertmesin diye guvenli() ile sarılır. Player.closeContainer -> closeMenu.
//  - Sunucudan gelen veri sadece Component olarak bağlanır (sayı bağlamada Double/Float sorunu).
//
//  YENİ BÖLÜM: BOLUMLER listesine ekle + bolum('kimlik', [...öğeler]).
//  Öğeler:
//    { t: 'kart',  baslik: 'Başlık', alt: 'Açıklama', deger: f(p) -> yazı, oran: f(p) -> 0..1 (isteğe bağlı) }
//    { t: 'yazi',  metin: 'Sabit yazı' }
//    { t: 'giris', ad: 'miktar', ipucu: 'Miktar', min: 1, max: 1000000 }   (min yoksa serbest yazı)
//    { t: 'dugme', yazi: 'Kredi çek', komut: 'kredi cek {miktar}' }       (oyuncunun yetkisiyle)
//    { t: 'dugmeler', liste: [ {yazi, komut}, ... ] }                    (yan yana düğmeler)
//  f(p) fonksiyonları SADECE sunucuda çalışır ve her tick güncellenir.
//  Bölüm içeriği oyuncuya göre değişmemeli; yetkiye göre farklılık f(p) içinde yapılır.
//
//  !! Gerçek bir oyunda ÇALIŞTIRILARAK TEST EDİLMEDİ.
// =====================================================================

;(function () {
  var ModularUI = Java.loadClass('com.lowdragmc.lowdraglib2.gui.ui.ModularUI')
  var UI = Java.loadClass('com.lowdragmc.lowdraglib2.gui.ui.UI')
  var UIElement = Java.loadClass('com.lowdragmc.lowdraglib2.gui.ui.UIElement')
  var Label = Java.loadClass('com.lowdragmc.lowdraglib2.gui.ui.elements.Label')
  var TextField = Java.loadClass('com.lowdragmc.lowdraglib2.gui.ui.elements.TextField')
  var DataBindingBuilder = Java.loadClass('com.lowdragmc.lowdraglib2.gui.sync.bindings.impl.DataBindingBuilder')
  var ColorRectTexture = Java.loadClass('com.lowdragmc.lowdraglib2.gui.texture.ColorRectTexture')
  var FD = Java.loadClass('dev.vfyjxf.taffy.style.FlexDirection')
  var AI = Java.loadClass('dev.vfyjxf.taffy.style.AlignItems')
  var AC = Java.loadClass('dev.vfyjxf.taffy.style.AlignContent')
  var Component = Java.loadClass('net.minecraft.network.chat.Component')
  var JUUID = Java.loadClass('java.util.UUID')
  var ArrayList = Java.loadClass('java.util.ArrayList')
  var StylesheetManager = null
  function tema() { if (StylesheetManager == null) StylesheetManager = Java.loadClass('com.lowdragmc.lowdraglib2.gui.ui.style.StylesheetManager'); return StylesheetManager }

  // ----------------------------- RENKLER (Meal Mastery) -------------------
  function renk(rgb, alfa) { return (((alfa == null ? 0xFF : alfa) << 24) | rgb) | 0 }
  var R = {
    cerceve: renk(0x6B5530),   // ince altın çerçeve
    panel: renk(0x16130F, 0xEE),
    ust: renk(0x221B13, 0xF5),
    yan: renk(0x1B1712, 0xF5),
    secili: renk(0xC57B2A),
    cizgi: renk(0x3A3227),
    dugme: renk(0x2E261C),
    baslik: renk(0xE9A23B),    // turuncu-altın başlık
    acik: renk(0xE6DCC8),      // kart başlığı
    gri: renk(0x8F8676),       // açıklama
    koyu: renk(0x1A1208),      // seçili menü yazısı
    dolu: 0xE39B2E, bos: 0x4A3F31  // çubuk renkleri (RGB)
  }

  // ----------------------------- YARDIMCILAR ------------------------------
  function E() { return new UIElement() }
  function zemin(el, argb) { el.style(function (s) { s.background(new ColorRectTexture(argb)) }); return el }
  function yatay(el) { el.layout(function (l) { l['flexDirection(dev.vfyjxf.taffy.style.FlexDirection)'](FD.ROW) }); return el }
  function ortala(el) { el.layout(function (l) { l['alignItems(dev.vfyjxf.taffy.style.AlignItems)'](AI.CENTER) }); return el }
  function iki_uca(el) { el.layout(function (l) { l['justifyContent(dev.vfyjxf.taffy.style.AlignContent)'](AC.SPACE_BETWEEN) }); return el }
  function buyu(el) { el.layout(function (l) { l['flexGrow(float)'](1) }); return el }
  function yazi(metin, r) {
    var lb = new Label()
    lb.setText(Component.literal(metin))
    lb.textStyle(function (s) { s.textColor(r).textShadow(false) })
    return lb
  }
  // f() düz metin döner; hazirBilesen=true ise f() zaten bir Component döner (ör. renkli çubuk)
  function bagliYazi(r, sunucuda, f, hazirBilesen) {
    var lb = new Label()
    lb.textStyle(function (s) { s.textColor(r).textShadow(false) })
    lb.bind(DataBindingBuilder.componentS2C(function () {
      if (!sunucuda) return Component.literal('')
      try { return hazirBilesen ? f() : Component.literal(String(f())) } catch (err) { return Component.literal('?') }
    }).build())
    return lb
  }
  // Metin çubuğu: turuncu dolu + koyu boş kareler (ProgressBar sayı bağlaması Double/Float yüzünden kullanılmıyor)
  var CUBUK_UZ = 30
  function cubuk(oran) {
    var o = Math.max(0, Math.min(1, Number(oran) || 0))
    var n = Math.round(o * CUBUK_UZ)
    var dolu = Component.literal(new Array(n + 1).join('▬')).withColor(R.dolu)
    var bos = Component.literal(new Array(CUBUK_UZ - n + 1).join('▬')).withColor(R.bos)
    return dolu['append(net.minecraft.network.chat.Component)'](bos)
  }

  // ----------------------------- SUNUCU VERİLERİ --------------------------
  var HAZINE = '5f0c2d1e-7a3b-4e9c-8d6f-1b2a3c4d5e6f'
  var Numismatics = null, OPAC = null
  function banka(uuid) {
    if (Numismatics == null) Numismatics = Java.loadClass('dev.ithundxr.createnumismatics.Numismatics')
    var h = Numismatics.BANK.getAccount(uuid)
    return h ? h.getBalance() : 0
  }
  function claimSayisi(p) {
    if (OPAC == null) OPAC = Java.loadClass('xaero.pac.common.server.api.OpenPACServerAPI')
    var m = OPAC.get(p.server).getServerClaimsManager()
    return m.hasPlayerInfo(p.getUuid()) ? m.getPlayerInfo(p.getUuid()).getClaimCount() : 0
  }
  function veriOku(p, anahtar) {
    var s = p.server.persistentData.getString(anahtar)
    if (!s) return {}
    try { return JSON.parse(s) } catch (e) { return {} }
  }
  function borcKaydi(p) { var d = veriOku(p, 'borc_veri'); return (d.o || {})[String(p.getUuid())] || null }
  function vergiKaydi(p) { return (veriOku(p, 'vergi_veri').kayitlar || {})[String(p.getUuid())] || null }
  function para(n) { return String(Math.floor(n)).replace(/\B(?=(\d{3})+(?!\d))/g, '.') + ' spur' }
  function sure(ms) { var dk = Math.max(0, Math.floor(ms / 60000)); var g = Math.floor(dk / 1440); return (g > 0 ? g + ' g ' : '') + Math.floor((dk % 1440) / 60) + ' sa ' + (dk % 60) + ' dk' }
  function yetkili(p) { return p.createCommandSourceStack().hasPermission(2) }

  // ----------------------------- BÖLÜMLER ---------------------------------
  var BOLUMLER = [
    { id: 'ana', ad: 'Genel' },
    { id: 'kredi', ad: 'Kredi & Borç' },
    { id: 'vergi', ad: 'Arazi Vergisi' },
    { id: 'savas', ad: 'Savaş' },
    { id: 'devlet', ad: 'Devlet' }
  ]
  var ICERIK = {}
  function bolum(id, ogeler) { ICERIK[id] = ogeler }

  bolum('ana', [
    { t: 'kart', baslik: 'Banka', alt: 'Numismatics hesabındaki para', deger: function (p) { return para(banka(p.getUuid())) } },
    { t: 'kart', baslik: 'Kredi Notu', alt: 'Limitini ve faizini belirler',
      deger: function (p) { var r = borcKaydi(p); return (r ? r.not : 500) + ' / 1000' },
      oran: function (p) { var r = borcKaydi(p); return (r ? r.not : 500) / 1000 } },
    { t: 'kart', baslik: 'Borç', alt: 'Ödenmeyen cezalar, günlük %2 faiz',
      deger: function (p) { var r = borcKaydi(p); return r && r.borc > 0 ? para(Math.ceil(r.borc)) : 'Yok' } },
    { t: 'kart', baslik: 'Arazi', alt: 'Claim edilen chunk ve günlük vergi',
      deger: function (p) { var n = claimSayisi(p); return n + ' chunk · ' + para(n * 25) + '/gün' } },
    { t: 'kart', baslik: 'Savaşlar', alt: 'Sunucudaki aktif ve hazırlıktaki savaşlar',
      deger: function (p) { return String((veriOku(p, 'savas_veri').savaslar || []).length) } }
  ])

  bolum('kredi', [
    { t: 'kart', baslik: 'Kredi Notu', alt: '300 altı: kredi yok · 900+: 50.000 spur, %3',
      deger: function (p) { var r = borcKaydi(p); return (r ? r.not : 500) + ' / 1000' },
      oran: function (p) { var r = borcKaydi(p); return (r ? r.not : 500) / 1000 } },
    { t: 'kart', baslik: 'Aktif Kredi', alt: '7 günlük taksit, bankadan otomatik',
      deger: function (p) { var r = borcKaydi(p); return r && r.kredi ? 'Kalan ' + para(r.kredi.kalan) : 'Yok' },
      oran: function (p) { var r = borcKaydi(p); if (!r || !r.kredi) return 0; var top = r.kredi.taksit * 7; return 1 - r.kredi.kalan / top } },
    { t: 'kart', baslik: 'Borç', alt: 'Borç varken kredi çekilemez',
      deger: function (p) { var r = borcKaydi(p); return r && r.borc > 0 ? para(Math.ceil(r.borc)) : 'Yok' } },
    { t: 'giris', ad: 'miktar', ipucu: 'Miktar (spur)', min: 1, max: 1000000 },
    { t: 'dugmeler', liste: [
      { yazi: 'Kredi çek', komut: 'kredi cek {miktar}' },
      { yazi: 'Krediyi kapat', komut: 'kredi ode' },
      { yazi: 'Ayrıntı', komut: 'kredi durum' }
    ] }
  ])

  bolum('vergi', [
    { t: 'kart', baslik: 'Arazi', alt: 'Chunk başına günde 25 spur',
      deger: function (p) { var n = claimSayisi(p); return n + ' chunk · ' + para(n * 25) + '/gün' } },
    { t: 'kart', baslik: 'Ön Ödeme', alt: 'Bu chunk sayısıyla kalan süre (çubuk: 1 hafta)',
      deger: function (p) {
        var r = vergiKaydi(p); var n = claimSayisi(p)
        if (!r) return 'Kayıt yok'
        if (r.askida) return 'ASKIDA'
        if (n <= 0) return para(Math.max(0, r.kredi || 0))
        return sure(Math.max(0, r.kredi || 0) / (n * 25) * 86400000)
      },
      oran: function (p) { var r = vergiKaydi(p); var n = claimSayisi(p); if (!r || n <= 0) return 0; return (Math.max(0, r.kredi || 0) / (n * 25)) / 7 } },
    { t: 'kart', baslik: 'Otomatik Ödeme', alt: 'Süre bitince bankadan bir günlük kesilir',
      deger: function (p) { var r = vergiKaydi(p); return r && r.auto === false ? 'Kapalı' : 'Açık' } },
    { t: 'dugmeler', liste: [
      { yazi: '1 gün', komut: 'vergi ode gun' },
      { yazi: '1 hafta', komut: 'vergi ode hafta' },
      { yazi: '1 ay', komut: 'vergi ode ay' }
    ] },
    { t: 'dugmeler', liste: [
      { yazi: 'Otomatik aç', komut: 'vergi otomatik ac' },
      { yazi: 'Otomatik kapat', komut: 'vergi otomatik kapat' }
    ] }
  ])

  function savasKarti(i) {
    return { t: 'kart',
      baslik: '',
      basF: function (p) { var s = (veriOku(p, 'savas_veri').savaslar || [])[i]; return s ? s.a.ad + '  vs  ' + s.b.ad : (i === 0 ? 'Savaş yok' : '') },
      altF: function (p) { var s = (veriOku(p, 'savas_veri').savaslar || [])[i]; if (!s) return ''; return s.durum === 'hazirlik' ? 'Hazırlık: ' + sure(s.baslangic - Date.now()) : 'Aktif · kalan ' + sure(s.son - Date.now()) },
      deger: function (p) { var s = (veriOku(p, 'savas_veri').savaslar || [])[i]; return s ? s.skor.a + ' - ' + s.skor.b : '' },
      oran: function (p) { var s = (veriOku(p, 'savas_veri').savaslar || [])[i]; return s ? Math.max(s.skor.a, s.skor.b) / 10 : 0 } }
  }
  bolum('savas', [
    savasKarti(0), savasKarti(1),
    { t: 'giris', ad: 'oyuncu', ipucu: 'Karşı oyuncu adı' },
    { t: 'dugmeler', liste: [
      { yazi: 'Savaş ilan et', komut: 'savas ilan {oyuncu}' },
      { yazi: 'Barış', komut: 'savas baris {oyuncu}' },
      { yazi: 'Teslim ol', komut: 'savas teslim {oyuncu}' }
    ] }
  ])

  bolum('devlet', [
    { t: 'kart', baslik: 'Devlet Hazinesi', alt: 'Vergiler, cezalar ve savaş ilanları',
      deger: function (p) { return yetkili(p) ? para(banka(JUUID.fromString(HAZINE))) : 'Yetkili değil' } },
    { t: 'kart', baslik: 'Toplam Gelir', alt: 'Arazi + ölüm + tescil + cinayet + savaş',
      deger: function (p) { if (!yetkili(p)) return '-'; var g = veriOku(p, 'hazine_veri').gelir || {}; return para((g.arazi || 0) + (g.olum || 0) + (g.tescil || 0) + (g.cinayet || 0) + (g.savas || 0)) } },
    { t: 'giris', ad: 'oyuncu', ipucu: 'Oyuncu adı' },
    { t: 'giris', ad: 'miktar', ipucu: 'Miktar (spur)', min: 1, max: 100000000 },
    { t: 'dugmeler', liste: [
      { yazi: 'Aktar', komut: 'devlet aktar {oyuncu} {miktar}' },
      { yazi: 'Bankama çek', komut: 'devlet cek {miktar}' },
      { yazi: 'Hareketler', komut: 'devlet durum' }
    ] }
  ])

  // ----------------------------- TIKLAMA (oyuncu tarafı) -----------------
  function istemci() { return Java.loadClass('net.minecraft.client.Minecraft').getInstance() }
  function durumMesaji(m) { var mc = istemci(); if (mc.player != null) mc.player.displayClientMessage(Component.literal(m), true) }
  function istemciKomut(komut, kapat) {
    var mc = istemci()
    if (mc.player == null) return
    if (kapat) { try { mc.player.closeMenu() } catch (e1) { mc.setScreen(null) } }
    mc.player.connection.sendCommand(komut)
  }
  function guvenli(fn) {
    return function (ev) {
      try { fn(ev) } catch (err) {
        console.error('[Arayuz] tiklama hatasi: ' + err)
        try { durumMesaji('Arayüz hatası: ' + err) } catch (e2) { }
      }
    }
  }
  function tiklaninca(el, fn) { el.addEventListener('mouseDown', guvenli(fn)); return el }
  function komutHazirla(sablon, durum, ogeler) {
    var hata = null
    var komut = sablon.replace(/\{(\w+)\}/g, function (m, ad) {
      var v = String(durum[ad] == null ? '' : durum[ad]).trim()
      var tanim = ogeler.filter(function (o) { return o.t === 'giris' && o.ad === ad })[0]
      if (v === '') { hata = (tanim && tanim.ipucu ? tanim.ipucu : 'Kutu') + ' boş.'; return '' }
      if (tanim && tanim.min != null && !/^\d+$/.test(v)) { hata = 'Kutuya sadece sayı yaz.'; return '' }
      if (!/^[A-Za-z0-9_]+$/.test(v)) { hata = 'Geçersiz karakter.'; return '' }
      return v
    })
    return hata ? { hata: hata } : { komut: komut }
  }

  // ----------------------------- PARÇALAR ---------------------------------
  function dugmeYap(metin, onTik) {
    var d = ortala(zemin(E(), R.dugme))
    d.layout(function (l) { l['flexGrow(float)'](1); l['paddingAll(float)'](3) })
    d.addChild(yazi(metin, R.baslik))
    return tiklaninca(d, onTik)
  }
  function kartYap(o, sunucuda, p) {
    var kart = E()
    kart.layout(function (l) { l['paddingAll(float)'](3); l['gapAll(float)'](1) })
    var ust = iki_uca(yatay(E()))
    var sol = E()
    if (o.basF) sol.addChild(bagliYazi(R.acik, sunucuda, function () { return '• ' + o.basF(p) }))
    else sol.addChild(yazi('• ' + o.baslik, R.acik))
    if (o.altF) sol.addChild(bagliYazi(R.gri, sunucuda, function () { return o.altF(p) }))
    else sol.addChild(yazi(o.alt || '', R.gri))
    ust.addChild(sol)
    ust.addChild(bagliYazi(R.acik, sunucuda, function () { return o.deger(p) }))
    kart.addChild(ust)
    if (o.oran) kart.addChild(bagliYazi(R.acik, sunucuda, function () { return cubuk(o.oran(p)) }, true))
    var cizgi = zemin(E(), R.cizgi)
    cizgi.layout(function (l) { l['height(float)'](1) })
    kart.addChild(cizgi)
    return kart
  }

  // ----------------------------- EKRAN ------------------------------------
  BOLUMLER.forEach(function (bol) {
    LDLib2UI.player('arayuz:' + bol.id, function (e) {
      var sunucuda = !e.level.isClientSide()
      var p = e.player
      var durum = {}
      var ogeler = ICERIK[bol.id] || []

      // Dış çerçeve (1 px altın) > panel
      var kok = zemin(E(), R.cerceve)
      kok.layout(function (l) { l['width(float)'](330); l['paddingAll(float)'](1) })
      var panel = zemin(E(), R.panel)
      kok.addChild(panel)

      // Üst çubuk: solda başlık, sağda bölüm adı + banka
      var ust = ortala(iki_uca(yatay(zemin(E(), R.ust))))
      ust.layout(function (l) { l['paddingAll(float)'](4) })
      ust.addChild(yazi('Sunucu Menüsü', R.baslik))
      ust.addChild(bagliYazi(R.acik, sunucuda, function () { return bol.ad + '  ·  ' + para(banka(p.getUuid())) }))
      panel.addChild(ust)

      // Gövde: solda menü, sağda içerik
      var govde = yatay(E())
      panel.addChild(govde)
      var yan = zemin(E(), R.yan)
      yan.layout(function (l) { l['width(float)'](78); l['paddingAll(float)'](3); l['gapAll(float)'](1) })
      BOLUMLER.forEach(function (b2) {
        var secili = b2.id === bol.id
        var m = E()
        m.layout(function (l) { l['paddingAll(float)'](2) })
        if (secili) zemin(m, R.secili)
        m.addChild(yazi(b2.ad, secili ? R.koyu : R.acik))
        if (!secili) tiklaninca(m, function () { istemciKomut('menu ' + b2.id, true) })
        yan.addChild(m)
      })
      govde.addChild(yan)

      var icerik = buyu(E())
      icerik.layout(function (l) { l['paddingAll(float)'](4); l['gapAll(float)'](2) })
      govde.addChild(icerik)

      ogeler.forEach(function (o) {
        if (o.t === 'kart') {
          icerik.addChild(kartYap(o, sunucuda, p))
        } else if (o.t === 'yazi') {
          icerik.addChild(yazi(o.metin, R.gri))
        } else if (o.t === 'giris') {
          durum[o.ad] = ''
          if (o.ipucu) icerik.addChild(yazi(o.ipucu, R.gri))
          var tf = new TextField()
          if (o.min != null) tf.setNumbersOnlyInt(o.min, o.max); else tf.setAnyString()
          tf.setTextResponder(function (v) { durum[o.ad] = String(v) })
          icerik.addChild(tf)
        } else if (o.t === 'dugme' || o.t === 'dugmeler') {
          var sira = yatay(E())
          sira.layout(function (l) { l['gapAll(float)'](3) })
          var liste = o.t === 'dugme' ? [o] : o.liste
          liste.forEach(function (d) {
            sira.addChild(dugmeYap(d.yazi, function () {
              var h = komutHazirla(d.komut, durum, ogeler)
              if (h.hata) { durumMesaji(h.hata); return }
              istemciKomut(h.komut, true)
            }))
          })
          icerik.addChild(sira)
        }
      })

      var temalar = new ArrayList()
      var t = tema().INSTANCE.getStylesheet(tema().MC)
      if (t != null) temalar.add(t)
      var arayuz = UI['of(com.lowdragmc.lowdraglib2.gui.ui.UIElement,java.util.List,com.lowdragmc.lowdraglib2.gui.ui.UI$DynamicSizeProvider)'](kok, temalar, null)
      e.modularUI = ModularUI['of(com.lowdragmc.lowdraglib2.gui.ui.UI,net.minecraft.world.entity.player.Player)'](arayuz, p)
    })
  })

  console.info('[Arayuz] ' + BOLUMLER.length + ' bolum kaydedildi (Meal Mastery stili)')
})()
