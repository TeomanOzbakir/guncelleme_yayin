// =====================================================================
// Modpack duzeltmeleri - Ice and Fire gumus alet basliklari
// Dosya: kubejs/startup_scripts/modpack_duzeltmeler_items.js
// (Overgeared x Ice and Fire eklentisi kurulu olmadigi icin eksikti.)
// =====================================================================

StartupEvents.registry('item', event => {
  event.create('kubejs:silver_axe_head')
  event.create('kubejs:silver_hoe_head')
  event.create('kubejs:silver_pickaxe_head')
  event.create('kubejs:silver_shovel_head')
  event.create('kubejs:silver_sword_blade')
})
