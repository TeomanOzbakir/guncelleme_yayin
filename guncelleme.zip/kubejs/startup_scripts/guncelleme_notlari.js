// =====================================================================
//  GÜNCELLEME NOTLARI  -  /menu > Güncellemeler
//  HER GÜNCELLEMEDE en üste yeni kayıt ekle (sürüm = oyuncu güncelleme numarası, guncelleme_hazirla.ps1).
//  Maddeler oyuncunun anlayacağı dille, kısa. Uzun madde arayüzde alt satıra kaydırılır.
// =====================================================================
global.guncellemeNotlari = [
  { surum: 71, tarih: '24.11.2026', maddeler: [
    'Başkan sistemi: başkanın adının önünde [Başkan] unvanı var. Başkan vergi oranlarını değiştirebilir ve hazineyi yönetir.',
    'Güncel vergi oranları: /vergi oran (menü > Vergi > Vergi oranları). Kira, dükkan/fabrika, araç vergisi, KDV, harç, ölüm vergisi ve tescil ücreti başkanın elinde; her değişiklik herkese duyurulur.',
    'Royal Zombie sadece zindan seviye 10\'un, Royal Enderman sadece seviye 25\'in boss\'u; başka seviyelerde çıkmıyorlar.',
    'Patlayan spawner artık 48-64 yerine 5-10 Spawner Chain düşürüyor. Önceki sürümdeki Rogue Spawner seyreltmesi geri alındı.'
  ] },
  { surum: 70, tarih: '24.11.2026', maddeler: [
    'Menüye Güncellemeler sekmesi eklendi: her güncellemede neler değiştiği burada.',
    'Royal Variations canavarları artık elit olarak çıkmıyor; bazıları zindanın seviye sonu boss\'u oldu (ör. Royal Zombie, Royal Enderman).',
    'Apotheosis\'in yeraltındaki sandıklı canavar spawner\'ları (Rogue Spawner) yaklaşık 6 kat daha seyrek (yeni keşfedilen yerlerde).',
    'Necromancer dalı Büyücü\'den Terbiyeci\'ye taşındı: Terbiyeci artık iki daldan birini seçiyor. Büyücü ve Terbiyeci ağaçları sıfırlandı, puanlar iade edildi.'
  ] },
  { surum: 69, tarih: '24.11.2026', maddeler: [
    'TaCZ silahları Demirci örsünde tamir edilebiliyor (önceki sürümde örs tarif bulamıyordu).',
    'Silah Bakım Kiti silahları artık tanıyor.',
    'DMR silahları (MK14, SKS, SCAR MK20, SPR15HB, M1866) Iron Ingot ile onarılabiliyor.'
  ] },
  { surum: 68, tarih: '24.11.2026', maddeler: [
    'Zindanda boss ve kat merdiveni artık her zaman katın en uzak odasında.',
    'Zindan ganimeti yenilendi: zümrüt, sikkeler (Bronz/Gümüş/Altın), Kadim Mücevher, mod malzemeleri, tasarımlar ve hazır sınıf ekipmanı (kendi sınıfından biraz daha sık).',
    'Zindan setleri: Shadow Steel, Refined Radiance (zindan 20-30) ve Shadow Radiance (40-60). Set bonusu sadece zindan canavarlarına karşı hasar azaltır.',
    'Setlerin tarifinde Kadim Kaplama var: Demirci, zindandan düşen Kadim Tasarım ile döver.',
    'Born in Chaos, Cataclysm, Mowzie\'s canavarları ve Iron\'s yapıları overworld\'den kalktı (yeni keşfedilen yerlerde); artık zindanın işi.',
    'Mithril cevheri kapandı, sadece zindandan çıkıyor.',
    'Reskillable seviyeleri düşürüldü (ör. elmas 15 -> 10, netherite 30 -> 20).',
    'Zindan canavarlarının seviye başı hasarı azaldı, elitler daha sert.',
    'Create QoL göğüslüğünün pervane, havada durma ve elytra özellikleri kapalı.'
  ] },
  { surum: 66, tarih: '24.11.2026', maddeler: [
    'Ice and Fire ve Spartan Fire metal silah/zırhları Demirci örsünde dövülüyor; organik olanlar Demirci bağlantısı istiyor.'
  ] },
  { surum: 65, tarih: '24.11.2026', maddeler: [
    'Silah üretimi yenilendi: silahlar daha pahalı ve kendi türünde farklı maliyetli; üst düzey silahlar zindan malzemesi istiyor.',
    'Silah parçalarını sadece Demirci (Silah Ustalığı düğümleri) dövebilir; vuruşların %35\'i ıska geçerse parça kırılır.',
    'Silah tamiri: kalıcı tamir Demirci\'de, sahada Silah Bakım Kiti ile geçici tamir.'
  ] },
  { surum: 64, tarih: '24.11.2026', maddeler: [
    'Sınıf ağaçları büyüdü, dallar artık birbirini dışlıyor. Elementalist sınıfı eklendi. Zanaatkar artık İnşaatçı.',
    'Zindan elitleri ayrı havuzdan geliyor; zindan duvarları kırılamıyor.'
  ] },
  { surum: 62, tarih: '24.11.2026', maddeler: [
    'Menü açılınca Genel paneli hazır açık; ekranın sağ altında paran görünüyor.',
    'Meslek ağacını bitirince ek meslek alınabiliyor (2000, 4000, 8000 spur).',
    'Iron\'s scroll\'ları sadece zindandan çıkıyor; artifact ihtimali %25 arttı.',
    'Create: Metallurgy eklendi (Brass, Constantan, Bronze alaşımları).',
    'Her sabah ekranda gün, arazi ve kira bilgisi çıkıyor.'
  ] },
  { surum: 60, tarih: '23.11.2026', maddeler: [
    'Performans: Kaleidoscope Grilling, Epic Fight ve Touch n Motion kaldırıldı.'
  ] }
]
