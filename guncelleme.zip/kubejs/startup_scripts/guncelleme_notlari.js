// =====================================================================
//  GÜNCELLEME NOTLARI  -  /menu > Güncellemeler
//  HER GÜNCELLEMEDE en üste yeni kayıt ekle (sürüm = oyuncu güncelleme numarası, guncelleme_hazirla.ps1).
//  Maddeler oyuncunun anlayacağı dille, kısa. Uzun madde arayüzde alt satıra kaydırılır.
// =====================================================================
global.guncellemeNotlari = [
  { surum: 91, tarih: '27.11.2026', maddeler: [
    'Zindan ganimeti değişti: canavar ve sandıklar sikke + üretim malzemesi düşürür; kat bekçisi, boss ve Şans Odası KASA verir (Sıradan / Nadir / Efsane).',
    'Kasayı açmak için Kasa Anahtarı gerekir (Sıradan/Nadir 1, Efsane 2). Ekipman, gem, scroll ve kartlar artık kasadan çıkar. Kasa zindan dışında sağ tıkla açılır.',
    'Zindan Tüccarı: sikkeyle anahtar, kasa, sikke bozdurma ve her gün değişen sınırlı teklifler.',
    'Gizli Dükkân: bazı zindanlarda en derin dallarda, haritada görünmeyen bir tüccar odası çıkar; daha nadir eşyalar satar.'
  ] },
  { surum: 90, tarih: '27.11.2026', maddeler: [
    'Türkçe yama: oyun dili Türkçe oldu, modlu eşyaların çoğunun adı Türkçe. Garip çeviri görürsen ekran görüntüsü at.',
    'Borsa: her coin\'in günlük artış/düşüş sınırı var (tavan/taban). Sınıra dayanan coin o gün daha fazla oynamaz.',
    'Banka binası: bankacı kendi claim\'inden 2 chunk\'ı banka binası yapabilir (/banka bina ekle). Bu chunk\'lar savaşta yağmalanmaz, antlaşmayla verilemez, borç haczine girmez.',
    'İşlevi olmayan /tescil komutu kaldırıldı.'
  ] },
  { surum: 89, tarih: '27.11.2026', maddeler: [
    'Yeni modlar: Living Wind (rüzgâr), Afterwear (aşınan eşyalar), Aeronautics: simulated copycats, Best in Pack (B tuşu: en iyi eşyalar), Toast Control (gereksiz bildirim kutuları kapalı).',
    'Silah ve büyü eşyalarının altında hangi sınıfın kullanabileceği, beceri kilidi olanlarda gereken beceri seviyesi yazıyor.',
    'Borsa: fiyatlar artık neredeyse tamamen piyasa şansına bağlı (oyuncu alım-satımının etkisi çok küçük). Grafik: Gün / Hafta / Ay.',
    'Borç yaptırımları gerçek saate göre: 4. saat gelirlerin %50\'si, 8. saat [BORÇLU] damgası, 16. saat gelirlerin tamamı, 24. saat kelle avı ve haciz.',
    'Borçluyken bankana yatan her para (satış, Vendor, transfer) kesintiye girer. Damgalı borçlu savaş ilan edemez, banka kuramaz, başkan olamaz.',
    'Banka kredileri 7 günde otomatik taksitle ödenir; ödenmeyen taksit borcuna yazılır.',
    'Forceload yapılmış araziler sadece sahibi oyundayken çalışır.',
    'Beceriler: Çeviklik (koşma/zıplama) ve büyüleme puanı artık işliyor.'
  ] },
  { surum: 88, tarih: '26.11.2026', maddeler: [
    'Create makinelerinin yağı bitince ya da başlığı kırılınca bildirim gelir (arazinin sahibine ve yakındaki oyunculara).',
    'Tabancayı artık her sınıf kullanabilir.',
    'Menü > Sınıf & Meslek > Beceriler\'den Reskillable ekranı açılabiliyor (kısayolu G).',
    'Life Mending büyüsü kapatıldı (Mending gibi). Better Combat kaldırıldı.',
    'Madencilik Makinesi 2 kat stres çeker (RPM başına 128 su).',
    'Zindan: özel şartla öldürülebilen canavarlar çıkarıldı (Harbinger, Ancient Remnant, Ignited Revenant, Ferrous Wroughtnaut, Grottol).'
  ] },
  { surum: 87, tarih: '26.11.2026', maddeler: [
    'Zindan odaları artık chunk\'a tam oturuyor (16x16), kapılar 4 blok geniş.',
    'Boss bölümü 2x3 chunk: önce giriş salonu, sonra 2x2 chunk arena; arenaya giriş tam ortadan.'
  ] },
  { surum: 86, tarih: '26.11.2026', maddeler: [
    'Sunucu kuralları yazıldı: Menü > Rehber > Kurallar. Claim\'siz yerler korumasız (yarı anarşi). Cezaları OP verir (/ceza).',
    'Savaşta düşmanla çatışınca 30 sn geri sayım başlar (ekranın altında); bu sürede oyundan çıkan ölür, cesedi yerinde kalır.',
    'Zindan temaları: Çökmüş Maden, Kemik Mahzeni, Kabile Ormanı, Donmuş Hapishane, Firavun Mezarı, Lanetli Hasat, Batık Tapınak, Kül Kalesi, Derin Karanlık, Kaos Katedrali, Büyücü Kalesi, Antik Fabrika, Hiçlik Kulesi, Dread Kalesi. Tema seviyeye göre seçilir; canavarlar ve odalar ona göre.',
    'Zindan: başarısız ya da yarıda bırakılan koşudan sonra 10 dk yeni zindana girilemez. Başkasının koşusuna girilemez.',
    'Girişteki gereksiz mod mesajları kapatıldı (CSC, Create QoL, Best in Pack, Distant Horizons, Pufferfish yeni puan mesajı).'
  ] },
  { surum: 85, tarih: '25.11.2026', maddeler: [
    'Beceriler (Reskillable) 1-10 kademe: bakır 1, demir 2, çelik/titanyum 3, elmas 4, ... netherite 7, dragonsteel ve Cataclysm boss eşyaları 8, zindan setleri 9-10. Seviye atlamak iş + XP seviyesi ister (ikisi de seviyeyle doğrusal artar). Eski seviyelerin yeni ölçeğe çevrildi.',
    'Silah becerisi artık ateşli silahla canavar vurdukça gelişir.',
    'Pufferfish: her yetenek puanı 1 XP seviyesi de harcar (XP yetmezse düğüm açılmaz). Yetenek ağaçları dairesel (spiral) görünümde.',
    'Canavarlardan %30 daha az XP düşer.',
    'Zindan dengesi: 1. seviyede 120 canlı canavarlar bitti; canavar canı ve hasarı artık seviyeye göre ölçülü.',
    'Zindan sandıklarından ve boss\'lardan trim şablonları, müzik diskleri ve netherite yükseltme şablonu çıkabiliyor.',
    'Iron\'s büyüleri Black Hole ve Pocket Dimension kapatıldı. Apotheosis yükseltme şablonları kaldırıldı.',
    'Slice and Dice sprinkler menzili 32. Uçaklar: Lift Fix artık çalışıyor (Copycat Wing kaldırıldı), kaldırma kuvveti artırıldı.',
    'Kaldırılan modlar: Saturn, Cupboard, Frequency, Aeronautics Preflight Checklist, Create Aeronautics Copycat Wing.',
    'Tuş atamaları: önemsiz mod tuşları bir kez boşa alındı (oyun, silah, sesli sohbet, harita, Create ve büyü tuşları duruyor).'
  ] },
  { surum: 84, tarih: '25.11.2026', maddeler: [
    'Yeni meslekler: Aşçı (yemek pişir/üret, fazladan yemek şansı) ve Mühendis (3 dal: Fabrika, Havacılık, Ağır Sanayi; ilk dal hemen, sonraki dal öncekini bitirince). Çiftçi\'nin yemek dalı Aşçı\'ya geçti, yerine Hayvancılık geldi.',
    'Sınıf silahları: her sınıf kendi silahını kullanır (Savaşçı ağır yakın dövüş ve kalkan, Avcı yay ve hançer, Nişancı ateşli silah, Büyücü/Elementalist büyü, Terbiyeci mızrak ve yay). Sınıfsızken vanilla kılıç, yay, arbalet, kalkan ve tabanca.',
    'Menüye Rehber bölümü ve görev kitabı (FTB Quests: Başlangıç, Zindan Yolu, Ekonomi).',
    'Zindan: haftalık ödül (her pazartesi en iyi 3 ekip, Menü > Zindan > Bu Hafta). Zindan Deposu\'nda eşyalar artık yığın halinde.',
    'Başkana Ekonomi Paneli (para arzı, en zenginler, borçlar, son 7 gün).',
    'Güncelleyici, Java ayarın boşsa ZGC açar (çökmeleri azaltır).'
  ] },
  { surum: 82, tarih: '25.11.2026', maddeler: [
    'Building Gadgets 2 eklendi (inşa, değiştirme, kopyala-yapıştır, kes-yapıştır, yıkım aletleri). Kullanmak için İnşaat becerisi gerekir (5 / 7 / 10 / 13).',
    'Create: The Air War titanyum aletleri artık Overgeared usulü: titanyum külçeyi fırında kızdır, dövme örsünde başlığı döv, başlık + çubuk = alet. Titanyum, kükürt ve amalgam cevherleri madencilik puanı verir.',
    'Better Combat: Overgeared dövme çekici, oltalar ve aletler artık silah sayılmıyor (örs mini oyunu bozulmasın diye).',
    'Zindanda 13 yeni üretim malzemesi düşüyor: Paslı Zincir, Mezar Mumu, Zindan İpeği (1-20), Kara Demir, Gölge Derisi, Yankı Taşı (11-35), Lanetli Kehribar, Ruh İpi, Mühürlü Rün Taşı (26-60), Yıldız Demiri, Hiçlik Parçası, Ejder Kanı (51+) ve sadece boss ile kat bekçisinden Kadim Çekirdek. Şimdilik Selling Bin\'de satılır; ileride ekipman tariflerinde kullanılacak.'
  ] },
  { surum: 80, tarih: '25.11.2026', maddeler: [
    'Düzeltme: Pufferfish yetenek ağaçları yüklenmiyordu (yeni Meslekler ağacındaki bir tanım hatası). Sınıf ve meslek ağaçları geri geldi.'
  ] },
  { surum: 79, tarih: '25.11.2026', maddeler: [
    'Düzeltme: menü, /arazi, /vergi, /savas, /kredi, /sinif gibi komutlar sunucuda hiç yüklenmiyordu (betik hatası). /arazi\'nin eskiden beri çalışmamasının sebebi de buydu.',
    'Düzeltme: JEI\'de bir eşyanın tarifine bakınca oyun çöküyordu (Petrol\'s Parts kütüphanesi). Mod duruyor, sorunlu kısmı kapatıldı.',
    'K tuşu artık sadece Sınıf & Meslek ekranını açar: K\'deki shader aç/kapat (Iris), Rotation Lock (Quark) ve diğer atamalar bir kez boşa alındı. İstersen Kontroller\'den başka tuşa koyabilirsin.'
  ] },
  { surum: 78, tarih: '25.11.2026', maddeler: [
    'Menü tamamen yenilendi (Y): solda bölümler, üstte sekmeler, oyuncu/banka/savaş seçimleri açılır listeden; yazı yazmak çok azaldı. Komut sonucu menünün altında görünür.',
    'Banka bölümü: Hesabım (mevduat yatır/çek), Transfer (oyuncuya para gönder, harç %1), Günlük (gelen/giden transferler), Kredi & Borç (devletten veya bir bankadan kredi; borç seçip öde), Bankalar, Bankacı (başvuru onayı, faiz, duyuru, defter), Banka Kur.',
    'Bankadan kredi: oyuncu başvurur, bankacı onaylayınca para bankanın kasasından gelir; borç bankacının faiziyle deftere yazılır.',
    'Arazi bölümü sadeleşti (sadece Kirala + kategori). Kira her gün bankadan otomatik kesilir. /arazi komutlarının çalışmaması düzeltildi.',
    'Yeni Vergiler bölümü: tüm oranlar ve sana etkisi. OP ve başkanın her şeyi tek "Yönetim" bölümünde (hazine, vergi oranları, teftiş, savaş onayı, borsa kasası).',
    'Savaş bölümü sekmelere ayrıldı: Savaşlar, İlan & Barış, Antlaşma, Müttefik, Kelle Ödülü.',
    'Haksız cinayet cezası: 500 spur; öldürenin serveti 10.000\'i her ikiye katlayışında ceza da ikiye katlanır.',
    'Zindan: bir seviyeyi bitirince sonraki kalıcı açılır (sigil gerekmez). Sadece 10, 25, 50, 75, 100 sigil ister. Yeni Rekorlar sekmesi: her seviyeyi kim, kaç dakikada bitirdi.',
    'K tuşu: Sınıf & Meslek ekranı (oradan Pufferfish ağaçlarına). Meslekler Pufferfish\'te tek ağaçta: kökünü açtığın meslek seçilir; bir meslek ağacını bitirince ücretsiz bir meslek daha açılır. Eski meslek seviyelerin taşındı.',
    'Düellocu sınıfı kaldırıldı (Düellocu olanlar yeni sınıfını ücretsiz seçer).',
    'Reskillable becerileri artık XP ile değil işi yaparak gelişir (kazmak, kesmek, blok koymak, savaşmak, hasat...). İlerleme: K > Beceriler. Eksik silah/zırh kilitleri eklendi.',
    'Apotheosis yükseltme şablonları: demir eşya Elmas şablonuyla doğrudan elmasa yükselir (efsun ve affix\'ler korunur); işe yaramayan altın basamağı kalktı.',
    'Üretilemeyen Spartan silahları (tin, electrum, invar ve myrmex) kaldırıldı; zencefilli içecekler ve plastik boru artık üretilebiliyor.',
    'Yeni modlar: Petrol\'s Parts, Create: Flight Control, Create: The Air War, Better Combat.'
  ] },
  { surum: 77, tarih: '25.11.2026', maddeler: [
    'Cataclysm yapılarındaki boss\'lar ve sandıklar yine kendi malzemelerini veriyor: Ancient Metal, Cursium, Essence of the Storm (zindanda da çıkmaya devam ediyor).'
  ] },
  { surum: 76, tarih: '24.11.2026', maddeler: [
    'Cataclysm (Acropolis, Ancient Factory, Cursed Pyramid, Frosted Prison, Sunken City, Amethyst Nest) ve Mowzie\'s yapıları overworld\'e geri döndü (yeni keşfedilen yerlerde). Bu modların canavarları yine kendiliğinden doğmuyor; sadece yapılarda.'
  ] },
  { surum: 75, tarih: '24.11.2026', maddeler: [
    'Borsa ekranı yenilendi (menü > Borsa veya /borsaekran): solda coin listesi ve portföyün, sağda büyük fiyat grafiği (2 / 6 / 24 saat, fareyle üzerine gelince fiyat ve zaman).',
    'Al/Sat paneli: spur veya adet yaz, +100 / +1000 / Tümü ve %25 / %50 / Hepsi kısayolları, ne kadar alacağının tahmini, satış bekleme süresi ve işlem sonucu ekranda.',
    'Altta son 3 borsa haberi. Ekran açıkken veriler 2 saniyede bir tazelenir.'
  ] },
  { surum: 74, tarih: '24.11.2026', maddeler: [
    'Açılışta çökme düzeltildi: sunucunun 3 kendi modu (bakım, piyasa, zindan) bozuk paketlenmişti.'
  ] },
  { surum: 72, tarih: '24.11.2026', maddeler: [
    'BORSA açıldı (menü > Borsa veya /borsa): 4 coin var. Dişli sakin, Petro sanayi coin\'i, Kılıç savaşta hareketlenir, Uçuk çok oynak.',
    'Fiyatlar her dakika değişir: trend dönemleri, sohbete düşen haberler, oyuncuların alım-satımı fiyatı iter (etkisi zamanla söner).',
    'Al: /borsa al <coin> <spur> · Sat: /borsa sat <coin> <adet|hepsi> · Portföy: /borsa portfoy · Coin göndermek: /borsa gonder <oyuncu> <coin> <adet>.',
    'Alınan coin en az 10 dakika tutulmadan satılamaz. Alış-satış farkı %0,5, komisyon %1 (başkan değiştirebilir: /vergi oran borsa).',
    'Karşı taraf Borsa Kasası: başkan hazineden besler (/borsa kasa yatir). Kasa boşsa satış yapılamaz.',
    'Madencilik Makinesi (Machine Maintenance sekmesi): Create gücüyle döndükçe Dişli üretir. Sunucunun günlük üretimi sabit, makineler güçleri oranında paylaşır; üretim zamanla yarılanır.'
  ] },
  { surum: 71, tarih: '24.11.2026', maddeler: [
    'Başkan sistemi: başkanın adının önünde [Başkan] unvanı var. Başkan vergi oranlarını değiştirebilir ve hazineyi yönetir.',
    'Güncel vergi oranları: /vergi oran (menü > Vergi > Vergi oranları). Kira, dükkan/fabrika, araç vergisi, KDV, harç, ölüm vergisi ve tescil ücreti başkanın elinde; her değişiklik herkese duyurulur.',
    'Royal Zombie sadece zindan seviye 10\'un, Royal Enderman sadece seviye 25\'in boss\'u; başka seviyelerde çıkmıyorlar.',
    'Patlayan spawner artık 48-64 yerine 5-10 Spawner Chain düşürüyor. Önceki sürümdeki Rogue Spawner seyreltmesi geri alındı.'
  ] },
  { surum: 70, tarih: '24.11.2026', maddeler: [
    'Menüye Güncellemeler sekmesi eklendi: her güncellemede neler değiştiği burada.',
    'Royal Variations canavarları artık elit olarak çıkmıyor; bazıları zindanın seviye sonu boss\'u oldu (ör. Royal Zombie, Royal Enderman).',
    'Apotheosis\'in yeraltındaki sandıklı canavar spawner\'ları (Rogue Spawner) yaklaşık 6 kat daha seyrek (yeni keşfedilen yerlerde).',
    'Necromancer dalı Büyücü\'den Terbiyeci\'ye taşındı: Terbiyeci artık iki daldan birini seçiyor. Büyücü ve Terbiyeci ağaçları sıfırlandı, puanlar iade edildi.'
  ] },
  { surum: 69, tarih: '24.11.2026', maddeler: [
    'TaCZ silahları Demirci örsünde tamir edilebiliyor (önceki sürümde örs tarif bulamıyordu).',
    'Silah Bakım Kiti silahları artık tanıyor.',
    'DMR silahları (MK14, SKS, SCAR MK20, SPR15HB, M1866) Iron Ingot ile onarılabiliyor.'
  ] },
  { surum: 68, tarih: '24.11.2026', maddeler: [
    'Zindanda boss ve kat merdiveni artık her zaman katın en uzak odasında.',
    'Zindan ganimeti yenilendi: zümrüt, sikkeler (Bronz/Gümüş/Altın), Kadim Mücevher, mod malzemeleri, tasarımlar ve hazır sınıf ekipmanı (kendi sınıfından biraz daha sık).',
    'Zindan setleri: Shadow Steel, Refined Radiance (zindan 20-30) ve Shadow Radiance (40-60). Set bonusu sadece zindan canavarlarına karşı hasar azaltır.',
    'Setlerin tarifinde Kadim Kaplama var: Demirci, zindandan düşen Kadim Tasarım ile döver.',
    'Born in Chaos, Cataclysm, Mowzie\'s canavarları ve Iron\'s yapıları overworld\'den kalktı (yeni keşfedilen yerlerde); artık zindanın işi.',
    'Mithril cevheri kapandı, sadece zindandan çıkıyor.',
    'Reskillable seviyeleri düşürüldü (ör. elmas 15 -> 10, netherite 30 -> 20).',
    'Zindan canavarlarının seviye başı hasarı azaldı, elitler daha sert.',
    'Create QoL göğüslüğünün pervane, havada durma ve elytra özellikleri kapalı.'
  ] },
  { surum: 66, tarih: '24.11.2026', maddeler: [
    'Ice and Fire ve Spartan Fire metal silah/zırhları Demirci örsünde dövülüyor; organik olanlar Demirci bağlantısı istiyor.'
  ] },
  { surum: 65, tarih: '24.11.2026', maddeler: [
    'Silah üretimi yenilendi: silahlar daha pahalı ve kendi türünde farklı maliyetli; üst düzey silahlar zindan malzemesi istiyor.',
    'Silah parçalarını sadece Demirci (Silah Ustalığı düğümleri) dövebilir; vuruşların %35\'i ıska geçerse parça kırılır.',
    'Silah tamiri: kalıcı tamir Demirci\'de, sahada Silah Bakım Kiti ile geçici tamir.'
  ] },
  { surum: 64, tarih: '24.11.2026', maddeler: [
    'Sınıf ağaçları büyüdü, dallar artık birbirini dışlıyor. Elementalist sınıfı eklendi. Zanaatkar artık İnşaatçı.',
    'Zindan elitleri ayrı havuzdan geliyor; zindan duvarları kırılamıyor.'
  ] },
  { surum: 62, tarih: '24.11.2026', maddeler: [
    'Menü açılınca Genel paneli hazır açık; ekranın sağ altında paran görünüyor.',
    'Meslek ağacını bitirince ek meslek alınabiliyor (2000, 4000, 8000 spur).',
    'Iron\'s scroll\'ları sadece zindandan çıkıyor; artifact ihtimali %25 arttı.',
    'Create: Metallurgy eklendi (Brass, Constantan, Bronze alaşımları).',
    'Her sabah ekranda gün, arazi ve kira bilgisi çıkıyor.'
  ] },
  { surum: 60, tarih: '23.11.2026', maddeler: [
    'Performans: Kaleidoscope Grilling, Epic Fight ve Touch n Motion kaldırıldı.'
  ] }
]
