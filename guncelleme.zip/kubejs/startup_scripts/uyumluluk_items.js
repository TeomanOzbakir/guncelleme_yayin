// =====================================================================
//  UYUMLULUK EŞYALARI  -  kubejs/startup_scripts/uyumluluk_items.js
//  2026-11-25: Create: The Air War titanyum aletleri Overgeared düzenine uyarlandı (gümüş aletler gibi):
//  titanyum külçe fırında kızar -> Overgeared örsünde başlık dövülür -> başlık + çubuk = alet.
//  Tarifler/etiketler: server_scripts/uyumluluk.js. Dokular Overgeared demir dokularından boyandı.
// =====================================================================
StartupEvents.registry('item', function (event) {
  event.create('kubejs:heated_titanium_ingot').displayName('Heated Titanium Ingot')
  event.create('kubejs:titanium_axe_head').displayName('Titanium Axe Head')
  event.create('kubejs:titanium_hoe_head').displayName('Titanium Hoe Head')
  event.create('kubejs:titanium_pickaxe_head').displayName('Titanium Pickaxe Head')
  event.create('kubejs:titanium_shovel_head').displayName('Titanium Shovel Head')
})
