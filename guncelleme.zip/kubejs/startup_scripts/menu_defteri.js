// =====================================================================
//  SUNUCU DEFTERİ + MENÜ TUŞU  -  kubejs/startup_scripts/menu_defteri.js
//  - kubejs:sunucu_defteri : sağ tıklayınca /menu açılır (server_scripts/arayuz_komut.js).
//    Yeni oyunculara ilk girişte verilir; tarif: book + gold_nugget.
//  - "Sunucu menüsünü aç" tuşu (varsayılan Y), Ayarlar > Kontroller > Sunucu'dan değiştirilir.
//    Basınca oyuncu tarafı /menu komutunu gönderir (client_scripts/menu_tusu.js).
//  SUNUCUDA VE OYUNCULARDA AYNI DOSYA OLMALI (yeni eşya = kayıt eşleşmesi).
// =====================================================================

StartupEvents.registry('item', function (event) {
  event.create('kubejs:sunucu_defteri')
    .texture('minecraft:item/writable_book')
    .unstackable()
})

// Tuş kaydı sadece oyuncu tarafında vardır; sunucuda KeyBindEvents tanımlı olmayabilir.
if (typeof KeyBindEvents !== 'undefined') {
  try {
    KeyBindEvents.registry(function (event) {
      // Tuş adı GLFW biçiminde olmalı: 'KEY_Y' ('Y' tanınmaz, tuş atanmamış kalır).
      // Kimlik 'sunucu_menusu'ndan değişti: eski sürüm options.txt'ye "atanmamış" olarak kaydedildi.
      event.register('sunucu_menu_ac').defaultKey('KEY_Y').inGame().category('key.categories.sunucu')
    })
  } catch (err) { console.warn('[Menu] tus kaydi yapilamadi: ' + err) }
}
