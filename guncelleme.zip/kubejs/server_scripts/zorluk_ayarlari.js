// =====================================================================
// Zorluk ayarlari - zararli yaratiklar
// Dosya: kubejs/server_scripts/zorluk_ayarlari.js
//
// "Zararli yaratik" = oyunun MONSTER kategorisindeki her yaratik (zombi,
// iskelet, creeper, ghast, wither ve modlarin dusmanlari). Inek, koylu,
// golem, evcil hayvanlar ve oyuncular etkilenmez.
//
//  - CAN_CARPANI 2.0  : yaratik dunyaya girdiginde gercek maksimum canina
//                       kalici bir "+%100 temel can" degistiricisi eklenir
//                       (Mob Settings'in de kullandigi yontem). Jade dogru
//                       cani gosterir. Ayni degistirici ikinci kez eklenmez.
//  - HASAR_CARPANI 1.3: yaratigin verdigi her hasar 1.3 ile carpilir
//                       (kilic/pence, ok, ates topu, creeper patlamasi dahil).
//
// Degerleri degistirip /reload yazabilirsiniz. CAN_CARPANI degisikligi
// sadece yeni dogan yaratiklara uygulanir. Kapatmak icin dosyayi silin;
// zaten guclenmis yaratiklar oyle kalir, yenileri normal dogar.
// =====================================================================

const CAN_CARPANI = 2.0
const HASAR_CARPANI = 1.3

const Attributes = Java.loadClass('net.minecraft.world.entity.ai.attributes.Attributes')
const AttributeModifier = Java.loadClass('net.minecraft.world.entity.ai.attributes.AttributeModifier')
const Operation = Java.loadClass('net.minecraft.world.entity.ai.attributes.AttributeModifier$Operation')
const ResourceLocation = Java.loadClass('net.minecraft.resources.ResourceLocation')
const CAN_ID = ResourceLocation.fromNamespaceAndPath('silahparca', 'zorluk_can')

// 2x can: gercek maksimum can
EntityEvents.spawned(event => {
  var e = event.entity
  if (!e.isLiving() || !e.isMonster()) return
  if (e.getTags().contains('zindan')) return   // zindan canavarlari: sunucu_zindan modu kendi olcekler (2x dahil)
  var can = e.getAttribute(Attributes.MAX_HEALTH)
  if (can == null || can.hasModifier(CAN_ID)) return
  can.addPermanentModifier(new AttributeModifier(CAN_ID, CAN_CARPANI - 1.0, Operation.ADD_MULTIPLIED_BASE))
  e.setHealth(e.getMaxHealth())
})

// 1.3x hasar: saldiran (ok/ates topu atan dahil) zararli bir yaratiksa
EntityEvents.beforeHurt(event => {
  var attacker = event.source.getActual()
  if (attacker != null && attacker.isLiving() && attacker.isMonster() && !attacker.getTags().contains('zindan')) {
    event.setDamage(event.damage * HASAR_CARPANI)
  }
})

console.info('[zorluk_ayarlari] zararli yaratiklar: ' + CAN_CARPANI + 'x gercek can, ' + HASAR_CARPANI + 'x hasar')

// 2026-11-25 (kullanıcı): canavarlardan %30 daha az XP düşer (oyuncu ölümü hariç)
NativeEvents.onEvent('net.neoforged.neoforge.event.entity.living.LivingExperienceDropEvent', function (event) {
  try {
    var e = event.entity
    if (e == null || e.isPlayer()) return
    var x = event.getDroppedExperience()
    if (x > 0) event.setDroppedExperience(Math.floor(x * 0.7 + Math.random()))   // olasılıklı yuvarlama: ortalama tam %70
  } catch (err) { console.error('[Zorluk] xp: ' + err) }
})
