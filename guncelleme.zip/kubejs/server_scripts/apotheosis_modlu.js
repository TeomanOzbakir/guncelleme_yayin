// =====================================================================
//  APOTHEOSIS: HER MODUN SİLAH VE ZIRHI AFFIX'Lİ ÇIKSIN (2026-11-24)
//  Apotheosis affix'li ekipmanı sadece data/apotheosis/affix_loot_entries listesindeki eşyalardan
//  üretir; listede yalnızca vanilla eşyalar vardı. Bu betik sunucu verisi yüklenirken (açılış, /reload)
//  tüm eşya kayıtlarını tarar, Apotheosis'in affix verebildiği (LootCategory) modlu silah, alet, zırh,
//  yay, arbalet ve kalkanları güçlerine göre vanilla ile aynı kademelere ekler.
//   Alet/silah: malzeme saldırı bonusu (taş 1, demir 2, elmas 3, netherite 4)
//   Zırh: savunma / elmas parçası + sertlik / 3 (deri-zincir < 0.6 < demir < 0.95 < elmas < 1.85 < netherite)
//  Kademeler: haven (1-10), frontier (11-25), ascent (26-50), summit (51-75), pinnacle (76+)
//  Hariç: minecraft (Apotheosis'te zaten var), TaCZ, yaratıcı/test eşyaları, hayvan zırhları.
// =====================================================================
ServerEvents.generateData('after_mods', function (event) {
  var BuiltInRegistries = Java.loadClass('net.minecraft.core.registries.BuiltInRegistries')
  var ItemStack = Java.loadClass('net.minecraft.world.item.ItemStack')
  var ArmorItem = Java.loadClass('net.minecraft.world.item.ArmorItem')
  var AnimalArmorItem = Java.loadClass('net.minecraft.world.item.AnimalArmorItem')
  var TieredItem = Java.loadClass('net.minecraft.world.item.TieredItem')
  var SwordItem = Java.loadClass('net.minecraft.world.item.SwordItem')
  var DiggerItem = Java.loadClass('net.minecraft.world.item.DiggerItem')
  var ProjectileWeaponItem = Java.loadClass('net.minecraft.world.item.ProjectileWeaponItem')
  var ShieldItem = Java.loadClass('net.minecraft.world.item.ShieldItem')
  var TridentItem = Java.loadClass('net.minecraft.world.item.TridentItem')
  var JsonParser = Java.loadClass('com.google.gson.JsonParser')
  var LootCategory = null
  try { LootCategory = Java.loadClass('dev.shadowsoffire.apotheosis.loot.LootCategory') } catch (e) { LootCategory = null }

  var HARIC_AD = ['minecraft', 'tacz', 'apotheosis']
  var HARIC_KELIME = ['creative', 'debug', 'admin', 'test_', '_spawn_egg']
  // Vanilla ağırlıklarıyla aynı oranlar (modlu eşya sayısı çok olduğundan biraz düşük)
  var KADEME = {
    dusuk: { haven: { weight: 12 }, frontier: { weight: 6 } },
    demir: { frontier: { weight: 15 }, ascent: { weight: 6 }, summit: { weight: 6 } },
    elmas: { ascent: { weight: 15 }, summit: { weight: 15 }, pinnacle: { weight: 3 } },
    netherite: { summit: { weight: 3 }, pinnacle: { weight: 15 } },
    menzilli: { weight: 6 },
    kalkan: { weight: 4 },
    ozel: { summit: { weight: 3 }, pinnacle: { weight: 5 } }   // kademesi ölçülemeyen yakın dövüş (boss silahları vb.)
  }
  var ELMAS = { HELMET: 3, CHESTPLATE: 8, LEGGINGS: 6, BOOTS: 3 }

  function kademeBul(it) {
    if (it instanceof ArmorItem) {
      var tur = String(it.getType().name())
      var en = ELMAS[tur]
      if (!en || it.getDefense() <= 0) return null
      var puan = it.getDefense() / en + it.getToughness() / 3
      return puan < 0.6 ? 'dusuk' : puan < 0.95 ? 'demir' : puan < 1.85 ? 'elmas' : 'netherite'
    }
    if (it instanceof ShieldItem) return 'kalkan'
    if (it instanceof ProjectileWeaponItem) return 'menzilli'
    if (it instanceof TridentItem) return 'ozel'
    if (it instanceof TieredItem) {
      var b = it.getTier().getAttackDamageBonus()
      return b < 1.5 ? 'dusuk' : b < 2.5 ? 'demir' : b < 3.5 ? 'elmas' : 'netherite'
    }
    return 'ozel'
  }
  function uygunMu(it, st) {
    if (it instanceof AnimalArmorItem) return false
    if (LootCategory != null) {
      try { return !LootCategory.forItem(st).isNone() } catch (e) { /* etiketler henüz bağlı değilse sınıfa bak */ }
    }
    return it instanceof ArmorItem || it instanceof SwordItem || it instanceof DiggerItem ||
      it instanceof ProjectileWeaponItem || it instanceof ShieldItem || it instanceof TridentItem
  }

  var sayac = {}
  var toplam = 0
  var it2 = BuiltInRegistries.ITEM.entrySet().iterator()
  while (it2.hasNext()) {
    var giris = it2.next()
    var id = giris.getKey().location()
    var ns = String(id.getNamespace()), yol = String(id.getPath())
    if (HARIC_AD.indexOf(ns) >= 0) continue
    var atla = false
    for (var i = 0; i < HARIC_KELIME.length; i++) if (yol.indexOf(HARIC_KELIME[i]) >= 0) atla = true
    if (atla) continue
    var esya = giris.getValue()
    try {
      if (!(esya instanceof ArmorItem || esya instanceof TieredItem || esya instanceof ProjectileWeaponItem ||
        esya instanceof ShieldItem || esya instanceof TridentItem)) continue
      var st = new ItemStack(esya)
      if (!uygunMu(esya, st)) continue
      var k = kademeBul(esya)
      if (k == null) continue
      var veri = { type: 'apotheosis:affix_loot_entry', stack: { count: 1, id: ns + ':' + yol }, weights: KADEME[k] }
      event.json('apotheosis:affix_loot_entries/modlu/' + ns + '/' + yol, JsonParser.parseString(JSON.stringify(veri)))
      sayac[k] = (sayac[k] || 0) + 1
      toplam++
    } catch (err) { console.warn('[ApotheosisModlu] atlandi ' + ns + ':' + yol + ' - ' + err) }
  }
  console.info('[ApotheosisModlu] ' + toplam + ' modlu esya affix ganimetine eklendi: ' + JSON.stringify(sayac))
})
