// =====================================================================
//  VENDOR SATIŞ KAYDI  -  kubejs/server_scripts/satis_kayit.js
//  Numismatics Vendor (ve Creative Vendor) satışları için olay yok. Bu yüzden:
//  oyuncu Vendor'a sağ tıklayınca envanterindeki ürün sayısı alınır, 2 tick sonra
//  tekrar sayılır; fark varsa satış kaydedilir.
//    fark > 0 : oyuncu Vendor'dan satın aldı   (y: 'al')
//    fark < 0 : oyuncu Vendor'a sattı           (y: 'sat')
//  Kayıt: persistentData 'satis_kayit' = [{ t, a (oyuncu), s (vendor sahibi), i (ürün), n (adet), m (spur), y }]
//  Son 500 kayıt tutulur. Menüde "Satışlar" bölümünde sayfa sayfa görünür.
//  Not: Create ile otomatik (kol, huni) yapılan alımlar ve envanter doluyken yere düşen
//  ürünler kaydedilmez.
// =====================================================================
;(function () {
  var MAX_KAYIT = 500
  var VENDORLAR = { 'numismatics:vendor': true, 'numismatics:creative_vendor': true }
  var ItemStack = Java.loadClass('net.minecraft.world.item.ItemStack')
  var bekleyen = {}

  function kayitEkle(server, e) {
    var s = server.persistentData.getString('satis_kayit')
    var l = []
    if (s) { try { l = JSON.parse(s) } catch (x) { l = [] } }
    if (!Array.isArray(l)) l = []
    l.push(e)
    if (l.length > MAX_KAYIT) l = l.slice(-MAX_KAYIT)
    server.persistentData.putString('satis_kayit', JSON.stringify(l))
  }
  function adBul(server, uuid) {
    if (uuid == null) return 'Sunucu'
    var o = server.playerList.getPlayer(uuid)
    if (o != null) return String(o.username)
    var prof = server.getProfileCache().get(uuid)
    return prof.isPresent() ? String(prof.get().getName()) : String(uuid).substring(0, 8)
  }
  function say(p, ornek) {
    var inv = p.inventory
    var n = 0
    for (var i = 0; i < inv.getSlots(); i++) {
      var st = inv.getStackInSlot(i)
      if (!st.isEmpty() && ItemStack.isSameItemSameComponents(st, ornek)) n += st.getCount()
    }
    return n
  }

  BlockEvents.rightClicked(function (event) {
    try {
      if (!VENDORLAR[String(event.block.id)]) return
      var p = event.player
      var be = event.block.entity
      if (p == null || be == null) return
      var anahtar = String(event.block.pos) + '|' + String(p.getUuid())
      if (bekleyen[anahtar]) return   // iki el için iki kez tetiklenmesin
      var ornek = be.filterActsSpecial() ? be.getStackToSell() : be.getFilterItem()
      if (ornek == null || ornek.isEmpty()) return
      ornek = ornek.copy()
      var birim = Math.max(1, ornek.getCount())
      var fiyat = be.getTotalPrice()
      var creative = be.isCreativeVendor()
      var sahip = creative ? null : be.getDepositAccount()
      var once = say(p, ornek)
      bekleyen[anahtar] = true
      var server = event.server
      server.scheduleInTicks(2, function () {
        delete bekleyen[anahtar]
        try {
          var fark = say(p, ornek) - once
          if (fark === 0) return
          var adet = Math.abs(fark)
          var islem = Math.max(1, Math.round(adet / birim))
          kayitEkle(server, {
            t: Date.now(), a: String(p.username), s: creative ? 'Sunucu' : adBul(server, sahip),
            i: String(ornek.getHoverName().getString()), n: adet, m: islem * fiyat, y: fark > 0 ? 'al' : 'sat'
          })
        } catch (err) { console.error('[Satis] kayit hatasi: ' + err) }
      })
    } catch (err) { console.error('[Satis] ' + err) }
  })
})()
