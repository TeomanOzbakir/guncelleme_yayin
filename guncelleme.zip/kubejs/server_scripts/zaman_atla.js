// =====================================================================
//  ZAMAN ATLAMA (TEST)  -  kubejs/server_scripts/zaman_atla.js
//  2026-11-28 (kullanıcı): banka, kredi, mevduat, borç ve kira sistemlerini test etmek için zamanı ileri alma.
//  /zamanatla <saat>  (OP, 1-720): ekonomi sayaçlarına o kadar süre eklenir; bir dakika içinde işlenir:
//    - borc_kredi.js : devlet kredisi taksitleri, borç faizi, yaptırım saatleri, kredi notu (zatla_borc)
//    - banka_sistemi.js: banka kredi taksitleri, mevduat faizi, vadeli mevduat vadeleri (zatla_banka)
//    - vergi_sistemi.js: arazi kirası ve ödeme ek süresi (zatla_vergi); birikmiş kira dakikada 1 gün kesilir
//    - borsa_sistemi.js: o kadar dakikalık fiyat hareketi + günlük sınırların yenilenmesi (hemen, en fazla 7 gün)
//  Gerçek saat, Minecraft gün/gece, savaş süreleri ve zindan bekleme süreleri DEĞİŞMEZ.
//  Her kullanım tüm sunucuya duyurulur ve 'zaman_atla_kayit'e yazılır.
// =====================================================================
;(function () {
  ServerEvents.commandRegistry(function (event) {
    var Commands = event.commands
    var Arguments = event.arguments
    event.register(Commands.literal('zamanatla').requires(function (s) { return s.hasPermission(2) })
      .then(Commands.argument('saat', Arguments.INTEGER.create(event)).executes(function (ctx) {
        var server = ctx.source.server
        var saat = Arguments.INTEGER.getResult(ctx, 'saat')
        if (saat < 1 || saat > 720) { ctx.source.sendSystemMessage(Text.red(Text.ofString('Saat 1 ile 720 (30 gün) arasında olmalı.'))); return 0 }
        var ms = saat * 3600 * 1000
        ;['borc', 'banka', 'vergi'].forEach(function (k) {
          var eski = Number(server.persistentData.getString('zatla_' + k) || 0)
          server.persistentData.putString('zatla_' + k, String((eski > 0 ? eski : 0) + ms))
        })
        var borsa = ''
        try {
          var f = global.ortak ? global.ortak.get('borsaAtla') : null
          if (f) { var dk = Math.min(saat, 168) * 60; f(server, dk); borsa = ' Borsa ' + Math.floor(dk / 60) + ' saat ilerledi.' }
        } catch (e) { console.error('[ZamanAtla] borsa: ' + e); borsa = ' (borsa atlanamadı: ' + e + ')' }
        var kim = ctx.source.player != null ? String(ctx.source.player.username) : 'konsol'
        var kayit = []
        try { kayit = JSON.parse(server.persistentData.getString('zaman_atla_kayit') || '[]') } catch (e2) { kayit = [] }
        kayit = kayit.concat([{ t: Date.now(), saat: saat, kim: kim }]).slice(-50)
        server.persistentData.putString('zaman_atla_kayit', JSON.stringify(kayit))
        server.tell(Text.gold(Text.ofString('[Test] ' + kim + ' ekonomi zamanını ' + saat + ' saat ileri aldı: kredi taksitleri, borç faizi, mevduat faizi, vadeler ve kira 1 dakika içinde işlenir.' + borsa)))
        return 1
      })))
  })
})()
