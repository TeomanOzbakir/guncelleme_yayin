// =====================================================================
// Silah Uretim Sistemi - TaCZ mermi (25) ve aksesuar (98) tarifleri
// Dosya: kubejs/server_scripts/silah_uretim_mermi_aksesuar.js
//
// Mermi: bakir yerine kovan (pistol/rifle/heavy casing, shotshell hull),
//        mermi ucu (bullet / heavy bullet / kursun nugget / patlayici dolgu).
//        Kovan ve uc sayisi = cikan mermi sayisi. Barut ve nadir malzemeler aynen.
// Aksesuar: demir yerine parca (optic housing + lens, laser module, muzzle
//        device, suppressor baffles, bayonet blade, sarjor + yay, grip, stock).
// ammo_mod_* tariflerine dokunulmadi (demir icermiyorlar).
// 'result' bolumleri TaCZ'nin orijinal dosyalarindan birebir kopyalandi.
// Adetleri burada degistirip /reload yazmaniz yeterli. En fazla 12 malzeme.
// =====================================================================

const TARIFLER_EK = [
    {
        "id":  "tacz:ammo/12g",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:shotshell_hull"
                                       },
                              "count":  18
                          },
                          {
                              "item":  {
                                           "tag":  "c:nuggets/lead"
                                       },
                              "count":  18
                          },
                          {
                              "item":  {
                                           "tag":  "c:gunpowders"
                                       },
                              "count":  6
                          }
                      ],
        "result":  {
                       "type":  "ammo",
                       "group":  "shotgun_shells",
                       "id":  "tacz:12g",
                       "count":  18
                   }
    },
    {
        "id":  "tacz:ammo/22wmr",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_casing"
                                       },
                              "count":  100
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bullet"
                                       },
                              "count":  100
                          },
                          {
                              "item":  {
                                           "tag":  "c:gunpowders"
                                       },
                              "count":  2
                          }
                      ],
        "result":  {
                       "type":  "ammo",
                       "group":  "pd_cartridges",
                       "id":  "tacz:22wmr",
                       "count":  100
                   }
    },
    {
        "id":  "tacz:ammo/30_06",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_casing"
                                       },
                              "count":  32
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bullet"
                                       },
                              "count":  32
                          },
                          {
                              "item":  {
                                           "tag":  "c:gunpowders"
                                       },
                              "count":  6
                          }
                      ],
        "result":  {
                       "type":  "ammo",
                       "group":  "lc_specialized",
                       "id":  "tacz:30_06",
                       "count":  32
                   }
    },
    {
        "id":  "tacz:ammo/300blk",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_casing"
                                       },
                              "count":  45
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bullet"
                                       },
                              "count":  45
                          },
                          {
                              "item":  {
                                           "tag":  "c:gunpowders"
                                       },
                              "count":  3
                          }
                      ],
        "result":  {
                       "type":  "ammo",
                       "group":  "ifp_rifle_cartridges",
                       "id":  "tacz:300blk",
                       "count":  45
                   }
    },
    {
        "id":  "tacz:ammo/308",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_casing"
                                       },
                              "count":  60
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bullet"
                                       },
                              "count":  60
                          },
                          {
                              "item":  {
                                           "tag":  "c:gunpowders"
                                       },
                              "count":  10
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/lapis"
                                       }
                          }
                      ],
        "result":  {
                       "type":  "ammo",
                       "group":  "ifp_rifle_cartridges",
                       "id":  "tacz:308",
                       "count":  60
                   }
    },
    {
        "id":  "tacz:ammo/338",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:heavy_casing"
                                       },
                              "count":  18
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:heavy_bullet"
                                       },
                              "count":  18
                          },
                          {
                              "item":  {
                                           "tag":  "c:gunpowders"
                                       },
                              "count":  8
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/lapis"
                                       },
                              "count":  4
                          }
                      ],
        "result":  {
                       "type":  "ammo",
                       "group":  "lc_specialized",
                       "id":  "tacz:338",
                       "count":  18
                   }
    },
    {
        "id":  "tacz:ammo/357mag",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_casing"
                                       },
                              "count":  48
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bullet"
                                       },
                              "count":  48
                          },
                          {
                              "item":  {
                                           "tag":  "c:gunpowders"
                                       },
                              "count":  6
                          }
                      ],
        "result":  {
                       "type":  "ammo",
                       "group":  "lc_specialized",
                       "id":  "tacz:357mag",
                       "count":  48
                   }
    },
    {
        "id":  "tacz:ammo/40mm",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:heavy_casing"
                                       },
                              "count":  6
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:explosive_charge"
                                       },
                              "count":  6
                          },
                          {
                              "item":  {
                                           "tag":  "c:gunpowders"
                                       },
                              "count":  9
                          }
                      ],
        "result":  {
                       "type":  "ammo",
                       "group":  "explosives",
                       "id":  "tacz:40mm",
                       "count":  6
                   }
    },
    {
        "id":  "tacz:ammo/45_70",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_casing"
                                       },
                              "count":  36
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bullet"
                                       },
                              "count":  36
                          },
                          {
                              "item":  {
                                           "tag":  "c:gunpowders"
                                       },
                              "count":  7
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/lapis"
                                       },
                              "count":  5
                          }
                      ],
        "result":  {
                       "type":  "ammo",
                       "group":  "lc_specialized",
                       "id":  "tacz:45_70",
                       "count":  36
                   }
    },
    {
        "id":  "tacz:ammo/45acp",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_casing"
                                       },
                              "count":  30
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bullet"
                                       },
                              "count":  30
                          },
                          {
                              "item":  {
                                           "tag":  "c:gunpowders"
                                       },
                              "count":  2
                          }
                      ],
        "result":  {
                       "type":  "ammo",
                       "group":  "pd_cartridges",
                       "id":  "tacz:45acp",
                       "count":  30
                   }
    },
    {
        "id":  "tacz:ammo/46x30",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_casing"
                                       },
                              "count":  48
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bullet"
                                       },
                              "count":  48
                          },
                          {
                              "item":  {
                                           "tag":  "c:gunpowders"
                                       },
                              "count":  2
                          }
                      ],
        "result":  {
                       "type":  "ammo",
                       "group":  "pd_cartridges",
                       "id":  "tacz:46x30",
                       "count":  48
                   }
    },
    {
        "id":  "tacz:ammo/500mag",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:heavy_casing"
                                       },
                              "count":  32
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:heavy_bullet"
                                       },
                              "count":  32
                          },
                          {
                              "item":  {
                                           "tag":  "c:gunpowders"
                                       },
                              "count":  10
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/lapis"
                                       },
                              "count":  5
                          }
                      ],
        "result":  {
                       "type":  "ammo",
                       "group":  "lc_specialized",
                       "id":  "tacz:500mag",
                       "count":  32
                   }
    },
    {
        "id":  "tacz:ammo/50ae",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:heavy_casing"
                                       },
                              "count":  36
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:heavy_bullet"
                                       },
                              "count":  36
                          },
                          {
                              "item":  {
                                           "tag":  "c:gunpowders"
                                       },
                              "count":  7
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/lapis"
                                       },
                              "count":  5
                          }
                      ],
        "result":  {
                       "type":  "ammo",
                       "group":  "lc_specialized",
                       "id":  "tacz:50ae",
                       "count":  36
                   }
    },
    {
        "id":  "tacz:ammo/50bmg",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:heavy_casing"
                                       },
                              "count":  24
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:heavy_bullet"
                                       },
                              "count":  24
                          },
                          {
                              "item":  {
                                           "tag":  "c:gunpowders"
                                       },
                              "count":  20
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/lapis"
                                       },
                              "count":  12
                          },
                          {
                              "item":  {
                                           "tag":  "c:rods/blaze"
                                       }
                          }
                      ],
        "result":  {
                       "type":  "ammo",
                       "group":  "lc_specialized",
                       "id":  "tacz:50bmg",
                       "count":  24
                   }
    },
    {
        "id":  "tacz:ammo/545x39",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_casing"
                                       },
                              "count":  45
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bullet"
                                       },
                              "count":  45
                          },
                          {
                              "item":  {
                                           "tag":  "c:gunpowders"
                                       },
                              "count":  3
                          }
                      ],
        "result":  {
                       "type":  "ammo",
                       "group":  "ifp_rifle_cartridges",
                       "id":  "tacz:545x39",
                       "count":  45
                   }
    },
    {
        "id":  "tacz:ammo/556x45",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_casing"
                                       },
                              "count":  45
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bullet"
                                       },
                              "count":  45
                          },
                          {
                              "item":  {
                                           "tag":  "c:gunpowders"
                                       },
                              "count":  3
                          }
                      ],
        "result":  {
                       "type":  "ammo",
                       "group":  "ifp_rifle_cartridges",
                       "id":  "tacz:556x45",
                       "count":  45
                   }
    },
    {
        "id":  "tacz:ammo/57x28",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_casing"
                                       },
                              "count":  48
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bullet"
                                       },
                              "count":  48
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/lapis"
                                       },
                              "count":  5
                          },
                          {
                              "item":  {
                                           "tag":  "c:gunpowders"
                                       },
                              "count":  2
                          }
                      ],
        "result":  {
                       "type":  "ammo",
                       "group":  "pd_cartridges",
                       "id":  "tacz:57x28",
                       "count":  48
                   }
    },
    {
        "id":  "tacz:ammo/58x42",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_casing"
                                       },
                              "count":  40
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bullet"
                                       },
                              "count":  40
                          },
                          {
                              "item":  {
                                           "tag":  "c:gunpowders"
                                       },
                              "count":  3
                          }
                      ],
        "result":  {
                       "type":  "ammo",
                       "group":  "ifp_rifle_cartridges",
                       "id":  "tacz:58x42",
                       "count":  40
                   }
    },
    {
        "id":  "tacz:ammo/68x51fury",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_casing"
                                       },
                              "count":  40
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bullet"
                                       },
                              "count":  40
                          },
                          {
                              "item":  {
                                           "tag":  "c:gunpowders"
                                       },
                              "count":  5
                          }
                      ],
        "result":  {
                       "type":  "ammo",
                       "group":  "ifp_rifle_cartridges",
                       "id":  "tacz:68x51fury",
                       "count":  40
                   }
    },
    {
        "id":  "tacz:ammo/762x25",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_casing"
                                       },
                              "count":  45
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bullet"
                                       },
                              "count":  45
                          },
                          {
                              "item":  {
                                           "tag":  "c:gunpowders"
                                       },
                              "count":  2
                          }
                      ],
        "result":  {
                       "type":  "ammo",
                       "group":  "pd_cartridges",
                       "id":  "tacz:762x25",
                       "count":  45
                   }
    },
    {
        "id":  "tacz:ammo/762x39",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_casing"
                                       },
                              "count":  35
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bullet"
                                       },
                              "count":  35
                          },
                          {
                              "item":  {
                                           "tag":  "c:gunpowders"
                                       },
                              "count":  3
                          }
                      ],
        "result":  {
                       "type":  "ammo",
                       "group":  "ifp_rifle_cartridges",
                       "id":  "tacz:762x39",
                       "count":  35
                   }
    },
    {
        "id":  "tacz:ammo/762x54",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_casing"
                                       },
                              "count":  60
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bullet"
                                       },
                              "count":  60
                          },
                          {
                              "item":  {
                                           "tag":  "c:gunpowders"
                                       },
                              "count":  8
                          }
                      ],
        "result":  {
                       "type":  "ammo",
                       "group":  "ifp_rifle_cartridges",
                       "id":  "tacz:762x54",
                       "count":  60
                   }
    },
    {
        "id":  "tacz:ammo/792x57",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_casing"
                                       },
                              "count":  48
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bullet"
                                       },
                              "count":  48
                          },
                          {
                              "item":  {
                                           "tag":  "c:gunpowders"
                                       },
                              "count":  6
                          }
                      ],
        "result":  {
                       "type":  "ammo",
                       "group":  "ifp_rifle_cartridges",
                       "id":  "tacz:792x57",
                       "count":  48
                   }
    },
    {
        "id":  "tacz:ammo/9mm",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_casing"
                                       },
                              "count":  50
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bullet"
                                       },
                              "count":  50
                          },
                          {
                              "item":  {
                                           "tag":  "c:gunpowders"
                                       },
                              "count":  2
                          }
                      ],
        "result":  {
                       "type":  "ammo",
                       "group":  "pd_cartridges",
                       "id":  "tacz:9mm",
                       "count":  50
                   }
    },
    {
        "id":  "tacz:ammo/rpg_rocket",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:explosive_charge"
                                       },
                              "count":  3
                          },
                          {
                              "item":  {
                                           "tag":  "c:plates/steel"
                                       },
                              "count":  3
                          },
                          {
                              "item":  {
                                           "tag":  "c:gunpowders"
                                       },
                              "count":  12
                          }
                      ],
        "result":  {
                       "type":  "ammo",
                       "group":  "explosives",
                       "id":  "tacz:rpg_rocket",
                       "count":  3
                   }
    },
    {
        "id":  "tacz:attachments/bayonet_6h3",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:bayonet_blade"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "minecraft:logs"
                                       },
                              "count":  4
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:bayonet_6h3"
                   }
    },
    {
        "id":  "tacz:attachments/bayonet_m9",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:bayonet_blade"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "minecraft:logs"
                                       },
                              "count":  4
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:bayonet_m9"
                   }
    },
    {
        "id":  "tacz:attachments/deagle_golden_long_barrel",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  30
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:deagle_golden_long_barrel"
                   }
    },
    {
        "id":  "tacz:attachments/extended_mag_1",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:magazine_spring"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  4
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:extended_mag_1"
                   }
    },
    {
        "id":  "tacz:attachments/extended_mag_2",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:magazine_spring"
                                       },
                              "count":  2
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  8
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/lapis"
                                       },
                              "count":  8
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:extended_mag_2"
                   }
    },
    {
        "id":  "tacz:attachments/extended_mag_3",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:magazine_spring"
                                       },
                              "count":  3
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  12
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/diamond"
                                       },
                              "count":  3
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:extended_mag_3"
                   }
    },
    {
        "id":  "tacz:attachments/grip_cobra",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  3
                          },
                          {
                              "item":  {
                                           "tag":  "c:leathers"
                                       },
                              "count":  6
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:grip_cobra"
                   }
    },
    {
        "id":  "tacz:attachments/grip_magpul_afg",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  3
                          },
                          {
                              "item":  {
                                           "tag":  "c:leathers"
                                       },
                              "count":  4
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:grip_magpul_afg"
                   }
    },
    {
        "id":  "tacz:attachments/grip_magpul_afg_2",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  3
                          },
                          {
                              "item":  {
                                           "tag":  "c:leathers"
                                       },
                              "count":  4
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:grip_magpul_afg_2"
                   }
    },
    {
        "id":  "tacz:attachments/grip_osovets_black",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  3
                          },
                          {
                              "item":  {
                                           "tag":  "c:leathers"
                                       },
                              "count":  4
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:grip_osovets_black"
                   }
    },
    {
        "id":  "tacz:attachments/grip_rk0",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  3
                          },
                          {
                              "item":  {
                                           "tag":  "c:leathers"
                                       },
                              "count":  4
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:grip_rk0"
                   }
    },
    {
        "id":  "tacz:attachments/grip_rk1_b25u",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  4
                          },
                          {
                              "item":  {
                                           "tag":  "c:leathers"
                                       },
                              "count":  5
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:grip_rk1_b25u"
                   }
    },
    {
        "id":  "tacz:attachments/grip_rk6",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:leathers"
                                       },
                              "count":  1
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:grip_rk6"
                   }
    },
    {
        "id":  "tacz:attachments/grip_se_5",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  3
                          },
                          {
                              "item":  {
                                           "tag":  "c:leathers"
                                       },
                              "count":  4
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:grip_se_5"
                   }
    },
    {
        "id":  "tacz:attachments/grip_td",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  3
                          },
                          {
                              "item":  {
                                           "tag":  "c:leathers"
                                       },
                              "count":  4
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:grip_td"
                   }
    },
    {
        "id":  "tacz:attachments/grip_troy",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  2
                          },
                          {
                              "item":  {
                                           "tag":  "c:leathers"
                                       },
                              "count":  3
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:grip_troy"
                   }
    },
    {
        "id":  "tacz:attachments/grip_vertical_military",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  4
                          },
                          {
                              "item":  {
                                           "tag":  "c:leathers"
                                       },
                              "count":  5
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:grip_vertical_military"
                   }
    },
    {
        "id":  "tacz:attachments/grip_vertical_ranger",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  5
                          },
                          {
                              "item":  {
                                           "tag":  "c:leathers"
                                       },
                              "count":  6
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:grip_vertical_ranger"
                   }
    },
    {
        "id":  "tacz:attachments/grip_vertical_talon",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  3
                          },
                          {
                              "item":  {
                                           "tag":  "c:leathers"
                                       },
                              "count":  4
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:grip_vertical_talon"
                   }
    },
    {
        "id":  "tacz:attachments/laser_compact",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:laser_module"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/redstone"
                                       },
                              "count":  4
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:laser_compact"
                   }
    },
    {
        "id":  "tacz:attachments/laser_lopro",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:laser_module"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/redstone"
                                       },
                              "count":  4
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:laser_lopro"
                   }
    },
    {
        "id":  "tacz:attachments/laser_ngal",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:laser_module"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/redstone"
                                       },
                              "count":  4
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:laser_ngal"
                   }
    },
    {
        "id":  "tacz:attachments/laser_nightstick",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:laser_module"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/redstone"
                                       },
                              "count":  4
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:laser_nightstick"
                   }
    },
    {
        "id":  "tacz:attachments/laser_peq6",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:laser_module"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/redstone"
                                       },
                              "count":  4
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/amethyst"
                                       },
                              "count":  1
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:laser_peq6"
                   }
    },
    {
        "id":  "tacz:attachments/light_extended_mag_1",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:magazine_spring"
                                       },
                              "count":  1
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:light_extended_mag_1"
                   }
    },
    {
        "id":  "tacz:attachments/light_extended_mag_2",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:magazine_spring"
                                       },
                              "count":  2
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/lapis"
                                       },
                              "count":  8
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:light_extended_mag_2"
                   }
    },
    {
        "id":  "tacz:attachments/light_extended_mag_3",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:magazine_spring"
                                       },
                              "count":  3
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/lapis"
                                       },
                              "count":  8
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/quartz"
                                       },
                              "count":  4
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:light_extended_mag_3"
                   }
    },
    {
        "id":  "tacz:attachments/muzzle_brake_cthulhu",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:muzzle_device"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  5
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:muzzle_brake_cthulhu"
                   }
    },
    {
        "id":  "tacz:attachments/muzzle_brake_cyclone_d2",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:muzzle_device"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  4
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:muzzle_brake_cyclone_d2"
                   }
    },
    {
        "id":  "tacz:attachments/muzzle_brake_mastiff_sg",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:muzzle_device"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  4
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:muzzle_brake_mastiff_sg"
                   }
    },
    {
        "id":  "tacz:attachments/muzzle_brake_pioneer",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:muzzle_device"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  5
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:muzzle_brake_pioneer"
                   }
    },
    {
        "id":  "tacz:attachments/muzzle_brake_timeless50",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:muzzle_device"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/redstone"
                                       },
                              "count":  5
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:muzzle_brake_timeless50"
                   }
    },
    {
        "id":  "tacz:attachments/muzzle_brake_trex",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:muzzle_device"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  6
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:muzzle_brake_trex"
                   }
    },
    {
        "id":  "tacz:attachments/muzzle_choke_sg",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:muzzle_device"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  6
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:muzzle_choke_sg"
                   }
    },
    {
        "id":  "tacz:attachments/muzzle_compensator_trident",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:muzzle_device"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  4
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:muzzle_compensator_trident"
                   }
    },
    {
        "id":  "tacz:attachments/muzzle_silencer_knight_qd",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:suppressor_baffles"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:leathers"
                                       },
                              "count":  6
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/redstone"
                                       },
                              "count":  2
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:muzzle_silencer_knight_qd"
                   }
    },
    {
        "id":  "tacz:attachments/muzzle_silencer_mirage",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:suppressor_baffles"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/redstone"
                                       },
                              "count":  2
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:muzzle_silencer_mirage"
                   }
    },
    {
        "id":  "tacz:attachments/muzzle_silencer_phantom_s1",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:suppressor_baffles"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:leathers"
                                       },
                              "count":  6
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/redstone"
                                       },
                              "count":  2
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:muzzle_silencer_phantom_s1"
                   }
    },
    {
        "id":  "tacz:attachments/muzzle_silencer_ptilopsis",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:suppressor_baffles"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/redstone"
                                       },
                              "count":  2
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:muzzle_silencer_ptilopsis"
                   }
    },
    {
        "id":  "tacz:attachments/muzzle_silencer_sg",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:suppressor_baffles"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:leathers"
                                       },
                              "count":  5
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/redstone"
                                       },
                              "count":  2
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:muzzle_silencer_sg"
                   }
    },
    {
        "id":  "tacz:attachments/muzzle_silencer_socom_rc1",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:suppressor_baffles"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:leathers"
                                       },
                              "count":  6
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/redstone"
                                       },
                              "count":  2
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:muzzle_silencer_socom_rc1"
                   }
    },
    {
        "id":  "tacz:attachments/muzzle_silencer_ursus",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:suppressor_baffles"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:leathers"
                                       },
                              "count":  6
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/redstone"
                                       },
                              "count":  2
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:muzzle_silencer_ursus"
                   }
    },
    {
        "id":  "tacz:attachments/muzzle_silencer_vulture",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:suppressor_baffles"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:leathers"
                                       },
                              "count":  6
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/redstone"
                                       },
                              "count":  2
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:muzzle_silencer_vulture"
                   }
    },
    {
        "id":  "tacz:attachments/muzzle_silencer_wraith",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:suppressor_baffles"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:leathers"
                                       },
                              "count":  4
                          },
                          {
                              "item":  {
                                           "tag":  "minecraft:wool"
                                       },
                              "count":  2
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:muzzle_silencer_wraith"
                   }
    },
    {
        "id":  "tacz:attachments/scope_1866_4x",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:optic_housing"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:lens"
                                       },
                              "count":  4
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/copper"
                                       },
                              "count":  16
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:scope_1866_4x"
                   }
    },
    {
        "id":  "tacz:attachments/scope_1873_6x",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:optic_housing"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:lens"
                                       },
                              "count":  4
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/copper"
                                       },
                              "count":  16
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:scope_1873_6x"
                   }
    },
    {
        "id":  "tacz:attachments/scope_98k",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:optic_housing"
                                       },
                              "count":  2
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:lens"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/amethyst"
                                       },
                              "count":  1
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:scope_98k"
                   }
    },
    {
        "id":  "tacz:attachments/scope_acog_ta31",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:optic_housing"
                                       },
                              "count":  2
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:lens"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/amethyst"
                                       },
                              "count":  3
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/redstone"
                                       },
                              "count":  8
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:scope_acog_ta31"
                   }
    },
    {
        "id":  "tacz:attachments/scope_amg_10",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:optic_housing"
                                       },
                              "count":  3
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:lens"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/amethyst"
                                       },
                              "count":  8
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/glowstone"
                                       },
                              "count":  8
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/redstone"
                                       },
                              "count":  8
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:scope_amg_10"
                   }
    },
    {
        "id":  "tacz:attachments/scope_c79",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:optic_housing"
                                       },
                              "count":  2
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:lens"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/amethyst"
                                       },
                              "count":  3
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/redstone"
                                       },
                              "count":  8
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:scope_c79"
                   }
    },
    {
        "id":  "tacz:attachments/scope_contender",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:optic_housing"
                                       },
                              "count":  2
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:lens"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/amethyst"
                                       },
                              "count":  2
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:scope_contender"
                   }
    },
    {
        "id":  "tacz:attachments/scope_elcan_4x",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:optic_housing"
                                       },
                              "count":  2
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:lens"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/amethyst"
                                       },
                              "count":  5
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/redstone"
                                       },
                              "count":  10
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:scope_elcan_4x"
                   }
    },
    {
        "id":  "tacz:attachments/scope_hamr",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:optic_housing"
                                       },
                              "count":  3
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:lens"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/amethyst"
                                       },
                              "count":  4
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/redstone"
                                       },
                              "count":  10
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:scope_hamr"
                   }
    },
    {
        "id":  "tacz:attachments/scope_lpvo_1_6",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:optic_housing"
                                       },
                              "count":  2
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:lens"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/amethyst"
                                       },
                              "count":  4
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/glowstone"
                                       },
                              "count":  8
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/redstone"
                                       },
                              "count":  6
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:scope_lpvo_1_6"
                   }
    },
    {
        "id":  "tacz:attachments/scope_mk4ert",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:optic_housing"
                                       },
                              "count":  2
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:lens"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/amethyst"
                                       },
                              "count":  8
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/glowstone"
                                       },
                              "count":  8
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/redstone"
                                       },
                              "count":  8
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:scope_mk4ert"
                   }
    },
    {
        "id":  "tacz:attachments/scope_mk5hd",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:optic_housing"
                                       },
                              "count":  3
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:lens"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/amethyst"
                                       },
                              "count":  10
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/glowstone"
                                       },
                              "count":  8
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/redstone"
                                       },
                              "count":  8
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:scope_mk5hd"
                   }
    },
    {
        "id":  "tacz:attachments/scope_qmk152",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:optic_housing"
                                       },
                              "count":  2
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:lens"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/amethyst"
                                       },
                              "count":  8
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/redstone"
                                       },
                              "count":  10
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:scope_qmk152"
                   }
    },
    {
        "id":  "tacz:attachments/scope_reap_ir",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:optic_housing"
                                       },
                              "count":  2
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:lens"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/copper"
                                       },
                              "count":  12
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/amethyst"
                                       },
                              "count":  3
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/redstone"
                                       },
                              "count":  16
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/glowstone"
                                       },
                              "count":  12
                          },
                          {
                              "item":  {
                                           "item":  "minecraft:shroomlight"
                                       },
                              "count":  6
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:scope_reap_ir"
                   }
    },
    {
        "id":  "tacz:attachments/scope_retro_2x",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:optic_housing"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:lens"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/amethyst"
                                       },
                              "count":  1
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:scope_retro_2x"
                   }
    },
    {
        "id":  "tacz:attachments/scope_standard_8x",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:optic_housing"
                                       },
                              "count":  3
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:lens"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/amethyst"
                                       },
                              "count":  8
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/glowstone"
                                       },
                              "count":  8
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/redstone"
                                       },
                              "count":  8
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:scope_standard_8x"
                   }
    },
    {
        "id":  "tacz:attachments/scope_vudu",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:optic_housing"
                                       },
                              "count":  2
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:lens"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/amethyst"
                                       },
                              "count":  4
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/glowstone"
                                       },
                              "count":  8
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/redstone"
                                       },
                              "count":  6
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:scope_vudu"
                   }
    },
    {
        "id":  "tacz:attachments/scope_xl50",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:optic_housing"
                                       },
                              "count":  3
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:lens"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/copper"
                                       },
                              "count":  16
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/amethyst"
                                       },
                              "count":  12
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/redstone"
                                       },
                              "count":  24
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/glowstone"
                                       },
                              "count":  16
                          },
                          {
                              "item":  {
                                           "item":  "minecraft:shroomlight"
                                       },
                              "count":  8
                          },
                          {
                              "item":  {
                                           "item":  "minecraft:observer"
                                       },
                              "count":  2
                          },
                          {
                              "item":  {
                                           "item":  "minecraft:ender_eye"
                                       },
                              "count":  1
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:scope_xl50"
                   }
    },
    {
        "id":  "tacz:attachments/scope_xm157",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:optic_housing"
                                       },
                              "count":  3
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:lens"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/amethyst"
                                       },
                              "count":  12
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/glowstone"
                                       },
                              "count":  8
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/redstone"
                                       },
                              "count":  16
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/diamond"
                                       },
                              "count":  3
                          },
                          {
                              "item":  {
                                           "item":  "minecraft:observer"
                                       },
                              "count":  2
                          },
                          {
                              "item":  {
                                           "item":  "minecraft:ender_eye"
                                       },
                              "count":  1
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:scope_xm157"
                   }
    },
    {
        "id":  "tacz:attachments/shotgun_extended_mag_1",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:magazine_spring"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:plates/steel"
                                       },
                              "count":  1
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:shotgun_extended_mag_1"
                   }
    },
    {
        "id":  "tacz:attachments/shotgun_extended_mag_2",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:magazine_spring"
                                       },
                              "count":  2
                          },
                          {
                              "item":  {
                                           "tag":  "c:plates/steel"
                                       },
                              "count":  2
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  2
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:shotgun_extended_mag_2"
                   }
    },
    {
        "id":  "tacz:attachments/shotgun_extended_mag_3",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:magazine_spring"
                                       },
                              "count":  3
                          },
                          {
                              "item":  {
                                           "tag":  "c:plates/steel"
                                       },
                              "count":  3
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  5
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/lapis"
                                       },
                              "count":  8
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:shotgun_extended_mag_3"
                   }
    },
    {
        "id":  "tacz:attachments/sight_1p87",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:optic_housing"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:lens"
                                       },
                              "count":  2
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/redstone"
                                       },
                              "count":  4
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:sight_1p87"
                   }
    },
    {
        "id":  "tacz:attachments/sight_552",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:optic_housing"
                                       },
                              "count":  2
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:lens"
                                       },
                              "count":  4
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  5
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/redstone"
                                       },
                              "count":  6
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:sight_552"
                   }
    },
    {
        "id":  "tacz:attachments/sight_acro_pistol",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:optic_housing"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:lens"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/redstone"
                                       },
                              "count":  1
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:sight_acro_pistol"
                   }
    },
    {
        "id":  "tacz:attachments/sight_apm4s",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:optic_housing"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:lens"
                                       },
                              "count":  2
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/redstone"
                                       },
                              "count":  2
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:sight_apm4s"
                   }
    },
    {
        "id":  "tacz:attachments/sight_coyote",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:optic_housing"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:lens"
                                       },
                              "count":  2
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/redstone"
                                       },
                              "count":  4
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:sight_coyote"
                   }
    },
    {
        "id":  "tacz:attachments/sight_deltapoint_pistol",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:optic_housing"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:lens"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/redstone"
                                       },
                              "count":  1
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:sight_deltapoint_pistol"
                   }
    },
    {
        "id":  "tacz:attachments/sight_exp3",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:optic_housing"
                                       },
                              "count":  2
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:lens"
                                       },
                              "count":  4
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  5
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/redstone"
                                       },
                              "count":  8
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:sight_exp3"
                   }
    },
    {
        "id":  "tacz:attachments/sight_fastfire_pistol",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:optic_housing"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:lens"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/redstone"
                                       },
                              "count":  1
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:sight_fastfire_pistol"
                   }
    },
    {
        "id":  "tacz:attachments/sight_infitac_fmp13",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:optic_housing"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:lens"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/amethyst"
                                       },
                              "count":  2
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/redstone"
                                       },
                              "count":  8
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/glowstone"
                                       },
                              "count":  6
                          },
                          {
                              "item":  {
                                           "item":  "minecraft:shroomlight"
                                       },
                              "count":  4
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:sight_infitac_fmp13"
                   }
    },
    {
        "id":  "tacz:attachments/sight_okp7",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:optic_housing"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:lens"
                                       },
                              "count":  2
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/redstone"
                                       },
                              "count":  4
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:sight_okp7"
                   }
    },
    {
        "id":  "tacz:attachments/sight_pk06_pistol",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:optic_housing"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:lens"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/redstone"
                                       },
                              "count":  1
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:sight_pk06_pistol"
                   }
    },
    {
        "id":  "tacz:attachments/sight_rmr_dot",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:optic_housing"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:lens"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/redstone"
                                       },
                              "count":  1
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:sight_rmr_dot"
                   }
    },
    {
        "id":  "tacz:attachments/sight_sro_dot",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:optic_housing"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:lens"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/redstone"
                                       },
                              "count":  1
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:sight_sro_dot"
                   }
    },
    {
        "id":  "tacz:attachments/sight_srs_02",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:optic_housing"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:lens"
                                       },
                              "count":  2
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/redstone"
                                       },
                              "count":  2
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:sight_srs_02"
                   }
    },
    {
        "id":  "tacz:attachments/sight_t1",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:optic_housing"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:lens"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/redstone"
                                       },
                              "count":  1
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:sight_t1"
                   }
    },
    {
        "id":  "tacz:attachments/sight_t2",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:optic_housing"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:lens"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/redstone"
                                       },
                              "count":  1
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:sight_t2"
                   }
    },
    {
        "id":  "tacz:attachments/sight_uh1",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:optic_housing"
                                       },
                              "count":  2
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:lens"
                                       },
                              "count":  4
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  6
                          },
                          {
                              "item":  {
                                           "tag":  "c:dusts/redstone"
                                       },
                              "count":  8
                          },
                          {
                              "item":  {
                                           "item":  "minecraft:observer"
                                       },
                              "count":  2
                          },
                          {
                              "item":  {
                                           "item":  "minecraft:ender_eye"
                                       },
                              "count":  1
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:sight_uh1"
                   }
    },
    {
        "id":  "tacz:attachments/sniper_extended_mag_1",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:magazine_spring"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  6
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:sniper_extended_mag_1"
                   }
    },
    {
        "id":  "tacz:attachments/sniper_extended_mag_2",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:magazine_spring"
                                       },
                              "count":  2
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  12
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/lapis"
                                       },
                              "count":  12
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:sniper_extended_mag_2"
                   }
    },
    {
        "id":  "tacz:attachments/sniper_extended_mag_3",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:magazine_spring"
                                       },
                              "count":  3
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  16
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/quartz"
                                       },
                              "count":  8
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/diamond"
                                       },
                              "count":  5
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:sniper_extended_mag_3"
                   }
    },
    {
        "id":  "tacz:attachments/stock_ak12",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  4
                          },
                          {
                              "item":  {
                                           "tag":  "c:leathers"
                                       },
                              "count":  5
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:stock_ak12"
                   }
    },
    {
        "id":  "tacz:attachments/stock_carbon_bone_c5",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  3
                          },
                          {
                              "item":  {
                                           "tag":  "c:leathers"
                                       },
                              "count":  3
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:stock_carbon_bone_c5"
                   }
    },
    {
        "id":  "tacz:attachments/stock_heavy_ctr",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  5
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  4
                          },
                          {
                              "item":  {
                                           "tag":  "c:leathers"
                                       },
                              "count":  4
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:stock_heavy_ctr"
                   }
    },
    {
        "id":  "tacz:attachments/stock_heavy_spas_12",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  5
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  2
                          },
                          {
                              "item":  {
                                           "tag":  "c:leathers"
                                       },
                              "count":  4
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:stock_heavy_spas_12"
                   }
    },
    {
        "id":  "tacz:attachments/stock_hk_slim_line",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  4
                          },
                          {
                              "item":  {
                                           "tag":  "c:leathers"
                                       },
                              "count":  5
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:stock_hk_slim_line"
                   }
    },
    {
        "id":  "tacz:attachments/stock_m4ss",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  2
                          },
                          {
                              "item":  {
                                           "tag":  "c:leathers"
                                       },
                              "count":  5
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:stock_m4ss"
                   }
    },
    {
        "id":  "tacz:attachments/stock_militech_b5",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  4
                          },
                          {
                              "item":  {
                                           "tag":  "c:leathers"
                                       },
                              "count":  5
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:stock_militech_b5"
                   }
    },
    {
        "id":  "tacz:attachments/stock_moe",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  3
                          },
                          {
                              "item":  {
                                           "tag":  "c:leathers"
                                       },
                              "count":  5
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:stock_moe"
                   }
    },
    {
        "id":  "tacz:attachments/stock_ripstock",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  3
                          },
                          {
                              "item":  {
                                           "tag":  "c:leathers"
                                       },
                              "count":  5
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:stock_ripstock"
                   }
    },
    {
        "id":  "tacz:attachments/stock_sba3",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  4
                          },
                          {
                              "item":  {
                                           "tag":  "c:leathers"
                                       },
                              "count":  5
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:stock_sba3"
                   }
    },
    {
        "id":  "tacz:attachments/stock_tactical_ar",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  5
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  4
                          },
                          {
                              "item":  {
                                           "tag":  "c:leathers"
                                       },
                              "count":  4
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:stock_tactical_ar"
                   }
    },
    {
        "id":  "tacz:attachments/stock_tactical_spas_12",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  4
                          },
                          {
                              "item":  {
                                           "tag":  "c:leathers"
                                       },
                              "count":  3
                          }
                      ],
        "result":  {
                       "type":  "attachment",
                       "id":  "tacz:stock_tactical_spas_12"
                   }
    }
]

ServerEvents.recipes(event => {
  TARIFLER_EK.forEach(t => {
    event.remove({ id: t.id })
    event.custom({
      type: 'tacz:gun_smith_table_crafting',
      materials: t.materials,
      result: t.result
    }).id(t.id)
  })
  console.info('[silah_uretim] mermi/aksesuar: ' + TARIFLER_EK.length + ' TaCZ tarifi parca sistemine cevrildi')
})
