// =====================================================================
// Silah seviye zorunlulugu (Reskillable ozel "Silah" becerisi)
// Dosya: kubejs/server_scripts/silah_seviye.js
//
// "Silah" becerisi config/reskillable/custom_skills.json icinde tanimli;
// beceri ekraninin (G tusu) ikinci sayfasinda gorunur
// (reskillable-common.toml: enableSecondSkillPage = true).
//
// Reskillable'in kendi skill_locks.json kilidi TaCZ silahlarinda ise
// yaramaz: TaCZ atisi Reskillable'in dinledigi "esya kullanma" olayindan
// gecmez. Bu script TaCZ'nin kendi atis olayini (GunShootEvent) sunucuda
// dinler; Silah seviyesi yetmeyen oyuncunun atisini iptal eder ve ekranin
// altinda gereken seviyeyi yazar. Silah becerisi bulunamazsa (config
// yuklenmediyse) Attack becerisine bakar.
//
//  - Iptal edilen atista MERMI HARCANMAZ: TaCZ mermiyi bu olaydan sonra
//    dusurur (tek istisna: bos hazneye ilk fisegin surulmesi; o fisek
//    kaybolmaz, haznede kalir).
//  - Silahi tasimak, doldurmak, nisan almak serbesttir; sadece ates edilemez.
//  - Yaratik modu (creative) oyuncular etkilenmez.
//
// Seviyeleri asagidan degistirip /reload yazabilirsiniz.
// Kapatmak icin dosyayi silin ve /reload yazin.
// =====================================================================

;(function () {
  var BECERI = 'silah'
  var YEDEK_BECERI = 'attack'

  // Silah turune gore gereken Silah seviyesi (Reskillable en fazla 32)
  var TUR_SEVIYE = {
    pistol: 5,
    smg: 10,
    shotgun: 10,
    rifle: 15,
    dmr: 15,
    sniper: 20,
    mg: 20,
    rpg: 25
  }
  // Listede olmayan (baska silah paketinden gelen) silahlar
  var VARSAYILAN_SEVIYE = 10

  // TaCZ silah kimligi -> tur (silah_uretim tablosuyla ayni)
  var SILAH_TUR = {}
  var ekle = (tur, liste) => liste.split(',').forEach(g => { SILAH_TUR['tacz:' + g] = tur })
  ekle('pistol', 'b93r,cz75,deagle,deagle_golden,glock_17,hk_mk23,lonetrail,m1911,m9a4,p320,rhino357,taurus500,taurus943,tec_9,timeless50')
  ekle('smg', 'hk_mp5a5,hk_mp7a1,p90,ump45,uzi,vector45')
  ekle('shotgun', 'aa12,db_long,db_short,m1014,m1897,m870,spas_12')
  ekle('rifle', 'ak12,ak47,ak74m,aug,fn_fal,g36k,hcar,hk_g3,hk416d,m16a1,m16a4,m4a1,mcx_spear_lt,mk18,qbz_191,qbz_95,qr_24,scar_h,scar_l,type_81,urgi')
  ekle('dmr', 'm1866,mk14,scar_mk20,sks_tactical,spr15hb')
  ekle('sniper', 'ai_awp,hm50b,kar98,m107,m700,m95,mrad,springfield1873,svd')
  ekle('mg', 'fn_evolys,m249,minigun,pkm,rpk')
  ekle('rpg', 'm320,rpg7')

  // Ozel olarak tek bir silaha farkli seviye vermek icin (tur seviyesini ezer):
  var SILAH_OZEL = {
    // 'tacz:deagle_golden': 12,
  }

  var IGun = Java.loadClass('com.tacz.guns.api.item.IGun')
  var ReskillableApi = Java.loadClass('net.bandit.reskillable.common.ReskillableApi')

  var TUR_ADI = {
    pistol: 'Tabanca', smg: 'Hafif makineli', shotgun: 'Pompali', rifle: 'Tufek',
    dmr: 'Nisanci tufegi', sniper: 'Keskin nisanci', mg: 'Makineli', rpg: 'Roketatar'
  }

  var gerekenSeviye = gunId => {
    if (SILAH_OZEL[gunId] != null) return SILAH_OZEL[gunId]
    var tur = SILAH_TUR[gunId]
    return tur ? TUR_SEVIYE[tur] : VARSAYILAN_SEVIYE
  }

  NativeEvents.onEvent('com.tacz.guns.api.event.common.GunShootEvent', event => {
    if (!event.getLogicalSide().isServer()) return
    var player = event.getShooter()
    if (player == null || !player.isPlayer() || player.isCreative()) return

    var stack = event.getGunItemStack()
    var gun = IGun.getIGunOrNull(stack)
    if (gun == null) return
    var gunId = String(gun.getGunId(stack))

    var gereken = gerekenSeviye(gunId)
    var silahVar = ReskillableApi.isSkillEnabled(BECERI)
    var beceri = silahVar ? BECERI : YEDEK_BECERI
    var seviye = ReskillableApi.getLevel(player, beceri)
    if (seviye >= gereken) return

    event.setCanceled(true)
    var tur = SILAH_TUR[gunId]
    player.setStatusMessage(Text.red(Text.ofString((tur ? TUR_ADI[tur] : 'Bu silah') + ' icin ' + (silahVar ? 'Silah' : 'Attack') + ' becerisi ' + gereken + ' gerekli (sen: ' + seviye + ')')))
  })

  console.info('[silah_seviye] TaCZ silah seviye zorunlulugu aktif, beceri: ' +
    (ReskillableApi.isSkillEnabled(BECERI) ? BECERI : YEDEK_BECERI + ' (Silah becerisi bulunamadi!)'))
})()
