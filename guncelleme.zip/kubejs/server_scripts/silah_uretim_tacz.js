// =====================================================================
// Silah Uretim Sistemi v2 - TaCZ silah tarifleri (70 silah)
// Dosya: kubejs/server_scripts/silah_uretim_tacz.js
//
// Her silahin tarifi asagidaki TARIFLER listesinde. Adetleri burada
// degistirip oyunda /reload yazmaniz yeterli.
//  - Parcalar: silahparca:*  (namlu, govde, surgu, tetik, kabza, dipcik, sarjor)
//  - Orijinal tarifteki demir: 1/4'u kaldi; tahta/kutuk yerine dipcik geldi
//  - Altin, elmas, blaze rod, netherite, lapis, quartz vb. aynen korundu
//  - 'result' bolumu TaCZ'nin orijinal dosyasindan birebir kopyalandi
//    (bazi silahlar hazir aksesuarla geliyor; onlar korunuyor)
// TaCZ masasi bir tarifte en fazla 12 malzeme gosterir; bu siniri asmayin.
// =====================================================================

const TARIFLER = [
    {
        "id":  "tacz:gun/aa12",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:shotgun_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  20
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  16
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/diamond"
                                       },
                              "count":  2
                          },
                          {
                              "item":  {
                                           "tag":  "c:rods/blaze"
                                       },
                              "count":  4
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:aa12"
                   }
    },
    {
        "id":  "tacz:gun/ai_awp",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:sniper_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  50
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/diamond"
                                       },
                              "count":  10
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  50
                          },
                          {
                              "item":  {
                                           "tag":  "c:rods/blaze"
                                       },
                              "count":  5
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:ai_awp",
                       "attachments":  {
                                           "scope":  "tacz:scope_contender"
                                       }
                   }
    },
    {
        "id":  "tacz:gun/ak12",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  14
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  12
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/quartz"
                                       },
                              "count":  8
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:ak12"
                   }
    },
    {
        "id":  "tacz:gun/ak47",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  10
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/lapis"
                                       },
                              "count":  6
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:ak47"
                   }
    },
    {
        "id":  "tacz:gun/ak74m",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  7
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/lapis"
                                       },
                              "count":  4
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:ak74m"
                   }
    },
    {
        "id":  "tacz:gun/aug",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  10
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/lapis"
                                       },
                              "count":  8
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/amethyst"
                                       },
                              "count":  1
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:aug"
                   }
    },
    {
        "id":  "tacz:gun/b93r",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_frame"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_slide"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  6
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/lapis"
                                       },
                              "count":  2
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:b93r"
                   }
    },
    {
        "id":  "tacz:gun/cz75",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_frame"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_slide"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  5
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:cz75"
                   }
    },
    {
        "id":  "tacz:gun/db_long",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:shotgun_barrel"
                                       },
                              "count":  2
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  4
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:db_long"
                   }
    },
    {
        "id":  "tacz:gun/db_short",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:shotgun_barrel"
                                       },
                              "count":  2
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  2
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:db_short"
                   }
    },
    {
        "id":  "tacz:gun/deagle",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_frame"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_slide"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  11
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/diamond"
                                       },
                              "count":  2
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  6
                          },
                          {
                              "item":  {
                                           "tag":  "c:rods/blaze"
                                       }
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:deagle"
                   }
    },
    {
        "id":  "tacz:gun/deagle_golden",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_frame"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_slide"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  4
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/diamond"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  32
                          },
                          {
                              "item":  {
                                           "tag":  "c:rods/blaze"
                                       }
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:deagle_golden"
                   }
    },
    {
        "id":  "tacz:gun/fn_evolys",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_magazine"
                                       },
                              "count":  2
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  37
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/diamond"
                                       },
                              "count":  6
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  30
                          },
                          {
                              "item":  {
                                           "tag":  "c:rods/blaze"
                                       },
                              "count":  5
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:fn_evolys"
                   }
    },
    {
        "id":  "tacz:gun/fn_fal",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  16
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/lapis"
                                       },
                              "count":  20
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  10
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:fn_fal"
                   }
    },
    {
        "id":  "tacz:gun/g36k",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  16
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  16
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/quartz"
                                       },
                              "count":  8
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:g36k"
                   }
    },
    {
        "id":  "tacz:gun/glock_17",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_frame"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_slide"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  4
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:glock_17"
                   }
    },
    {
        "id":  "tacz:gun/hcar",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  33
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  18
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/diamond"
                                       },
                              "count":  4
                          },
                          {
                              "item":  {
                                           "tag":  "c:rods/blaze"
                                       },
                              "count":  6
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/quartz"
                                       },
                              "count":  4
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:hcar"
                   }
    },
    {
        "id":  "tacz:gun/hk_g3",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  18
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  9
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/quartz"
                                       },
                              "count":  5
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:hk_g3"
                   }
    },
    {
        "id":  "tacz:gun/hk_mk23",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_frame"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_slide"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  9
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  4
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/lapis"
                                       },
                              "count":  2
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:hk_mk23"
                   }
    },
    {
        "id":  "tacz:gun/hk_mp5a5",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  9
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/lapis"
                                       },
                              "count":  4
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:hk_mp5a5"
                   }
    },
    {
        "id":  "tacz:gun/hk_mp7a1",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  11
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  4
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/quartz"
                                       },
                              "count":  6
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:hk_mp7a1"
                   }
    },
    {
        "id":  "tacz:gun/hk416d",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  16
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  16
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/quartz"
                                       },
                              "count":  8
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:hk416d",
                       "attachments":  {
                                           "stock":  "tacz:stock_hk_slim_line"
                                       }
                   }
    },
    {
        "id":  "tacz:gun/hm50b",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:sniper_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  88
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  60
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/diamond"
                                       },
                              "count":  16
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/netherite"
                                       },
                              "count":  3
                          },
                          {
                              "item":  {
                                           "tag":  "c:rods/blaze"
                                       },
                              "count":  5
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:hm50b",
                       "attachments":  {
                                           "scope":  "tacz:scope_contender"
                                       }
                   }
    },
    {
        "id":  "tacz:gun/kar98",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:sniper_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  7
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  4
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/lapis"
                                       },
                              "count":  12
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:kar98"
                   }
    },
    {
        "id":  "tacz:gun/lonetrail",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_frame"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_slide"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  10
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/lapis"
                                       },
                              "count":  20
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  4
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:lonetrail",
                       "attachments":  {
                                           "scope":  "tacz:scope_contender"
                                       }
                   }
    },
    {
        "id":  "tacz:gun/m1014",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:shotgun_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  16
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  12
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/diamond"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/lapis"
                                       },
                              "count":  8
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:m1014"
                   }
    },
    {
        "id":  "tacz:gun/m107",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:sniper_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  80
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/diamond"
                                       },
                              "count":  18
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  64
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/netherite"
                                       },
                              "count":  3
                          },
                          {
                              "item":  {
                                           "tag":  "c:rods/blaze"
                                       },
                              "count":  5
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:m107",
                       "attachments":  {
                                           "scope":  "tacz:scope_contender"
                                       }
                   }
    },
    {
        "id":  "tacz:gun/m16a1",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  8
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/lapis"
                                       },
                              "count":  6
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:m16a1"
                   }
    },
    {
        "id":  "tacz:gun/m16a4",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  9
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/lapis"
                                       },
                              "count":  8
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:m16a4"
                   }
    },
    {
        "id":  "tacz:gun/m1866",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  6
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/copper"
                                       },
                              "count":  10
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:m1866"
                   }
    },
    {
        "id":  "tacz:gun/m1897",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:shotgun_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  7
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:m1897"
                   }
    },
    {
        "id":  "tacz:gun/m1911",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_frame"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_slide"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  4
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:m1911"
                   }
    },
    {
        "id":  "tacz:gun/m249",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_magazine"
                                       },
                              "count":  2
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  28
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/diamond"
                                       },
                              "count":  4
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  16
                          },
                          {
                              "item":  {
                                           "tag":  "c:rods/blaze"
                                       },
                              "count":  2
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:m249"
                   }
    },
    {
        "id":  "tacz:gun/m320",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:launcher_tube"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  13
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  15
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/lapis"
                                       },
                              "count":  6
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:m320"
                   }
    },
    {
        "id":  "tacz:gun/m4a1",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  10
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/lapis"
                                       },
                              "count":  6
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:m4a1",
                       "attachments":  {
                                           "stock":  "tacz:stock_m4ss"
                                       }
                   }
    },
    {
        "id":  "tacz:gun/m700",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:sniper_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  12
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/diamond"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  4
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:m700",
                       "attachments":  {
                                           "scope":  "tacz:scope_contender"
                                       }
                   }
    },
    {
        "id":  "tacz:gun/m870",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:shotgun_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  7
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:m870"
                   }
    },
    {
        "id":  "tacz:gun/m95",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:sniper_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  75
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/diamond"
                                       },
                              "count":  15
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  60
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/netherite"
                                       },
                              "count":  3
                          },
                          {
                              "item":  {
                                           "tag":  "c:rods/blaze"
                                       },
                              "count":  5
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:m95",
                       "attachments":  {
                                           "scope":  "tacz:scope_contender"
                                       }
                   }
    },
    {
        "id":  "tacz:gun/m9a4",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_frame"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_slide"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  4
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:m9a4"
                   }
    },
    {
        "id":  "tacz:gun/mcx_spear_lt",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  12
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  8
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/quartz"
                                       },
                              "count":  6
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/diamond"
                                       },
                              "count":  2
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:mcx_spear_lt"
                   }
    },
    {
        "id":  "tacz:gun/minigun",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_barrel"
                                       },
                              "count":  6
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_magazine"
                                       },
                              "count":  2
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  80
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/diamond"
                                       },
                              "count":  40
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  80
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/netherite"
                                       },
                              "count":  10
                          },
                          {
                              "item":  {
                                           "tag":  "c:rods/blaze"
                                       },
                              "count":  10
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:minigun"
                   }
    },
    {
        "id":  "tacz:gun/mk14",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  21
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  20
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/diamond"
                                       },
                              "count":  4
                          },
                          {
                              "item":  {
                                           "tag":  "c:rods/blaze"
                                       },
                              "count":  2
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:mk14"
                   }
    },
    {
        "id":  "tacz:gun/mk18",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  12
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/lapis"
                                       },
                              "count":  8
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:mk18",
                       "attachments":  {
                                           "stock":  "tacz:stock_militech_b5"
                                       }
                   }
    },
    {
        "id":  "tacz:gun/mrad",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:sniper_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  53
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  55
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/diamond"
                                       },
                              "count":  10
                          },
                          {
                              "item":  {
                                           "tag":  "c:rods/blaze"
                                       },
                              "count":  6
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:mrad"
                   }
    },
    {
        "id":  "tacz:gun/p320",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_frame"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_slide"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  7
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  4
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/lapis"
                                       },
                              "count":  2
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:p320"
                   }
    },
    {
        "id":  "tacz:gun/p90",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  18
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  8
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/quartz"
                                       },
                              "count":  3
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/diamond"
                                       },
                              "count":  2
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:p90"
                   }
    },
    {
        "id":  "tacz:gun/pkm",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_magazine"
                                       },
                              "count":  2
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  39
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  32
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/diamond"
                                       },
                              "count":  5
                          },
                          {
                              "item":  {
                                           "tag":  "c:rods/blaze"
                                       },
                              "count":  7
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:pkm"
                   }
    },
    {
        "id":  "tacz:gun/qbz_191",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  16
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  8
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/lapis"
                                       },
                              "count":  16
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/quartz"
                                       },
                              "count":  8
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:qbz_191"
                   }
    },
    {
        "id":  "tacz:gun/qbz_95",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  10
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  3
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/lapis"
                                       },
                              "count":  8
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:qbz_95"
                   }
    },
    {
        "id":  "tacz:gun/qr_24",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  12
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  6
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/lapis"
                                       },
                              "count":  14
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:qr_24"
                   }
    },
    {
        "id":  "tacz:gun/rhino357",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_frame"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:revolver_cylinder"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  8
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/lapis"
                                       },
                              "count":  8
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  4
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:rhino357"
                   }
    },
    {
        "id":  "tacz:gun/rpg7",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:launcher_tube"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  18
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  8
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/lapis"
                                       },
                              "count":  4
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:rpg7"
                   }
    },
    {
        "id":  "tacz:gun/rpk",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_magazine"
                                       },
                              "count":  2
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  14
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  8
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/quartz"
                                       },
                              "count":  8
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:rpk"
                   }
    },
    {
        "id":  "tacz:gun/scar_h",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  24
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  16
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/diamond"
                                       },
                              "count":  2
                          },
                          {
                              "item":  {
                                           "tag":  "c:rods/blaze"
                                       },
                              "count":  4
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:scar_h"
                   }
    },
    {
        "id":  "tacz:gun/scar_l",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  12
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  6
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/quartz"
                                       },
                              "count":  3
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:scar_l"
                   }
    },
    {
        "id":  "tacz:gun/scar_mk20",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  24
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  18
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/diamond"
                                       },
                              "count":  3
                          },
                          {
                              "item":  {
                                           "tag":  "c:rods/blaze"
                                       },
                              "count":  5
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:scar_mk20"
                   }
    },
    {
        "id":  "tacz:gun/sks_tactical",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  10
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/lapis"
                                       },
                              "count":  8
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:sks_tactical"
                   }
    },
    {
        "id":  "tacz:gun/spas_12",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:shotgun_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  28
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  20
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/diamond"
                                       },
                              "count":  2
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/lapis"
                                       },
                              "count":  5
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:spas_12"
                   }
    },
    {
        "id":  "tacz:gun/spr15hb",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  18
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  8
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/diamond"
                                       },
                              "count":  2
                          },
                          {
                              "item":  {
                                           "tag":  "c:rods/blaze"
                                       },
                              "count":  5
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:spr15hb"
                   }
    },
    {
        "id":  "tacz:gun/springfield1873",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:sniper_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  1
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:springfield1873"
                   }
    },
    {
        "id":  "tacz:gun/svd",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:sniper_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  25
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  18
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/diamond"
                                       },
                              "count":  3
                          },
                          {
                              "item":  {
                                           "tag":  "c:rods/blaze"
                                       },
                              "count":  5
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/lapis"
                                       },
                              "count":  2
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:svd"
                   }
    },
    {
        "id":  "tacz:gun/taurus500",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_frame"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:revolver_cylinder"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  22
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/diamond"
                                       },
                              "count":  8
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  65
                          },
                          {
                              "item":  {
                                           "tag":  "c:rods/blaze"
                                       },
                              "count":  4
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:taurus500"
                   }
    },
    {
        "id":  "tacz:gun/taurus943",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_frame"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:revolver_cylinder"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  3
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:taurus943"
                   }
    },
    {
        "id":  "tacz:gun/tec_9",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_frame"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_slide"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  5
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/lapis"
                                       },
                              "count":  2
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:tec_9"
                   }
    },
    {
        "id":  "tacz:gun/timeless50",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_frame"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_slide"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  12
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/diamond"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  6
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:timeless50"
                   }
    },
    {
        "id":  "tacz:gun/type_81",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  7
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:type_81"
                   }
    },
    {
        "id":  "tacz:gun/ump45",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  16
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  5
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/quartz"
                                       },
                              "count":  3
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:ump45"
                   }
    },
    {
        "id":  "tacz:gun/urgi",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:rifle_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  14
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/lapis"
                                       },
                              "count":  10
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:urgi"
                   }
    },
    {
        "id":  "tacz:gun/uzi",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  8
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:uzi"
                   }
    },
    {
        "id":  "tacz:gun/vector45",
        "materials":  [
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_barrel"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:receiver"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:bolt_carrier"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:trigger_group"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:grip"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:stock"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "item":  "silahparca:pistol_magazine"
                                       },
                              "count":  1
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/iron"
                                       },
                              "count":  15
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/lapis"
                                       },
                              "count":  8
                          },
                          {
                              "item":  {
                                           "tag":  "c:ingots/gold"
                                       },
                              "count":  12
                          },
                          {
                              "item":  {
                                           "tag":  "c:gems/diamond"
                                       },
                              "count":  10
                          }
                      ],
        "result":  {
                       "type":  "gun",
                       "id":  "tacz:vector45"
                   }
    }
]

ServerEvents.recipes(event => {
  TARIFLER.forEach(t => {
    event.remove({ id: t.id })
    event.custom({
      type: 'tacz:gun_smith_table_crafting',
      materials: t.materials,
      result: t.result
    }).id(t.id)
  })
  console.info('[silah_uretim] v2: ' + TARIFLER.length + ' TaCZ silah tarifi parca sistemine cevrildi')
})
