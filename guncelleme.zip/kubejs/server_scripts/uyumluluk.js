// =====================================================================
//  UYUMLULUK  -  kubejs/server_scripts/uyumluluk.js
//  2026-11-25 (kullanıcı: "paketi tara, gerekirse yeniden uyumluluk yap"). Yeni eklenen modların pakete uydurulması:
//   - Create: The Air War: titanyum/kükürt/amalgam cevherleri ve titanyum malzemeleri c: etiketlerine girer
//     (Madenci ve beceri puanı #c:ores'a bakar; tarifler c:ingots/titanium görür).
//   - Titanyum aletler Overgeared düzeninde: külçe fırında kızar, örste başlık dövülür, başlık + çubuk = alet
//     (masada doğrudan külçeyle yapım kaldırıldı). Eşyalar: startup_scripts/uyumluluk_items.js
// =====================================================================
;(function () {
  var AW = 'create_the_air_wars:'
  var ALETLER = [
    { alet: 'titanium_axe', bas: 'titanium_axe_head', bp: 'axe', desen: [['##', '# '], ['##', ' #']], eski: 'ta' },
    { alet: 'titanium_hoe', bas: 'titanium_hoe_head', bp: 'hoe', desen: [['##']], eski: 'th' },
    { alet: 'titaniumpickaxe', bas: 'titanium_pickaxe_head', bp: 'pickaxe', desen: [['###']], eski: 'tp' },
    { alet: 'titaniumshovel', bas: 'titanium_shovel_head', bp: 'shovel', desen: [['#']], eski: 'ts' }
  ]

  ServerEvents.tags('item', function (event) {
    event.add('overgeared:heated_metals', 'kubejs:heated_titanium_ingot')
    event.add('c:ingots/titanium', AW + 'titaniumingot'); event.add('c:ingots', AW + 'titaniumingot')
    event.add('c:nuggets/titanium', AW + 'titaniumnugget'); event.add('c:nuggets', AW + 'titaniumnugget')
    event.add('c:storage_blocks/titanium', AW + 'titaniumblock'); event.add('c:storage_blocks', AW + 'titaniumblock')
    event.add('c:plates/titanium', AW + 'titaniumsheet'); event.add('c:plates', AW + 'titaniumsheet')
    event.add('c:raw_materials/titanium', AW + 'rawtitanium'); event.add('c:raw_materials', AW + 'rawtitanium')
    ;['titanium_ore', 'deepslatetitaniumore'].forEach(function (o) { event.add('c:ores/titanium', AW + o); event.add('c:ores', AW + o) })
    ;['sulfur_ore', 'deepdlatesulfurore'].forEach(function (o) { event.add('c:ores/sulfur', AW + o); event.add('c:ores', AW + o) })
    ;['amalgam_ore', 'deep_state_amalgam_ore'].forEach(function (o) { event.add('c:ores/amalgam', AW + o); event.add('c:ores', AW + o) })
    ;['titanium_axe'].forEach(function (t) { event.add('minecraft:axes', AW + t) })
    event.add('minecraft:pickaxes', AW + 'titaniumpickaxe')
    event.add('minecraft:shovels', AW + 'titaniumshovel')
    event.add('minecraft:hoes', AW + 'titanium_hoe')
  })
  ServerEvents.tags('block', function (event) {
    ;['titanium_ore', 'deepslatetitaniumore'].forEach(function (o) { event.add('c:ores/titanium', AW + o); event.add('c:ores', AW + o) })
    ;['sulfur_ore', 'deepdlatesulfurore'].forEach(function (o) { event.add('c:ores/sulfur', AW + o); event.add('c:ores', AW + o) })
    ;['amalgam_ore', 'deep_state_amalgam_ore'].forEach(function (o) { event.add('c:ores/amalgam', AW + o); event.add('c:ores', AW + o) })
    event.add('c:storage_blocks/titanium', AW + 'titaniumblock')
  })

  ServerEvents.recipes(function (event) {
    try {
      // kızdırma / soğutma
      event.smelting('kubejs:heated_titanium_ingot', AW + 'titaniumingot').cookingTime(160).id('kubejs:uyum/heated_titanium_smelting')
      event.blasting('kubejs:heated_titanium_ingot', AW + 'titaniumingot').cookingTime(80).id('kubejs:uyum/heated_titanium_blasting')
      event.custom({ type: 'overgeared:cooling', input: { item: 'kubejs:heated_titanium_ingot' }, output: { id: AW + 'titaniumingot' } }).id('kubejs:uyum/titanium_cooling')
      ALETLER.forEach(function (a) {
        event.remove({ id: AW + a.eski })
        a.desen.forEach(function (d, i) {
          event.custom({
            type: 'overgeared:forging', blueprint: [a.bp], category: 'TOOL_HEADS', hammering: 4, tier: 'stone',
            has_quality: true, has_polishing: false, need_quenching: false, show_notification: false,
            pattern: d, key: { '#': { item: 'kubejs:heated_titanium_ingot' } },
            result: { count: 1, id: 'kubejs:' + a.bas }
          }).id('kubejs:uyum/' + a.bas + (i > 0 ? '_' + (i + 1) : ''))
        })
        event.custom({
          type: 'overgeared:crafting_shapeless', category: 'equipment',
          ingredients: [{ item: 'kubejs:' + a.bas }, { item: 'minecraft:stick' }],
          result: { count: 1, id: AW + a.alet }
        }).id('kubejs:uyum/' + a.alet)
      })
    } catch (err) { console.error('[Uyumluluk] tarif: ' + err) }
  })
})()

// 2026-11-26: girişteki gereksiz chat mesajları. Pufferfish "You have a new skill point. Press Not Bound..." mesajı
// (K = Sınıf & Meslek ekranı; Pufferfish'in kendi tuşu boşta olduğu için yanıltıcı) gamerule ile kapatılır.
ServerEvents.loaded(function (event) {
  try { event.server.runCommandSilent('gamerule puffish_skills:announceNewPoints false') } catch (err) { console.error('[Uyumluluk] gamerule: ' + err) }
})