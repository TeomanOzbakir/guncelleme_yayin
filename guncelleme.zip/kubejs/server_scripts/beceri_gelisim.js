// =====================================================================
//  BECERİ GELİŞİMİ (Reskillable)  -  kubejs/server_scripts/beceri_gelisim.js
//  2026-11-25 (kullanıcı): Reskillable becerileri XP harcayarak değil, O İŞİ YAPARAK gelişir.
//  config/reskillable-common.toml: enableSkillLeveling = false (arayüzden seviye atlanmaz; seviyeyi bu betik verir).
//  Puanlar (oyuncunun persistentData 'beceri_puan'):
//    mining    kazma ile kırılan taş 1, cevher 5
//    gathering balta/kürek ile kırılan blok 1, kütük 2
//    building  yerleştirilen blok 1
//    farming   olgun ürün hasadı 2, hayvan üretme 4
//    attack    öldürülen canavar: min(can, 300) / 6 (en az 1)
//    defense   canavardan alınan hasar (1 can = 1 puan)
//    agility   koşulan her 40 m 1, her 15 zıplama 1
//    magic     büyüleme (harcanan seviye x 4), iksir demleme 3, Iron's büyüsü 2
//  Seviye L -> L+1 için gereken: GEREK_TABAN + GEREK_ARTIS x L puan. Dakikalık üst sınır ve "kendi koyduğun bloğu
//  kırma" kontrolü çiftlik yapmayı engeller. Menü > Sınıf & Meslek > Beceriler (ortak('beceriOzet')).
//  !! Gerçek bir oyunda ÇALIŞTIRILARAK TEST EDİLMEDİ.
// =====================================================================
;(function () {
  function ortak(ad) { try { return global.ortak ? global.ortak.get(ad) : null } catch (e) { return null } }
  var AYAR = {
    GEREK_TABAN: 40,
    GEREK_ARTIS: 30,
    DAKIKA_SINIR: { mining: 120, gathering: 120, building: 90, farming: 120, attack: 150, defense: 60, agility: 30, magic: 120 },
    MAKS: 32
  }
  var AD = { mining: 'Madencilik', gathering: 'Toplayıcılık', attack: 'Saldırı', defense: 'Savunma', building: 'İnşaat', farming: 'Çiftçilik', agility: 'Çeviklik', magic: 'Büyü' }
  var SkillModel = null
  try { SkillModel = Java.loadClass('net.bandit.reskillable.common.capabilities.SkillModel') } catch (e) { console.warn('[Beceri] Reskillable bulunamadi: ' + e) }
  var CropBlock = Java.loadClass('net.minecraft.world.level.block.CropBlock')
  var ServerPlayer = Java.loadClass('net.minecraft.server.level.ServerPlayer')
  var Stats = Java.loadClass('net.minecraft.stats.Stats')

  function gerek(l) { return AYAR.GEREK_TABAN + AYAR.GEREK_ARTIS * l }
  function veri(p) { var s = p.persistentData.getString('beceri_puan'); if (!s) return {}; try { return JSON.parse(s) || {} } catch (e) { return {} } }
  function seviye(p, b) { try { return SkillModel.get(p).getSkillLevel(b) } catch (e) { return 1 } }
  // dakikalık sınır için sayaç (bellekte)
  var dakika = {}
  function puanVer(p, b, m) {
    if (SkillModel == null || !(m > 0) || p.isCreative() || p.isSpectator()) return
    var id = String(p.getUuid())
    var dk = Math.floor(Date.now() / 60000)
    var s = dakika[id] || (dakika[id] = { dk: dk })
    if (s.dk !== dk) { dakika[id] = s = { dk: dk } }
    var kalan = AYAR.DAKIKA_SINIR[b] - (s[b] || 0)
    if (kalan <= 0) return
    m = Math.min(m, kalan)
    s[b] = (s[b] || 0) + m
    var v = veri(p)
    v[b] = (v[b] || 0) + m
    var model = SkillModel.get(p)
    var l = model.getSkillLevel(b)
    var atladi = false
    while (l < AYAR.MAKS && v[b] >= gerek(l)) { v[b] -= gerek(l); l++; atladi = true }
    if (l >= AYAR.MAKS) v[b] = 0
    p.persistentData.putString('beceri_puan', JSON.stringify(v))
    if (atladi) {
      model.setSkillLevel(b, l)
      model.syncSkills(p)
      p.tell(Text.green(Text.ofString('Beceri gelişti: ' + AD[b] + ' ' + l + '. seviye!')))
    }
  }
  if (global.ortak) global.ortak.put('beceriOzet', beceriOzetFn)
  function beceriOzetFn(p) {
    var v = veri(p)
    return Object.keys(AD).map(function (b) { var l = seviye(p, b); return { b: b, ad: AD[b], sv: l, puan: Math.floor(v[b] || 0), gerek: l >= AYAR.MAKS ? 0 : gerek(l) } })
  }

  // ----------------------------- kendi koyduğun blok ----------------------
  var konan = {}, konanSira = []
  function anahtar(e) { var pos = e.block.pos; return String(e.level.getDimension()) + '|' + pos.x + '|' + pos.y + '|' + pos.z }
  BlockEvents.placed(function (e) {
    var p = e.player
    if (p == null || !(p instanceof ServerPlayer)) return
    try {
      var k = anahtar(e)
      if (!konan[k]) { konanSira.push(k); if (konanSira.length > 20000) delete konan[konanSira.shift()] }
      konan[k] = 1
      puanVer(p, 'building', 1)
    } catch (err) { console.error('[Beceri] yerlestirme: ' + err) }
  })
  BlockEvents.broken(function (e) {
    var p = e.player
    if (p == null || !(p instanceof ServerPlayer)) return
    try {
      var k = anahtar(e)
      if (konan[k]) { delete konan[k]; return }   // oyuncunun koyduğu blok: puan yok
      var st = e.block.blockState
      var b = st.getBlock()
      if (b instanceof CropBlock) { if (b.isMaxAge(st)) puanVer(p, 'farming', 2); return }
      var el = p.getMainHandItem()
      var bl = e.block
      if (bl.hasTag('minecraft:mineable/pickaxe') && el.hasTag('minecraft:pickaxes')) { puanVer(p, 'mining', bl.hasTag('c:ores') ? 5 : 1); return }
      if (bl.hasTag('minecraft:mineable/axe') && el.hasTag('minecraft:axes')) { puanVer(p, 'gathering', bl.hasTag('minecraft:logs') ? 2 : 1); return }
      if (bl.hasTag('minecraft:mineable/shovel') && el.hasTag('minecraft:shovels')) puanVer(p, 'gathering', 1)
    } catch (err) { console.error('[Beceri] kirma: ' + err) }
  })

  // ----------------------------- dövüş ------------------------------------
  EntityEvents.death(function (e) {
    var o = e.entity
    if (!o || o.isPlayer()) return
    var k = e.source.getActual()
    if (k == null || !(k instanceof ServerPlayer)) return
    try { puanVer(k, 'attack', Math.max(1, Math.round(Math.min(o.getMaxHealth(), 300) / 6))) } catch (err) { console.error('[Beceri] oldurme: ' + err) }
  })
  NativeEvents.onEvent('net.neoforged.neoforge.event.entity.living.LivingDamageEvent$Post', function (e) {
    try {
      var p = e.entity
      if (!(p instanceof ServerPlayer)) return
      var a = e.getSource().getActual()
      if (a == null || a instanceof ServerPlayer) return   // sadece canavar hasarı (oyuncular birbirini döverek kasamasın)
      var h = e.getNewDamage()
      if (h > 0) puanVer(p, 'defense', Math.min(20, h))
    } catch (err) { console.error('[Beceri] hasar: ' + err) }
  })

  // ----------------------------- çiftçilik: hayvan üretme -----------------
  NativeEvents.onEvent('net.neoforged.neoforge.event.entity.living.BabyEntitySpawnEvent', function (e) {
    try { var p = e.getCausedByPlayer(); if (p instanceof ServerPlayer) puanVer(p, 'farming', 4) } catch (err) { console.error('[Beceri] uretme: ' + err) }
  })

  // ----------------------------- büyü -------------------------------------
  NativeEvents.onEvent('net.neoforged.neoforge.event.brewing.PlayerBrewedPotionEvent', function (e) {
    try { var p = e.entity; if (p instanceof ServerPlayer) puanVer(p, 'magic', 3) } catch (err) { console.error('[Beceri] demleme: ' + err) }
  })
  try {
    NativeEvents.onEvent('io.redspace.ironsspellbooks.api.events.SpellOnCastEvent', function (e) {
      try { var p = e.entity; if (p instanceof ServerPlayer) puanVer(p, 'magic', 2) } catch (err) { console.error('[Beceri] buyu: ' + err) }
    })
  } catch (e0) { console.warn('[Beceri] Iron\'s buyu olayi baglanamadi: ' + e0) }

  // ----------------------------- istatistikten: çeviklik + büyüleme (30 sn) ------
  ServerEvents.tick(function (event) {
    var server = event.server
    if (server.tickCount % 600 !== 77 || SkillModel == null) return
    try {
      var on = server.playerList.getPlayers().toArray()
      for (var i = 0; i < on.length; i++) {
        var p = on[i]
        var st = p.getStats()
        var kos = st.getValue(Stats.CUSTOM.get(Stats.SPRINT_ONE_CM))
        var zip = st.getValue(Stats.CUSTOM.get(Stats.JUMP))
        var buy = st.getValue(Stats.CUSTOM.get(Stats.ENCHANT_ITEM))
        var v = veri(p)
        var o = v._ist || null
        v._ist = { k: kos, z: zip, b: buy }
        p.persistentData.putString('beceri_puan', JSON.stringify(v))
        if (o == null) continue   // ilk ölçüm: sadece başlangıç kaydı
        var cev = Math.floor(Math.max(0, kos - o.k) / 4000) + Math.floor(Math.max(0, zip - o.z) / 15)
        if (cev > 0) puanVer(p, 'agility', cev)
        if (buy > o.b) puanVer(p, 'magic', (buy - o.b) * 12)   // büyüleme başına ~3 seviye x 4
      }
    } catch (err) { console.error('[Beceri] istatistik: ' + err) }
  })

  console.info('[Beceri] Reskillable is yaparak gelisim hazir' + (SkillModel == null ? ' (Reskillable YOK)' : ''))
})()
