// =====================================================================
//  BECERİ GELİŞİMİ (Reskillable)  -  kubejs/server_scripts/beceri_gelisim.js
//  2026-11-25 (kullanıcı): Reskillable becerileri XP harcayarak değil, O İŞİ YAPARAK gelişir.
//  config/reskillable-common.toml: enableSkillLeveling = false (arayüzden seviye atlanmaz; seviyeyi bu betik verir).
//  Puanlar (oyuncunun persistentData 'beceri_puan'):
//    mining    kazma ile kırılan taş 1, cevher 5
//    gathering balta/kürek ile kırılan blok 1, kütük 2
//    building  yerleştirilen blok 1
//    farming   olgun ürün hasadı 2, hayvan üretme 4
//    attack    öldürülen canavar: min(can, 300) / 6 (en az 1)
//    defense   canavardan alınan hasar (1 can = 1 puan)
//    agility   koşulan her 40 m 1, her 15 zıplama 1
//    magic     büyüleme (harcanan seviye x 4), iksir demleme 3, Iron's büyüsü 2
//  Seviye L -> L+1 için gereken: GEREK_TABAN + GEREK_ARTIS x L puan. Dakikalık üst sınır ve "kendi koyduğun bloğu
//  kırma" kontrolü çiftlik yapmayı engeller. Menü > Sınıf & Meslek > Beceriler (ortak('beceriOzet')).
//  !! Gerçek bir oyunda ÇALIŞTIRILARAK TEST EDİLMEDİ.
// =====================================================================
;(function () {
  function ortak(ad) { try { return global.ortak ? global.ortak.get(ad) : null } catch (e) { return null } }
  // 2026-11-25 (kullanıcı): seviyeler 1-10 kademe (reskillable_kademe.ps1); L -> L+1 için PUAN_BIRIM x L iş puanı
  // VE XP_BIRIM x L XP seviyesi (ikisi de doğrusal). XP yetmezse puan eşikte bekler, XP toplanınca bir sonraki işte atlar.
  var AYAR = {
    PUAN_BIRIM: 250,
    XP_BIRIM: 2,
    DAKIKA_SINIR: { mining: 120, gathering: 120, building: 90, farming: 120, attack: 150, defense: 60, agility: 30, magic: 120, silah: 150 },
    MAKS: 10,
    SURUM: 3   // 2: eski 1-32 -> 1-10 (hatalıydı, zaten 1-10 olanları da küçülttü); 3: onarım, bkz. ONARIM
  }
  var AD = { mining: 'Madencilik', gathering: 'Toplayıcılık', attack: 'Saldırı', defense: 'Savunma', building: 'İnşaat', farming: 'Çiftçilik', agility: 'Çeviklik', magic: 'Büyü', silah: 'Silah' }
  var SkillModel = null
  try { SkillModel = Java.loadClass('net.bandit.reskillable.common.capabilities.SkillModel') } catch (e) { console.warn('[Beceri] Reskillable bulunamadi: ' + e) }
  var CropBlock = Java.loadClass('net.minecraft.world.level.block.CropBlock')
  var ServerPlayer = Java.loadClass('net.minecraft.server.level.ServerPlayer')
  var Stats = Java.loadClass('net.minecraft.stats.Stats')

  function gerek(l) { return AYAR.PUAN_BIRIM * l }
  function xpGerek(l) { return AYAR.XP_BIRIM * l }
  function veri(p) { var s = p.persistentData.getString('beceri_puan'); if (!s) return {}; try { return JSON.parse(s) || {} } catch (e) { return {} } }
  // 2026-11-27: SkillModel.getSkillLevel/setSkillLevel'in (Skill) ve (String) iki hali var; Rhino metni Skill enum'una
  // çevirmeye çalışıp özel beceride ('silah') YAKALANAMAYAN hata veriyordu (menüdeki Beceriler bölümü bu yüzden bozuktu).
  // Okuma: ReskillableApi.getLevel(oyuncu, String) (tek hali var). Yazma: Reskillable'ın kendi /skills set komutu
  // (yerleşik ve özel beceriyi ayırır, perk bonuslarını ve eşitlemeyi kendisi yapar).
  var Api = null
  try { Api = Java.loadClass('net.bandit.reskillable.common.ReskillableApi') } catch (e) { Api = null }
  var YERLESIK_B = { mining: 1, gathering: 1, attack: 1, defense: 1, building: 1, farming: 1, agility: 1, magic: 1 }
  function svAl(p, b) {
    try {
      if (Api != null) return Api.getLevel(p, b)
      return YERLESIK_B[b] ? SkillModel.get(p).getSkillLevel(b) : 1
    } catch (e) { return 1 }
  }
  function svYaz(p, b, l) {
    p.server.runCommandSilent('skills set ' + p.username + ' ' + b + ' ' + Math.max(1, Math.min(AYAR.MAKS, l)))
  }
  function seviye(p, b) { return svAl(p, b) }
  // eski ölçek (1-32) -> kademe: kilit tablosuyla aynı (2->1, 3->2, 7->3, 10->4, 13->5, 17->6, 20->7, 24->9, 28->10)
  function kademe(eski) {
    var e = [[28, 10], [24, 9], [20, 7], [17, 6], [13, 5], [10, 4], [5, 3], [3, 2]]
    for (var i = 0; i < e.length; i++) if (eski >= e[i][0]) return e[i][1]
    return 1
  }
  // 2026-11-27 ONARIM (SURUM 3): v88/v89'da geçiş ilk kez çalıştı ama oyuncular zaten 1-10 ölçeğindeydi ->
  // seviyeleri bir kez daha küçüldü (2->1, 3-4->2, 5-9->3). Geçiş görenlere (beceri_surum 2) her becerinin
  // grubunun üst değeri geri verilir: 1->2, 2->4, 3->5, 4->10. Eksik/fazla kalan OP'nin /beceri ile düzeltilir.
  var ONARIM = { 1: 2, 2: 4, 3: 5, 4: 10 }
  var YERLESIK = ['mining', 'gathering', 'attack', 'defense', 'building', 'farming', 'agility', 'magic']
  PlayerEvents.loggedIn(function (event) {
    var p = event.player
    try {
      var surum = p.persistentData.getInt('beceri_surum')
      if (SkillModel == null || surum >= AYAR.SURUM) return
      var model = SkillModel.get(p)
      var deg = []
      // Sadece Reskillable'ın 8 yerleşik becerisi ('silah' özel becerisi bu sürümde enum'da yok)
      YERLESIK.forEach(function (b) {
        var l = model.getSkillLevel(b)
        var k = l
        if (surum === 2) k = Math.max(l, ONARIM[l] || l)    // hatalı geçişi geri al
        else if (l > AYAR.MAKS) k = kademe(l)              // sadece gerçekten eski ölçekte (10'dan büyük) kalanlar
        if (k !== l) { model.setSkillLevel(b, k); deg.push(AD[b] + ' ' + l + '→' + k) }
      })
      try { model.updateSkillAttributeBonuses(p) } catch (e) { }
      model.syncSkills(p)
      p.persistentData.putInt('beceri_surum', AYAR.SURUM)
      if (deg.length) p.tell(Text.gold(Text.ofString(surum === 2
        ? 'Özür dileriz: son güncellemede beceri seviyelerin yanlışlıkla düştü, geri yüklendi: ' + deg.join(', ') + '. Eksik kalan varsa yöneticiye söyle.'
        : 'Beceri seviyeleri 1-10 ölçeğe çevrildi: ' + deg.join(', '))))
      if (deg.length) console.info('[Beceri] gecis ' + p.username + ' (surum ' + surum + '): ' + deg.join(', '))
    } catch (err) { console.error('[Beceri] gecis: ' + err) }
  })
  // dakikalık sınır için sayaç (bellekte)
  var dakika = {}
  var xpUyari = {}
  function puanVer(p, b, m) {
    if (SkillModel == null || !(m > 0) || p.isCreative() || p.isSpectator()) return
    var id = String(p.getUuid())
    var dk = Math.floor(Date.now() / 60000)
    var s = dakika[id] || (dakika[id] = { dk: dk })
    if (s.dk !== dk) { dakika[id] = s = { dk: dk } }
    var kalan = AYAR.DAKIKA_SINIR[b] - (s[b] || 0)
    if (kalan <= 0) return
    m = Math.min(m, kalan)
    s[b] = (s[b] || 0) + m
    var v = veri(p)
    var l = svAl(p, b)
    if (l >= AYAR.MAKS) return
    v[b] = Math.min((v[b] || 0) + m, gerek(l))   // eşikte bekler (XP gelene kadar)
    var atladi = false
    if (v[b] >= gerek(l)) {
      var xg = xpGerek(l)
      if (p.experienceLevel >= xg) {
        p.giveExperienceLevels(-xg)
        v[b] = 0; l++; atladi = true
      } else if (!xpUyari[id + b] || Date.now() - xpUyari[id + b] > 120000) {
        xpUyari[id + b] = Date.now()
        p.tell(Text.yellow(Text.ofString(AD[b] + ' ' + (l + 1) + '. seviyeye hazır: ' + xg + ' XP seviyesi gerekli (sende ' + p.experienceLevel + ').')))
      }
    }
    p.persistentData.putString('beceri_puan', JSON.stringify(v))
    if (atladi) {
      svYaz(p, b, l)
      p.tell(Text.green(Text.ofString('Beceri gelişti: ' + AD[b] + ' ' + l + '. seviye! (' + xpGerek(l - 1) + ' XP seviyesi harcandı)')))
    }
  }
  // Silah becerisi (Reskillable özel beceri 'silah'): TaCZ silahıyla vurdukça
  try {
    NativeEvents.onEvent('com.tacz.guns.api.event.common.EntityHurtByGunEvent$Post', function (event) {
      try {
        if (!event.getLogicalSide().isServer()) return
        var a = event.getAttacker()
        if (!(a instanceof ServerPlayer)) return
        var h = event.getHurtEntity()
        if (h == null || h instanceof ServerPlayer) return   // oyuncu vurmak puan vermez
        puanVer(a, 'silah', 1)
      } catch (err) { console.error('[Beceri] silah: ' + err) }
    })
  } catch (e0) { console.warn('[Beceri] TaCZ olayi baglanamadi: ' + e0) }  if (global.ortak) global.ortak.put('beceriOzet', beceriOzetFn)
  function beceriOzetFn(p) {
    var v = veri(p)
    var xpVar = 0
    try { xpVar = p.experienceLevel } catch (e) { xpVar = 0 }
    return Object.keys(AD).map(function (b) { var l = seviye(p, b); return { b: b, ad: AD[b], sv: l, puan: Math.floor(v[b] || 0), gerek: l >= AYAR.MAKS ? 0 : gerek(l), xp: l >= AYAR.MAKS ? 0 : xpGerek(l), xpVar: xpVar } })
  }

  // ----------------------------- kendi koyduğun blok ----------------------
  var konan = {}, konanSira = []
  function anahtar(e) { var pos = e.block.pos; return String(e.level.getDimension()) + '|' + pos.x + '|' + pos.y + '|' + pos.z }
  BlockEvents.placed(function (e) {
    var p = e.player
    if (p == null || !(p instanceof ServerPlayer)) return
    try {
      var k = anahtar(e)
      if (!konan[k]) { konanSira.push(k); if (konanSira.length > 20000) delete konan[konanSira.shift()] }
      konan[k] = 1
      puanVer(p, 'building', 1)
    } catch (err) { console.error('[Beceri] yerlestirme: ' + err) }
  })
  BlockEvents.broken(function (e) {
    var p = e.player
    if (p == null || !(p instanceof ServerPlayer)) return
    try {
      var k = anahtar(e)
      if (konan[k]) { delete konan[k]; return }   // oyuncunun koyduğu blok: puan yok
      var st = e.block.blockState
      var b = st.getBlock()
      if (b instanceof CropBlock) { if (b.isMaxAge(st)) puanVer(p, 'farming', 2); return }
      var el = p.getMainHandItem()
      var bl = e.block
      if (bl.hasTag('minecraft:mineable/pickaxe') && el.hasTag('minecraft:pickaxes')) { puanVer(p, 'mining', bl.hasTag('c:ores') ? 5 : 1); return }
      if (bl.hasTag('minecraft:mineable/axe') && el.hasTag('minecraft:axes')) { puanVer(p, 'gathering', bl.hasTag('minecraft:logs') ? 2 : 1); return }
      if (bl.hasTag('minecraft:mineable/shovel') && el.hasTag('minecraft:shovels')) puanVer(p, 'gathering', 1)
    } catch (err) { console.error('[Beceri] kirma: ' + err) }
  })

  // ----------------------------- dövüş ------------------------------------
  EntityEvents.death(function (e) {
    var o = e.entity
    if (!o || o.isPlayer()) return
    var k = e.source.getActual()
    if (k == null || !(k instanceof ServerPlayer)) return
    try { puanVer(k, 'attack', Math.max(1, Math.round(Math.min(o.getMaxHealth(), 300) / 6))) } catch (err) { console.error('[Beceri] oldurme: ' + err) }
  })
  NativeEvents.onEvent('net.neoforged.neoforge.event.entity.living.LivingDamageEvent$Post', function (e) {
    try {
      var p = e.entity
      if (!(p instanceof ServerPlayer)) return
      var a = e.getSource().getActual()
      if (a == null || a instanceof ServerPlayer) return   // sadece canavar hasarı (oyuncular birbirini döverek kasamasın)
      var h = e.getNewDamage()
      if (h > 0) puanVer(p, 'defense', Math.min(20, h))
    } catch (err) { console.error('[Beceri] hasar: ' + err) }
  })

  // ----------------------------- çiftçilik: hayvan üretme -----------------
  NativeEvents.onEvent('net.neoforged.neoforge.event.entity.living.BabyEntitySpawnEvent', function (e) {
    try { var p = e.getCausedByPlayer(); if (p instanceof ServerPlayer) puanVer(p, 'farming', 4) } catch (err) { console.error('[Beceri] uretme: ' + err) }
  })

  // ----------------------------- büyü -------------------------------------
  NativeEvents.onEvent('net.neoforged.neoforge.event.brewing.PlayerBrewedPotionEvent', function (e) {
    try { var p = e.entity; if (p instanceof ServerPlayer) puanVer(p, 'magic', 3) } catch (err) { console.error('[Beceri] demleme: ' + err) }
  })
  try {
    NativeEvents.onEvent('io.redspace.ironsspellbooks.api.events.SpellOnCastEvent', function (e) {
      try { var p = e.entity; if (p instanceof ServerPlayer) puanVer(p, 'magic', 2) } catch (err) { console.error('[Beceri] buyu: ' + err) }
    })
  } catch (e0) { console.warn('[Beceri] Iron\'s buyu olayi baglanamadi: ' + e0) }

  // ----------------------------- istatistikten: çeviklik + büyüleme (30 sn) ------
  ServerEvents.tick(function (event) {
    var server = event.server
    if (server.tickCount % 600 !== 77 || SkillModel == null) return
    try {
      var on = server.playerList.getPlayers().toArray()
      for (var i = 0; i < on.length; i++) {
        var p = on[i]
        // 2026-11-27 düzeltme: KubeJS getStats()'ı getStatsCounter() olarak yeniden adlandırır (RemapForJS);
        // eski çağrı her 30 sn hata verip Çeviklik ve büyüleme puanını hiç vermiyordu.
        var st = p.getStatsCounter()
        var kos = st.getValue(Stats.CUSTOM.get(Stats.SPRINT_ONE_CM))
        var zip = st.getValue(Stats.CUSTOM.get(Stats.JUMP))
        var buy = st.getValue(Stats.CUSTOM.get(Stats.ENCHANT_ITEM))
        var v = veri(p)
        var o = v._ist || null
        v._ist = { k: kos, z: zip, b: buy }
        p.persistentData.putString('beceri_puan', JSON.stringify(v))
        if (o == null) continue   // ilk ölçüm: sadece başlangıç kaydı
        var cev = Math.floor(Math.max(0, kos - o.k) / 4000) + Math.floor(Math.max(0, zip - o.z) / 15)
        if (cev > 0) puanVer(p, 'agility', cev)
        if (buy > o.b) puanVer(p, 'magic', (buy - o.b) * 12)   // büyüleme başına ~3 seviye x 4
      }
    } catch (err) { console.error('[Beceri] istatistik: ' + err) }
  })

  // ----------------------------- OP: beceri ve perk yönetimi (2026-11-27, kullanıcı) -----------------------------
  //  /beceri bak <oyuncu>                        seviyeler + perk durumu
  //  /beceri ver|al|ayarla <oyuncu> <beceri> <n>  seviye ekle / düş / ayarla (1-10). İlerleme puanı o beceride sıfırlanır.
  //  /beceri perk <oyuncu> <beceri> ac|kapat      o becerinin perk'ini (Reskillable öznitelik bonusu) aç/kapat
  //  /beceri sifirla <oyuncu>                    bütün beceriler 1, ilerleme silinir
  //  Her işlem oyuncuya bildirilir ve persistentData 'beceri_op_kayit'a (son 200) yazılır. Menü > Yönetim > OP'de de var.
  var BECERILER = ['mining', 'gathering', 'attack', 'defense', 'building', 'farming', 'agility', 'magic', 'silah']
  function beceriKodu(s) {
    var t = String(s || '').toLowerCase()
    if (BECERILER.indexOf(t) >= 0) return t
    var tr = { madencilik: 'mining', toplayicilik: 'gathering', saldiri: 'attack', savunma: 'defense', insaat: 'building', ciftcilik: 'farming', ceviklik: 'agility', buyu: 'magic', silah: 'silah' }
    t = t.replace(/ı/g, 'i').replace(/ş/g, 's').replace(/ç/g, 'c').replace(/ğ/g, 'g').replace(/ü/g, 'u').replace(/ö/g, 'o')
    return tr[t] || null
  }
  function opKayit(server, kim, hedef, metin) {
    var l = []
    try { l = JSON.parse(server.persistentData.getString('beceri_op_kayit') || '[]') } catch (e) { l = [] }
    l = l.concat([{ t: Date.now(), k: kim, h: hedef, m: metin }]).slice(-200)
    server.persistentData.putString('beceri_op_kayit', JSON.stringify(l))
    console.info('[Beceri] OP ' + kim + ' -> ' + hedef + ': ' + metin)
  }
  function uygula(p) {
    var model = SkillModel.get(p)
    try { model.updateSkillAttributeBonuses(p) } catch (e) { console.warn('[Beceri] perk guncellenemedi: ' + e) }
    model.syncSkills(p)
  }

  ServerEvents.commandRegistry(function (event) {
    var Commands = event.commands
    var Arguments = event.arguments
    function kim(ctx) { return ctx.source.player != null ? String(ctx.source.player.username) : 'Konsol' }
    function cevap(ctx, m) { ctx.source.sendSystemMessage(Text.ofString(m)) }
    function hazir(ctx) { if (SkillModel == null) { cevap(ctx, 'Reskillable yüklü değil.'); return false } return true }

    function seviyeIslem(ctx, islem) {
      if (!hazir(ctx)) return 0
      var p = Arguments.PLAYER.getResult(ctx, 'oyuncu')
      var b = beceriKodu(Arguments.WORD.getResult(ctx, 'beceri'))
      if (!b) { cevap(ctx, 'Bilinmeyen beceri. Seçenekler: ' + BECERILER.map(function (x) { return x + ' (' + AD[x] + ')' }).join(', ')); return 0 }
      var n = Arguments.INTEGER.getResult(ctx, 'miktar')
      var eski = svAl(p, b)
      var yeni = islem === 'ver' ? eski + n : islem === 'al' ? eski - n : n
      yeni = Math.max(1, Math.min(AYAR.MAKS, yeni))
      svYaz(p, b, yeni)
      var v = veri(p); v[b] = 0
      p.persistentData.putString('beceri_puan', JSON.stringify(v))
      var m = AD[b] + ' ' + eski + ' → ' + yeni
      opKayit(p.server, kim(ctx), String(p.username), m)
      cevap(ctx, String(p.username) + ': ' + m)
      p.tell(Text.gold(Text.ofString('[Yönetim] Beceri seviyen değişti: ' + m)))
      return 1
    }

    var beceriArg = function () {
      return Commands.argument('beceri', Arguments.WORD.create(event))
    }
    var seviyeDali = function (islem) {
      return Commands.literal(islem).then(Commands.argument('oyuncu', Arguments.PLAYER.create(event)).then(beceriArg()
        .then(Commands.argument('miktar', Arguments.INTEGER.create(event)).executes(function (ctx) { return seviyeIslem(ctx, islem) }))))
    }

    event.register(Commands.literal('beceri').requires(function (s) { return s.hasPermission(2) })
      .then(Commands.literal('bak').then(Commands.argument('oyuncu', Arguments.PLAYER.create(event)).executes(function (ctx) {
        if (!hazir(ctx)) return 0
        var p = Arguments.PLAYER.getResult(ctx, 'oyuncu')
        var model = SkillModel.get(p)
        cevap(ctx, '=== ' + p.username + ' becerileri ===')
        var v = veri(p)
        BECERILER.forEach(function (b) {
          var l = svAl(p, b)
          var perk = ''
          if (YERLESIK_B[b]) { try { perk = ' · perk ' + (model.isPerkEnabled(b) ? 'açık' : 'KAPALI') } catch (e) { perk = '' } }
          cevap(ctx, AD[b] + ' (' + b + '): seviye ' + l + '/' + AYAR.MAKS + (l < AYAR.MAKS ? ' · ilerleme ' + Math.floor(v[b] || 0) + '/' + gerek(l) : '') + perk)
        })
        return 1
      })))
      .then(seviyeDali('ver'))
      .then(seviyeDali('al'))
      .then(seviyeDali('ayarla'))
      .then(Commands.literal('perk').then(Commands.argument('oyuncu', Arguments.PLAYER.create(event)).then(beceriArg()
        .then(Commands.literal('ac').executes(function (ctx) { return perkIslem(ctx, true) }))
        .then(Commands.literal('kapat').executes(function (ctx) { return perkIslem(ctx, false) })))))
      .then(Commands.literal('sifirla').then(Commands.argument('oyuncu', Arguments.PLAYER.create(event)).executes(function (ctx) {
        if (!hazir(ctx)) return 0
        var p = Arguments.PLAYER.getResult(ctx, 'oyuncu')
        BECERILER.forEach(function (b) { svYaz(p, b, 1) })
        p.persistentData.putString('beceri_puan', JSON.stringify({}))
        opKayit(p.server, kim(ctx), String(p.username), 'bütün beceriler sıfırlandı')
        cevap(ctx, p.username + ': bütün beceriler 1. seviyeye indi.')
        p.tell(Text.red(Text.ofString('[Yönetim] Bütün becerilerin sıfırlandı.')))
        return 1
      }))))

    function perkIslem(ctx, ac) {
      if (!hazir(ctx)) return 0
      var p = Arguments.PLAYER.getResult(ctx, 'oyuncu')
      var b = beceriKodu(Arguments.WORD.getResult(ctx, 'beceri'))
      if (!b) { cevap(ctx, 'Bilinmeyen beceri: ' + BECERILER.join(', ')); return 0 }
      if (!YERLESIK_B[b]) { cevap(ctx, AD[b] + ' becerisinin perk\'i yok.'); return 0 }
      var model = SkillModel.get(p)
      if (model.isPerkEnabled(b) !== ac) model.togglePerk(b, p)
      uygula(p)
      var m = AD[b] + ' perk ' + (ac ? 'açıldı' : 'kapatıldı')
      opKayit(p.server, kim(ctx), String(p.username), m)
      cevap(ctx, String(p.username) + ': ' + m)
      p.tell(Text.gold(Text.ofString('[Yönetim] ' + m)))
      return 1
    }
  })

  console.info('[Beceri] Reskillable is yaparak gelisim hazir' + (SkillModel == null ? ' (Reskillable YOK)' : ''))
})()
