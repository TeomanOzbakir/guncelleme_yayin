// =====================================================================
//  YETENEK SİSTEMİ (Sınıf + Meslek)  -  kubejs/server_scripts/yetenek_sistemi.js
//  Hedef: NeoForge 1.21.1 | KubeJS 2101.7.2 | Pufferfish's Skills 0.19.2
//
//  Ağaçlar: kubejs/data/puffish_skills/puffish_skills (üretici:
//  modpack_duzeltmeler/yetenek/YetenekUret.java). Hepsi kilitli başlar.
//
//  - MESLEK: /meslek sec <ad>  - her zaman seçilebilir (aktif mesleği değiştirir)
//      madenci, zanaatkar, demirci, simyaci, ciftci, balikci, tacir
//    EK MESLEK: aktif mesleğin ağacının TAMAMI açılınca /meslek ekle <ad>; ücret EK_MESLEK_UCRET x 2^(ek sayısı)
//      (2000, 4000, 8000...). Bitmiş meslek ve bonusları kalır (r.ekMeslekler), puan yeni (aktif) mesleğe gider.
//  - SINIF (1 tane):  /sinif sec <ad>   - zindanda SINIF_ZINDAN. seviyeyi bitirince
//      savasci, avci, nisanci, buyucu, elementalist, terbiyeci (Düellocu 2026-11-25 kaldırıldı)
//      Her sınıf ağacında 2 dal vardır, yalnızca biri açılabilir.
//  - İlk seçim bedava; değiştirmek DEGISIM_UCRET spur (eski ağacın tüm ilerlemesi silinir).
//  - /yetenek sifirla sinif|meslek: harcanan puan x PUAN_UCRET spur, puanlar geri gelir
//    (dal değiştirmek de böyle). Ücretler Devlet Hazinesi'ne.
//  - Puanlar: sınıflar yaratık öldürerek (zindanda ek), madenci kazarak, zanaatkar üretip
//    eriterek, simyacı büyüleyip iksir demleyerek, balıkçı balık tutarak (Pufferfish kendisi);
//    çiftçi olgun hasattan, tacir Selling Bin satışından (bu script).
//  - Özel düğümler "yt_..." etiketi verir; bu script ve vergi/kredi/piyasa okur:
//      Nişancı: TaCZ hasar/kafa vuruşu | Çiftçi: iki kat hasat | Simyacı: iksir süresi, ekstra iksir
//      Tacir: satış bonusu (sunucu_piyasa), vergi indirimi (vergi_sistemi), kredi (borc_kredi)
//    Çevrimdışı oyuncular için etiketler 'yetenek_etiket' önbelleğine yazılır.
//
//  !! Gerçek bir oyunda ÇALIŞTIRILARAK TEST EDİLMEDİ.
// =====================================================================

;(function () {
  var AYAR = {
    SINIF_ZINDAN: 5,        // sınıf seçmek için bitirilmiş en yüksek zindan seviyesi
    DEGISIM_UCRET: 2000,    // sınıf/meslek değiştirme
    EK_MESLEK_UCRET: 2000,  // ek meslek: 1. ek 2000, 2. ek 4000, 3. ek 8000 ... (her seferinde 2 katı)
    PUAN_UCRET: 50,         // sıfırlamada harcanan puan başı
    CIFTCI_XP: 3,           // olgun ürün başı
    SIMYA_XP: 15,           // demlenen iksir başı
    SIMYA_SINIR: 3,         // 20 sn'de en fazla bu kadar iksir ödül alır (bir demleme = 3 iksir)
    TACIR_SPUR_XP: 4,       // her 4 spur satış = 1 deneyim
    ZINDAN_XP_BOLEN: 25,    // zindan canavarı ek deneyimi = can / 25
    ZINDAN_BOSS_XP: 60      // boss / kat bekçisi ek deneyimi
  }
  // v7 (2026-11-25, kullanıcı): Düellocu kaldırıldı (özel getirisi yoktu). Meslekler Pufferfish'te TEK kategoride ("meslek"):
  // düğümler "<meslek>_<id>", kökler "<meslek>_k". Oyuncu kökü Pufferfish'te tıklayarak veya menüden seçer. Açılabilen meslek
  // sayısı = 1 + ağacını bitirdiği meslek sayısı (ücretsiz); fazladan açılan kök geri kilitlenir. Meslek deneyimi
  // "yt_meslek_<ad>" etiketine bağlı (Pufferfish has_tag), etiketleri bu betik eşitler. Eski ayrı meslek kategorileri
  // gizli durur; oyuncu girince seviyeleri yeni kategoriye taşınır (AGAC_SURUM 7).
  var SINIF = { savasci: 'Savaşçı', avci: 'Avcı', nisanci: 'Nişancı', buyucu: 'Büyücü', elementalist: 'Elementalist', terbiyeci: 'Terbiyeci' }
  var MESLEK = { madenci: 'Madenci', zanaatkar: 'İnşaatçı', demirci: 'Demirci', simyaci: 'Simyacı', ciftci: 'Çiftçi', balikci: 'Balıkçı', tacir: 'Tacir', asci: 'Aşçı', muhendis: 'Mühendis' }
  var HAZINE_UUID_STR = '5f0c2d1e-7a3b-4e9c-8d6f-1b2a3c4d5e6f'

  var JUUID = Java.loadClass('java.util.UUID')
  var RL = Java.loadClass('net.minecraft.resources.ResourceLocation')
  var SkillsAPI = Java.loadClass('net.puffish.skillsmod.api.SkillsAPI')
  var Numismatics = Java.loadClass('dev.ithundxr.createnumismatics.Numismatics')
  var ReasonHolder = Java.loadClass('dev.ithundxr.createnumismatics.content.backend.ReasonHolder')
  var BankType = Java.loadClass('dev.ithundxr.createnumismatics.content.backend.BankAccount$Type')
  var CropBlock = Java.loadClass('net.minecraft.world.level.block.CropBlock')
  var McBlock = Java.loadClass('net.minecraft.world.level.block.Block')
  var DataComponents = Java.loadClass('net.minecraft.core.component.DataComponents')
  var MobEffectInstance = Java.loadClass('net.minecraft.world.effect.MobEffectInstance')
  var ServerPlayer = Java.loadClass('net.minecraft.server.level.ServerPlayer')
  var HAZINE_UUID = JUUID.fromString(HAZINE_UUID_STR)
  var ZindanApi = null
  try { ZindanApi = Java.loadClass('tr.sunucu.zindan.ZindanApi') } catch (e) { ZindanApi = null }

  // TaCZ silah türleri (silah_seviye.js ile aynı liste)
  var SILAH_TUR = {}
  function turEkle(tur, liste) { liste.split(',').forEach(function (g) { SILAH_TUR['tacz:' + g] = tur }) }
  turEkle('pistol', 'b93r,cz75,deagle,deagle_golden,glock_17,hk_mk23,lonetrail,m1911,m9a4,p320,rhino357,taurus500,taurus943,tec_9,timeless50')
  turEkle('smg', 'hk_mp5a5,hk_mp7a1,p90,ump45,uzi,vector45')
  turEkle('shotgun', 'aa12,db_long,db_short,m1014,m1897,m870,spas_12')
  turEkle('rifle', 'ak12,ak47,ak74m,aug,fn_fal,g36k,hcar,hk_g3,hk416d,m16a1,m16a4,m4a1,mcx_spear_lt,mk18,qbz_191,qbz_95,qr_24,scar_h,scar_l,type_81,urgi')
  turEkle('dmr', 'm1866,mk14,scar_mk20,sks_tactical,spr15hb')
  turEkle('sniper', 'ai_awp,hm50b,kar98,m107,m700,m95,mrad,springfield1873,svd')
  turEkle('mg', 'fn_evolys,m249,minigun,pkm,rpk')
  turEkle('rpg', 'm320,rpg7')
  var TUFEK = { rifle: 1, dmr: 1, sniper: 1 }
  var AGIR = { mg: 1, shotgun: 1, rpg: 1 }

  // ----------------------------- VERİ --------------------------------
  function yukle(server) {
    var s = server.persistentData.getString('yetenek_veri')
    var d = null
    if (s) { try { d = JSON.parse(s) } catch (e) { d = null } }
    if (!d || !d.o) d = { o: {} }
    return d
  }
  function kaydet(server, d) { server.persistentData.putString('yetenek_veri', JSON.stringify(d)) }
  function kayit(d, id) { return d.o[id] || (d.o[id] = { sinif: null, meslek: null }) }
  // Sahip olunan meslekler (sıralı). r.meslek / r.ekMeslekler diğer betikler için eşit tutulur (banka: tacir kontrolü).
  function meslekleri(r) {
    if (!r) return []
    if (r.meslekler) return r.meslekler.slice()
    return (r.meslek ? [r.meslek] : []).concat(r.ekMeslekler ? r.ekMeslekler : [])
  }
  function meslekYaz(r, l) { r.meslekler = l; r.meslek = l[0] || null; r.ekMeslekler = l.slice(1) }
  function meslekVar(r, ad) { return meslekleri(r).indexOf(ad) >= 0 }
  var MK = 'meslek'
  function meslekKat() { return kategori(MK) }
  // Mesleğin (meslek kategorisindeki <ad>_ ile başlayan) tüm düğümleri açık mı
  function agacBitti(p, ad) {
    var k = meslekKat()
    if (k == null || !k.isUnlocked(p)) return false
    var on = ad + '_', hepsi = 0, acik = 0
    var it = k.streamSkills().iterator()
    while (it.hasNext()) { if (String(it.next().getId()).indexOf(on) === 0) hepsi++ }
    var it2 = k.streamUnlockedSkills(p).iterator()
    while (it2.hasNext()) { if (String(it2.next().getId()).indexOf(on) === 0) acik++ }
    return hepsi > 0 && acik >= hepsi
  }
  function meslekIlerleme(p, ad) {
    var k = meslekKat()
    if (k == null) return '0/0'
    var on = ad + '_', hepsi = 0, acik = 0
    var it = k.streamSkills().iterator()
    while (it.hasNext()) { if (String(it.next().getId()).indexOf(on) === 0) hepsi++ }
    var it2 = k.streamUnlockedSkills(p).iterator()
    while (it2.hasNext()) { if (String(it2.next().getId()).indexOf(on) === 0) acik++ }
    return acik + '/' + hepsi
  }
  // Açılabilecek meslek sayısı: 1 + bitirilen meslek ağacı (ve zaten sahip olunan sayının altına inmez)
  function meslekHakki(p, l) {
    var biten = 0
    l.forEach(function (ad) { if (agacBitti(p, ad)) biten++ })
    return Math.max(l.length, 1 + biten)
  }
  function kokAcikMi(k, p, ad) { var o = k.getSkill(ad + '_k'); return o.isPresent() && String(o.get().getState(p)) === 'UNLOCKED' }
  // Bir mesleğin açık düğümlerini kilitler (önce dallar, en son kök); puanlar geri gelir
  function meslekKilitle(k, p, ad) {
    var on = ad + '_', kok = null, l = []
    var it = k.streamUnlockedSkills(p).iterator()
    while (it.hasNext()) { var s = it.next(); var id = String(s.getId()); if (id.indexOf(on) !== 0) continue; if (id === on + 'k') kok = s; else l.push(s) }
    l.reverse().forEach(function (s) { s.lock(p) })
    if (kok != null) kok.lock(p)
  }
  function kokAc(k, p, ad) {
    var o = k.getSkill(ad + '_k')
    if (!o.isPresent() || String(o.get().getState(p)) === 'UNLOCKED') return true
    if (k.getPointsLeft(p) < 1) { p.tell(Text.ofString('Kökü açacak puanın olunca Pufferfish\'te (Meslekler) kökü aç.')); return false }
    o.get().unlock(p)
    return true
  }

  function kategori(ad) {
    var o = SkillsAPI.getCategory(RL.parse('puffish_skills:' + ad))
    return o.isPresent() ? o.get() : null
  }
  function deneyimVer(p, ad, m) {
    if (!ad || !(m > 0)) return
    var k = MESLEK[ad] ? meslekKat() : kategori(ad)
    if (k == null || !k.isUnlocked(p)) return
    var e = k.getExperience()
    if (e.isPresent()) e.get().addTotal(p, Math.floor(m))
  }
  function etiketVar(p, t) { return p.getTags().contains(t) }
  function zindanSeviye(p) {
    if (ZindanApi == null) return 0
    try { return JSON.parse(String(ZindanApi.ozet(String(p.getUuid())))).enYuksek || 0 } catch (e) { return 0 }
  }

  // ----------------------------- PARA --------------------------------
  function ucretAl(p, m, neden) {
    if (m <= 0) return true
    var h = Numismatics.BANK.getAccount(p.getUuid())
    if (!h || h.getBalance() < m || !h.deduct(m, ReasonHolder.IGNORED)) return false
    h.markDirty()
    var hz = Numismatics.BANK.getOrCreateAccount(HAZINE_UUID, BankType.BLAZE_BANKER); hz.deposit(m); hz.markDirty()
    var s = p.server.persistentData.getString('hazine_veri')
    var d = null
    if (s) { try { d = JSON.parse(s) } catch (e) { d = null } }
    if (!d) d = {}
    if (!d.gelir) d.gelir = { arazi: 0, olum: 0, tescil: 0 }
    d.gelir.yetenek = (d.gelir.yetenek || 0) + m
    d.hareket = (d.hareket || []).concat([{ t: Date.now(), tur: 'yetenek', m: m, k: String(p.username) + ' (' + neden + ')' }]).slice(-500)
    p.server.persistentData.putString('hazine_veri', JSON.stringify(d))
    return true
  }

  // ----------------------------- SEÇİM -------------------------------
  // tur: 'sinif' | 'meslek'
  function sec(p, tur, ad) {
    if (tur === 'meslek') return meslekSec(p, ad)
    var liste = tur === 'sinif' ? SINIF : MESLEK
    if (!liste[ad]) { p.tell(Text.red(Text.ofString('Böyle bir ' + (tur === 'sinif' ? 'sınıf' : 'meslek') + ' yok.'))); return 0 }
    if (tur === 'sinif') {
      var sv = zindanSeviye(p)
      if (sv < AYAR.SINIF_ZINDAN) {
        p.tell(Text.red(Text.ofString('Sınıf seçmek için zindanda ' + AYAR.SINIF_ZINDAN + '. seviyeyi bitirmelisin (en yüksek: ' + sv + '). /zindan')))
        return 0
      }
    }
    var server = p.server
    var d = yukle(server)
    var r = kayit(d, String(p.getUuid()))
    var eski = r[tur]
    if (eski === ad) { p.tell(Text.ofString('Zaten ' + liste[ad] + '.')); return 0 }
    if (tur === 'meslek' && meslekVar(r, ad)) { p.tell(Text.ofString(liste[ad] + ' mesleğini zaten bitirdin; hâlâ sende.')); return 0 }
    // Bankası açık Tacir mesleğini bırakamaz (banka_sistemi.js)
    if (tur === 'meslek' && eski === 'tacir') {
      var bv = {}
      try { bv = JSON.parse(server.persistentData.getString('banka_veri') || '{}') } catch (e) { bv = {} }
      var sahipId = String(p.getUuid())
      var bankasi = Object.keys(bv.b || {}).filter(function (k) { return bv.b[k].sahip === sahipId })[0]
      if (bankasi) { p.tell(Text.red(Text.ofString('Bankan (' + bv.b[bankasi].ad + ') açıkken Tacir mesleğini bırakamazsın. Önce bankayı kapat: /banka kapat'))); return 0 }
    }
    var yeni = kategori(ad)
    if (yeni == null) { p.tell(Text.red(Text.ofString('Yetenek ağacı bulunamadı (' + ad + '). Yöneticiye haber ver.'))); return 0 }
    var ucret = eski ? AYAR.DEGISIM_UCRET : 0
    if (!ucretAl(p, ucret, tur + ' ' + ad)) { p.tell(Text.red(Text.ofString('Değiştirmek için bankanda ' + ucret + ' spur olmalı.'))); return 0 }
    if (eski) { var k = kategori(eski); if (k != null) { k.erase(p); k.lock(p) } }
    yeni.erase(p)
    yeni.unlock(p)
    r[tur] = ad
    kaydet(server, d)
    p.tell(Text.green(Text.ofString((tur === 'sinif' ? 'Sınıfın: ' : 'Mesleğin: ') + liste[ad] +
      (ucret > 0 ? ' (' + ucret + ' spur, eski ağacın ilerlemesi silindi)' : '') + '. Yetenek ağacını açmak için Pufferfish tuşu (varsayılan K) veya /yetenek ac')))
    return 1
  }

  // Meslek seçimi (menü veya /meslek sec): boş hak varsa eklenir (ücretsiz); yoksa son meslek çıkarılıp
  // (düğümleri kilitlenir, puanları geri gelir) yenisi konur, DEGISIM_UCRET ödenir. Pufferfish'te kök tıklamak da seçer.
  function meslekSec(p, ad) {
    if (!MESLEK[ad]) { p.tell(Text.red(Text.ofString('Böyle bir meslek yok.'))); return 0 }
    var server = p.server
    var d = yukle(server)
    var r = kayit(d, String(p.getUuid()))
    var l = meslekleri(r)
    if (l.indexOf(ad) >= 0) { p.tell(Text.ofString(MESLEK[ad] + ' zaten mesleğin.')); return 0 }
    var k = meslekKat()
    if (k == null) { p.tell(Text.red(Text.ofString('Meslek ağacı bulunamadı. Yöneticiye haber ver.'))); return 0 }
    if (!k.isUnlocked(p)) k.unlock(p)
    var hak = meslekHakki(p, l)
    var ucret = 0, cikan = null
    if (l.length >= hak) {
      cikan = l[l.length - 1]
      if (cikan === 'tacir') {
        var bv = {}
        try { bv = JSON.parse(server.persistentData.getString('banka_veri') || '{}') } catch (e) { bv = {} }
        var sahipId = String(p.getUuid())
        var bankasi = Object.keys(bv.b || {}).filter(function (x) { return bv.b[x].sahip === sahipId })[0]
        if (bankasi) { p.tell(Text.red(Text.ofString('Bankan (' + bv.b[bankasi].ad + ') açıkken Tacir mesleğini bırakamazsın. Önce bankayı kapat.'))); return 0 }
      }
      ucret = AYAR.DEGISIM_UCRET
      if (!ucretAl(p, ucret, 'meslek ' + ad)) { p.tell(Text.red(Text.ofString('Meslek değiştirmek için bankanda ' + ucret + ' spur olmalı (' + MESLEK[cikan] + ' bırakılır).'))); return 0 }
      meslekKilitle(k, p, cikan)
      l.pop()
    }
    l.push(ad)
    meslekYaz(r, l)
    kaydet(server, d)
    meslekEtiketi(p, r)
    kokAc(k, p, ad)
    p.tell(Text.green(Text.ofString('Meslek: ' + MESLEK[ad] + (cikan ? ' (' + MESLEK[cikan] + ' bırakıldı, puanları geri geldi, ' + ucret + ' spur)' : '') +
      '. Mesleklerin: ' + l.map(function (m) { return MESLEK[m] }).join(', ') + '. Ağaç: K > Yetenek ağaçları > Meslekler.')))
    return 1
  }

  // Oyuncunun meslek etiketleri (Pufferfish deneyimi bunlara bakar)
  function meslekEtiketi(p, r) {
    var l = meslekleri(r)
    Object.keys(MESLEK).forEach(function (ad) {
      var t = 'yt_meslek_' + ad
      var var_ = p.getTags().contains(t)
      if (l.indexOf(ad) >= 0 && !var_) p.addTag(t)
      else if (l.indexOf(ad) < 0 && var_) p.removeTag(t)
    })
  }

  function sifirla(p, tur) {
    var d = yukle(p.server)
    var r = kayit(d, String(p.getUuid()))
    if (tur === 'sinif' ? !r.sinif : !meslekleri(r).length) { p.tell(Text.ofString('Önce bir ' + (tur === 'sinif' ? 'sınıf' : 'meslek') + ' seçmelisin.')); return 0 }
    var k = tur === 'sinif' ? kategori(r.sinif) : meslekKat()
    if (k == null) return 0
    var harcanan = k.getSpentPoints(p)
    if (harcanan <= 0) { p.tell(Text.ofString('Bu ağaçta harcanmış puanın yok.')); return 0 }
    var ucret = harcanan * AYAR.PUAN_UCRET
    if (!ucretAl(p, ucret, 'sifirla ' + (tur === 'sinif' ? r.sinif : 'meslek'))) { p.tell(Text.red(Text.ofString('Sıfırlamak için bankanda ' + ucret + ' spur olmalı (' + harcanan + ' puan x ' + AYAR.PUAN_UCRET + ').'))); return 0 }
    k.resetSkills(p)
    p.tell(Text.green(Text.ofString(harcanan + ' puan geri verildi (' + ucret + ' spur). Ağacı yeniden dağıtabilirsin' + (tur === 'sinif' ? '; dal da değiştirebilirsin.' : '; mesleklerin duruyor, köklerini Pufferfish\'te yeniden aç.'))))
    return 1
  }

  function durum(p) {
    var r = kayit(yukle(p.server), String(p.getUuid()))
    var sv = zindanSeviye(p)
    var l = meslekleri(r)
    p.tell(Text.gold(Text.ofString('--- Yetenekler (menü: K) ---')))
    p.tell(Text.ofString('Sınıf: ' + (r.sinif ? SINIF[r.sinif] + puanYazi(p, kategori(r.sinif)) : (sv >= AYAR.SINIF_ZINDAN ? 'seçilmedi (/sinif)' : 'kilitli - zindan ' + AYAR.SINIF_ZINDAN + '. seviye gerekli (sen: ' + sv + ')'))))
    p.tell(Text.ofString('Meslek: ' + (l.length ? l.map(function (m) { return MESLEK[m] + ' ' + meslekIlerleme(p, m) }).join(', ') + puanYazi(p, meslekKat()) : 'seçilmedi (/meslek)')))
    var hak = meslekHakki(p, l)
    if (hak > l.length) p.tell(Text.green(Text.ofString('Bir meslek daha seçebilirsin (ücretsiz): /meslek sec <ad> veya Pufferfish\'te kökünü aç.')))
    p.tell(Text.ofString('Değiştirme: ' + AYAR.DEGISIM_UCRET + ' spur | Sıfırlama: harcanan puan x ' + AYAR.PUAN_UCRET + ' spur (/yetenek sifirla sinif|meslek)'))
  }
  function puanYazi(p, k) {
    if (k == null) return ''
    var e = k.getExperience()
    return ' (seviye ' + (e.isPresent() ? e.get().getLevel(p) : 0) + ', harcanan ' + k.getSpentPoints(p) + ', boşta ' + k.getPointsLeft(p) + ' puan)'
  }

  // Menü (arayuz_komut.js > Sınıf & Meslek) için özet
  if (global.ortak) global.ortak.put('yetenekOzet', yetenekOzetFn)
  function yetenekOzetFn(p) {
    var r = kayit(yukle(p.server), String(p.getUuid()))
    var l = meslekleri(r)
    var ks = r.sinif ? kategori(r.sinif) : null, km = meslekKat()
    function sv(k) { if (k == null) return 0; var e = k.getExperience(); return e.isPresent() ? e.get().getLevel(p) : 0 }
    return {
      sinif: r.sinif, sinifAd: r.sinif ? SINIF[r.sinif] : '', sinifSv: sv(ks), sinifBos: ks ? ks.getPointsLeft(p) : 0,
      sinifAcik: zindanSeviye(p) >= AYAR.SINIF_ZINDAN, sinifZindan: AYAR.SINIF_ZINDAN,
      meslekler: l.map(function (m) { return MESLEK[m] + ' ' + meslekIlerleme(p, m) }), meslekSv: sv(km), meslekBos: km ? km.getPointsLeft(p) : 0,
      ekHak: Math.max(0, meslekHakki(p, l) - l.length), degisim: AYAR.DEGISIM_UCRET, puanUcret: AYAR.PUAN_UCRET,
      sinifSecenek: Object.keys(SINIF).map(function (k) { return { d: k, y: SINIF[k] + (k === r.sinif ? ' (şu an)' : '') } }),
      meslekSecenek: Object.keys(MESLEK).filter(function (k) { return l.indexOf(k) < 0 }).map(function (k) { return { d: k, y: MESLEK[k] } })
    }
  }
  // ----------------------------- KOMUTLAR ----------------------------
  ServerEvents.commandRegistry(function (event) {
    var Commands = event.commands
    function oyuncu(ctx) { return ctx.source.player }

    var sinifK = Commands.literal('sinif').executes(function (ctx) {
      var p = oyuncu(ctx); if (p == null) return 0
      durum(p)
      p.tell(Text.ofString('Sınıflar: ' + Object.keys(SINIF).map(function (k) { return SINIF[k] + ' (/sinif sec ' + k + ')' }).join(', ')))
      return 1
    })
    var sinifSec = Commands.literal('sec')
    Object.keys(SINIF).forEach(function (ad) {
      sinifSec = sinifSec.then(Commands.literal(ad).executes(function (ctx) { var p = oyuncu(ctx); return p == null ? 0 : sec(p, 'sinif', ad) }))
    })
    event.register(sinifK.then(sinifSec))

    var meslekK = Commands.literal('meslek').executes(function (ctx) {
      var p = oyuncu(ctx); if (p == null) return 0
      durum(p)
      p.tell(Text.ofString('Meslekler: ' + Object.keys(MESLEK).map(function (k) { return MESLEK[k] + ' (/meslek sec ' + k + ')' }).join(', ')))
      return 1
    })
    var meslekSec = Commands.literal('sec')
    Object.keys(MESLEK).forEach(function (ad) {
      meslekSec = meslekSec.then(Commands.literal(ad).executes(function (ctx) { var p = oyuncu(ctx); return p == null ? 0 : sec(p, 'meslek', ad) }))
    })
    event.register(meslekK.then(meslekSec))

    event.register(Commands.literal('yetenek')
      .executes(function (ctx) { var p = oyuncu(ctx); if (p == null) return 0; durum(p); return 1 })
      .then(Commands.literal('ac').executes(function (ctx) { var p = oyuncu(ctx); if (p == null) return 0; SkillsAPI.openScreen(p); return 1 }))
      .then(Commands.literal('sifirla')
        .then(Commands.literal('sinif').executes(function (ctx) { var p = oyuncu(ctx); return p == null ? 0 : sifirla(p, 'sinif') }))
        .then(Commands.literal('meslek').executes(function (ctx) { var p = oyuncu(ctx); return p == null ? 0 : sifirla(p, 'meslek') }))))
  })

  // ----------------------------- SINIF ETİKETİ (zindan ganimeti) -----
  // 2026-11-24: sunucu_zindan modu oyuncunun sınıfını "yt_sinif_<ad>" etiketinden okur (kendi sınıfının
  // ekipmanı zindanda biraz daha sık düşer). 5 saniyede bir çevrimiçi oyuncular için eşitlenir.
  function sinifEtiketi(p, d) {
    var r = d.o[String(p.getUuid())]
    var istenen = r && r.sinif ? 'yt_sinif_' + r.sinif : null
    var sil = []
    var it = p.getTags().iterator()
    while (it.hasNext()) { var t = String(it.next()); if (t.indexOf('yt_sinif_') === 0 && t !== istenen) sil.push(t) }
    for (var i = 0; i < sil.length; i++) p.removeTag(sil[i])
    if (istenen && !p.getTags().contains(istenen)) p.addTag(istenen)
  }
  ServerEvents.tick(function (event) {
    var server = event.server
    if (server.tickCount % 100 !== 37) return
    try {
      var d = yukle(server)
      var on = server.playerList.getPlayers().toArray()
      for (var i = 0; i < on.length; i++) { sinifEtiketi(on[i], d); meslekEtiketi(on[i], d.o[String(on[i].getUuid())] || {}) }
    } catch (e) { console.warn('[yetenek] sinif etiketi: ' + e) }
  })

  // ----------------------------- ETİKET ÖNBELLEĞİ + TACİR ------------
  // Çevrimdışı oyuncuların vergi/kredi bonusları için 'yt_' etiketleri; Tacir deneyimi kuyruğu
  ServerEvents.tick(function (event) {
    var server = event.server
    if (server.tickCount % 1200 !== 600) return
    try {
      var on = server.playerList.getPlayers().toArray()
      var et = {}
      try { et = JSON.parse(server.persistentData.getString('yetenek_etiket') || '{}') } catch (e) { et = {} }
      for (var i = 0; i < on.length; i++) {
        var l = []
        var it = on[i].getTags().iterator()
        while (it.hasNext()) { var t = String(it.next()); if (t.indexOf('yt_') === 0) l.push(t) }
        et[String(on[i].getUuid())] = l
      }
      server.persistentData.putString('yetenek_etiket', JSON.stringify(et))

      // Tacir: sunucu_piyasa modunun yazdığı satışlar ('satis_xp': [{u, m(spur)}]); çevrimdışı olanınki bekler
      var s = server.persistentData.getString('satis_xp')
      if (s && s !== '[]') {
        var liste = []
        try { liste = JSON.parse(s) } catch (e) { liste = [] }
        var d = yukle(server)
        var kalan = []
        var topla = {}
        liste.forEach(function (x) { if (x && x.u && x.m > 0) topla[x.u] = (topla[x.u] || 0) + x.m })
        Object.keys(topla).forEach(function (id) {
          var r = d.o[id]
          if (!meslekVar(r, 'tacir')) return
          var p = server.playerList.getPlayer(JUUID.fromString(id))
          if (p == null) { kalan.push({ u: id, m: topla[id] }); return }
          deneyimVer(p, 'tacir', topla[id] / AYAR.TACIR_SPUR_XP)
        })
        server.persistentData.putString('satis_xp', JSON.stringify(kalan))
      }
    } catch (err) { console.error('[Yetenek] tick hatasi: ' + err) }
  })

  // ----------------------------- SINIF: ZİNDAN EK DENEYİMİ ----------
  EntityEvents.death(function (event) {
    var e = event.entity
    if (!e || e.isPlayer() || !e.getTags().contains('zindan')) return
    var k = event.source.getActual()
    if (k == null || !k.isPlayer()) return
    try {
      var r = yukle(event.server).o[String(k.getUuid())]
      if (!r || !r.sinif) return
      var m = Math.min(e.getMaxHealth(), 1000) / AYAR.ZINDAN_XP_BOLEN
      if (e.getTags().contains('zindan_boss')) m += AYAR.ZINDAN_BOSS_XP
      deneyimVer(k, r.sinif, m)
    } catch (err) { console.error('[Yetenek] zindan deneyim hatasi: ' + err) }
  })

  // ----------------------------- ÇİFTÇİ -------------------------------
  BlockEvents.broken(function (event) {
    var p = event.player
    if (p == null || p.isCreative()) return
    try {
      var st = event.block.blockState
      var b = st.getBlock()
      if (!(b instanceof CropBlock) || !b.isMaxAge(st)) return
      var r = yukle(event.server).o[String(p.getUuid())]
      if (meslekVar(r, 'ciftci')) deneyimVer(p, 'ciftci', AYAR.CIFTCI_XP)
      var sans = (etiketVar(p, 'yt_hasat_1') ? 0.1 : 0) + (etiketVar(p, 'yt_hasat_2') ? 0.1 : 0) +
        (etiketVar(p, 'yt_hasat_3') ? 0.1 : 0) + (etiketVar(p, 'yt_hasat_4') ? 0.05 : 0) + (etiketVar(p, 'yt_hasat_5') ? 0.05 : 0) +
        (etiketVar(p, 'yt_hasat_ana') ? 0.1 : 0) + (etiketVar(p, 'yt_hasat_doruk') ? 0.2 : 0)
      if (sans > 0 && Math.random() < sans) {
        var lvl = event.level
        var pos = event.block.pos
        var drops = McBlock.getDrops(st, lvl, pos, null).toArray()
        for (var i = 0; i < drops.length; i++) McBlock.popResource(lvl, pos, drops[i])
      }
    } catch (err) { console.error('[Yetenek] hasat hatasi: ' + err) }
  })

  // ----------------------------- SİMYACI ------------------------------
  var simyaSayac = {}   // uuid -> [zamanlar]
  NativeEvents.onEvent('net.neoforged.neoforge.event.brewing.PlayerBrewedPotionEvent', function (event) {
    // NativeEvents hatayı yakalamaz (oyun çöker): her şey try içinde
    try {
      var p = event.entity
      if (!(p instanceof ServerPlayer)) return
      var id = String(p.getUuid())
      var simdi = p.server.tickCount
      var l = (simyaSayac[id] || []).filter(function (t) { return simdi - t < 400 })
      if (l.length >= AYAR.SIMYA_SINIR) { simyaSayac[id] = l; return }
      l.push(simdi)
      simyaSayac[id] = l
      var r = yukle(p.server).o[id]
      if (meslekVar(r, 'simyaci')) deneyimVer(p, 'simyaci', AYAR.SIMYA_XP)
      var sans = (etiketVar(p, 'yt_iksir_bereket_1') ? 0.1 : 0) + (etiketVar(p, 'yt_iksir_bereket_2') ? 0.1 : 0) +
        (etiketVar(p, 'yt_iksir_bereket_3') ? 0.05 : 0) + (etiketVar(p, 'yt_iksir_ana') ? 0.1 : 0) + (etiketVar(p, 'yt_iksir_doruk') ? 0.15 : 0)
      if (sans > 0 && Math.random() < sans) {
        p.give(event.getStack().copy())
        p.setStatusMessage(Text.green(Text.ofString('Bereketli demleme: bir iksir fazla!')))
      }
    } catch (err) { console.error('[Yetenek] simya hatasi: ' + err) }
  })
  // İçilen iksirin etkileri daha uzun sürer
  NativeEvents.onEvent('net.neoforged.neoforge.event.entity.living.LivingEntityUseItemEvent$Finish', function (event) {
    try {
      var p = event.entity
      if (!(p instanceof ServerPlayer)) return
      var carpan = (etiketVar(p, 'yt_iksir_sure_1') ? 0.15 : 0) + (etiketVar(p, 'yt_iksir_sure_2') ? 0.15 : 0) +
        (etiketVar(p, 'yt_iksir_sure_3') ? 0.15 : 0) + (etiketVar(p, 'yt_iksir_sure_4') ? 0.1 : 0) +
        (etiketVar(p, 'yt_iksir_ana') ? 0.1 : 0) + (etiketVar(p, 'yt_iksir_doruk') ? 0.25 : 0)
      if (carpan <= 0) return
      var st = event.getItem()
      if (String(st.id) !== 'minecraft:potion') return
      var icerik = st.get(DataComponents.POTION_CONTENTS)
      if (icerik == null) return
      var it = icerik.getAllEffects().iterator()
      while (it.hasNext()) {
        var ef = it.next()
        if (ef.getEffect().value().isInstantenous()) continue
        var sure = Math.floor(ef.getDuration() * (1 + carpan))
        p.addEffect(new MobEffectInstance(ef.getEffect(), sure, ef.getAmplifier(), ef.isAmbient(), ef.isVisible(), ef.showIcon()))
      }
    } catch (err) { console.error('[Yetenek] iksir suresi hatasi: ' + err) }
  })

  // ----------------------------- DEMİRCİ ------------------------------
  // Mending kapalı. Tamir: Overgeared dövme örsünde hasarlı eşya + malzeme, mini oyunla (sunucu_bakim modu,
  // Tamir.java; vuruş kalitesi onarımı belirler, deneyimi de mod verir). Normal örs herkes için vanilla.
  // Burada sadece Create makine başlığını normal örste bitirmenin deneyimi.
  NativeEvents.onEvent('net.neoforged.neoforge.event.entity.player.AnvilRepairEvent', function (event) {
    try {
      var p = event.entity
      if (!(p instanceof ServerPlayer)) return
      var r = yukle(p.server).o[String(p.getUuid())]
      if (!meslekVar(r, 'demirci')) return
      var cikti = String(event.getOutput().id)
      if (cikti.indexOf('sunucu_bakim:') === 0) deneyimVer(p, 'demirci', 15 * event.getOutput().getCount())   // makine başlığı bitirme
    } catch (err) { console.error('[Yetenek] demirci xp hatasi: ' + err) }
  })

  // ----------------------------- NİŞANCI (TaCZ) ----------------------
  var SILAH_ETIKET = /^yt_(silah|kafa|tufek|agir)_v(\d+)_/
  function silahEtiketleri(tg) {
    var t = { silah: 0, kafa: 0, tufek: 0, agir: 0 }
    var it = tg.iterator()
    while (it.hasNext()) {
      var m = SILAH_ETIKET.exec(String(it.next()))
      if (m) t[m[1]] += Number(m[2]) / 100
    }
    return t
  }
  NativeEvents.onEvent('com.tacz.guns.api.event.common.EntityHurtByGunEvent$Pre', function (event) {
    try {
      if (!event.getLogicalSide().isServer()) return
      var a = event.getAttacker()
      if (!(a instanceof ServerPlayer)) return
      var tg = a.getTags()
      var tur = SILAH_TUR[String(event.getGunId())]
      // v3 etiketleri: yt_<tur>_v<yüzde>_<sıra> (YetenekUret.java); her tür için yüzdeler toplanır
      var top = silahEtiketleri(tg)
      var hasar = top.silah
      var kafa = top.kafa
      if (TUFEK[tur]) hasar += top.tufek
      else if (AGIR[tur]) hasar += top.agir
      if (hasar > 0) event.setBaseAmount(event.getBaseAmount() * (1 + hasar))
      if (kafa > 0 && event.isHeadShot()) event.setHeadshotMultiplier(event.getHeadshotMultiplier() * (1 + kafa))
    } catch (err) { console.error('[Yetenek] silah hatasi: ' + err) }
  })

  // ----------------------------- AĞAÇ SÜRÜMÜ ------------------------
  // Ağaçlar değişince (v2: büyütme + sınıf dallarının birbirini dışlaması) oyuncunun sınıf ve meslek
  // puanları bir kez ücretsiz iade edilir; iki dalı birden açmış olanlar da böylece temizlenir.
  // v3 (2026-11-24): sınıf ağaçları çok büyüdü, Büyücü 3 dal, Elementalist, Terbiyeci tek dal (meslekler aynı)
  // v4 (2026-11-24): Demirci ağacı 3 yol (Tamir / Silah Ustalığı / Dövme Ustalığı) -> Demirci puanları iade
  // v5: Dövme Ustalığı yolu 4 kademe (Ice and Fire / Spartan Fire)
  // v6: Necromancer dalı Büyücü'den Terbiyeci'ye taşındı -> Büyücü ve Terbiyeci puanları iade
  // v7: Düellocu kaldırıldı; meslekler tek kategori (eski kategorilerin seviyeleri toplanıp taşınır)
  var AGAC_SURUM = 7
  function v7Gecis(p, r) {
    var mesaj = []
    if (r.sinif === 'duellocu') { r.sinif = null; mesaj.push('Düellocu sınıfı kaldırıldı; yeni sınıfını ücretsiz seç (K).') }
    var l = meslekleri(r)
    var k = meslekKat()
    if (k == null) return mesaj   // meslek kategorisi yüklenmediyse r.meslekGecis kurulmaz, sonraki girişte yeniden denenir
    r.meslekGecis = true
    if (!k.isUnlocked(p)) k.unlock(p)
    var seviye = 0
    Object.keys(MESLEK).forEach(function (ad) {
      var ok = kategori(ad)   // eski, ayrı meslek kategorisi (gizli tutuluyor)
      if (ok == null || !ok.isUnlocked(p)) return
      var e = ok.getExperience()
      if (e.isPresent()) seviye += e.get().getLevel(p)
      ok.erase(p); ok.lock(p)
    })
    var yeni = k.getExperience()
    if (seviye > 0 && yeni.isPresent()) yeni.get().setTotal(p, Math.max(yeni.get().getTotal(p), yeni.get().getRequiredTotal(seviye)))
    meslekYaz(r, l)
    if (l.length) mesaj.push('Meslekler tek ağaçta birleşti (Pufferfish > Meslekler). Eski meslek seviyelerin (' + seviye +
      ') taşındı; köklerini açıp puanlarını yeniden dağıt. Bir meslek ağacını bitirince ücretsiz bir meslek daha seçebilirsin.')
    return mesaj
  }
  PlayerEvents.loggedIn(function (event) {
    var p = event.player
    try {
      var d = yukle(p.server)
      var r = kayit(d, String(p.getUuid()))
      var eski = r.agac || 1
      if (eski >= AGAC_SURUM && r.meslekGecis) return
      var iade = 0
      var kategoriler = []
      if (eski < 3 && r.sinif) kategoriler.push(r.sinif)
      if (eski < 2 && r.meslek) kategoriler.push(r.meslek)
      if (eski < 5 && meslekVar(r, 'demirci') && kategoriler.indexOf('demirci') < 0) kategoriler.push('demirci')
      if (eski < 6 && (r.sinif === 'buyucu' || r.sinif === 'terbiyeci') && kategoriler.indexOf(r.sinif) < 0) kategoriler.push(r.sinif)
      if (eski < 3) r.elementler = []
      var v7 = (eski < 7 || !r.meslekGecis) ? v7Gecis(p, r) : []   // v80: v78-79'da ağaç yüklenmediği için taşıma yapılamamıştı
      kategoriler = kategoriler.filter(function (ad) { return !MESLEK[ad] })   // eski meslek kategorileri v7Gecis'te taşındı
      kategoriler.forEach(function (ad) {
        var k = kategori(ad)
        if (k == null) return
        iade += k.getSpentPoints(p)
        k.resetSkills(p)
      })
      r.agac = AGAC_SURUM
      kaydet(p.server, d)
      v7.forEach(function (m) { p.tell(Text.gold(Text.ofString(m))) })
      if (iade > 0) p.tell(Text.gold(Text.ofString('Yetenek ağaçları yenilendi (Necromancer artık Terbiyeci dalı; Demirci yolları). ' +
        iade + ' puanın ücretsiz iade edildi; /yetenek ac ile yeniden dağıt.')))
    } catch (err) { console.error('[Yetenek] agac surumu hatasi: ' + err) }
  })

  // ----------------------------- v8 MESLEK REWORK (2026-11-25) ------------
  // Aşçı (yemek üret/pişir), Mühendis (3 dal: Fabrika / Havacılık / Ağır Sanayi), Çiftçi Hayvancılık dalı.
  var ServerPlayerC = ServerPlayer
  function etYuzde(p, tur) {   // yt_<tur>_v<yüzde>_<n> etiketlerinin toplamı (0.15 = %15)
    var top = 0, re = new RegExp('^yt_' + tur + '_v(\\d+)_')
    var it = p.getTags().iterator()
    while (it.hasNext()) { var m = re.exec(String(it.next())); if (m) top += Number(m[1]) / 100 }
    return top
  }
  var HAVA_NS = { aeronautics: 1, simulated: 1, sable: 1, create_flight_control: 1, aeroworks: 1, createthrusters: 1, createpropulsion: 1, aeroclaims: 1, copycat_wing: 1, createwingsplus: 1, linearbearing: 1, aerocopycats: 1 }
  var AGIR_NS = { tfmg: 1, createbigcannons: 1, cbc_at: 1, cbc_equally_opposite: 1, cbc_enhanced_shells: 1, create_the_air_wars: 1, createliquidfuel: 1 }
  function muhendisTuru(ns) {
    if (AGIR_NS[ns]) return 'agir'
    if (HAVA_NS[ns]) return 'hava'
    if (ns.indexOf('create') === 0 || ns === 'petrolsparts' || ns === 'railways' || ns === 'tracks' || ns === 'copycats') return 'create'
    return null
  }
  var dkSayac = {}
  function sinirli(p, ad, m, sinir) {   // dakika başı deneyim sınırı (çiftlik yapılmasın)
    var id = String(p.getUuid()) + '|' + ad, dk = Math.floor(Date.now() / 60000)
    var s = dkSayac[id]
    if (!s || s.dk !== dk) s = dkSayac[id] = { dk: dk, n: 0 }
    var v = Math.min(m, sinir - s.n)
    if (v <= 0) return 0
    s.n += v
    return v
  }
  function uretimOdulu(p, st, kaynak) {
    try {
      if (!(p instanceof ServerPlayerC) || st == null || st.isEmpty()) return
      var r = yukle(p.server).o[String(p.getUuid())]
      var ns = String(st.id).split(':')[0]
      // Aşçı: yemek
      if (st.has(DataComponents.FOOD)) {
        if (meslekVar(r, 'asci')) { var x = sinirli(p, 'asci', 2, 120); if (x > 0) deneyimVer(p, 'asci', x) }
        var b = etYuzde(p, 'asci_bereket')
        if (b > 0 && Math.random() < b) { p.give(st.copy()); p.setStatusMessage(Text.green(Text.ofString('Bereketli Mutfak: bir tane fazla!'))) }
        return
      }
      // Mühendis: mühendislik modlarının eşyaları
      var tur = muhendisTuru(ns)
      if (!tur) return
      if (meslekVar(r, 'muhendis') && kaynak === 'uret') { var y = sinirli(p, 'muhendis', 2, 150); if (y > 0) deneyimVer(p, 'muhendis', y) }
      var sans = tur === 'agir' ? etYuzde(p, 'uretim_agir') : (tur === 'create' ? etYuzde(p, 'uretim_create') : 0)
      if (sans > 0 && Math.random() < sans) { p.give(st.copy()); p.setStatusMessage(Text.green(Text.ofString('Seri Üretim: bir tane fazla!'))) }
    } catch (err) { console.error('[Yetenek] uretim odulu: ' + err) }
  }
  ItemEvents.crafted(function (event) { uretimOdulu(event.player, event.item, 'uret') })
  ItemEvents.smelted(function (event) { uretimOdulu(event.player, event.item, 'uret') })
  // Mühendis: mühendislik bloğu kurmak da puan
  BlockEvents.placed(function (event) {
    try {
      var p = event.player
      if (!(p instanceof ServerPlayerC)) return
      if (!muhendisTuru(String(event.block.id).split(':')[0])) return
      var r = yukle(p.server).o[String(p.getUuid())]
      if (!meslekVar(r, 'muhendis')) return
      var x = sinirli(p, 'muhendis_blok', 1, 60)
      if (x > 0) deneyimVer(p, 'muhendis', x)
    } catch (err) { console.error('[Yetenek] muhendis blok: ' + err) }
  })
  // Çiftçi: hayvan üretmek puan; Hayvancılık dalı: kesilen çiftlik hayvanından iki kat ürün şansı
  var Animal = Java.loadClass('net.minecraft.world.entity.animal.Animal')
  NativeEvents.onEvent('net.neoforged.neoforge.event.entity.living.BabyEntitySpawnEvent', function (event) {
    try {
      var p = event.getCausedByPlayer()
      if (!(p instanceof ServerPlayerC)) return
      var r = yukle(p.server).o[String(p.getUuid())]
      if (!meslekVar(r, 'ciftci')) return
      var x = sinirli(p, 'ciftci_hayvan', 6, 90)
      if (x > 0) deneyimVer(p, 'ciftci', x)
    } catch (err) { console.error('[Yetenek] uretme: ' + err) }
  })
  NativeEvents.onEvent('net.neoforged.neoforge.event.entity.living.LivingDropsEvent', function (event) {
    try {
      var e = event.entity
      if (!(e instanceof Animal)) return
      var p = event.getSource().getActual()
      if (!(p instanceof ServerPlayerC)) return
      var sans = etYuzde(p, 'hayvan')
      if (sans <= 0 || Math.random() >= sans) return
      var it = event.getDrops().iterator()
      while (it.hasNext()) { var ie = it.next(); var s = ie.getItem(); s.grow(s.getCount()) }
    } catch (err) { console.error('[Yetenek] hayvan urunu: ' + err) }
  })

  // Mühendis dalları: açık dal sayısı = 1 + bitirilen dal. Fazladan açılan dal başı kilitlenir.
  var MUH_DAL = ['f', 'h', 'a']
  var MUH_AD = { f: 'Fabrika', h: 'Havacılık', a: 'Ağır Sanayi' }
  function dalSay(k, p, on) {
    var hepsi = 0, acik = 0
    var it = k.streamSkills().iterator()
    while (it.hasNext()) { if (String(it.next().getId()).indexOf(on) === 0) hepsi++ }
    var it2 = k.streamUnlockedSkills(p).iterator()
    while (it2.hasNext()) { if (String(it2.next().getId()).indexOf(on) === 0) acik++ }
    return { hepsi: hepsi, acik: acik }
  }
  function dalKapat(k, p, on) {
    var bas = null, l = []
    var it = k.streamUnlockedSkills(p).iterator()
    while (it.hasNext()) { var s = it.next(); var id = String(s.getId()); if (id.indexOf(on) !== 0) continue; if (id === on + 'k') bas = s; else l.push(s) }
    l.reverse().forEach(function (s) { s.lock(p) })
    if (bas != null) bas.lock(p)
  }
  ServerEvents.tick(function (event) {
    var server = event.server
    if (server.tickCount % 20 !== 15) return
    try {
      var k = meslekKat()
      if (k == null) return
      var d = null
      var on = server.playerList.getPlayers().toArray()
      for (var i = 0; i < on.length; i++) {
        var p = on[i]
        if (!kokAcikMi(k, p, 'muhendis')) continue
        if (d == null) d = yukle(server)
        var r = kayit(d, String(p.getUuid()))
        var secili = (r.muhDal || []).slice()
        var acik = MUH_DAL.filter(function (x) { return acikMi(k, p, 'muhendis_' + x + 'k') })
        var biten = 0
        acik.forEach(function (x) { var s = dalSay(k, p, 'muhendis_' + x); if (s.hepsi > 0 && s.acik >= s.hepsi) biten++ })
        var hak = 1 + biten
        secili = secili.filter(function (x) { return acik.indexOf(x) >= 0 })
        acik.forEach(function (x) { if (secili.indexOf(x) < 0 && secili.length < hak) secili.push(x) })
        acik.filter(function (x) { return secili.indexOf(x) < 0 }).forEach(function (x) {
          dalKapat(k, p, 'muhendis_' + x)
          p.tell(Text.red(Text.ofString('Mühendis: ' + MUH_AD[x] + ' dalı kapatıldı. Yeni dal açmak için önce açık dalını (' +
            secili.map(function (y) { return MUH_AD[y] }).join(', ') + ') sonuna kadar bitir. Puanların geri verildi.')))
        })
        if (JSON.stringify(secili) !== JSON.stringify(r.muhDal || [])) { r.muhDal = secili; kaydet(server, d) }
      }
    } catch (err) { console.error('[Yetenek] muhendis dal hatasi: ' + err) }
  })

  // ----------------------------- MESLEK KÖKLERİ (saniyede bir) ---------  // Pufferfish'te tıklanan meslek kökü: hak varsa meslek olarak eklenir, yoksa geri kilitlenir (puanı döner).
  // Her açılabilir meslek hakkı için 1 ek puan verilir (kökü açabilmek için; ilk meslek deneyimsiz başlar).
  ServerEvents.tick(function (event) {
    var server = event.server
    if (server.tickCount % 20 !== 13) return
    try {
      var k = meslekKat()
      if (k == null) return
      var d = null
      var on = server.playerList.getPlayers().toArray()
      for (var i = 0; i < on.length; i++) {
        var p = on[i]
        if (d == null) d = yukle(server)
        var r = kayit(d, String(p.getUuid()))
        if ((r.agac || 1) < AGAC_SURUM || !r.meslekGecis) continue   // önce giriş geçişi
        if (!k.isUnlocked(p)) k.unlock(p)
        var l = meslekleri(r)
        var hak = meslekHakki(p, l)
        var degisti = false
        if ((r.kokPuan || 0) < hak) { k.addExtraPoints(p, hak - (r.kokPuan || 0)); r.kokPuan = hak; degisti = true }
        Object.keys(MESLEK).forEach(function (ad) {
          if (l.indexOf(ad) >= 0 || !kokAcikMi(k, p, ad)) return
          if (l.length < hak) {
            l.push(ad); degisti = true
            p.tell(Text.green(Text.ofString('Meslek seçildi: ' + MESLEK[ad] + '. Mesleklerin: ' + l.map(function (m) { return MESLEK[m] }).join(', '))))
          } else {
            meslekKilitle(k, p, ad)
            p.tell(Text.red(Text.ofString(MESLEK[ad] + ' kökü kapatıldı: şu an ' + hak + ' meslek hakkın var (' + l.map(function (m) { return MESLEK[m] }).join(', ') +
              '). Bir meslek ağacını bitirince bir meslek daha açabilirsin; değiştirmek için menü (K).')))
          }
        })
        if (degisti) { meslekYaz(r, l); meslekEtiketi(p, r); kaydet(server, d) }
      }
    } catch (err) { console.error('[Yetenek] meslek kok hatasi: ' + err) }
  })

  // ----------------------------- ELEMENTALİST: EN FAZLA 2 DAL ---------
  // Puffish'te "en fazla 2 kök" ayarı yok (exclusive_root tek kök). Saniyede bir kontrol: 3. dal açılırsa
  // o dal (kökü ve dal düğümleri) kilitlenir, puanı geri gelir. Seçilen dallar r.elementler'de tutulur.
  var ELEMENT_KOK = ['ka', 'kb', 'kc', 'kd']
  var ELEMENT_AD = { ka: 'Ateş', kb: 'Buz', kc: 'Yıldırım', kd: 'Doğa' }
  function acikMi(k, p, id) {
    var o = k.getSkill(id)
    return o.isPresent() && String(o.get().getState(p)) === 'UNLOCKED'
  }
  function dalKilitle(k, p, kokId) {
    var kod = kokId.substring(1)
    var it = k.streamUnlockedSkills(p).iterator()
    var kilit = []
    while (it.hasNext()) {
      var s = it.next()
      var id = String(s.getId())
      if (id === kokId || (id.charAt(0) === kod && id.length > 1 && id !== 'k' + kod)) kilit.push(s)
    }
    // önce yapraklar: dal düğümleri, en son kök
    kilit.reverse().forEach(function (s) { s.lock(p) })
  }
  ServerEvents.tick(function (event) {
    var server = event.server
    if (server.tickCount % 20 !== 11) return
    try {
      var d = null
      var on = server.playerList.getPlayers().toArray()
      for (var i = 0; i < on.length; i++) {
        var p = on[i]
        if (d == null) d = yukle(server)
        var r = d.o[String(p.getUuid())]
        if (!r || r.sinif !== 'elementalist') continue
        var k = kategori('elementalist')
        if (k == null || !k.isUnlocked(p)) continue
        var acik = ELEMENT_KOK.filter(function (id) { return acikMi(k, p, id) })
        var secili = (r.elementler || []).filter(function (id) { return acik.indexOf(id) >= 0 })
        acik.forEach(function (id) { if (secili.length < 2 && secili.indexOf(id) < 0) secili.push(id) })
        var fazla = acik.filter(function (id) { return secili.indexOf(id) < 0 })
        fazla.forEach(function (id) {
          dalKilitle(k, p, id)
          p.tell(Text.red(Text.ofString('Elementalist en fazla 2 element dalı açabilir (' + secili.map(function (x) { return ELEMENT_AD[x] }).join(', ') +
            '). ' + ELEMENT_AD[id] + ' dalı kapatıldı, puanların geri verildi. Dal değiştirmek için: /yetenek sifirla sinif')))
        })
        if (JSON.stringify(secili) !== JSON.stringify(r.elementler || [])) { r.elementler = secili; kaydet(server, d) }
      }
    } catch (err) { console.error('[Yetenek] elementalist hatasi: ' + err) }
  })

  console.info('[Yetenek] yuklendi: ' + Object.keys(SINIF).length + ' sinif, ' + Object.keys(MESLEK).length + ' meslek')
})()
