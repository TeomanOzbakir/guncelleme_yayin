// =====================================================================
//  YETENEK SİSTEMİ (Sınıf + Meslek)  -  kubejs/server_scripts/yetenek_sistemi.js
//  Hedef: NeoForge 1.21.1 | KubeJS 2101.7.2 | Pufferfish's Skills 0.19.2
//
//  Ağaçlar: kubejs/data/puffish_skills/puffish_skills (üretici:
//  modpack_duzeltmeler/yetenek/YetenekUret.java). Hepsi kilitli başlar.
//
//  - MESLEK (1 tane): /meslek sec <ad>  - her zaman seçilebilir
//      madenci, zanaatkar, simyaci, ciftci, balikci, tacir
//  - SINIF (1 tane):  /sinif sec <ad>   - zindanda SINIF_ZINDAN. seviyeyi bitirince
//      savasci, avci, nisanci, buyucu, terbiyeci, duellocu
//      Her sınıf ağacında 2 dal vardır, yalnızca biri açılabilir.
//  - İlk seçim bedava; değiştirmek DEGISIM_UCRET spur (eski ağacın tüm ilerlemesi silinir).
//  - /yetenek sifirla sinif|meslek: harcanan puan x PUAN_UCRET spur, puanlar geri gelir
//    (dal değiştirmek de böyle). Ücretler Devlet Hazinesi'ne.
//  - Puanlar: sınıflar yaratık öldürerek (zindanda ek), madenci kazarak, zanaatkar üretip
//    eriterek, simyacı büyüleyip iksir demleyerek, balıkçı balık tutarak (Pufferfish kendisi);
//    çiftçi olgun hasattan, tacir Selling Bin satışından (bu script).
//  - Özel düğümler "yt_..." etiketi verir; bu script ve vergi/kredi/piyasa okur:
//      Nişancı: TaCZ hasar/kafa vuruşu | Çiftçi: iki kat hasat | Simyacı: iksir süresi, ekstra iksir
//      Tacir: satış bonusu (sunucu_piyasa), vergi indirimi (vergi_sistemi), kredi (borc_kredi)
//    Çevrimdışı oyuncular için etiketler 'yetenek_etiket' önbelleğine yazılır.
//
//  !! Gerçek bir oyunda ÇALIŞTIRILARAK TEST EDİLMEDİ.
// =====================================================================

;(function () {
  var AYAR = {
    SINIF_ZINDAN: 5,        // sınıf seçmek için bitirilmiş en yüksek zindan seviyesi
    DEGISIM_UCRET: 2000,    // sınıf/meslek değiştirme
    PUAN_UCRET: 50,         // sıfırlamada harcanan puan başı
    CIFTCI_XP: 3,           // olgun ürün başı
    SIMYA_XP: 15,           // demlenen iksir başı
    SIMYA_SINIR: 3,         // 20 sn'de en fazla bu kadar iksir ödül alır (bir demleme = 3 iksir)
    TACIR_SPUR_XP: 4,       // her 4 spur satış = 1 deneyim
    ZINDAN_XP_BOLEN: 25,    // zindan canavarı ek deneyimi = can / 25
    ZINDAN_BOSS_XP: 60      // boss / kat bekçisi ek deneyimi
  }
  var SINIF = { savasci: 'Savaşçı', avci: 'Avcı', nisanci: 'Nişancı', buyucu: 'Büyücü', terbiyeci: 'Terbiyeci', duellocu: 'Düellocu' }
  var MESLEK = { madenci: 'Madenci', zanaatkar: 'Zanaatkar', demirci: 'Demirci', simyaci: 'Simyacı', ciftci: 'Çiftçi', balikci: 'Balıkçı', tacir: 'Tacir' }
  var DEMIRCI_XP = 10   // örste yapılan her tamir
  var HAZINE_UUID_STR = '5f0c2d1e-7a3b-4e9c-8d6f-1b2a3c4d5e6f'

  var JUUID = Java.loadClass('java.util.UUID')
  var RL = Java.loadClass('net.minecraft.resources.ResourceLocation')
  var SkillsAPI = Java.loadClass('net.puffish.skillsmod.api.SkillsAPI')
  var Numismatics = Java.loadClass('dev.ithundxr.createnumismatics.Numismatics')
  var ReasonHolder = Java.loadClass('dev.ithundxr.createnumismatics.content.backend.ReasonHolder')
  var BankType = Java.loadClass('dev.ithundxr.createnumismatics.content.backend.BankAccount$Type')
  var CropBlock = Java.loadClass('net.minecraft.world.level.block.CropBlock')
  var McBlock = Java.loadClass('net.minecraft.world.level.block.Block')
  var DataComponents = Java.loadClass('net.minecraft.core.component.DataComponents')
  var MobEffectInstance = Java.loadClass('net.minecraft.world.effect.MobEffectInstance')
  var ServerPlayer = Java.loadClass('net.minecraft.server.level.ServerPlayer')
  var HAZINE_UUID = JUUID.fromString(HAZINE_UUID_STR)
  var ZindanApi = null
  try { ZindanApi = Java.loadClass('tr.sunucu.zindan.ZindanApi') } catch (e) { ZindanApi = null }

  // TaCZ silah türleri (silah_seviye.js ile aynı liste)
  var SILAH_TUR = {}
  function turEkle(tur, liste) { liste.split(',').forEach(function (g) { SILAH_TUR['tacz:' + g] = tur }) }
  turEkle('pistol', 'b93r,cz75,deagle,deagle_golden,glock_17,hk_mk23,lonetrail,m1911,m9a4,p320,rhino357,taurus500,taurus943,tec_9,timeless50')
  turEkle('smg', 'hk_mp5a5,hk_mp7a1,p90,ump45,uzi,vector45')
  turEkle('shotgun', 'aa12,db_long,db_short,m1014,m1897,m870,spas_12')
  turEkle('rifle', 'ak12,ak47,ak74m,aug,fn_fal,g36k,hcar,hk_g3,hk416d,m16a1,m16a4,m4a1,mcx_spear_lt,mk18,qbz_191,qbz_95,qr_24,scar_h,scar_l,type_81,urgi')
  turEkle('dmr', 'm1866,mk14,scar_mk20,sks_tactical,spr15hb')
  turEkle('sniper', 'ai_awp,hm50b,kar98,m107,m700,m95,mrad,springfield1873,svd')
  turEkle('mg', 'fn_evolys,m249,minigun,pkm,rpk')
  turEkle('rpg', 'm320,rpg7')
  var TUFEK = { rifle: 1, dmr: 1, sniper: 1 }
  var AGIR = { mg: 1, shotgun: 1, rpg: 1 }

  // ----------------------------- VERİ --------------------------------
  function yukle(server) {
    var s = server.persistentData.getString('yetenek_veri')
    var d = null
    if (s) { try { d = JSON.parse(s) } catch (e) { d = null } }
    if (!d || !d.o) d = { o: {} }
    return d
  }
  function kaydet(server, d) { server.persistentData.putString('yetenek_veri', JSON.stringify(d)) }
  function kayit(d, id) { return d.o[id] || (d.o[id] = { sinif: null, meslek: null }) }

  function kategori(ad) {
    var o = SkillsAPI.getCategory(RL.parse('puffish_skills:' + ad))
    return o.isPresent() ? o.get() : null
  }
  function deneyimVer(p, ad, m) {
    if (!ad || !(m > 0)) return
    var k = kategori(ad)
    if (k == null || !k.isUnlocked(p)) return
    var e = k.getExperience()
    if (e.isPresent()) e.get().addTotal(p, Math.floor(m))
  }
  function etiketVar(p, t) { return p.getTags().contains(t) }
  function zindanSeviye(p) {
    if (ZindanApi == null) return 0
    try { return JSON.parse(String(ZindanApi.ozet(String(p.getUuid())))).enYuksek || 0 } catch (e) { return 0 }
  }

  // ----------------------------- PARA --------------------------------
  function ucretAl(p, m, neden) {
    if (m <= 0) return true
    var h = Numismatics.BANK.getAccount(p.getUuid())
    if (!h || h.getBalance() < m || !h.deduct(m, ReasonHolder.IGNORED)) return false
    h.markDirty()
    var hz = Numismatics.BANK.getOrCreateAccount(HAZINE_UUID, BankType.BLAZE_BANKER); hz.deposit(m); hz.markDirty()
    var s = p.server.persistentData.getString('hazine_veri')
    var d = null
    if (s) { try { d = JSON.parse(s) } catch (e) { d = null } }
    if (!d) d = {}
    if (!d.gelir) d.gelir = { arazi: 0, olum: 0, tescil: 0 }
    d.gelir.yetenek = (d.gelir.yetenek || 0) + m
    d.hareket = (d.hareket || []).concat([{ t: Date.now(), tur: 'yetenek', m: m, k: String(p.username) + ' (' + neden + ')' }]).slice(-500)
    p.server.persistentData.putString('hazine_veri', JSON.stringify(d))
    return true
  }

  // ----------------------------- SEÇİM -------------------------------
  // tur: 'sinif' | 'meslek'
  function sec(p, tur, ad) {
    var liste = tur === 'sinif' ? SINIF : MESLEK
    if (!liste[ad]) { p.tell(Text.red(Text.ofString('Böyle bir ' + (tur === 'sinif' ? 'sınıf' : 'meslek') + ' yok.'))); return 0 }
    if (tur === 'sinif') {
      var sv = zindanSeviye(p)
      if (sv < AYAR.SINIF_ZINDAN) {
        p.tell(Text.red(Text.ofString('Sınıf seçmek için zindanda ' + AYAR.SINIF_ZINDAN + '. seviyeyi bitirmelisin (en yüksek: ' + sv + '). /zindan')))
        return 0
      }
    }
    var server = p.server
    var d = yukle(server)
    var r = kayit(d, String(p.getUuid()))
    var eski = r[tur]
    if (eski === ad) { p.tell(Text.ofString('Zaten ' + liste[ad] + '.')); return 0 }
    var yeni = kategori(ad)
    if (yeni == null) { p.tell(Text.red(Text.ofString('Yetenek ağacı bulunamadı (' + ad + '). Yöneticiye haber ver.'))); return 0 }
    var ucret = eski ? AYAR.DEGISIM_UCRET : 0
    if (!ucretAl(p, ucret, tur + ' ' + ad)) { p.tell(Text.red(Text.ofString('Değiştirmek için bankanda ' + ucret + ' spur olmalı.'))); return 0 }
    if (eski) { var k = kategori(eski); if (k != null) { k.erase(p); k.lock(p) } }
    yeni.erase(p)
    yeni.unlock(p)
    r[tur] = ad
    kaydet(server, d)
    p.tell(Text.green(Text.ofString((tur === 'sinif' ? 'Sınıfın: ' : 'Mesleğin: ') + liste[ad] +
      (ucret > 0 ? ' (' + ucret + ' spur, eski ağacın ilerlemesi silindi)' : '') + '. Yetenek ağacını açmak için Pufferfish tuşu (varsayılan K) veya /yetenek ac')))
    return 1
  }

  function sifirla(p, tur) {
    var d = yukle(p.server)
    var r = kayit(d, String(p.getUuid()))
    if (!r[tur]) { p.tell(Text.ofString('Önce bir ' + (tur === 'sinif' ? 'sınıf' : 'meslek') + ' seçmelisin.')); return 0 }
    var k = kategori(r[tur])
    if (k == null) return 0
    var harcanan = k.getSpentPoints(p)
    if (harcanan <= 0) { p.tell(Text.ofString('Bu ağaçta harcanmış puanın yok.')); return 0 }
    var ucret = harcanan * AYAR.PUAN_UCRET
    if (!ucretAl(p, ucret, 'sifirla ' + r[tur])) { p.tell(Text.red(Text.ofString('Sıfırlamak için bankanda ' + ucret + ' spur olmalı (' + harcanan + ' puan x ' + AYAR.PUAN_UCRET + ').'))); return 0 }
    k.resetSkills(p)
    p.tell(Text.green(Text.ofString(harcanan + ' puan geri verildi (' + ucret + ' spur). Ağacı yeniden dağıtabilirsin; dal da değiştirebilirsin.')))
    return 1
  }

  function durum(p) {
    var r = kayit(yukle(p.server), String(p.getUuid()))
    var sv = zindanSeviye(p)
    p.tell(Text.gold(Text.ofString('--- Yetenekler ---')))
    p.tell(Text.ofString('Sınıf: ' + (r.sinif ? SINIF[r.sinif] + puanYazi(p, r.sinif) : (sv >= AYAR.SINIF_ZINDAN ? 'seçilmedi (/sinif)' : 'kilitli - zindan ' + AYAR.SINIF_ZINDAN + '. seviye gerekli (sen: ' + sv + ')'))))
    p.tell(Text.ofString('Meslek: ' + (r.meslek ? MESLEK[r.meslek] + puanYazi(p, r.meslek) : 'seçilmedi (/meslek)')))
    p.tell(Text.ofString('Değiştirme: ' + AYAR.DEGISIM_UCRET + ' spur | Sıfırlama: harcanan puan x ' + AYAR.PUAN_UCRET + ' spur (/yetenek sifirla sinif|meslek)'))
  }
  function puanYazi(p, ad) {
    var k = kategori(ad)
    if (k == null) return ''
    var e = k.getExperience()
    return ' (seviye ' + (e.isPresent() ? e.get().getLevel(p) : 0) + ', harcanan ' + k.getSpentPoints(p) + ', boşta ' + k.getPointsLeft(p) + ' puan)'
  }

  // ----------------------------- KOMUTLAR ----------------------------
  ServerEvents.commandRegistry(function (event) {
    var Commands = event.commands
    function oyuncu(ctx) { return ctx.source.player }

    var sinifK = Commands.literal('sinif').executes(function (ctx) {
      var p = oyuncu(ctx); if (p == null) return 0
      durum(p)
      p.tell(Text.ofString('Sınıflar: ' + Object.keys(SINIF).map(function (k) { return SINIF[k] + ' (/sinif sec ' + k + ')' }).join(', ')))
      return 1
    })
    var sinifSec = Commands.literal('sec')
    Object.keys(SINIF).forEach(function (ad) {
      sinifSec = sinifSec.then(Commands.literal(ad).executes(function (ctx) { var p = oyuncu(ctx); return p == null ? 0 : sec(p, 'sinif', ad) }))
    })
    event.register(sinifK.then(sinifSec))

    var meslekK = Commands.literal('meslek').executes(function (ctx) {
      var p = oyuncu(ctx); if (p == null) return 0
      durum(p)
      p.tell(Text.ofString('Meslekler: ' + Object.keys(MESLEK).map(function (k) { return MESLEK[k] + ' (/meslek sec ' + k + ')' }).join(', ')))
      return 1
    })
    var meslekSec = Commands.literal('sec')
    Object.keys(MESLEK).forEach(function (ad) {
      meslekSec = meslekSec.then(Commands.literal(ad).executes(function (ctx) { var p = oyuncu(ctx); return p == null ? 0 : sec(p, 'meslek', ad) }))
    })
    event.register(meslekK.then(meslekSec))

    event.register(Commands.literal('yetenek')
      .executes(function (ctx) { var p = oyuncu(ctx); if (p == null) return 0; durum(p); return 1 })
      .then(Commands.literal('ac').executes(function (ctx) { var p = oyuncu(ctx); if (p == null) return 0; SkillsAPI.openScreen(p); return 1 }))
      .then(Commands.literal('sifirla')
        .then(Commands.literal('sinif').executes(function (ctx) { var p = oyuncu(ctx); return p == null ? 0 : sifirla(p, 'sinif') }))
        .then(Commands.literal('meslek').executes(function (ctx) { var p = oyuncu(ctx); return p == null ? 0 : sifirla(p, 'meslek') }))))
  })

  // ----------------------------- ETİKET ÖNBELLEĞİ + TACİR ------------
  // Çevrimdışı oyuncuların vergi/kredi bonusları için 'yt_' etiketleri; Tacir deneyimi kuyruğu
  ServerEvents.tick(function (event) {
    var server = event.server
    if (server.tickCount % 1200 !== 600) return
    try {
      var on = server.playerList.getPlayers().toArray()
      var et = {}
      try { et = JSON.parse(server.persistentData.getString('yetenek_etiket') || '{}') } catch (e) { et = {} }
      for (var i = 0; i < on.length; i++) {
        var l = []
        var it = on[i].getTags().iterator()
        while (it.hasNext()) { var t = String(it.next()); if (t.indexOf('yt_') === 0) l.push(t) }
        et[String(on[i].getUuid())] = l
      }
      server.persistentData.putString('yetenek_etiket', JSON.stringify(et))

      // Tacir: sunucu_piyasa modunun yazdığı satışlar ('satis_xp': [{u, m(spur)}]); çevrimdışı olanınki bekler
      var s = server.persistentData.getString('satis_xp')
      if (s && s !== '[]') {
        var liste = []
        try { liste = JSON.parse(s) } catch (e) { liste = [] }
        var d = yukle(server)
        var kalan = []
        var topla = {}
        liste.forEach(function (x) { if (x && x.u && x.m > 0) topla[x.u] = (topla[x.u] || 0) + x.m })
        Object.keys(topla).forEach(function (id) {
          var r = d.o[id]
          if (!r || r.meslek !== 'tacir') return
          var p = server.playerList.getPlayer(JUUID.fromString(id))
          if (p == null) { kalan.push({ u: id, m: topla[id] }); return }
          deneyimVer(p, 'tacir', topla[id] / AYAR.TACIR_SPUR_XP)
        })
        server.persistentData.putString('satis_xp', JSON.stringify(kalan))
      }
    } catch (err) { console.error('[Yetenek] tick hatasi: ' + err) }
  })

  // ----------------------------- SINIF: ZİNDAN EK DENEYİMİ ----------
  EntityEvents.death(function (event) {
    var e = event.entity
    if (!e || e.isPlayer() || !e.getTags().contains('zindan')) return
    var k = event.source.getActual()
    if (k == null || !k.isPlayer()) return
    try {
      var r = yukle(event.server).o[String(k.getUuid())]
      if (!r || !r.sinif) return
      var m = Math.min(e.getMaxHealth(), 1000) / AYAR.ZINDAN_XP_BOLEN
      if (e.getTags().contains('zindan_boss')) m += AYAR.ZINDAN_BOSS_XP
      deneyimVer(k, r.sinif, m)
    } catch (err) { console.error('[Yetenek] zindan deneyim hatasi: ' + err) }
  })

  // ----------------------------- ÇİFTÇİ -------------------------------
  BlockEvents.broken(function (event) {
    var p = event.player
    if (p == null || p.isCreative()) return
    try {
      var st = event.block.blockState
      var b = st.getBlock()
      if (!(b instanceof CropBlock) || !b.isMaxAge(st)) return
      var r = yukle(event.server).o[String(p.getUuid())]
      if (r && r.meslek === 'ciftci') deneyimVer(p, 'ciftci', AYAR.CIFTCI_XP)
      var sans = (etiketVar(p, 'yt_hasat_1') ? 0.1 : 0) + (etiketVar(p, 'yt_hasat_2') ? 0.1 : 0) +
        (etiketVar(p, 'yt_hasat_3') ? 0.1 : 0) + (etiketVar(p, 'yt_hasat_doruk') ? 0.2 : 0)
      if (sans > 0 && Math.random() < sans) {
        var lvl = event.level
        var pos = event.block.pos
        var drops = McBlock.getDrops(st, lvl, pos, null).toArray()
        for (var i = 0; i < drops.length; i++) McBlock.popResource(lvl, pos, drops[i])
      }
    } catch (err) { console.error('[Yetenek] hasat hatasi: ' + err) }
  })

  // ----------------------------- SİMYACI ------------------------------
  var simyaSayac = {}   // uuid -> [zamanlar]
  NativeEvents.onEvent('net.neoforged.neoforge.event.brewing.PlayerBrewedPotionEvent', function (event) {
    // NativeEvents hatayı yakalamaz (oyun çöker): her şey try içinde
    try {
      var p = event.getEntity()
      if (!(p instanceof ServerPlayer)) return
      var id = String(p.getUuid())
      var simdi = p.server.tickCount
      var l = (simyaSayac[id] || []).filter(function (t) { return simdi - t < 400 })
      if (l.length >= AYAR.SIMYA_SINIR) { simyaSayac[id] = l; return }
      l.push(simdi)
      simyaSayac[id] = l
      var r = yukle(p.server).o[id]
      if (r && r.meslek === 'simyaci') deneyimVer(p, 'simyaci', AYAR.SIMYA_XP)
      var sans = (etiketVar(p, 'yt_iksir_bereket_1') ? 0.1 : 0) + (etiketVar(p, 'yt_iksir_bereket_2') ? 0.1 : 0) +
        (etiketVar(p, 'yt_iksir_doruk') ? 0.15 : 0)
      if (sans > 0 && Math.random() < sans) {
        p.give(event.getStack().copy())
        p.setStatusMessage(Text.green(Text.ofString('Bereketli demleme: bir iksir fazla!')))
      }
    } catch (err) { console.error('[Yetenek] simya hatasi: ' + err) }
  })
  // İçilen iksirin etkileri daha uzun sürer
  NativeEvents.onEvent('net.neoforged.neoforge.event.entity.living.LivingEntityUseItemEvent$Finish', function (event) {
    try {
      var p = event.getEntity()
      if (!(p instanceof ServerPlayer)) return
      var carpan = (etiketVar(p, 'yt_iksir_sure_1') ? 0.15 : 0) + (etiketVar(p, 'yt_iksir_sure_2') ? 0.15 : 0) +
        (etiketVar(p, 'yt_iksir_sure_3') ? 0.15 : 0) + (etiketVar(p, 'yt_iksir_doruk') ? 0.25 : 0)
      if (carpan <= 0) return
      var st = event.getItem()
      if (String(st.id) !== 'minecraft:potion') return
      var icerik = st.get(DataComponents.POTION_CONTENTS)
      if (icerik == null) return
      var it = icerik.getAllEffects().iterator()
      while (it.hasNext()) {
        var ef = it.next()
        if (ef.getEffect().value().isInstantenous()) continue
        var sure = Math.floor(ef.getDuration() * (1 + carpan))
        p.addEffect(new MobEffectInstance(ef.getEffect(), sure, ef.getAmplifier(), ef.isAmbient(), ef.isVisible(), ef.showIcon()))
      }
    } catch (err) { console.error('[Yetenek] iksir suresi hatasi: ' + err) }
  })

  // ----------------------------- DEMİRCİ (örs tamiri) ----------------
  // Mending kapalı. Demirci örste malzemeyle tamir edince: maliyet birikmez (REPAIR_COST artmaz),
  // 'çok pahalı' sınırı yok, malzeme başı %25 (+düğümler) onarım, seviye maliyeti = malzeme sayısı (-%25'ler).
  // Diğer oyuncular vanilla örs kurallarına tabidir (maliyet birikir) -> Demirciye iş düşer.
  NativeEvents.onEvent('net.neoforged.neoforge.event.AnvilUpdateEvent', function (event) {
    try {
      var p = event.getPlayer()
      if (!(p instanceof ServerPlayer) || !etiketVar(p, 'yt_demirci')) return
      var sol = event.getLeft(), sag = event.getRight()
      if (sol.isEmpty() || sag.isEmpty() || !sol.isDamageableItem() || !sol.isDamaged()) return
      if (!sol.getItem().isValidRepairItem(sol, sag)) return
      var ad = event.getName()
      if (ad != null && String(ad).trim() !== '' && String(ad) !== String(sol.getHoverName().getString())) return   // yeniden adlandırma: vanilla
      var oran = 0.25 + (etiketVar(p, 'yt_dem_verim_1') ? 0.08 : 0) + (etiketVar(p, 'yt_dem_verim_2') ? 0.08 : 0) + (etiketVar(p, 'yt_dem_doruk') ? 0.25 : 0)
      var enCok = sol.getMaxDamage()
      var parca = Math.max(1, Math.floor(enCok * Math.min(1, oran)))
      var hasar = sol.getDamageValue()
      var n = Math.min(sag.getCount(), Math.ceil(hasar / parca))
      if (n <= 0) return
      var cikti = sol.copy()
      cikti.setDamageValue(Math.max(0, hasar - parca * n))
      var indirim = (etiketVar(p, 'yt_dem_ucuz_1') ? 0.25 : 0) + (etiketVar(p, 'yt_dem_ucuz_2') ? 0.25 : 0)
      var maliyet = etiketVar(p, 'yt_dem_doruk') ? 1 : Math.max(1, Math.min(39, Math.round(n * (1 - indirim))))
      event.setOutput(cikti)
      event.setCost(maliyet)
      event.setMaterialCost(n)
    } catch (err) { console.error('[Yetenek] demirci ors hatasi: ' + err) }
  })
  NativeEvents.onEvent('net.neoforged.neoforge.event.entity.player.AnvilRepairEvent', function (event) {
    try {
      var p = event.getEntity()
      if (!(p instanceof ServerPlayer)) return
      var r = yukle(p.server).o[String(p.getUuid())]
      if (!r || r.meslek !== 'demirci') return
      var cikti = String(event.getOutput().id)
      if (cikti.indexOf('sunucu_bakim:') === 0) deneyimVer(p, 'demirci', 15 * event.getOutput().getCount())   // makine başlığı bitirme
      else if (event.getLeft().isDamaged()) deneyimVer(p, 'demirci', DEMIRCI_XP)
    } catch (err) { console.error('[Yetenek] demirci xp hatasi: ' + err) }
  })

  // ----------------------------- NİŞANCI (TaCZ) ----------------------
  NativeEvents.onEvent('com.tacz.guns.api.event.common.EntityHurtByGunEvent$Pre', function (event) {
    try {
      if (!event.getLogicalSide().isServer()) return
      var a = event.getAttacker()
      if (!(a instanceof ServerPlayer)) return
      var tg = a.getTags()
      var tur = SILAH_TUR[String(event.getGunId())]
      var hasar = (tg.contains('yt_silah_1') ? 0.05 : 0) + (tg.contains('yt_silah_2') ? 0.05 : 0)
      var kafa = (tg.contains('yt_kafa_1') ? 0.1 : 0) + (tg.contains('yt_kafa_2') ? 0.1 : 0) + (tg.contains('yt_kafa_3') ? 0.1 : 0)
      if (TUFEK[tur]) {
        hasar += (tg.contains('yt_tufek_1') ? 0.08 : 0) + (tg.contains('yt_tufek_2') ? 0.08 : 0) + (tg.contains('yt_tufek_3') ? 0.08 : 0)
        if (tg.contains('yt_tufek_doruk')) { hasar += 0.15; kafa += 0.2 }
      } else if (AGIR[tur]) {
        hasar += (tg.contains('yt_agir_1') ? 0.08 : 0) + (tg.contains('yt_agir_2') ? 0.08 : 0) + (tg.contains('yt_agir_3') ? 0.08 : 0)
        if (tg.contains('yt_agir_doruk')) hasar += 0.15
      }
      if (hasar > 0) event.setBaseAmount(event.getBaseAmount() * (1 + hasar))
      if (kafa > 0 && event.isHeadShot()) event.setHeadshotMultiplier(event.getHeadshotMultiplier() * (1 + kafa))
    } catch (err) { console.error('[Yetenek] silah hatasi: ' + err) }
  })

  console.info('[Yetenek] yuklendi: ' + Object.keys(SINIF).length + ' sinif, ' + Object.keys(MESLEK).length + ' meslek')
})()
