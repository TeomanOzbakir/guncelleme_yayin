// =====================================================================
// Modpack duzeltmeleri - bozuk mod tarifleri (34 tarif)
// Dosya: kubejs/server_scripts/modpack_duzeltmeler.js
//  - Overgeared Spartan: 25 tahta Spartan silahi eski 'spartanweaponry:' ID'lerini
//    kullaniyordu; 'spartan_weaponry_unofficial:' ile duzeltildi.
//  - Ice and Fire gumus aletleri: dovulmus gumus alet basi + Spartan Handle.
//  - CBC Advanced Technology: 3 Mechanical Saw tarifi (Create 6 sonuc formati).
//  - Create Radars: radar_jammer.json'daki eksik virgul.
// Bu dosya _generator/generate_fixes.ps1 ile JAR'lardan uretildi.
// =====================================================================

const DUZELTMELER = [
    {
        "id":  "overgearedspartan:wooden/weapons/wooden_battle_hammer",
        "json":  {
                     "type":  "minecraft:crafting_shaped",
                     "group":  "spartan_weaponry_unofficial:battle_hammer",
                     "key":  {
                                 "#":  {
                                           "tag":  "minecraft:planks"
                                       },
                                 "|":  {
                                           "item":  "spartan_weaponry_unofficial:simple_handle"
                                       }
                             },
                     "pattern":  [
                                     "###",
                                     "###",
                                     " | "
                                 ],
                     "result":  {
                                    "count":  1,
                                    "id":  "spartan_weaponry_unofficial:battle_hammer_wooden"
                                }
                 }
    },
    {
        "id":  "overgearedspartan:wooden/weapons/wooden_battleaxe",
        "json":  {
                     "type":  "minecraft:crafting_shaped",
                     "group":  "spartan_weaponry_unofficial:battleaxe",
                     "key":  {
                                 "#":  {
                                           "tag":  "minecraft:planks"
                                       },
                                 "|":  {
                                           "tag":  "c:rods/wooden"
                                       },
                                 "/":  {
                                           "item":  "spartan_weaponry_unofficial:simple_handle"
                                       }
                             },
                     "pattern":  [
                                     "###",
                                     "#/#",
                                     " | "
                                 ],
                     "result":  {
                                    "count":  1,
                                    "id":  "spartan_weaponry_unofficial:battleaxe_wooden"
                                }
                 }
    },
    {
        "id":  "overgearedspartan:wooden/weapons/wooden_boomerang",
        "json":  {
                     "type":  "minecraft:crafting_shaped",
                     "group":  "spartan_weaponry_unofficial:boomerang",
                     "key":  {
                                 "#":  {
                                           "tag":  "minecraft:planks"
                                       },
                                 "P":  {
                                           "tag":  "minecraft:planks"
                                       }
                             },
                     "pattern":  [
                                     "#PP",
                                     "P  ",
                                     "P  "
                                 ],
                     "result":  {
                                    "count":  1,
                                    "id":  "spartan_weaponry_unofficial:boomerang_wooden"
                                }
                 }
    },
    {
        "id":  "overgearedspartan:wooden/weapons/wooden_club",
        "json":  {
                     "type":  "minecraft:crafting_shaped",
                     "group":  "spartan_weaponry_unofficial:club",
                     "key":  {
                                 "#":  {
                                           "tag":  "minecraft:logs"
                                       }
                             },
                     "pattern":  [
                                     " #",
                                     "# "
                                 ],
                     "result":  {
                                    "count":  1,
                                    "id":  "spartan_weaponry_unofficial:wooden_club"
                                }
                 }
    },
    {
        "id":  "overgearedspartan:wooden/weapons/wooden_dagger",
        "json":  {
                     "type":  "minecraft:crafting_shaped",
                     "group":  "spartan_weaponry_unofficial:dagger",
                     "key":  {
                                 "#":  {
                                           "tag":  "minecraft:planks"
                                       },
                                 "|":  {
                                           "item":  "spartan_weaponry_unofficial:simple_handle"
                                       }
                             },
                     "pattern":  [
                                     "#",
                                     "|"
                                 ],
                     "result":  {
                                    "count":  1,
                                    "id":  "spartan_weaponry_unofficial:dagger_wooden"
                                }
                 }
    },
    {
        "id":  "overgearedspartan:wooden/weapons/wooden_flanged_mace",
        "json":  {
                     "type":  "minecraft:crafting_shaped",
                     "group":  "spartan_weaponry_unofficial:flanged_mace",
                     "key":  {
                                 "#":  {
                                           "tag":  "minecraft:planks"
                                       },
                                 "/":  {
                                           "tag":  "c:rods/wooden"
                                       },
                                 "|":  {
                                           "item":  "spartan_weaponry_unofficial:simple_handle"
                                       }
                             },
                     "pattern":  [
                                     " ##",
                                     " |#",
                                     "/  "
                                 ],
                     "result":  {
                                    "count":  1,
                                    "id":  "spartan_weaponry_unofficial:flanged_mace_wooden"
                                }
                 }
    },
    {
        "id":  "overgearedspartan:wooden/weapons/wooden_glaive",
        "json":  {
                     "type":  "minecraft:crafting_shaped",
                     "group":  "spartan_weaponry_unofficial:glaive",
                     "key":  {
                                 "#":  {
                                           "tag":  "minecraft:planks"
                                       },
                                 "/":  {
                                           "item":  "spartan_weaponry_unofficial:simple_pole"
                                       }
                             },
                     "pattern":  [
                                     " #",
                                     " #",
                                     " /"
                                 ],
                     "result":  {
                                    "count":  1,
                                    "id":  "spartan_weaponry_unofficial:glaive_wooden"
                                }
                 }
    },
    {
        "id":  "overgearedspartan:wooden/weapons/wooden_greatsword",
        "json":  {
                     "type":  "minecraft:crafting_shaped",
                     "group":  "spartan_weaponry_unofficial:greatsword",
                     "key":  {
                                 "#":  {
                                           "tag":  "minecraft:planks"
                                       },
                                 "|":  {
                                           "item":  "spartan_weaponry_unofficial:simple_handle"
                                       }
                             },
                     "pattern":  [
                                     " # ",
                                     "###",
                                     "#|#"
                                 ],
                     "result":  {
                                    "count":  1,
                                    "id":  "spartan_weaponry_unofficial:greatsword_wooden"
                                }
                 }
    },
    {
        "id":  "overgearedspartan:wooden/weapons/wooden_halberd",
        "json":  {
                     "type":  "minecraft:crafting_shaped",
                     "group":  "spartan_weaponry_unofficial:halberd",
                     "key":  {
                                 "#":  {
                                           "tag":  "minecraft:planks"
                                       },
                                 "/":  {
                                           "item":  "spartan_weaponry_unofficial:simple_pole"
                                       }
                             },
                     "pattern":  [
                                     " #",
                                     "##",
                                     "#/"
                                 ],
                     "result":  {
                                    "count":  1,
                                    "id":  "spartan_weaponry_unofficial:halberd_wooden"
                                }
                 }
    },
    {
        "id":  "overgearedspartan:wooden/weapons/wooden_heavy_crossbow",
        "json":  {
                     "type":  "minecraft:crafting_shaped",
                     "group":  "spartan_weaponry_unofficial:heavy_crossbow",
                     "key":  {
                                 "#":  {
                                           "tag":  "minecraft:planks"
                                       },
                                 "D":  {
                                           "item":  "minecraft:bow"
                                       },
                                 "H":  {
                                           "item":  "minecraft:tripwire_hook"
                                       },
                                 "P":  {
                                           "tag":  "minecraft:planks"
                                       },
                                 "|":  {
                                           "item":  "spartan_weaponry_unofficial:simple_handle"
                                       }
                             },
                     "pattern":  [
                                     "#D#",
                                     "PHP",
                                     " | "
                                 ],
                     "result":  {
                                    "count":  1,
                                    "id":  "spartan_weaponry_unofficial:heavy_crossbow_wooden_strengthened"
                                }
                 }
    },
    {
        "id":  "overgearedspartan:wooden/weapons/wooden_javelin",
        "json":  {
                     "type":  "minecraft:crafting_shaped",
                     "group":  "spartan_weaponry_unofficial:javelin",
                     "key":  {
                                 "#":  {
                                           "tag":  "minecraft:planks"
                                       },
                                 "/":  {
                                           "item":  "spartan_weaponry_unofficial:simple_pole"
                                       }
                             },
                     "pattern":  [
                                     "/#"
                                 ],
                     "result":  {
                                    "count":  1,
                                    "id":  "spartan_weaponry_unofficial:javelin_wooden"
                                }
                 }
    },
    {
        "id":  "overgearedspartan:wooden/weapons/wooden_katana",
        "json":  {
                     "type":  "minecraft:crafting_shaped",
                     "group":  "spartan_weaponry_unofficial:katana",
                     "key":  {
                                 "#":  {
                                           "tag":  "minecraft:planks"
                                       },
                                 "|":  {
                                           "item":  "spartan_weaponry_unofficial:simple_handle"
                                       }
                             },
                     "pattern":  [
                                     "  #",
                                     " # ",
                                     "|  "
                                 ],
                     "result":  {
                                    "count":  1,
                                    "id":  "spartan_weaponry_unofficial:katana_wooden"
                                }
                 }
    },
    {
        "id":  "overgearedspartan:wooden/weapons/wooden_lance",
        "json":  {
                     "type":  "minecraft:crafting_shaped",
                     "group":  "spartan_weaponry_unofficial:lance",
                     "key":  {
                                 "#":  {
                                           "tag":  "minecraft:planks"
                                       },
                                 "/":  {
                                           "item":  "spartan_weaponry_unofficial:simple_pole"
                                       },
                                 "|":  {
                                           "item":  "spartan_weaponry_unofficial:simple_handle"
                                       }
                             },
                     "pattern":  [
                                     "  #",
                                     "#/ ",
                                     "|# "
                                 ],
                     "result":  {
                                    "count":  1,
                                    "id":  "spartan_weaponry_unofficial:lance_wooden"
                                }
                 }
    },
    {
        "id":  "overgearedspartan:wooden/weapons/wooden_longbow",
        "json":  {
                     "type":  "minecraft:crafting_shaped",
                     "group":  "spartan_weaponry_unofficial:longbow",
                     "key":  {
                                 "#":  {
                                           "tag":  "minecraft:planks"
                                       },
                                 "/":  {
                                           "tag":  "c:rods/wooden"
                                       },
                                 "|":  {
                                           "item":  "spartan_weaponry_unofficial:simple_handle"
                                       },
                                 "~":  {
                                           "item":  "minecraft:string"
                                       }
                             },
                     "pattern":  [
                                     "|/#",
                                     "/ ~",
                                     "#~~"
                                 ],
                     "result":  {
                                    "count":  1,
                                    "id":  "spartan_weaponry_unofficial:longbow_wooden_strengthened"
                                }
                 }
    },
    {
        "id":  "overgearedspartan:wooden/weapons/wooden_longsword",
        "json":  {
                     "type":  "minecraft:crafting_shaped",
                     "group":  "spartan_weaponry_unofficial:longsword",
                     "key":  {
                                 "#":  {
                                           "tag":  "minecraft:planks"
                                       },
                                 "|":  {
                                           "item":  "spartan_weaponry_unofficial:simple_handle"
                                       }
                             },
                     "pattern":  [
                                     " # ",
                                     " # ",
                                     "#|#"
                                 ],
                     "result":  {
                                    "count":  1,
                                    "id":  "spartan_weaponry_unofficial:longsword_wooden"
                                }
                 }
    },
    {
        "id":  "overgearedspartan:wooden/weapons/wooden_parrying_dagger",
        "json":  {
                     "type":  "minecraft:crafting_shaped",
                     "group":  "spartan_weaponry_unofficial:parrying_dagger",
                     "key":  {
                                 "#":  {
                                           "tag":  "minecraft:planks"
                                       },
                                 "|":  {
                                           "item":  "spartan_weaponry_unofficial:simple_handle"
                                       }
                             },
                     "pattern":  [
                                     " #",
                                     "#|"
                                 ],
                     "result":  {
                                    "count":  1,
                                    "id":  "spartan_weaponry_unofficial:parrying_dagger_wooden"
                                }
                 }
    },
    {
        "id":  "overgearedspartan:wooden/weapons/wooden_pike",
        "json":  {
                     "type":  "minecraft:crafting_shaped",
                     "group":  "spartan_weaponry_unofficial:pike",
                     "key":  {
                                 "#":  {
                                           "tag":  "minecraft:planks"
                                       },
                                 "/":  {
                                           "item":  "spartan_weaponry_unofficial:simple_pole"
                                       }
                             },
                     "pattern":  [
                                     "#",
                                     "/",
                                     "/"
                                 ],
                     "result":  {
                                    "count":  1,
                                    "id":  "spartan_weaponry_unofficial:pike_wooden"
                                }
                 }
    },
    {
        "id":  "overgearedspartan:wooden/weapons/wooden_quarterstaff",
        "json":  {
                     "type":  "minecraft:crafting_shaped",
                     "group":  "spartan_weaponry_unofficial:quarterstaff",
                     "key":  {
                                 "#":  {
                                           "tag":  "minecraft:planks"
                                       },
                                 "/":  {
                                           "item":  "spartan_weaponry_unofficial:simple_pole"
                                       }
                             },
                     "pattern":  [
                                     "  #",
                                     " / ",
                                     "#  "
                                 ],
                     "result":  {
                                    "count":  1,
                                    "id":  "spartan_weaponry_unofficial:quarterstaff_wooden"
                                }
                 }
    },
    {
        "id":  "overgearedspartan:wooden/weapons/wooden_rapier",
        "json":  {
                     "type":  "minecraft:crafting_shaped",
                     "group":  "spartan_weaponry_unofficial:rapier",
                     "key":  {
                                 "#":  {
                                           "tag":  "minecraft:planks"
                                       },
                                 "|":  {
                                           "item":  "spartan_weaponry_unofficial:simple_handle"
                                       }
                             },
                     "pattern":  [
                                     "  #",
                                     "## ",
                                     "|# "
                                 ],
                     "result":  {
                                    "count":  1,
                                    "id":  "spartan_weaponry_unofficial:rapier_wooden"
                                }
                 }
    },
    {
        "id":  "overgearedspartan:wooden/weapons/wooden_saber",
        "json":  {
                     "type":  "minecraft:crafting_shaped",
                     "group":  "spartan_weaponry_unofficial:saber",
                     "key":  {
                                 "#":  {
                                           "tag":  "minecraft:planks"
                                       },
                                 "|":  {
                                           "item":  "spartan_weaponry_unofficial:simple_handle"
                                       }
                             },
                     "pattern":  [
                                     " #",
                                     " #",
                                     "#|"
                                 ],
                     "result":  {
                                    "count":  1,
                                    "id":  "spartan_weaponry_unofficial:saber_wooden"
                                }
                 }
    },
    {
        "id":  "overgearedspartan:wooden/weapons/wooden_scythe",
        "json":  {
                     "type":  "minecraft:crafting_shaped",
                     "group":  "spartan_weaponry_unofficial:scythe",
                     "key":  {
                                 "#":  {
                                           "tag":  "minecraft:planks"
                                       },
                                 "/":  {
                                           "item":  "spartan_weaponry_unofficial:simple_pole"
                                       }
                             },
                     "pattern":  [
                                     "## ",
                                     "  #",
                                     " / "
                                 ],
                     "result":  {
                                    "count":  1,
                                    "id":  "spartan_weaponry_unofficial:scythe_wooden"
                                }
                 }
    },
    {
        "id":  "overgearedspartan:wooden/weapons/wooden_spear",
        "json":  {
                     "type":  "minecraft:crafting_shaped",
                     "group":  "spartan_weaponry_unofficial:spear",
                     "key":  {
                                 "#":  {
                                           "tag":  "minecraft:planks"
                                       },
                                 "/":  {
                                           "item":  "spartan_weaponry_unofficial:simple_pole"
                                       }
                             },
                     "pattern":  [
                                     "#",
                                     "/"
                                 ],
                     "result":  {
                                    "count":  1,
                                    "id":  "spartan_weaponry_unofficial:spear_wooden"
                                }
                 }
    },
    {
        "id":  "overgearedspartan:wooden/weapons/wooden_throwing_knife",
        "json":  {
                     "type":  "minecraft:crafting_shaped",
                     "group":  "spartan_weaponry_unofficial:throwing_knife",
                     "key":  {
                                 "#":  {
                                           "tag":  "minecraft:planks"
                                       },
                                 "|":  {
                                           "item":  "spartan_weaponry_unofficial:simple_handle"
                                       }
                             },
                     "pattern":  [
                                     "|#"
                                 ],
                     "result":  {
                                    "count":  1,
                                    "id":  "spartan_weaponry_unofficial:throwing_knife_wooden"
                                }
                 }
    },
    {
        "id":  "overgearedspartan:wooden/weapons/wooden_tomahawk",
        "json":  {
                     "type":  "minecraft:crafting_shaped",
                     "group":  "spartan_weaponry_unofficial:tomahawk",
                     "key":  {
                                 "#":  {
                                           "tag":  "minecraft:planks"
                                       },
                                 "|":  {
                                           "item":  "spartan_weaponry_unofficial:simple_handle"
                                       }
                             },
                     "pattern":  [
                                     "|#",
                                     " #"
                                 ],
                     "result":  {
                                    "count":  1,
                                    "id":  "spartan_weaponry_unofficial:tomahawk_wooden"
                                }
                 }
    },
    {
        "id":  "overgearedspartan:wooden/weapons/wooden_warhammer",
        "json":  {
                     "type":  "minecraft:crafting_shaped",
                     "group":  "spartan_weaponry_unofficial:warhammer",
                     "key":  {
                                 "#":  {
                                           "tag":  "minecraft:planks"
                                       },
                                 "|":  {
                                           "item":  "spartan_weaponry_unofficial:simple_handle"
                                       }
                             },
                     "pattern":  [
                                     " #",
                                     "##",
                                     " |"
                                 ],
                     "result":  {
                                    "count":  1,
                                    "id":  "spartan_weaponry_unofficial:warhammer_wooden"
                                }
                 }
    },
    {
        "id":  "iceandfire:silver_axe",
        "json":  {
                     "type":  "overgeared:crafting_shapeless",
                     "category":  "equipment",
                     "ingredients":  [
                                         {
                                             "item":  "spartan_weaponry_unofficial:handle"
                                         },
                                         {
                                             "item":  "kubejs:silver_axe_head"
                                         }
                                     ],
                     "result":  {
                                    "id":  "iceandfire:silver_axe",
                                    "count":  1
                                }
                 }
    },
    {
        "id":  "iceandfire:silver_hoe",
        "json":  {
                     "type":  "overgeared:crafting_shapeless",
                     "category":  "equipment",
                     "ingredients":  [
                                         {
                                             "item":  "spartan_weaponry_unofficial:handle"
                                         },
                                         {
                                             "item":  "kubejs:silver_hoe_head"
                                         }
                                     ],
                     "result":  {
                                    "id":  "iceandfire:silver_hoe",
                                    "count":  1
                                }
                 }
    },
    {
        "id":  "iceandfire:silver_pickaxe",
        "json":  {
                     "type":  "overgeared:crafting_shapeless",
                     "category":  "equipment",
                     "ingredients":  [
                                         {
                                             "item":  "spartan_weaponry_unofficial:handle"
                                         },
                                         {
                                             "item":  "kubejs:silver_pickaxe_head"
                                         }
                                     ],
                     "result":  {
                                    "id":  "iceandfire:silver_pickaxe",
                                    "count":  1
                                }
                 }
    },
    {
        "id":  "iceandfire:silver_shovel",
        "json":  {
                     "type":  "overgeared:crafting_shapeless",
                     "category":  "equipment",
                     "ingredients":  [
                                         {
                                             "item":  "spartan_weaponry_unofficial:handle"
                                         },
                                         {
                                             "item":  "kubejs:silver_shovel_head"
                                         }
                                     ],
                     "result":  {
                                    "id":  "iceandfire:silver_shovel",
                                    "count":  1
                                }
                 }
    },
    {
        "id":  "iceandfire:silver_sword",
        "json":  {
                     "type":  "overgeared:crafting_shapeless",
                     "category":  "equipment",
                     "ingredients":  [
                                         {
                                             "item":  "spartan_weaponry_unofficial:handle"
                                         },
                                         {
                                             "item":  "kubejs:silver_sword_blade"
                                         }
                                     ],
                     "result":  {
                                    "id":  "iceandfire:silver_sword",
                                    "count":  1
                                }
                 }
    },
    {
        "id":  "cbc_at:cutting/rocket_pod_rail_cast_mould",
        "json":  {
                     "type":  "create:cutting",
                     "ingredients":  [
                                         {
                                             "tag":  "minecraft:logs"
                                         }
                                     ],
                     "results":  [
                                     {
                                         "id":  "cbc_at:rocket_pod_rail_mould"
                                     }
                                 ]
                 }
    },
    {
        "id":  "cbc_at:cutting/rocket_pod_breech_cast_mould",
        "json":  {
                     "type":  "create:cutting",
                     "ingredients":  [
                                         {
                                             "tag":  "minecraft:logs"
                                         }
                                     ],
                     "results":  [
                                     {
                                         "id":  "cbc_at:rocket_pod_breech_mould"
                                     }
                                 ]
                 }
    },
    {
        "id":  "cbc_at:cutting/twin_autocannon_barrel_cast_mould",
        "json":  {
                     "type":  "create:cutting",
                     "ingredients":  [
                                         {
                                             "tag":  "minecraft:logs"
                                         }
                                     ],
                     "results":  [
                                     {
                                         "id":  "cbc_at:twin_autocannon_barrel_mould"
                                     }
                                 ]
                 }
    },
    {
        "id":  "create_radar:crafting/radar_jammer",
        "json":  {
                     "type":  "minecraft:crafting_shaped",
                     "key":  {
                                 "A":  {
                                           "item":  "create:transmitter"
                                       },
                                 "B":  {
                                           "item":  "create:shaft"
                                       },
                                 "C":  {
                                           "item":  "minecraft:quartz_block"
                                       },
                                 "E":  {
                                           "item":  "create:electron_tube"
                                       }
                             },
                     "pattern":  [
                                     "CCC",
                                     "CAC",
                                     "EBE"
                                 ],
                     "result":  {
                                    "id":  "create_radar:directional_jammer"
                                },
                     "show_notification":  true
                 }
    }
]

// Çıktısı bu mod sürümünde olmayan düzeltmeler atlanır (ör. Create: Radars 0.4.9.4'te directional_jammer yok;
// o düzeltme 5.x'in bozuk tarifi içindi). Böylece mod sürümü değişince tarif yükleme hatası çıkmaz.
const DuzeltmeKayit = Java.loadClass('net.minecraft.core.registries.BuiltInRegistries')
const DuzeltmeRL = Java.loadClass('net.minecraft.resources.ResourceLocation')
function duzeltmeCiktisi(j) {
  var r = j.result
  if (!r) return null
  return r.id || r.item || null
}
ServerEvents.recipes(event => {
  var uygulanan = 0
  DUZELTMELER.forEach(d => {
    var cikti = duzeltmeCiktisi(d.json)
    // Item.of(bilinmeyen) KubeJS'te hata sayılıyor ("KubeJS errors found"); kayıt sorgusu sessiz
    var yok = false
    if (cikti) { try { yok = !DuzeltmeKayit.ITEM.containsKey(DuzeltmeRL.parse(String(cikti))) } catch (e) { yok = true } }
    if (yok) { console.info('[modpack_duzeltmeler] atlandi (esya yok): ' + d.id + ' -> ' + cikti); return }
    event.remove({ id: d.id })
    event.custom(d.json).id(d.id)
    uygulanan++
  })
  console.info('[modpack_duzeltmeler] ' + uygulanan + ' bozuk tarif duzeltildi')
})
