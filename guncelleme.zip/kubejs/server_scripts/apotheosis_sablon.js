// =====================================================================
//  APOTHEOSIS YÜKSELTME ŞABLONLARI  -  kubejs/server_scripts/apotheosis_sablon.js
//  2026-11-25 (kullanıcı: "smithing template'leri bir işe yaramıyor gibi"):
//  Apotheosis şablonları eşyayı EFSUN/AFFIX ve soketleri koruyarak bir üst malzemeye taşır (smithing table).
//  Sorun: zincir taş -> demir -> ALTIN -> elmas idi; altın demirden zayıf olduğu için kimse kullanmıyordu.
//  Yeni zincir: taş -> demir (Iron şablonu) -> ELMAS (Diamond şablonu) -> netherite (vanilla şablon).
//  Altın şablonu ve demir->altın tarifleri kaldırıldı; demir -> elmas eklendi (4 elmas, Apotheosis'in kendi
//  "sized_upgrade" tarif türüyle: affix'ler, soketler ve efsunlar korunur).
// =====================================================================
ServerEvents.recipes(function (event) {
  try {
    event.remove({ id: 'apotheosis:gold_upgrade_smithing_template' })
    event.remove({ id: /^apotheosis:smithing\/upgrade_iron_.+_to_golden_.+$/ })
    ;['sword', 'pickaxe', 'axe', 'shovel', 'hoe', 'helmet', 'chestplate', 'leggings', 'boots'].forEach(function (t) {
      event.custom({
        type: 'apotheosis:sized_upgrade_recipe',
        template: { item: 'apotheosis:diamond_upgrade_smithing_template' },
        base: { item: 'minecraft:iron_' + t },
        addition: { tag: 'c:gems/diamond', count: 4 },
        result: { id: 'minecraft:diamond_' + t, count: 1 }
      }).id('kubejs:apotheosis/upgrade_iron_' + t + '_to_diamond_' + t)
    })
  } catch (err) { console.error('[ApotheosisSablon] ' + err) }
})
