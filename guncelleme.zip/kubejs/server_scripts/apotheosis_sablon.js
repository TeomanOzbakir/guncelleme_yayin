// =====================================================================
//  APOTHEOSIS YÜKSELTME ŞABLONLARI KALDIRILDI  -  kubejs/server_scripts/apotheosis_sablon.js
//  2026-11-25 (kullanıcı): "bunlar ne, sil". Apotheosis'in Iron/Gold/Diamond Upgrade Smithing Template'leri,
//  şablon tarifleri ve bütün taş->demir->altın->elmas yükseltme tarifleri silinir. Eşyalar JEI'den gizlenir
//  (client_scripts/apotheosis_sablon_gizle.js). Vanilla netherite yükseltmesi ve trim şablonları etkilenmez.
// =====================================================================
ServerEvents.recipes(function (event) {
  try {
    ;['iron', 'gold', 'diamond'].forEach(function (m) { event.remove({ id: 'apotheosis:' + m + '_upgrade_smithing_template' }) })
    event.remove({ id: /^apotheosis:smithing\// })
    event.remove({ output: /^apotheosis:(iron|gold|diamond)_upgrade_smithing_template$/ })
  } catch (err) { console.error('[ApotheosisSablon] ' + err) }
})