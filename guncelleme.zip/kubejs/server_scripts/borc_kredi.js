// =====================================================================
//  BORÇ, KREDİ NOTU ve KREDİ  -  kubejs/server_scripts/borc_kredi.js
//  Hedef: NeoForge 1.21.1 | KubeJS 2101.7.2 | Create Numismatics 1.1.0
//
//  BORÇ
//  - Diğer script'ler ödenemeyen tutarı 'borc_kuyruk' listesine yazar
//    (ör. savas_sistemi.js: cinayet cezasının ödenemeyen kısmı).
//  - Borca her gün GUNLUK_FAIZ işler (sunucu açıkken geçen süre sayılır).
//  - Borçlu istediği zaman /borc ode [miktar] ile bankasından öder.
//  - Borcu varken kredi çekilemez.
//
//  YAPTIRIM TAKVİMİ (2026-11-27, kullanıcı: 7 Minecraft günü = 140 dk yetmez -> 24 SAAT; sunucu açıkken geçen gerçek saat)
//   0-4. saat : ek süre, yaptırım yok
//   4. saat   : GELİRLERİN %50'si borca: Selling Bin, Vendor, transfer, bankaya yatan her para
//               (sunucu_piyasa: BankAccount.deposit kancası + kartsız Selling Bin kesintisi)
//   8. saat   : [BORÇLU] damgası (isim önü), /borclular listesi, borç kapanana kadar yeni arazi alınamaz
//               (vergi_sistemi.js); savaş ilan edemez, banka kuramaz, başkan atanamaz
//   16. saat  : gelirlerin %100'ü borca
//   24. saat  : KELLE AVI (öldüren borcun %25'i kadar ödülü hazineden alır,
//              ödül borca eklenir; ceset herkesçe yağmalanabilir; ödül her
//              KELLE_ARA saatte bir yeniden açılır) + ARAZİ HACZİ (claim'ler
//              askıya alınır, borç kapanınca geri gelir) + BANKA DONDURMA
//              (bankadaki ve envanterdeki paranın tamamı birkaç saniyede bir borca)
//  Borcu olan (aşama fark etmez) devletten de oyuncu bankasından da kredi alamaz.
//  OYUNCU BANKASI KREDİLERİ (banka_sistemi.js): onaylanan kredi VADE_GUN günde eşit taksitle bankaya ödenir;
//  ödenmeyen taksit buradaki borca 'alacak' olarak geçer, tahsil edilen kısım önce bankaya gider.
//  Paylaşılan veri: 'borc_durum' (borçlular, aşama, kesinti oranı, kelle) her
//  dakika yazılır; sunucu_piyasa modu satış kesintilerini 'borc_odeme'ye ekler.
//
//  KREDİ NOTU (0-1000, başlangıç 500)
//  - Her 2 saat borçsuz oyun: +3        - Borçlu geçen her gün: -15
//  - Kredi taksiti zamanında: +5        - Ödenemeyen taksit: -20
//  - Kredi tamamen ödendi: +25          - Cinayet cezası: -30
//  - Claim'leri askıda (vergi) her gün: -10
//
//  KREDİ (Devlet Hazinesi'nden)
//  - Limit ve faiz kredi notuna göre (KADEMELER tablosu). Hazinede yeterli
//    para yoksa kredi verilemez.
//  - Geri ödeme VADE_GUN günde eşit taksitle, günde bir bankadan otomatik.
//    Ödenemeyen taksit borca geçer.
//
//  !! Gerçek bir oyunda ÇALIŞTIRILARAK TEST EDİLMEDİ.
// =====================================================================

;(function () {
  var AYAR = {
    GUNLUK_FAIZ: 0.02,
    VADE_GUN: 7,
    BASLANGIC_NOTU: 500,
    // Yaptırımlar (SAAT cinsinden; 2026-11-27 öncesi 20 dk'lık "ekonomi günü"ydü)
    EKO_GUN: 60 * 60 * 1000,     // birim = 1 saat (ad eski kalsın, diğer hesaplar buna bağlı)
    KESINTI_YARIM_GUN: 4,        // gelirlerin %50'si borca
    DAMGA_GUN: 8,                // [BORÇLU] damgası + liste + yeni arazi/savaş/banka/başkan yasağı
    KESINTI_TAM_GUN: 16,         // gelirlerin %100'ü borca
    AGIR_GUN: 24,                // kelle avı + arazi haczi + banka dondurma
    KELLE_ORAN: 0.25,            // kelle ödülü = borcun %25'i
    KELLE_ARA_GUN: 12,           // (saat) ödül alındıktan sonra yeniden açılma
    TAKIM: 'borclu'              // damga için scoreboard takımı
  }
  // not >= alt  ->  limit (spur), toplam faiz (vade boyunca)
  var KADEMELER = [
    // 2026-11-27 (kullanıcı): limitler %25 düştü, faizler %30'dan %15'e
    { alt: 900, limit: 37500, faiz: 0.15 },
    { alt: 800, limit: 26250, faiz: 0.17 },
    { alt: 700, limit: 15000, faiz: 0.20 },
    { alt: 600, limit: 9000,  faiz: 0.23 },
    { alt: 500, limit: 4500,  faiz: 0.25 },
    { alt: 400, limit: 2250,  faiz: 0.27 },
    { alt: 300, limit: 750,   faiz: 0.30 }
  ]
  var PARA = { 'numismatics:spur': 1, 'numismatics:bevel': 8, 'numismatics:sprocket': 16,
    'numismatics:cog': 64, 'numismatics:crown': 512, 'numismatics:sun': 4096 }
  var HAZINE_UUID_STR = '5f0c2d1e-7a3b-4e9c-8d6f-1b2a3c4d5e6f'   // vergi_sistemi.js ile aynı
  var GUN = 24 * 3600 * 1000
  var MAX_ADIM = 5 * 60 * 1000
  var ASAMA_AD = ['Ek süre (yaptırım yok)', 'Gelirlerin %50\'si borca', '[BORÇLU] damgası, yeni arazi/savaş/banka yasağı, gelirlerin %50\'si borca',
    '[BORÇLU] damgası, yeni arazi/savaş/banka yasağı, gelirlerin tamamı borca', 'KELLE AVI, arazi haczi, banka ve üstündeki para tamamen borca']
  var ASAMA_GUN = [0, AYAR.KESINTI_YARIM_GUN, AYAR.DAMGA_GUN, AYAR.KESINTI_TAM_GUN, AYAR.AGIR_GUN]

  var JUUID = Java.loadClass('java.util.UUID')
  var Numismatics = Java.loadClass('dev.ithundxr.createnumismatics.Numismatics')
  var ReasonHolder = Java.loadClass('dev.ithundxr.createnumismatics.content.backend.ReasonHolder')
  var BankType = Java.loadClass('dev.ithundxr.createnumismatics.content.backend.BankAccount$Type')
  var ItemStack = Java.loadClass('net.minecraft.world.item.ItemStack')
  var HAZINE_UUID = JUUID.fromString(HAZINE_UUID_STR)
  // sunucu_piyasa: bankaya yatan paradan borç kesintisi; kendi iadelerimiz kesintiye takılmasın diye serbestYatir
  var BorcKesinti = null
  try { BorcKesinti = Java.loadClass('tr.sunucu.piyasa.BorcKesinti') } catch (e) { console.warn('[Borc] sunucu_piyasa BorcKesinti yok: ' + e) }
  var takimHazir = false
  var agirVar = false

  // ----------------------------- VERİ --------------------------------
  function yukle(server) {
    var s = server.persistentData.getString('borc_veri')
    var d = null
    if (s) { try { d = JSON.parse(s) } catch (e) { d = null } }
    if (!d || !d.o) d = { o: {} }
    return d
  }
  function kaydet(server, d) { server.persistentData.putString('borc_veri', JSON.stringify(d)) }
  function kayit(d, id, simdi) {
    var r = d.o[id]
    if (!r) r = d.o[id] = { borc: 0, borcBas: 0, faizSay: 0, gunSay: 0, onlineDk: 0, not: AYAR.BASLANGIC_NOTU, kredi: null, son: simdi, yas: 0, asama: 0 }
    return r
  }
  function notEkle(r, x) { r.not = Math.max(0, Math.min(1000, Math.round(r.not + x))) }
  function kademe(not) { for (var i = 0; i < KADEMELER.length; i++) if (not >= KADEMELER[i].alt) return KADEMELER[i]; return null }
  // Tacir mesleği: kredi limiti +%15/düğüm, faiz -%20/düğüm (yetenek_sistemi.js etiket önbelleği)
  function tacirKademe(server, id, k) {
    if (!k) return null
    var et = null
    try { et = JSON.parse(server.persistentData.getString('yetenek_etiket') || '{}')[id] } catch (e) { et = null }
    if (!et) return k
    var lim = 0, fz = 0
    if (et.indexOf('yt_limit_1') >= 0) lim += 0.15
    if (et.indexOf('yt_limit_2') >= 0) lim += 0.15
    if (et.indexOf('yt_faiz_1') >= 0) fz += 0.2
    if (et.indexOf('yt_faiz_2') >= 0) fz += 0.2
    if (et.indexOf('yt_limit_3') >= 0) lim += 0.1
    if (et.indexOf('yt_faiz_3') >= 0) fz += 0.1
    return { alt: k.alt, limit: Math.floor(k.limit * (1 + lim)), faiz: Math.round(k.faiz * (1 - fz) * 1000) / 1000 }
  }
  // Menü (arayuz_komut.js): devlet kredisinin bu oyuncu için limiti/faizi; not yetmiyorsa null
  if (global.ortak) global.ortak.put('krediKademe', function (server, id, not) { return tacirKademe(server, String(id), kademe(Number(not))) })

  // Borç yaşı ve aşama
  function borcEkle(r, m, simdi) {
    if (r.borc <= 0) { r.borcBas = simdi; r.yas = 0; r.asama = 0; r.kelleSon = null; r.kelleDuyuru = false }
    r.borc += m
  }
  function borcKapat(r) { r.alacak = {}; r.borc = 0; r.borcBas = 0; r.faizSay = 0; r.yas = 0; r.asama = 0; r.kelleSon = null; r.kelleDuyuru = false }
  function borcGunu(r) { return r.borc > 0 ? (r.yas || 0) / AYAR.EKO_GUN : 0 }
  function asama(r) {
    if (r.borc <= 0) return 0
    var g = borcGunu(r)
    for (var i = ASAMA_GUN.length - 1; i > 0; i--) if (g >= ASAMA_GUN[i]) return i
    return 0
  }
  function kesintiOrani(a) { return a >= 3 ? 1 : (a >= 1 ? 0.5 : 0) }
  function kelleAcik(r) {
    if (asama(r) < 4) return false
    return r.kelleSon == null || (r.yas || 0) - r.kelleSon >= AYAR.KELLE_ARA_GUN * AYAR.EKO_GUN
  }
  function kelleOdulu(r) { return Math.max(1, Math.ceil(r.borc * AYAR.KELLE_ORAN)) }
  function dk(ms) { var m = Math.max(1, Math.ceil(ms / 60000)); return m >= 60 ? Math.floor(m / 60) + ' sa ' + (m % 60) + ' dk' : m + ' dk' }
  function sonrakiYazi(r) {
    var a = asama(r)
    if (a >= 4) return ''
    return ' | Sonraki yaptırıma: ' + dk((ASAMA_GUN[a + 1] - borcGunu(r)) * AYAR.EKO_GUN)
  }

  // ----------------------------- BANKA / HAZİNE ----------------------
  function bakiye(uuid) { var h = Numismatics.BANK.getAccount(uuid); return h ? h.getBalance() : 0 }
  function kes(uuid, m) {
    m = Math.floor(m); if (m <= 0) return true
    var h = Numismatics.BANK.getAccount(uuid); if (!h) return false
    var ok = h.deduct(m, ReasonHolder.IGNORED); if (ok) h.markDirty(); return !!ok
  }
  function yatir(uuid, m, tip) {
    m = Math.floor(m); if (m <= 0) return
    var h = Numismatics.BANK.getOrCreateAccount(uuid, tip || BankType.PLAYER)
    if (BorcKesinti != null) BorcKesinti.serbestYatir(h, m); else h.deposit(m)
    h.markDirty()
  }
  // Tahsil edilen borç parası: önce alacaklı oyuncu bankalarına (ödenmeyen kredi taksitleri), kalanı hazineye.
  // r.alacak = { <banka anahtarı>: kalan alacak (spur) }. Hazineye giden kısmın tutarını döner.
  function tahsilatDagit(server, id, r, m, kim) {
    m = Math.floor(m)
    if (m <= 0) return 0
    var al = r.alacak || {}
    var ks = Object.keys(al)
    if (ks.length) {
      var bv = null
      try { bv = JSON.parse(server.persistentData.getString('banka_veri') || '{}') } catch (e) { bv = {} }
      var bankalar = (bv && bv.b) || {}
      for (var i = 0; i < ks.length && m > 0; i++) {
        var b = bankalar[ks[i]]
        var pay = Math.min(m, Math.floor(al[ks[i]]))
        if (!b || pay <= 0) { if (!b) delete al[ks[i]]; continue }
        var bh = Numismatics.BANK.getOrCreateAccount(JUUID.fromString(b.hesap), BankType.BLAZE_BANKER)
        bh.deposit(pay); bh.markDirty()
        al[ks[i]] -= pay
        if (al[ks[i]] < 1) delete al[ks[i]]
        m -= pay
        bildir(server, b.sahip, '[' + b.ad + '] ' + kim + ' borcundan ' + pay + ' spur tahsil edildi ve bankana yattı (ödenmeyen kredi taksiti).')
      }
      r.alacak = al
    }
    if (m > 0) {
      var h = hazine(); h.deposit(m); h.markDirty()
      hazineLog(server, 'borc', m, kim)
    }
    return m
  }
  function hazine() { return Numismatics.BANK.getOrCreateAccount(HAZINE_UUID, BankType.BLAZE_BANKER) }
  function hazineLog(server, tur, m, kim) {
    var s = server.persistentData.getString('hazine_veri')
    var d = null
    if (s) { try { d = JSON.parse(s) } catch (e) { d = null } }
    if (!d) d = {}
    if (!d.gelir) d.gelir = { arazi: 0, olum: 0, tescil: 0 }
    if (!d.hareket) d.hareket = []
    if (tur !== 'kredi') d.gelir[tur] = (d.gelir[tur] || 0) + m
    d.hareket = d.hareket.concat([{ t: Date.now(), tur: tur, m: m, k: kim }]).slice(-500)
    server.persistentData.putString('hazine_veri', JSON.stringify(d))
  }
  function ad(server, uuid) {
    var p = server.playerList.getPlayer(uuid)
    if (p != null) return String(p.username)
    var prof = server.getProfileCache().get(uuid)
    return prof.isPresent() ? String(prof.get().getName()) : String(uuid).substring(0, 8)
  }
  function bildir(server, id, msg) {
    var p = server.playerList.getPlayer(JUUID.fromString(id))
    if (p != null) p.tell(Text.ofString(msg))
  }
  function duyur(server, msg) { server.tell(Text.gold(Text.ofString(msg))) }

  // Borca para uygular: banka + (çevrimiçiyse) envanterdeki bozuk paralar (sadece 7. günden sonra)
  function borcTahsil(server, id, r) {
    if (r.borc <= 0) return
    var uuid = JUUID.fromString(id)
    var odenen = 0
    var borcTam = Math.ceil(r.borc)
    var b = Math.min(bakiye(uuid), borcTam)
    if (b > 0 && kes(uuid, b)) { odenen += b; r.borc -= b }
    var p = server.playerList.getPlayer(uuid)
    if (r.borc > 0 && p != null) {
      var inv = p.inventory
      var deger = 0
      for (var i = 0; i < inv.getContainerSize(); i++) {
        var st = inv.getItem(i)
        if (st.isEmpty()) continue
        var v = PARA[String(st.id)]
        if (!v) continue
        deger += v * st.getCount()
        inv.setItem(i, ItemStack.EMPTY)
      }
      if (deger > 0) {
        var kullan = Math.min(deger, Math.ceil(r.borc))
        r.borc -= kullan; odenen += kullan
        if (deger > kullan) yatir(uuid, deger - kullan)
        p.tell(Text.red(Text.ofString('Borcun için envanterindeki ' + deger + ' spur değerindeki bozuk para alındı' +
          (deger > kullan ? ' (artan ' + (deger - kullan) + ' spur bankana yatırıldı)' : '') + '.')))
      }
    }
    if (odenen > 0) {
      tahsilatDagit(server, id, r, odenen, ad(server, uuid))
      if (r.borc >= 1) bildir(server, id, 'Banka hesabın borç nedeniyle dondurulmuş: ' + odenen + ' spur borcuna alındı. Kalan: ' + Math.ceil(r.borc) + ' spur.')
    }
    if (r.borc < 1) {
      borcKapat(r)
      if (odenen > 0) bildir(server, id, 'Borcun tamamen ödendi. Tüm yaptırımlar kalktı.')
    }
  }

  // Diğer script'lerin / sunucu_piyasa modunun okuduğu özet
  function durumYaz(server, d) {
    var durum = {}
    agirVar = false
    Object.keys(d.o).forEach(function (id) {
      var r = d.o[id]
      if (r.borc <= 0) return
      var a = asama(r)
      if (a >= 4) agirVar = true
      durum[id] = { ad: r.ad || ad(server, JUUID.fromString(id)), b: Math.ceil(r.borc), kalan: r.borc, g: Math.floor(borcGunu(r) * 10) / 10,
        a: a, k: kesintiOrani(a), kelle: kelleAcik(r), odul: kelleOdulu(r) }
    })
    server.persistentData.putString('borc_durum', JSON.stringify(durum))
  }

  // [BORÇLU] damgası: scoreboard takımı (isim önü, sohbet ve isim etiketi)
  function takimKur(server) {
    if (takimHazir) return
    takimHazir = true
    server.runCommandSilent('team add ' + AYAR.TAKIM)
    server.runCommandSilent('team modify ' + AYAR.TAKIM + ' prefix {"text":"[BORÇLU] ","color":"red"}')
  }
  function damgaEsitle(server, d, online) {
    takimKur(server)
    var sb = server.getScoreboard()
    for (var i = 0; i < online.length; i++) {
      var p = online[i]
      var r = d.o[String(p.getUuid())]
      var isim = String(p.username)
      var takim = sb.getPlayersTeam(isim)
      var icinde = takim != null && String(takim.getName()) === AYAR.TAKIM
      var olmali = r != null && asama(r) >= 2
      if (olmali && !icinde) server.runCommandSilent('team join ' + AYAR.TAKIM + ' ' + isim)
      else if (!olmali && icinde) server.runCommandSilent('team leave ' + isim)
    }
  }

  function asamaBildir(server, id, r, a) {
    var odul = kelleOdulu(r)
    var m = [null,
      'Borcun ' + AYAR.KESINTI_YARIM_GUN + ' saattir ödenmedi: gelirlerinin (Selling Bin, Vendor, transfer, bankaya yatan para) %50\'si artık borcuna kesiliyor. /borc ode ile kapatabilirsin.',
      'Borcun ' + AYAR.DAMGA_GUN + ' saattir ödenmedi: adına [BORÇLU] damgası vuruldu, borçlular listesindesin (/borclular). Borç kapanana kadar yeni arazi alamaz, savaş ilan edemez, banka kuramazsın.',
      'Borcun ' + AYAR.KESINTI_TAM_GUN + ' saattir ödenmedi: gelirlerinin TAMAMI borcuna kesiliyor.',
      'Borcun ' + AYAR.AGIR_GUN + ' saattir ödenmedi: kellene ' + odul + ' spur ödül kondu, arazilerine haciz uygulandı ve banka hesabın donduruldu (bankana ve üstüne gelen para borca alınır).'][a]
    if (m) bildir(server, id, m)
  }

  function kuyrukIsle(server, d, simdi) {
    var ks = server.persistentData.getString('borc_kuyruk')
    if (!ks || ks === '[]') return
    var kuyruk = []
    try { kuyruk = JSON.parse(ks) } catch (e) { kuyruk = [] }
    kuyruk.forEach(function (x) {
      var r = kayit(d, x.u, simdi)
      if (x.s === 'kelle') {
        r.kelleSon = r.yas || 0
        r.kelleDuyuru = false
        if (x.m > 0) borcEkle(r, x.m, simdi)
        bildir(server, x.u, 'Kellen alındı: ödülü (' + Math.ceil(x.m || 0) + ' spur) borcuna eklendi. Kelle avı ' + AYAR.KELLE_ARA_GUN + ' saat sonra yeniden açılır.')
        return
      }
      if (x.m > 0) {
        borcEkle(r, x.m, simdi)
        // oyuncu bankasının ödenmeyen kredi taksiti: tahsil edilince önce o bankaya gider
        if (x.s === 'banka' && x.b) { if (!r.alacak) r.alacak = {}; r.alacak[x.b] = (r.alacak[x.b] || 0) + x.m }
        bildir(server, x.u, 'Ödeyemediğin ' + Math.ceil(x.m) + ' spur borcuna yazıldı (' + (x.s === 'banka' ? (x.ad || x.b) + ' Bankası kredi taksiti' : x.s) + '). Borca günde %' +
          Math.round(AYAR.GUNLUK_FAIZ * 100) + ' faiz işler. ' + AYAR.KESINTI_YARIM_GUN + ' saat içinde ödemezsen yaptırımlar başlar, ' + AYAR.AGIR_GUN + '. saatte kelle avı. Detay: /borc')
      }
      if (x.s === 'cinayet') notEkle(r, -30)
      if (x.s === 'banka') notEkle(r, -20)
    })
    server.persistentData.putString('borc_kuyruk', '[]')
  }

  // sunucu_piyasa modunun Selling Bin satışlarından kestiği tutarlar
  function satisKesintileri(server, d, simdi) {
    var os = server.persistentData.getString('borc_odeme')
    if (!os || os === '[]') return
    var liste = []
    try { liste = JSON.parse(os) } catch (e) { liste = [] }
    server.persistentData.putString('borc_odeme', '[]')
    var topla = {}
    liste.forEach(function (x) { if (x && x.u && x.m > 0) topla[x.u] = (topla[x.u] || 0) + x.m })
    Object.keys(topla).forEach(function (id) {
      var r = kayit(d, id, simdi)
      var m = topla[id]
      var fazla = m - Math.max(0, r.borc)
      if (fazla >= 1) yatir(JUUID.fromString(id), fazla)   // bu arada borç başka yoldan kapandıysa artan iade (kesintisiz)
      if (fazla > 0) m -= fazla
      r.borc -= m
      var kus = (d.kusurat || 0) + m
      var tam = Math.floor(kus)
      d.kusurat = kus - tam
      if (tam > 0) tahsilatDagit(server, id, r, tam, r.ad || ad(server, JUUID.fromString(id)))
      if (r.borc < 1) {
        borcKapat(r)
        bildir(server, id, 'Gelir kesintileriyle borcun tamamen ödendi. Tüm yaptırımlar kalktı.')
      } else {
        bildir(server, id, 'Gelirlerinden (satış, Vendor, transfer, bankaya yatan para) ' + (Math.round(m * 10) / 10) + ' spur borcuna kesildi. Kalan borç: ' + Math.ceil(r.borc) + ' spur.')
      }
    })
  }

  // ----------------------------- ZAMANLAYICI -------------------------
  ServerEvents.tick(function (event) {
    var server = event.server
    // Banka dondurma: 7. günü geçen borçluların bankası/parası birkaç saniyede bir borca alınır
    if (agirVar && server.tickCount % 100 === 50) {
      try {
        var dz = yukle(server)
        var degisti = false
        Object.keys(dz.o).forEach(function (id) {
          var r = dz.o[id]
          if (r.borc > 0 && asama(r) >= 4) { borcTahsil(server, id, r); degisti = true }
        })
        if (degisti) { kaydet(server, dz); durumYaz(server, dz) }
      } catch (err) { console.error('[Borc] dondurma hatasi: ' + err) }
    }
    if (server.tickCount % 1200 !== 0) return
    try {
      var d = yukle(server)
      var simdi = Date.now()
      // 2026-11-28: test için /zamanatla (zaman_atla.js) bekleyen süre: bu turda her kayda bir kez eklenir
      var ek = Number(server.persistentData.getString('zatla_borc') || 0)
      if (ek > 0) server.persistentData.putString('zatla_borc', '0'); else ek = 0

      // 1) Diğer script'lerden gelen borç / olay kuyruğu, satış kesintileri
      kuyrukIsle(server, d, simdi)
      satisKesintileri(server, d, simdi)

      // Çevrimiçi oyuncuların kaydı olsun (kredi notu birikir)
      var online = server.playerList.getPlayers().toArray()
      var onlineSet = {}
      for (var i = 0; i < online.length; i++) {
        var oid = String(online[i].getUuid())
        onlineSet[oid] = true
        kayit(d, oid, simdi).ad = String(online[i].username)
      }

      // Vergi kayıtları (askıdaki claim'ler)
      var vergi = {}
      try { var vs = server.persistentData.getString('vergi_veri'); if (vs) vergi = JSON.parse(vs).kayitlar || {} } catch (e) { vergi = {} }

      Object.keys(d.o).forEach(function (id) {
        var r = d.o[id]
        var adim = Math.min(Math.max(0, simdi - (r.son || simdi)), MAX_ADIM) + ek
        r.son = simdi

        // Faiz ve borç yaşı
        if (r.borc > 0) {
          r.faizSay += adim
          while (r.faizSay >= GUN) { r.faizSay -= GUN; r.borc *= (1 + AYAR.GUNLUK_FAIZ) }
          r.yas = (r.yas || 0) + adim
        }

        // Kredi taksiti
        if (r.kredi) {
          r.kredi.sayac += adim
          while (r.kredi && r.kredi.sayac >= GUN) {   // zaman atlamada birden çok gün işlenebilir
            r.kredi.sayac -= GUN
            var t = Math.min(r.kredi.taksit, r.kredi.kalan)
            if (kes(JUUID.fromString(id), t)) {
              var h = hazine(); h.deposit(t); h.markDirty()
              hazineLog(server, 'kredi_odeme', t, ad(server, JUUID.fromString(id)))
              notEkle(r, 5)
              bildir(server, id, 'Kredi taksiti ödendi: ' + t + ' spur. Kalan: ' + (r.kredi.kalan - t) + ' spur.')
            } else {
              borcEkle(r, t, simdi)
              notEkle(r, -20)
              bildir(server, id, 'Kredi taksiti (' + t + ' spur) ödenemedi, borcuna yazıldı. Kredi notun düştü.')
            }
            r.kredi.kalan -= t
            if (r.kredi.kalan <= 0) { r.kredi = null; notEkle(r, 25); bildir(server, id, 'Kredin kapandı.') }
          }
        }

        // Yaptırım aşaması
        var a = asama(r)
        if (a > (r.asama || 0)) { asamaBildir(server, id, r, a); r.asama = a }
        // 7. gün: banka dondurma (tam tahsil) ve kelle duyurusu
        if (a >= 4) borcTahsil(server, id, r)
        if (r.borc > 0 && kelleAcik(r) && !r.kelleDuyuru) {
          r.kelleDuyuru = true
          duyur(server, '[Kelle Avı] ' + (r.ad || ad(server, JUUID.fromString(id))) + ' ' + Math.floor(borcGunu(r)) +
            ' saattir borcunu ödemiyor. Kellesine ' + kelleOdulu(r) + ' spur ödül! Öldürmek suç sayılmaz, cesedi yağmalanabilir. (/borclular)')
        }

        // Kredi notu: günlük
        r.gunSay += adim
        while (r.gunSay >= GUN) {
          r.gunSay -= GUN
          if (r.borc > 0) notEkle(r, -15)
          if (vergi[id] && vergi[id].askida) notEkle(r, -10)
        }
        // Kredi notu: borçsuz oyun süresi
        if (onlineSet[id] && r.borc <= 0) {
          r.onlineDk += 1 + Math.floor(ek / 60000)
          while (r.onlineDk >= 120) { r.onlineDk -= 120; notEkle(r, 3) }
        }
      })
      kaydet(server, d)
      durumYaz(server, d)
      damgaEsitle(server, d, online)
    } catch (err) { console.error('[Borc] hata: ' + err) }
  })

  // Girişte borç hatırlatması
  PlayerEvents.loggedIn(function (event) {
    try {
      var p = event.player
      var d = yukle(event.server)
      var r = d.o[String(p.getUuid())]
      if (!r || r.borc <= 0) return
      p.tell(Text.red(Text.ofString('Borcun var: ' + Math.ceil(r.borc) + ' spur (' + Math.floor(borcGunu(r) * 10) / 10 + '. saat). Yaptırım: ' +
        ASAMA_AD[asama(r)] + sonrakiYazi(r) + '. Ödemek için: /borc ode')))
    } catch (err) { console.error('[Borc] giris hatasi: ' + err) }
  })

  // ----------------------------- KOMUTLAR ----------------------------
  ServerEvents.commandRegistry(function (event) {
    var Commands = event.commands
    var Arguments = event.arguments
    var yaz = function (ctx, m) { ctx.source.sendSystemMessage(Text.ofString(m)) }
    var op = function (src) { return src.hasPermission(2) }

    function ozet(ctx, server, id) {
      var d = yukle(server)
      var r = kayit(d, id, Date.now())
      var k = tacirKademe(server, id, kademe(r.not))
      yaz(ctx, 'Kredi notu: ' + r.not + '/1000 | Çekilebilir kredi: ' + (k ? k.limit + ' spur, faiz %' + Math.round(k.faiz * 100) : 'yok (not 300 altında)'))
      if (r.borc > 0) {
        yaz(ctx, 'Borç: ' + Math.ceil(r.borc) + ' spur (günlük faiz %' + Math.round(AYAR.GUNLUK_FAIZ * 100) + ') | Borç süresi: ' +
          Math.floor(borcGunu(r) * 10) / 10 + ' saat (sunucu açıkken; ' + AYAR.AGIR_GUN + '. saatte kelle avı)')
        yaz(ctx, 'Yaptırım: ' + ASAMA_AD[asama(r)] + sonrakiYazi(r))
        yaz(ctx, 'Ödemek için: /borc ode (tamamı, bankadan) veya /borc ode <miktar>')
      } else yaz(ctx, 'Borç: yok')
      if (r.kredi) yaz(ctx, 'Aktif kredi: kalan ' + r.kredi.kalan + ' spur, günlük taksit ' + r.kredi.taksit + ' spur')
    }

    function borcOde(ctx, miktar) {
      var p = ctx.source.player; if (p == null) return 0
      var server = p.server
      var id = String(p.getUuid())
      var d = yukle(server)
      var r = kayit(d, id, Date.now())
      if (r.borc <= 0) { yaz(ctx, 'Borcun yok.'); return 0 }
      var borcTam = Math.ceil(r.borc)
      var b = bakiye(p.getUuid())
      var m = miktar > 0 ? Math.min(miktar, borcTam) : Math.min(borcTam, b)
      if (m <= 0) { yaz(ctx, 'Bankanda para yok. Önce bankana para yatır (Bank Terminal).'); return 0 }
      if (m > b) { yaz(ctx, 'Bankanda ' + m + ' spur yok (bakiye: ' + b + ').'); return 0 }
      if (!kes(p.getUuid(), m)) { yaz(ctx, 'Ödeme yapılamadı.'); return 0 }
      tahsilatDagit(server, id, r, m, String(p.username))
      r.borc -= m
      if (r.borc < 1) {
        borcKapat(r)
        yaz(ctx, m + ' spur ödendi. Borcun kapandı, tüm yaptırımlar kalktı.')
      } else yaz(ctx, m + ' spur ödendi. Kalan borç: ' + Math.ceil(r.borc) + ' spur. (Kısmi ödeme borç süresini sıfırlamaz.)')
      kaydet(server, d)
      durumYaz(server, d)
      damgaEsitle(server, d, [p])
      return 1
    }

    event.register(Commands.literal('borc')
      .executes(function (ctx) {
        var p = ctx.source.player; if (p == null) return 0
        ozet(ctx, p.server, String(p.getUuid())); return 1
      })
      .then(Commands.literal('ode')
        .executes(function (ctx) { return borcOde(ctx, 0) })
        .then(Commands.argument('miktar', Arguments.INTEGER.create(event)).executes(function (ctx) {
          var m = Arguments.INTEGER.getResult(ctx, 'miktar')
          if (m <= 0) { yaz(ctx, 'Miktar 0\'dan büyük olmalı.'); return 0 }
          return borcOde(ctx, m)
        }))))

    // Herkese açık borçlular listesi (damgalı: 3. gün ve sonrası)
    event.register(Commands.literal('borclular').executes(function (ctx) {
      var server = ctx.source.server
      var durum = {}
      try { durum = JSON.parse(server.persistentData.getString('borc_durum') || '{}') } catch (e) { durum = {} }
      var liste = Object.keys(durum).map(function (id) { return durum[id] }).filter(function (x) { return x.a >= 2 })
      liste.sort(function (a, b) { return b.b - a.b })
      if (liste.length === 0) { yaz(ctx, 'Damgalı borçlu yok.'); return 1 }
      yaz(ctx, '--- [BORÇLU] listesi ---')
      liste.forEach(function (x) {
        yaz(ctx, x.ad + ': ' + x.b + ' spur, ' + Math.floor(x.g) + '. saat' + (x.kelle ? '  >> KELLE AVI: ' + x.odul + ' spur ödül' : (x.a >= 4 ? '  (kelle ödülü alındı, yakında yeniden açılır)' : '')))
      })
      return 1
    }))

    event.register(Commands.literal('kredi')
      .then(Commands.literal('durum').executes(function (ctx) {
        var p = ctx.source.player; if (p == null) return 0
        ozet(ctx, p.server, String(p.getUuid())); return 1
      }))
      .then(Commands.literal('cek').then(Commands.argument('miktar', Arguments.INTEGER.create(event)).executes(function (ctx) {
        var p = ctx.source.player; if (p == null) return 0
        var server = p.server
        var id = String(p.getUuid())
        var miktar = Arguments.INTEGER.getResult(ctx, 'miktar')
        var d = yukle(server)
        var r = kayit(d, id, Date.now())
        var k = tacirKademe(server, id, kademe(r.not))
        if (miktar <= 0) { yaz(ctx, 'Miktar 0\'dan büyük olmalı.'); return 0 }
        if (r.borc > 0) { yaz(ctx, 'Borcun varken kredi çekemezsin.'); return 0 }
        if (r.kredi) { yaz(ctx, 'Önce mevcut kredini kapatmalısın (/kredi ode).'); return 0 }
        if (!k) { yaz(ctx, 'Kredi notun (' + r.not + ') kredi için yetersiz. En az 300 gerekli.'); return 0 }
        if (miktar > k.limit) { yaz(ctx, 'Kredi notunla en fazla ' + k.limit + ' spur çekebilirsin.'); return 0 }
        var h = hazine()
        if (h.getBalance() < miktar || !h.deduct(miktar, ReasonHolder.IGNORED)) { yaz(ctx, 'Devlet hazinesinde şu an bu kadar para yok.'); return 0 }
        h.markDirty()
        yatir(p.getUuid(), miktar)
        var toplam = Math.ceil(miktar * (1 + k.faiz))
        r.kredi = { anapara: miktar, kalan: toplam, taksit: Math.ceil(toplam / AYAR.VADE_GUN), sayac: 0 }
        hazineLog(server, 'kredi', miktar, String(p.username))
        kaydet(server, d)
        yaz(ctx, miktar + ' spur kredi bankana yatırıldı. Geri ödeme: ' + toplam + ' spur, ' + AYAR.VADE_GUN + ' gün boyunca günde ' + r.kredi.taksit + ' spur.')
        return 1
      })))
      .then(Commands.literal('ode').executes(function (ctx) {
        var p = ctx.source.player; if (p == null) return 0
        var server = p.server
        var d = yukle(server)
        var r = kayit(d, String(p.getUuid()), Date.now())
        if (!r.kredi) { yaz(ctx, 'Aktif kredin yok.'); return 0 }
        var m = r.kredi.kalan
        if (!kes(p.getUuid(), m)) { yaz(ctx, 'Bankanda ' + m + ' spur olmalı.'); return 0 }
        var h = hazine(); h.deposit(m); h.markDirty()
        hazineLog(server, 'kredi_odeme', m, String(p.username))
        r.kredi = null; notEkle(r, 25)
        kaydet(server, d)
        yaz(ctx, 'Kredin kapatıldı (' + m + ' spur). Kredi notun yükseldi: ' + r.not)
        return 1
      }))
      // OP: başka oyuncunun durumu
      .then(Commands.literal('bak').requires(op).then(Commands.argument('oyuncu', Arguments.PLAYER.create(event)).executes(function (ctx) {
        var h = Arguments.PLAYER.getResult(ctx, 'oyuncu')
        yaz(ctx, '--- ' + String(h.username))
        ozet(ctx, ctx.source.server, String(h.getUuid())); return 1
      })))
      // OP: borcu sil
      .then(Commands.literal('borcsil').requires(op).then(Commands.argument('oyuncu', Arguments.PLAYER.create(event)).executes(function (ctx) {
        var h = Arguments.PLAYER.getResult(ctx, 'oyuncu')
        var server = ctx.source.server
        var d = yukle(server)
        var r = kayit(d, String(h.getUuid()), Date.now())
        borcKapat(r)
        kaydet(server, d)
        durumYaz(server, d)
        damgaEsitle(server, d, [h])
        yaz(ctx, String(h.username) + ' oyuncusunun borcu silindi.'); return 1
      })))
      // OP: test için borç süresini ileri al (/kredi borcgun <oyuncu> <saat>)
      .then(Commands.literal('borcgun').requires(op).then(Commands.argument('oyuncu', Arguments.PLAYER.create(event))
        .then(Commands.argument('gun', Arguments.INTEGER.create(event)).executes(function (ctx) {
          var h = Arguments.PLAYER.getResult(ctx, 'oyuncu')
          var g = Arguments.INTEGER.getResult(ctx, 'gun')
          var server = ctx.source.server
          var d = yukle(server)
          var r = kayit(d, String(h.getUuid()), Date.now())
          if (r.borc <= 0) { yaz(ctx, 'Bu oyuncunun borcu yok.'); return 0 }
          r.yas = Math.max(0, g) * AYAR.EKO_GUN
          kaydet(server, d)
          durumYaz(server, d)
          yaz(ctx, String(h.username) + ' borç süresi ' + g + ' saat yapıldı; yaptırımlar bir dakika içinde uygulanır.'); return 1
        })))))
  })

  console.info('[Borc] yuklendi: gunluk faiz %' + Math.round(AYAR.GUNLUK_FAIZ * 100) + ', kredi vadesi ' + AYAR.VADE_GUN + ' gun, yaptirimlar 4/8/16/24. saat')
})()
