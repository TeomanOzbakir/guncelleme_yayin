// =====================================================================
//  BORÇ, KREDİ NOTU ve KREDİ  -  kubejs/server_scripts/borc_kredi.js
//  Hedef: NeoForge 1.21.1 | KubeJS 2101.7.2 | Create Numismatics 1.1.0
//
//  BORÇ
//  - Diğer script'ler ödenemeyen tutarı 'borc_kuyruk' listesine yazar
//    (ör. savas_sistemi.js: cinayet cezasının ödenemeyen kısmı).
//  - Borca her gün GUNLUK_FAIZ işler (sunucu açıkken geçen süre sayılır).
//  - Her dakika: borçlunun bankasındaki para ve (çevrimiçiyse) envanterdeki
//    Numismatics bozuk paraları borca kesilir, hazineye gider. Bozuk paralar
//    borçtan fazlaysa artanı bankasına yatırılır.
//  - Borcu varken kredi çekilemez. (Diğer yaptırımlar henüz karara bağlanmadı.)
//
//  KREDİ NOTU (0-1000, başlangıç 500)
//  - Her 2 saat borçsuz oyun: +3        - Borçlu geçen her gün: -15
//  - Kredi taksiti zamanında: +5        - Ödenemeyen taksit: -20
//  - Kredi tamamen ödendi: +25          - Cinayet cezası: -30
//  - Claim'leri askıda (vergi) her gün: -10
//
//  KREDİ (Devlet Hazinesi'nden)
//  - Limit ve faiz kredi notuna göre (KADEMELER tablosu). Hazinede yeterli
//    para yoksa kredi verilemez.
//  - Geri ödeme VADE_GUN günde eşit taksitle, günde bir bankadan otomatik.
//    Ödenemeyen taksit borca geçer.
//
//  !! Gerçek bir oyunda ÇALIŞTIRILARAK TEST EDİLMEDİ.
// =====================================================================

;(function () {
  var AYAR = {
    GUNLUK_FAIZ: 0.02,
    VADE_GUN: 7,
    BASLANGIC_NOTU: 500
  }
  // not >= alt  ->  limit (spur), toplam faiz (vade boyunca)
  var KADEMELER = [
    { alt: 900, limit: 50000, faiz: 0.03 },
    { alt: 800, limit: 35000, faiz: 0.04 },
    { alt: 700, limit: 20000, faiz: 0.06 },
    { alt: 600, limit: 12000, faiz: 0.08 },
    { alt: 500, limit: 6000,  faiz: 0.10 },
    { alt: 400, limit: 3000,  faiz: 0.12 },
    { alt: 300, limit: 1000,  faiz: 0.15 }
  ]
  var PARA = { 'numismatics:spur': 1, 'numismatics:bevel': 8, 'numismatics:sprocket': 16,
    'numismatics:cog': 64, 'numismatics:crown': 512, 'numismatics:sun': 4096 }
  var HAZINE_UUID_STR = '5f0c2d1e-7a3b-4e9c-8d6f-1b2a3c4d5e6f'   // vergi_sistemi.js ile aynı
  var GUN = 24 * 3600 * 1000
  var MAX_ADIM = 5 * 60 * 1000

  var JUUID = Java.loadClass('java.util.UUID')
  var Numismatics = Java.loadClass('dev.ithundxr.createnumismatics.Numismatics')
  var ReasonHolder = Java.loadClass('dev.ithundxr.createnumismatics.content.backend.ReasonHolder')
  var BankType = Java.loadClass('dev.ithundxr.createnumismatics.content.backend.BankAccount$Type')
  var ItemStack = Java.loadClass('net.minecraft.world.item.ItemStack')
  var HAZINE_UUID = JUUID.fromString(HAZINE_UUID_STR)

  // ----------------------------- VERİ --------------------------------
  function yukle(server) {
    var s = server.persistentData.getString('borc_veri')
    var d = null
    if (s) { try { d = JSON.parse(s) } catch (e) { d = null } }
    if (!d || !d.o) d = { o: {} }
    return d
  }
  function kaydet(server, d) { server.persistentData.putString('borc_veri', JSON.stringify(d)) }
  function kayit(d, id, simdi) {
    var r = d.o[id]
    if (!r) r = d.o[id] = { borc: 0, borcBas: 0, faizSay: 0, gunSay: 0, onlineDk: 0, not: AYAR.BASLANGIC_NOTU, kredi: null, son: simdi }
    return r
  }
  function notEkle(r, x) { r.not = Math.max(0, Math.min(1000, Math.round(r.not + x))) }
  function kademe(not) { for (var i = 0; i < KADEMELER.length; i++) if (not >= KADEMELER[i].alt) return KADEMELER[i]; return null }

  // ----------------------------- BANKA / HAZİNE ----------------------
  function bakiye(uuid) { var h = Numismatics.BANK.getAccount(uuid); return h ? h.getBalance() : 0 }
  function kes(uuid, m) {
    m = Math.floor(m); if (m <= 0) return true
    var h = Numismatics.BANK.getAccount(uuid); if (!h) return false
    var ok = h.deduct(m, ReasonHolder.IGNORED); if (ok) h.markDirty(); return !!ok
  }
  function yatir(uuid, m, tip) {
    m = Math.floor(m); if (m <= 0) return
    var h = Numismatics.BANK.getOrCreateAccount(uuid, tip || BankType.PLAYER); h.deposit(m); h.markDirty()
  }
  function hazine() { return Numismatics.BANK.getOrCreateAccount(HAZINE_UUID, BankType.BLAZE_BANKER) }
  function hazineLog(server, tur, m, kim) {
    var s = server.persistentData.getString('hazine_veri')
    var d = null
    if (s) { try { d = JSON.parse(s) } catch (e) { d = null } }
    if (!d) d = {}
    if (!d.gelir) d.gelir = { arazi: 0, olum: 0, tescil: 0 }
    if (!d.hareket) d.hareket = []
    if (tur !== 'kredi') d.gelir[tur] = (d.gelir[tur] || 0) + m
    d.hareket = d.hareket.concat([{ t: Date.now(), tur: tur, m: m, k: kim }]).slice(-30)
    server.persistentData.putString('hazine_veri', JSON.stringify(d))
  }
  function ad(server, uuid) {
    var p = server.playerList.getPlayer(uuid)
    if (p != null) return String(p.username)
    var prof = server.getProfileCache().get(uuid)
    return prof.isPresent() ? String(prof.get().getName()) : String(uuid).substring(0, 8)
  }
  function bildir(server, id, msg) {
    var p = server.playerList.getPlayer(JUUID.fromString(id))
    if (p != null) p.tell(Text.ofString(msg))
  }

  // Borca para uygular: banka + (çevrimiçiyse) envanterdeki bozuk paralar
  function borcTahsil(server, id, r) {
    if (r.borc <= 0) return
    var uuid = JUUID.fromString(id)
    var odenen = 0
    var borcTam = Math.ceil(r.borc)
    var b = Math.min(bakiye(uuid), borcTam)
    if (b > 0 && kes(uuid, b)) { odenen += b; r.borc -= b }
    var p = server.playerList.getPlayer(uuid)
    if (r.borc > 0 && p != null) {
      var inv = p.inventory
      var deger = 0
      for (var i = 0; i < inv.getContainerSize(); i++) {
        var st = inv.getItem(i)
        if (st.isEmpty()) continue
        var v = PARA[String(st.id)]
        if (!v) continue
        deger += v * st.getCount()
        inv.setItem(i, ItemStack.EMPTY)
      }
      if (deger > 0) {
        var kullan = Math.min(deger, Math.ceil(r.borc))
        r.borc -= kullan; odenen += kullan
        if (deger > kullan) yatir(uuid, deger - kullan)
        p.tell(Text.red(Text.ofString('Borcun için envanterindeki ' + deger + ' spur değerindeki bozuk para alındı' +
          (deger > kullan ? ' (artan ' + (deger - kullan) + ' spur bankana yatırıldı)' : '') + '.')))
      }
    }
    if (odenen > 0) {
      var h = hazine(); h.deposit(odenen); h.markDirty()
      hazineLog(server, 'borc', odenen, ad(server, uuid))
    }
    if (r.borc < 1) {
      r.borc = 0; r.borcBas = 0; r.faizSay = 0
      if (odenen > 0) bildir(server, id, 'Borcun tamamen ödendi.')
    }
  }

  // ----------------------------- ZAMANLAYICI -------------------------
  ServerEvents.tick(function (event) {
    var server = event.server
    if (server.tickCount % 1200 !== 0) return
    try {
      var d = yukle(server)
      var simdi = Date.now()

      // 1) Diğer script'lerden gelen borç / olay kuyruğu
      var ks = server.persistentData.getString('borc_kuyruk')
      if (ks) {
        var kuyruk = []
        try { kuyruk = JSON.parse(ks) } catch (e) { kuyruk = [] }
        kuyruk.forEach(function (x) {
          var r = kayit(d, x.u, simdi)
          if (x.m > 0) {
            if (r.borc <= 0) r.borcBas = simdi
            r.borc += x.m
            bildir(server, x.u, 'Ödeyemediğin ' + Math.ceil(x.m) + ' spur borcuna yazıldı (' + x.s + '). Borca günde %' +
              Math.round(AYAR.GUNLUK_FAIZ * 100) + ' faiz işler. Detay: /borc')
          }
          if (x.s === 'cinayet') notEkle(r, -30)
        })
        server.persistentData.putString('borc_kuyruk', '[]')
      }

      // Çevrimiçi oyuncuların kaydı olsun (kredi notu birikir)
      var online = server.playerList.getPlayers().toArray()
      var onlineSet = {}
      for (var i = 0; i < online.length; i++) { var id = String(online[i].getUuid()); onlineSet[id] = true; kayit(d, id, simdi) }

      // Vergi kayıtları (askıdaki claim'ler)
      var vergi = {}
      try { var vs = server.persistentData.getString('vergi_veri'); if (vs) vergi = JSON.parse(vs).kayitlar || {} } catch (e) { vergi = {} }

      Object.keys(d.o).forEach(function (id) {
        var r = d.o[id]
        var adim = Math.min(Math.max(0, simdi - (r.son || simdi)), MAX_ADIM)
        r.son = simdi

        // Faiz
        if (r.borc > 0) {
          r.faizSay += adim
          while (r.faizSay >= GUN) { r.faizSay -= GUN; r.borc *= (1 + AYAR.GUNLUK_FAIZ) }
        }

        // Kredi taksiti
        if (r.kredi) {
          r.kredi.sayac += adim
          if (r.kredi.sayac >= GUN) {
            r.kredi.sayac -= GUN
            var t = Math.min(r.kredi.taksit, r.kredi.kalan)
            if (kes(JUUID.fromString(id), t)) {
              var h = hazine(); h.deposit(t); h.markDirty()
              hazineLog(server, 'kredi_odeme', t, ad(server, JUUID.fromString(id)))
              notEkle(r, 5)
              bildir(server, id, 'Kredi taksiti ödendi: ' + t + ' spur. Kalan: ' + (r.kredi.kalan - t) + ' spur.')
            } else {
              if (r.borc <= 0) r.borcBas = simdi
              r.borc += t
              notEkle(r, -20)
              bildir(server, id, 'Kredi taksiti (' + t + ' spur) ödenemedi, borcuna yazıldı. Kredi notun düştü.')
            }
            r.kredi.kalan -= t
            if (r.kredi.kalan <= 0) { r.kredi = null; notEkle(r, 25); bildir(server, id, 'Kredin kapandı.') }
          }
        }

        // Borç tahsili
        borcTahsil(server, id, r)

        // Kredi notu: günlük
        r.gunSay += adim
        while (r.gunSay >= GUN) {
          r.gunSay -= GUN
          if (r.borc > 0) notEkle(r, -15)
          if (vergi[id] && vergi[id].askida) notEkle(r, -10)
        }
        // Kredi notu: borçsuz oyun süresi
        if (onlineSet[id] && r.borc <= 0) {
          r.onlineDk += 1
          if (r.onlineDk >= 120) { r.onlineDk -= 120; notEkle(r, 3) }
        }
      })
      kaydet(server, d)
    } catch (err) { console.error('[Borc] hata: ' + err) }
  })

  // ----------------------------- KOMUTLAR ----------------------------
  ServerEvents.commandRegistry(function (event) {
    var Commands = event.commands
    var Arguments = event.arguments
    var yaz = function (ctx, m) { ctx.source.sendSystemMessage(Text.ofString(m)) }
    var op = function (src) { return src.hasPermission(2) }

    function ozet(ctx, server, id) {
      var d = yukle(server)
      var r = kayit(d, id, Date.now())
      var k = kademe(r.not)
      yaz(ctx, 'Kredi notu: ' + r.not + '/1000 | Çekilebilir kredi: ' + (k ? k.limit + ' spur, faiz %' + Math.round(k.faiz * 100) : 'yok (not 300 altında)'))
      yaz(ctx, 'Borç: ' + (r.borc > 0 ? Math.ceil(r.borc) + ' spur (günlük faiz %' + Math.round(AYAR.GUNLUK_FAIZ * 100) + ', ' +
        Math.floor((Date.now() - r.borcBas) / GUN) + ' gündür)' : 'yok'))
      if (r.kredi) yaz(ctx, 'Aktif kredi: kalan ' + r.kredi.kalan + ' spur, günlük taksit ' + r.kredi.taksit + ' spur')
    }

    event.register(Commands.literal('borc').executes(function (ctx) {
      var p = ctx.source.player; if (p == null) return 0
      ozet(ctx, p.server, String(p.getUuid())); return 1
    }))

    event.register(Commands.literal('kredi')
      .then(Commands.literal('durum').executes(function (ctx) {
        var p = ctx.source.player; if (p == null) return 0
        ozet(ctx, p.server, String(p.getUuid())); return 1
      }))
      .then(Commands.literal('cek').then(Commands.argument('miktar', Arguments.INTEGER.create(event)).executes(function (ctx) {
        var p = ctx.source.player; if (p == null) return 0
        var server = p.server
        var id = String(p.getUuid())
        var miktar = Arguments.INTEGER.getResult(ctx, 'miktar')
        var d = yukle(server)
        var r = kayit(d, id, Date.now())
        var k = kademe(r.not)
        if (miktar <= 0) { yaz(ctx, 'Miktar 0\'dan büyük olmalı.'); return 0 }
        if (r.borc > 0) { yaz(ctx, 'Borcun varken kredi çekemezsin.'); return 0 }
        if (r.kredi) { yaz(ctx, 'Önce mevcut kredini kapatmalısın (/kredi ode).'); return 0 }
        if (!k) { yaz(ctx, 'Kredi notun (' + r.not + ') kredi için yetersiz. En az 300 gerekli.'); return 0 }
        if (miktar > k.limit) { yaz(ctx, 'Kredi notunla en fazla ' + k.limit + ' spur çekebilirsin.'); return 0 }
        var h = hazine()
        if (h.getBalance() < miktar || !h.deduct(miktar, ReasonHolder.IGNORED)) { yaz(ctx, 'Devlet hazinesinde şu an bu kadar para yok.'); return 0 }
        h.markDirty()
        yatir(p.getUuid(), miktar)
        var toplam = Math.ceil(miktar * (1 + k.faiz))
        r.kredi = { anapara: miktar, kalan: toplam, taksit: Math.ceil(toplam / AYAR.VADE_GUN), sayac: 0 }
        hazineLog(server, 'kredi', miktar, String(p.username))
        kaydet(server, d)
        yaz(ctx, miktar + ' spur kredi bankana yatırıldı. Geri ödeme: ' + toplam + ' spur, ' + AYAR.VADE_GUN + ' gün boyunca günde ' + r.kredi.taksit + ' spur.')
        return 1
      })))
      .then(Commands.literal('ode').executes(function (ctx) {
        var p = ctx.source.player; if (p == null) return 0
        var server = p.server
        var d = yukle(server)
        var r = kayit(d, String(p.getUuid()), Date.now())
        if (!r.kredi) { yaz(ctx, 'Aktif kredin yok.'); return 0 }
        var m = r.kredi.kalan
        if (!kes(p.getUuid(), m)) { yaz(ctx, 'Bankanda ' + m + ' spur olmalı.'); return 0 }
        var h = hazine(); h.deposit(m); h.markDirty()
        hazineLog(server, 'kredi_odeme', m, String(p.username))
        r.kredi = null; notEkle(r, 25)
        kaydet(server, d)
        yaz(ctx, 'Kredin kapatıldı (' + m + ' spur). Kredi notun yükseldi: ' + r.not)
        return 1
      }))
      // OP: başka oyuncunun durumu
      .then(Commands.literal('bak').requires(op).then(Commands.argument('oyuncu', Arguments.PLAYER.create(event)).executes(function (ctx) {
        var h = Arguments.PLAYER.getResult(ctx, 'oyuncu')
        yaz(ctx, '--- ' + String(h.username))
        ozet(ctx, ctx.source.server, String(h.getUuid())); return 1
      })))
      // OP: borcu sil
      .then(Commands.literal('borcsil').requires(op).then(Commands.argument('oyuncu', Arguments.PLAYER.create(event)).executes(function (ctx) {
        var h = Arguments.PLAYER.getResult(ctx, 'oyuncu')
        var server = ctx.source.server
        var d = yukle(server)
        var r = kayit(d, String(h.getUuid()), Date.now())
        r.borc = 0; r.borcBas = 0; r.faizSay = 0
        kaydet(server, d)
        yaz(ctx, String(h.username) + ' oyuncusunun borcu silindi.'); return 1
      }))))
  })

  console.info('[Borc] yuklendi: gunluk faiz %' + Math.round(AYAR.GUNLUK_FAIZ * 100) + ', kredi vadesi ' + AYAR.VADE_GUN + ' gun')
})()
