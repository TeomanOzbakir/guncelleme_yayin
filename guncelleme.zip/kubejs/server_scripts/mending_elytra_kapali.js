// =====================================================================
//  MENDING ve ELYTRA KAPALI  -  kubejs/server_scripts/mending_elytra_kapali.js
//
//  Mending: kubejs/data/minecraft/enchantment/mending.json ile etkisi silindi
//  (deneyim tamiri yok, hiçbir eşyaya uygulanamaz). Burada da tüm büyü
//  etiketlerinden çıkarılır: köylü takası, sandık/balık ganimeti, büyü masası,
//  canavar ekipmanı hiçbir yerde çıkmaz. Tamir: Demirci mesleği (yetenek_sistemi.js)
//  ve Overgeared bileği taşı.
//
//  Elytra: süzülme her tick durdurulur (Elytra, Ignitium Elytra göğüslüğü,
//  Apothic elytra_flight dahil). Uçmak için Create Aeronautics araçları var.
// =====================================================================

ServerEvents.tags('enchantment', function (event) {
  try { event.removeAllTagsFrom('minecraft:mending') } catch (e) { console.error('[Mending] etiket hatasi: ' + e) }
})

;(function () {
  var sonUyari = {}
  PlayerEvents.tick(function (event) {
    try {
      var p = event.player
      if (!p.isFallFlying()) return
      p.stopFallFlying()
      var id = String(p.getUuid())
      var t = p.server.tickCount
      if (!sonUyari[id] || t - sonUyari[id] > 100) {
        sonUyari[id] = t
        p.setStatusMessage(Text.red(Text.ofString('Elytra ile süzülmek bu sunucuda kapalı.')))
      }
    } catch (err) { }
  })
})()
