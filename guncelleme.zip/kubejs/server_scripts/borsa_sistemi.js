// =====================================================================
//  BORSA  -  kubejs/server_scripts/borsa_sistemi.js   (2026-11-24)
//  Yarı simüle coin piyasası: fiyatı algoritma oynatır, oyuncuların alım-satımı üstüne etki eder.
//
//  Fiyat (her coin, sunucu açıkken her dakika):
//   - Rastgele dalgalanma (coin'e göre oynaklık)
//   - Trend dönemleri: yükseliş / düşüş / yatay, 2-10 saat sürer, ne zaman döneceği belli değil
//   - Haberler: ara sıra ani sıçrama veya çöküş (sohbete duyurulur)
//   - Çapaya dönüş: fiyat uzun vadede coin'in çapa değeri etrafında dolaşır (sonsuza kaçmaz)
//   - Oyuncu etkisi: alım fiyatı iter, satım düşürür; etki ~1,5 saatte söner
//   - Kılıç: aktif/hazırlıktaki savaş varken oynaklık artar ve yukarı eğilim kazanır
//   - Kasa koruması: borsa kasası, oyuncuların elindeki coin değerinin %60'ının altına düşerse
//     piyasaya gizli bir aşağı eğilim eklenir (kasa iflas etmesin)
//  Karşı taraf: BORSA KASASI (ayrı Numismatics hesabı). Alımda para kasaya girer, satımda kasadan çıkar.
//  Alış-satış farkı (%0,5) kasaya, komisyon (/vergi oran borsa, varsayılan %1) hazineye.
//  Alınan coin en az 10 dakika tutulmadan satılamaz.
//  Madencilik: sunucu_bakim Madencilik Makinesi (Create). Sunucunun günlük Dişli üretimi sabit,
//  makineler güçleri oranında paylaşır; toplam üretim her 400 Dişli'de yarılanır, en çok 800.
//
//  Komutlar: /borsa | al <coin> <spur> | sat <coin> <adet|hepsi> | portfoy | haber |
//            gonder <oyuncu> <coin> <adet> | kasa [yatir|cek <spur>] (başkan/OP) | olay <coin> <yüzde> (OP)
//  Veri: persistentData 'borsa_veri' = { c: {kod: durum}, o: {uuid: cüzdan}, h: [haber], m: madencilik, sv }
//  !! Gerçek bir oyunda ÇALIŞTIRILARAK TEST EDİLMEDİ.
// =====================================================================
;(function () {
  function ortak(ad) { try { return global.ortak ? global.ortak.get(ad) : null } catch (e) { return null } }
  var COIN = {
    dsl: { ad: 'Dişli', ilk: 100, vol: 0.004, rejim: 0.0015, haber: 1 / 720, hMin: 0.03, hMax: 0.07, derinlik: 60000, donus: 1 / (60 * 24), capaArtis: 0.0002 },
    ptr: { ad: 'Petro', ilk: 50, vol: 0.012, rejim: 0.004, haber: 1 / 360, hMin: 0.05, hMax: 0.15, derinlik: 30000, donus: 1 / (60 * 36), capaArtis: 0 },
    klc: { ad: 'Kılıç', ilk: 75, vol: 0.01, rejim: 0.004, haber: 1 / 400, hMin: 0.05, hMax: 0.15, derinlik: 30000, donus: 1 / (60 * 36), capaArtis: 0, savas: true },
    uck: { ad: 'Uçuk', ilk: 1, vol: 0.04, rejim: 0.015, haber: 1 / 150, hMin: 0.15, hMax: 0.5, derinlik: 8000, donus: 1 / (60 * 12), capaArtis: 0, cilgin: true }
  }
  var SIRA = ['dsl', 'ptr', 'klc', 'uck']
  var AYAR = {
    SPREAD: 0.005,          // alış fiyatı +%0,5, satış fiyatı -%0,5 (fark kasaya)
    MIN_ISLEM: 10,          // en az alım (spur)
    MIN_TUTMA_DK: 10,
    ETKI: 0.5,              // derinlik kadar alım fiyatı ~%65 iter (log 0,5)
    ETKI_SONUM_DK: 90,
    ETKI_MAX: 0.5,
    GRAFIK_ARALIK_DK: 5,    // grafik noktası aralığı
    GRAFIK_NOKTA: 288,      // 24 saatlik (açık sunucu) geçmiş
    KASA_HEDEF: 0.6,
    MADEN_GUNLUK: 12,       // açık sunucu günü başına toplam Dişli üretimi
    MADEN_YARILANMA: 400,
    MADEN_MAX: 800,
    HABER_MAX: 30
  }
  var HABER = {
    dsl: { y: ['Büyük bir banka Dişli rezervini artırdı', 'Madenciler Dişli satışını durdurdu', 'Dişli güvenli liman olarak görülüyor'],
           a: ['Büyük bir cüzdan Dişli boşalttı', 'Madencilikte zorluk korkusu', 'Dişli ağında kısa süreli kesinti'] },
    ptr: { y: ['Rafineri kapasitesi rekor kırdı', 'Petrol talebi patladı', 'Yeni petrol yatakları sanayiyi coşturdu'],
           a: ['Rafineride yangın çıktı', 'Boru hattı patladı', 'Sanayi siparişleri düştü'] },
    klc: { y: ['Sınırda gerginlik artıyor', 'Silah siparişleri arttı', 'Paralı askerler Kılıç ile ödeme istiyor'],
           a: ['Barış görüşmeleri umut veriyor', 'Silah stokları eridi', 'Ateşkes söylentisi'] },
    uck: { y: ['Ünlü bir oyuncu Uçuk aldığını açıkladı', 'Uçuk topluluğu "aya gidiyoruz" diyor', 'Uçuk yeni bir ortaklık duyurdu'],
           a: ['Uçuk geliştiricisi ortadan kayboldu', 'Büyük Uçuk satışı paniği', 'Uçuk\'un şaka olduğu söylentisi'] }
  }

  var JUUID = Java.loadClass('java.util.UUID')
  var Numismatics = Java.loadClass('dev.ithundxr.createnumismatics.Numismatics')
  var ReasonHolder = Java.loadClass('dev.ithundxr.createnumismatics.content.backend.ReasonHolder')
  var BankType = Java.loadClass('dev.ithundxr.createnumismatics.content.backend.BankAccount$Type')
  var HAZINE_UUID = '5f0c2d1e-7a3b-4e9c-8d6f-1b2a3c4d5e6f'
  var KASA_UUID = '7d3c1f2a-9b4e-4c6d-a1f0-2e8b5c9d0a13'
  var Madencilik = null
  try { Madencilik = Java.loadClass('tr.sunucu.bakim.Madencilik') } catch (e) { console.warn('[Borsa] sunucu_bakim Madencilik yok, madencilik kapali: ' + e) }

  // ----------------------------- VERİ -----------------------------------
  function yukle(server) {
    var d = null
    try { var s = server.persistentData.getString('borsa_veri'); if (s) d = JSON.parse(s) } catch (e) { d = null }
    if (!d) d = {}
    if (!d.c) d.c = {}
    if (!d.o) d.o = {}
    if (!d.h) d.h = []
    if (!d.m) d.m = { top: 0, k: {}, son: { n: 0, is: 0 } }
    for (var i = 0; i < SIRA.length; i++) {
      var k = SIRA[i]
      if (!d.c[k]) d.c[k] = { v: COIN[k].ilk, i: 0, r: 0, rk: 0, capa: COIN[k].ilk, g: [COIN[k].ilk], s: 0 }
    }
    return d
  }
  function kaydet(server, d) {
    server.persistentData.putString('borsa_veri', JSON.stringify(d))
    try { ozetYaz(server, d) } catch (e) { console.warn('[Borsa] ozet: ' + e) }
  }
  // Borsa ekranı (sunucu_piyasa BorsaEkrani) için oyuncuya gidecek özet: 'borsa_ozet'.
  // Cüzdanı Java tarafı 'borsa_veri'den sadece o oyuncu için ekler.
  var ACIKLAMA = { dsl: 'Sakin, uzun vadede hafif yükselir. Madencilikle çıkar.', ptr: 'Sanayi coin\'i, orta oynaklık.',
    klc: 'Savaş coin\'i: savaş varken hareketlenir.', uck: 'Çok oynak. Bir günde ikiye katlanabilir veya çökebilir.' }
  function ozetYaz(server, d) {
    var c = []
    for (var i = 0; i < SIRA.length; i++) {
      var k = SIRA[i], x = d.c[k]
      c.push({ k: k, ad: COIN[k].ad, p: fiyat(x), d24: degisim24(x), g: x.g || [], a: ACIKLAMA[k] })
    }
    var ks = 0
    try { ks = kasa().getBalance() } catch (e) { ks = 0 }
    var o = { c: c, h: d.h.slice(-12), kasa: ks, top: toplamDeger(d), kom: komisyonOrani(server), spread: AYAR.SPREAD,
      tutma: AYAR.MIN_TUTMA_DK, min: AYAR.MIN_ISLEM, aralik: AYAR.GRAFIK_ARALIK_DK, t: Date.now(),
      m: { n: d.m.son ? d.m.son.n : 0, top: d.m.top, max: AYAR.MADEN_MAX, uretim: AYAR.MADEN_GUNLUK * Math.pow(0.5, Math.floor(d.m.top / AYAR.MADEN_YARILANMA)) } }
    server.persistentData.putString('borsa_ozet', JSON.stringify(o))
  }
  function fiyat(c) { return c.v * Math.exp(c.i) }
  function cuzdan(d, id) { return d.o[id] || (d.o[id] = {}) }
  function varlik(w, k) { return w[k] || (w[k] = { n: 0, m: 0, t: 0 }) }

  function kodOku(s) {
    var t = String(s || '').toLowerCase().trim()
      .replace(/ş/g, 's').replace(/ı/g, 'i').replace(/ç/g, 'c').replace(/ü/g, 'u').replace(/ö/g, 'o').replace(/ğ/g, 'g')
    if (COIN[t]) return t
    var adlar = { disli: 'dsl', petro: 'ptr', kilic: 'klc', ucuk: 'uck' }
    return adlar[t] || null
  }
  function sayiOku(s) { var n = parseFloat(String(s).trim().replace(',', '.')); return isFinite(n) ? n : NaN }

  // ----------------------------- BİÇİM ----------------------------------
  function ondalik(n, b) {
    var s = Math.abs(n).toFixed(b).split('.')
    var tam = s[0].replace(/\B(?=(\d{3})+(?!\d))/g, '.')
    return (n < 0 ? '-' : '') + tam + (b > 0 ? ',' + s[1] : '')
  }
  function fiyatYaz(p) { return ondalik(p, p < 1 ? 4 : 2) }
  function adetYaz(n) { return ondalik(n, n < 10 ? 4 : 2) }
  function para(n) { return ondalik(Math.floor(n), 0) + ' spur' }
  function yuzde(x) { return (x >= 0 ? '+' : '') + ondalik(x * 100, 1) + '%' }
  var BLOK = ['▁', '▂', '▃', '▄', '▅', '▆', '▇', '█']
  function grafik(g, uzunluk) {
    if (!g || g.length < 2) return ''
    var adim = Math.max(1, Math.floor(g.length / uzunluk))
    var n = []
    for (var i = g.length - 1; i >= 0 && n.length < uzunluk; i -= adim) n.unshift(g[i])
    var lo = Math.min.apply(null, n), hi = Math.max.apply(null, n)
    var s = ''
    for (var j = 0; j < n.length; j++) s += BLOK[hi > lo ? Math.min(7, Math.floor((n[j] - lo) / (hi - lo) * 7.999)) : 3]
    return s
  }
  function degisim24(c) { var g = c.g || []; var ilk = g.length ? g[0] : c.v; return ilk > 0 ? fiyat(c) / ilk - 1 : 0 }

  // ----------------------------- PARA -----------------------------------
  function hesap(uuidStr, tip) { return Numismatics.BANK.getOrCreateAccount(JUUID.fromString(uuidStr), tip) }
  function kasa() {
    var h = hesap(KASA_UUID, BankType.BLAZE_BANKER)
    if (String(h.getLabel()) !== 'Borsa Kasası') { h.setLabel('Borsa Kasası'); h.markDirty() }
    return h
  }
  function hazine() { return hesap(HAZINE_UUID, BankType.BLAZE_BANKER) }
  function oyuncuHesap(uuid) { return Numismatics.BANK.getOrCreateAccount(uuid, BankType.PLAYER) }
  function hazineKaydi(server, tur, m, kim, gelir) {
    var d = null
    try { var s = server.persistentData.getString('hazine_veri'); if (s) d = JSON.parse(s) } catch (e) { d = null }
    if (!d) d = {}
    if (!d.gelir) d.gelir = {}
    if (!d.hareket) d.hareket = []
    if (gelir) d.gelir[tur] = (d.gelir[tur] || 0) + m
    d.hareket = d.hareket.concat([{ t: Date.now(), tur: tur, m: m, k: kim }]).slice(-500)
    server.persistentData.putString('hazine_veri', JSON.stringify(d))
  }
  function komisyonOrani(server) {
    try { if (ortak('vergiOrani')) return Math.max(0, Math.min(0.1, Number(ortak('vergiOrani')(server, 'borsa')) / 100)) } catch (e) { }
    return 0.01
  }
  function toplamDeger(d) {
    var t = 0
    Object.keys(d.o).forEach(function (id) {
      var w = d.o[id]
      for (var i = 0; i < SIRA.length; i++) if (w[SIRA[i]]) t += w[SIRA[i]].n * fiyat(d.c[SIRA[i]])
    })
    return t
  }
  function duyur(server, metin) { server.tell(Text.gold(Text.ofString('[Borsa] ' + metin))) }

  // ----------------------------- FİYAT MOTORU ---------------------------
  function gauss() { var u = 1 - Math.random(), v = Math.random(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v) }
  function sec(liste) { return liste[Math.floor(Math.random() * liste.length)] }
  function haberEkle(server, d, k, metin, oran) {
    d.h = d.h.concat([{ t: Date.now(), c: k, m: metin, y: oran }]).slice(-AYAR.HABER_MAX)
    duyur(server, COIN[k].ad + ': ' + metin + ' (' + yuzde(oran) + ')')
  }
  function savasSayisi(server) {
    try {
      var s = JSON.parse(server.persistentData.getString('savas_veri') || '{}')
      return (s.savaslar || []).filter(function (x) { return x.durum === 'aktif' || x.durum === 'hazirlik' }).length
    } catch (e) { return 0 }
  }
  function dakika(server) {
    var d = yukle(server)
    var savas = savasSayisi(server)
    var savasBasladi = savas > (d.sv || 0)
    d.sv = savas
    // kasa koruması
    var top = toplamDeger(d)
    var koruma = 0
    if (top > 0) {
      var R = kasa().getBalance() / top
      if (R < AYAR.KASA_HEDEF) koruma = -0.01 / 60 * Math.min(1, (AYAR.KASA_HEDEF - R) / AYAR.KASA_HEDEF)
    }
    for (var i = 0; i < SIRA.length; i++) {
      var k = SIRA[i], o = COIN[k], c = d.c[k]
      c.rk = (c.rk || 0) - 1
      if (c.rk <= 0) { var z = Math.random(); c.r = z < 0.35 ? 1 : z < 0.7 ? -1 : 0; c.rk = 120 + Math.floor(Math.random() * 480) }
      var vol = o.vol, egilim = o.rejim * c.r / 60 + koruma
      if (o.savas && savas > 0) { vol *= 2.5; egilim += 0.006 / 60 }
      c.capa = c.capa * (1 + o.capaArtis / 60)
      var lv = Math.log(c.v)
      lv += o.donus * (Math.log(c.capa) - lv) + egilim + vol / Math.sqrt(60) * gauss()
      // haberler
      var olay = 0
      if (o.savas && savasBasladi) { olay = 0.08 + Math.random() * 0.07; haberEkle(server, d, k, 'Savaş ilan edildi! Kılıç talebi fırladı', olay) }
      else if (o.cilgin && Math.random() < 1 / 6000) { olay = -0.6; haberEkle(server, d, k, 'Uçuk çöktü! Büyük cüzdanlar kaçtı', olay) }
      else if (o.cilgin && Math.random() < 1 / 6000) { olay = 1.5; haberEkle(server, d, k, 'Uçuk aya gitti!', olay) }
      else if (Math.random() < o.haber) {
        var yukari = Math.random() < 0.5
        olay = (o.hMin + Math.random() * (o.hMax - o.hMin)) * (yukari ? 1 : -1)
        haberEkle(server, d, k, sec(HABER[k][yukari ? 'y' : 'a']), olay)
      }
      if (olay !== 0) lv += Math.log(1 + olay)
      c.v = Math.max(o.ilk * 0.05, Math.min(o.ilk * 20, Math.exp(lv)))
      c.i = (c.i || 0) * Math.exp(-1 / AYAR.ETKI_SONUM_DK)
      c.s = (c.s || 0) + 1
      if (c.s % AYAR.GRAFIK_ARALIK_DK === 0) c.g = (c.g || []).concat([Math.round(fiyat(c) * 10000) / 10000]).slice(-AYAR.GRAFIK_NOKTA)
    }
    madencilik(server, d)
    kaydet(server, d)
  }
  function madencilik(server, d) {
    if (Madencilik == null) return
    var j = null
    try { j = JSON.parse(String(Madencilik.topla())) } catch (e) { console.warn('[Borsa] madencilik: ' + e); return }
    var isler = j.o || {}, ids = Object.keys(isler), toplamIs = 0
    ids.forEach(function (id) { toplamIs += Number(isler[id]) || 0 })
    d.m.son = { n: j.n || 0, is: toplamIs }
    if (toplamIs <= 0 || d.m.top >= AYAR.MADEN_MAX) return
    var uretim = AYAR.MADEN_GUNLUK / 1440 * Math.pow(0.5, Math.floor(d.m.top / AYAR.MADEN_YARILANMA))
    uretim = Math.min(uretim, AYAR.MADEN_MAX - d.m.top)
    ids.forEach(function (id) {
      var pay = uretim * (Number(isler[id]) || 0) / toplamIs
      if (pay <= 0) return
      varlik(cuzdan(d, id), 'dsl').n += pay
      d.m.k[id] = (d.m.k[id] || 0) + pay
      d.m.top += pay
    })
  }

  ServerEvents.tick(function (event) {
    if (event.server.tickCount % 1200 !== 610) return
    try { dakika(event.server) } catch (err) { console.error('[Borsa] dakika: ' + err) }
  })

  // ----------------------------- İŞLEMLER -------------------------------
  function al(p, k, spur) {
    var server = p.server, d = yukle(server), c = d.c[k]
    if (spur < AYAR.MIN_ISLEM) { p.tell(Text.red(Text.ofString('En az ' + AYAR.MIN_ISLEM + ' spur\'luk alım yapılabilir.'))); return 0 }
    var h = oyuncuHesap(p.getUuid())
    if (h.getBalance() < spur || !h.deduct(spur, ReasonHolder.IGNORED)) { p.tell(Text.red(Text.ofString('Bankanda ' + para(spur) + ' yok.'))); return 0 }
    h.markDirty()
    var kom = Math.floor(spur * komisyonOrani(server))
    var net = spur - kom
    var birim = fiyat(c) * (1 + AYAR.SPREAD)
    var adet = net / birim
    var ks = kasa(); ks.deposit(net); ks.markDirty()
    if (kom > 0) { var hz = hazine(); hz.deposit(kom); hz.markDirty(); hazineKaydi(server, 'borsa', kom, String(p.username) + ' (' + COIN[k].ad + ' alım)', true) }
    var v = varlik(cuzdan(d, String(p.getUuid())), k)
    v.n += adet; v.m += spur; v.t = Date.now()
    c.i = Math.max(-AYAR.ETKI_MAX, Math.min(AYAR.ETKI_MAX, (c.i || 0) + AYAR.ETKI * net / COIN[k].derinlik))
    kaydet(server, d)
    p.tell(Text.green(Text.ofString(adetYaz(adet) + ' ' + COIN[k].ad + ' aldın (birim ' + fiyatYaz(birim) + ', ödenen ' + para(spur) + (kom > 0 ? ', komisyon ' + kom : '') +
      '). En erken ' + AYAR.MIN_TUTMA_DK + ' dakika sonra satabilirsin.')))
    return 1
  }
  function sat(p, k, miktar) {
    var server = p.server, d = yukle(server), c = d.c[k]
    var w = cuzdan(d, String(p.getUuid())), v = w[k]
    if (!v || v.n <= 0) { p.tell(Text.red(Text.ofString('Hiç ' + COIN[k].ad + ' yok.'))); return 0 }
    var adet = String(miktar).toLowerCase() === 'hepsi' ? v.n : sayiOku(miktar)
    if (!(adet > 0)) { p.tell(Text.red(Text.ofString('Geçersiz miktar. Örnek: /borsa sat ' + k + ' 1.5  veya  hepsi'))); return 0 }
    if (adet > v.n + 1e-9) { p.tell(Text.red(Text.ofString('Elinde ' + adetYaz(v.n) + ' ' + COIN[k].ad + ' var.'))); return 0 }
    adet = Math.min(adet, v.n)
    var bekle = v.t + AYAR.MIN_TUTMA_DK * 60000 - Date.now()
    if (bekle > 0) { p.tell(Text.red(Text.ofString('Son alımından sonra ' + Math.ceil(bekle / 60000) + ' dakika daha beklemelisin.'))); return 0 }
    var birim = fiyat(c) * (1 - AYAR.SPREAD)
    var brut = Math.floor(adet * birim)
    if (brut < 1) { p.tell(Text.red(Text.ofString('Bu miktar 1 spur bile etmiyor.'))); return 0 }
    var ks = kasa()
    if (ks.getBalance() < brut || !ks.deduct(brut, ReasonHolder.IGNORED)) {
      p.tell(Text.red(Text.ofString('Borsa kasasında yeterli para yok (' + para(ks.getBalance()) + '). Başkana haber ver: /borsa kasa')))
      return 0
    }
    ks.markDirty()
    var kom = Math.floor(brut * komisyonOrani(server))
    var net = brut - kom
    var h = oyuncuHesap(p.getUuid()); h.deposit(net); h.markDirty()
    if (kom > 0) { var hz = hazine(); hz.deposit(kom); hz.markDirty(); hazineKaydi(server, 'borsa', kom, String(p.username) + ' (' + COIN[k].ad + ' satım)', true) }
    var maliyet = v.n > 0 ? v.m * adet / v.n : 0
    v.m = Math.max(0, v.m - maliyet); v.n -= adet
    if (v.n < 1e-6) delete w[k]
    c.i = Math.max(-AYAR.ETKI_MAX, Math.min(AYAR.ETKI_MAX, (c.i || 0) - AYAR.ETKI * brut / COIN[k].derinlik))
    kaydet(server, d)
    var kar = net - maliyet
    var satMesaj = Text.ofString(adetYaz(adet) + ' ' + COIN[k].ad + ' sattın: bankana ' + para(net) + (kom > 0 ? ' (komisyon ' + kom + ')' : '') +
      ' · bu satışta ' + (kar >= 0 ? 'kâr ' : 'zarar ') + para(Math.abs(kar)))
    p.tell(kar >= 0 ? Text.green(satMesaj) : Text.yellow(satMesaj))
    return 1
  }

  // ----------------------------- GÖSTERİM -------------------------------
  function piyasaYaz(src, d) {
    src.sendSystemMessage(Text.gold(Text.ofString('=== Borsa === (alış +%' + ondalik(AYAR.SPREAD * 100, 1) + ', satış -%' + ondalik(AYAR.SPREAD * 100, 1) + ', komisyon %' + ondalik(komisyonOrani(src.server) * 100, 1) + ')')))
    for (var i = 0; i < SIRA.length; i++) {
      var k = SIRA[i], c = d.c[k]
      src.sendSystemMessage(Text.ofString(' ' + k.toUpperCase() + ' ' + COIN[k].ad + ': ' + fiyatYaz(fiyat(c)) + ' spur  ' + yuzde(degisim24(c)) + '  ' + grafik(c.g, 16)))
    }
  }
  function portfoyYaz(p, d) {
    var w = d.o[String(p.getUuid())] || {}
    var top = 0, mal = 0, var_ = false
    p.tell(Text.gold(Text.ofString('=== Portföyün ===')))
    for (var i = 0; i < SIRA.length; i++) {
      var k = SIRA[i], v = w[k]
      if (!v || v.n <= 0) continue
      var_ = true
      var deger = v.n * fiyat(d.c[k]) * (1 - AYAR.SPREAD)
      top += deger; mal += v.m
      p.tell(Text.ofString(' ' + COIN[k].ad + ': ' + adetYaz(v.n) + ' adet · değer ' + para(deger) + ' · maliyet ' + para(v.m) + ' · ' + (v.m > 0 ? yuzde(deger / v.m - 1) : 'madencilik')))
    }
    if (!var_) { p.tell(Text.ofString(' Hiç coin\'in yok. Alım: /borsa al <coin> <spur>  (coin: dsl, ptr, klc, uck)')); return }
    p.tell(Text.ofString(' Toplam: ' + para(top) + ' · ' + (top - mal >= 0 ? 'kâr ' : 'zarar ') + para(Math.abs(top - mal))))
    var maden = d.m.k[String(p.getUuid())]
    if (maden > 0) p.tell(Text.gray(Text.ofString(' Madencilikten kazandığın toplam: ' + adetYaz(maden) + ' Dişli')))
  }
  function yetkili(src) { var p = src.player; if (src.hasPermission(2)) return true; var b = src.server.persistentData.getString('baskan'); return p != null && !!b && b === String(p.getUuid()) }

  // ----------------------------- KOMUTLAR -------------------------------
  ServerEvents.commandRegistry(function (event) {
    var Commands = event.commands
    var Arguments = event.arguments
    function coin(ctx) { return kodOku(Arguments.WORD.getResult(ctx, 'coin')) }
    function coinYok(ctx) { ctx.source.sendSystemMessage(Text.red(Text.ofString('Coin: dsl (Dişli), ptr (Petro), klc (Kılıç), uck (Uçuk)'))); return 0 }
    function oyuncu(ctx) { var p = ctx.source.player; if (p == null) ctx.source.sendSystemMessage(Text.ofString('Oyun içinden kullanın.')); return p }

    event.register(Commands.literal('borsa')
      .executes(function (ctx) {
        var d = yukle(ctx.source.server)
        piyasaYaz(ctx.source, d)
        ctx.source.sendSystemMessage(Text.gray(Text.ofString('Ekran: /borsaekran (menü > Borsa) · /borsa al <coin> <spur> · sat <coin> <adet|hepsi> · portfoy · haber')))
        return 1
      })
      .then(Commands.literal('al')
        .then(Commands.argument('coin', Arguments.WORD.create(event))
          .then(Commands.argument('spur', Arguments.INTEGER.create(event)).executes(function (ctx) {
            var p = oyuncu(ctx); if (p == null) return 0
            var k = coin(ctx); if (!k) return coinYok(ctx)
            return al(p, k, Arguments.INTEGER.getResult(ctx, 'spur'))
          }))))
      .then(Commands.literal('sat')
        .then(Commands.argument('coin', Arguments.WORD.create(event))
          .then(Commands.argument('miktar', Arguments.GREEDY_STRING.create(event)).executes(function (ctx) {
            var p = oyuncu(ctx); if (p == null) return 0
            var k = coin(ctx); if (!k) return coinYok(ctx)
            return sat(p, k, String(Arguments.GREEDY_STRING.getResult(ctx, 'miktar')))
          }))))
      .then(Commands.literal('portfoy').executes(function (ctx) {
        var p = oyuncu(ctx); if (p == null) return 0
        portfoyYaz(p, yukle(p.server)); return 1
      }))
      .then(Commands.literal('haber').executes(function (ctx) {
        var d = yukle(ctx.source.server)
        ctx.source.sendSystemMessage(Text.gold(Text.ofString('=== Borsa haberleri ===')))
        if (!d.h.length) ctx.source.sendSystemMessage(Text.ofString('Henüz haber yok.'))
        d.h.slice(-10).reverse().forEach(function (x) {
          var dk = Math.floor((Date.now() - x.t) / 60000)
          ctx.source.sendSystemMessage(Text.ofString(' ' + COIN[x.c].ad + ': ' + x.m + ' (' + yuzde(x.y) + ') · ' + (dk < 60 ? dk + ' dk' : Math.floor(dk / 60) + ' sa') + ' önce'))
        })
        return 1
      }))
      .then(Commands.literal('gonder')
        .then(Commands.argument('oyuncu', Arguments.PLAYER.create(event))
          .then(Commands.argument('coin', Arguments.WORD.create(event))
            .then(Commands.argument('miktar', Arguments.GREEDY_STRING.create(event)).executes(function (ctx) {
              var p = oyuncu(ctx); if (p == null) return 0
              var k = coin(ctx); if (!k) return coinYok(ctx)
              var hedef = Arguments.PLAYER.getResult(ctx, 'oyuncu')
              if (hedef.getUuid().equals(p.getUuid())) { p.tell(Text.red(Text.ofString('Kendine gönderemezsin.'))); return 0 }
              var d = yukle(p.server), w = cuzdan(d, String(p.getUuid())), v = w[k]
              var ms = String(Arguments.GREEDY_STRING.getResult(ctx, 'miktar'))
              var adet = v && ms.toLowerCase() === 'hepsi' ? v.n : sayiOku(ms)
              if (!v || !(adet > 0) || adet > v.n + 1e-9) { p.tell(Text.red(Text.ofString('Yeterli ' + COIN[k].ad + ' yok.'))); return 0 }
              adet = Math.min(adet, v.n)
              var maliyet = v.m * adet / v.n
              var hv = varlik(cuzdan(d, String(hedef.getUuid())), k)
              hv.n += adet; hv.m += maliyet; hv.t = Math.max(hv.t || 0, v.t || 0)
              v.n -= adet; v.m = Math.max(0, v.m - maliyet)
              if (v.n < 1e-6) delete w[k]
              kaydet(p.server, d)
              p.tell(Text.green(Text.ofString(hedef.getName().getString() + ' oyuncusuna ' + adetYaz(adet) + ' ' + COIN[k].ad + ' gönderdin.')))
              hedef.tell(Text.green(Text.ofString(String(p.username) + ' sana ' + adetYaz(adet) + ' ' + COIN[k].ad + ' gönderdi (/borsa portfoy).')))
              return 1
            })))))
      .then(Commands.literal('kasa')
        .executes(function (ctx) {
          var d = yukle(ctx.source.server)
          var k = kasa().getBalance(), t = toplamDeger(d)
          ctx.source.sendSystemMessage(Text.ofString('Borsa kasası: ' + para(k) + ' · oyuncuların coin değeri: ' + para(t) + ' · karşılama ' + (t > 0 ? Math.round(k / t * 100) + '%' : '-')))
          ctx.source.sendSystemMessage(Text.gray(Text.ofString('Başkan: /borsa kasa yatir <spur> (hazineden) · /borsa kasa cek <spur> (karşılama %100 üstündeyse)')))
          return 1
        })
        .then(Commands.literal('yatir').then(Commands.argument('spur', Arguments.INTEGER.create(event)).executes(function (ctx) {
          if (!yetkili(ctx.source)) { ctx.source.sendSystemMessage(Text.red(Text.ofString('Sadece başkan.'))); return 0 }
          var m = Arguments.INTEGER.getResult(ctx, 'spur'), hz = hazine()
          if (m <= 0 || hz.getBalance() < m || !hz.deduct(m, ReasonHolder.IGNORED)) { ctx.source.sendSystemMessage(Text.red(Text.ofString('Hazinede ' + para(m) + ' yok.'))); return 0 }
          hz.markDirty(); var ks = kasa(); ks.deposit(m); ks.markDirty()
          var kim = ctx.source.player != null ? String(ctx.source.player.username) : 'Yönetim'
          hazineKaydi(ctx.source.server, 'borsa_kasa', m, kim, false)
          duyur(ctx.source.server, kim + ' hazineden borsa kasasına ' + para(m) + ' aktardı.')
          return 1
        })))
        .then(Commands.literal('cek').then(Commands.argument('spur', Arguments.INTEGER.create(event)).executes(function (ctx) {
          if (!yetkili(ctx.source)) { ctx.source.sendSystemMessage(Text.red(Text.ofString('Sadece başkan.'))); return 0 }
          var d = yukle(ctx.source.server)
          var m = Arguments.INTEGER.getResult(ctx, 'spur'), ks = kasa()
          var serbest = Math.floor(ks.getBalance() - toplamDeger(d))
          if (m <= 0 || m > serbest) { ctx.source.sendSystemMessage(Text.red(Text.ofString('Çekilebilir: ' + para(Math.max(0, serbest)) + ' (kasa, oyuncuların coin değerini karşılamalı).'))); return 0 }
          if (!ks.deduct(m, ReasonHolder.IGNORED)) return 0
          ks.markDirty(); var hz = hazine(); hz.deposit(m); hz.markDirty()
          var kim = ctx.source.player != null ? String(ctx.source.player.username) : 'Yönetim'
          hazineKaydi(ctx.source.server, 'borsa_kasa_iade', m, kim, true)
          duyur(ctx.source.server, kim + ' borsa kasasından hazineye ' + para(m) + ' aktardı.')
          return 1
        }))))
      .then(Commands.literal('olay').requires(function (s) { return s.hasPermission(2) })
        .then(Commands.argument('coin', Arguments.WORD.create(event))
          .then(Commands.argument('yuzde', Arguments.INTEGER.create(event)).executes(function (ctx) {
            var k = coin(ctx); if (!k) return coinYok(ctx)
            var y = Math.max(-90, Math.min(500, Arguments.INTEGER.getResult(ctx, 'yuzde'))) / 100
            var d = yukle(ctx.source.server), c = d.c[k]
            c.v = Math.max(COIN[k].ilk * 0.05, Math.min(COIN[k].ilk * 20, c.v * (1 + y)))
            haberEkle(ctx.source.server, d, k, 'Piyasa olayı', y)
            kaydet(ctx.source.server, d)
            return 1
          })))))
  })

  // Menü (startup_scripts/arayuz.js) için yardımcılar
  if (global.ortak) global.ortak.put('borsaOzet', borsaOzetFn)
  function borsaOzetFn(server) {
    var d = yukle(server)
    return { d: d, kasa: kasa().getBalance(), top: toplamDeger(d), coin: COIN, sira: SIRA, spread: AYAR.SPREAD,
      fiyat: fiyat, fiyatYaz: fiyatYaz, adetYaz: adetYaz, yuzde: yuzde, grafik: grafik, degisim24: degisim24,
      uretim: AYAR.MADEN_GUNLUK * Math.pow(0.5, Math.floor(d.m.top / AYAR.MADEN_YARILANMA)) }
  }

  console.info('[Borsa] yuklendi: ' + SIRA.length + ' coin, kasa ' + KASA_UUID)
})()
