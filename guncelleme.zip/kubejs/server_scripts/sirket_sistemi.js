// =====================================================================
//  ŞİRKETLER VE HİSSELER  -  kubejs/server_scripts/sirket_sistemi.js
//  2026-11-28 (kullanıcı: "şirket kurma, hisse alma/satma"). Bankalarla aynı yapı:
//   - Kurmak: lisans (/vergi oran sirket, hazineye). Şirketin kendi Numismatics hesabı (kasası) ve kartı olur.
//     Kurucu ilk 1000 hissenin tamamına sahiptir. Kurucu = yönetici; ek yönetici atanabilir (kart + yönetim).
//   - Hisse ilanı: hissedar hissesini adet + birim fiyatla satışa çıkarır (hisseler ilanda kilitlenir, iptalde döner).
//   - İhraç: şirket YENİ hisse satar; para şirketin kasasına girer, toplam hisse artar (sermaye artırımı).
//   - Alım: ilandan istenen adet alınır; alıcıdan fiyat + borsa komisyonu (/vergi oran borsa, hazineye) kesilir.
//   - Fiyat: son işlem fiyatı. Piyasa değeri = fiyat x toplam hisse. Son 30 işlem herkese açık.
//   - Temettü: yönetici kasadan dağıtır, hisse oranına göre (küsurat kasada kalır).
//   - Kapatma: kurucunun hissesi %50'den fazlaysa; kasadaki para hisse oranına göre herkese dağıtılır.
//  Veri: persistentData 'sirket_veri' = { s: {anahtar: şirket}, ilan: {id: ilan}, n: sayaç }
//  Komutlar: /sirket kur|al|sat|iptal|ihrac|temettu|yonetici|kart|kapat  (OP: dondur|coz)
//  !! Gerçek bir oyunda ÇALIŞTIRILARAK TEST EDİLMEDİ.
// =====================================================================
;(function () {
  function ortak(ad) { try { return global.ortak ? global.ortak.get(ad) : null } catch (e) { return null } }
  var AYAR = { ILK_HISSE: 1000, ILAN_MAX: 10, ISLEM_MAX: 30, TEMETTU_MAX: 20, KART: 'numismatics:blue_card' }
  var HAZINE_UUID = '5f0c2d1e-7a3b-4e9c-8d6f-1b2a3c4d5e6f'
  var JUUID = Java.loadClass('java.util.UUID')
  var Numismatics = Java.loadClass('dev.ithundxr.createnumismatics.Numismatics')
  var ReasonHolder = Java.loadClass('dev.ithundxr.createnumismatics.content.backend.ReasonHolder')
  var BankType = Java.loadClass('dev.ithundxr.createnumismatics.content.backend.BankAccount$Type')
  var CardItem = Java.loadClass('dev.ithundxr.createnumismatics.content.bank.CardItem')

  // ----------------------------- VERİ -----------------------------------
  function yukle(server) {
    var d = null
    try { d = JSON.parse(server.persistentData.getString('sirket_veri') || '{}') } catch (e) { d = null }
    if (!d || !d.s) d = { s: {}, ilan: {}, n: 0 }
    if (!d.ilan) d.ilan = {}
    return d
  }
  function kaydet(server, d) { server.persistentData.putString('sirket_veri', JSON.stringify(d)) }
  function anahtar(ad) { return String(ad).toLowerCase() }
  function para(n) { return String(Math.floor(n)).replace(/\B(?=(\d{3})+(?!\d))/g, '.') + ' spur' }
  function hesap(s) { return Numismatics.BANK.getOrCreateAccount(JUUID.fromString(s.hesap), BankType.BLAZE_BANKER) }
  function oyuncuHesap(uuid) { return Numismatics.BANK.getOrCreateAccount(typeof uuid === 'string' ? JUUID.fromString(uuid) : uuid, BankType.PLAYER) }
  function kasa(s) { try { return hesap(s).getBalance() } catch (e) { return 0 } }
  function yetkili(s, id) { return s.sahip === id || (s.yonetici || []).indexOf(id) >= 0 }
  function sahipSirketi(d, id) { var k = Object.keys(d.s).filter(function (x) { return yetkili(d.s[x], id) })[0]; return k ? d.s[k] : null }
  function oran(server, ad, vars) { try { return ortak('vergiOrani') ? Number(ortak('vergiOrani')(server, ad)) : vars } catch (e) { return vars } }
  function hazineyeYatir(server, m, tur, kim) {
    if (!(m > 0)) return
    var h = Numismatics.BANK.getOrCreateAccount(JUUID.fromString(HAZINE_UUID), BankType.BLAZE_BANKER)
    h.deposit(m); h.markDirty()
    var d = null
    try { d = JSON.parse(server.persistentData.getString('hazine_veri') || '{}') } catch (e) { d = {} }
    if (!d) d = {}
    if (!d.gelir) d.gelir = {}
    if (!d.hareket) d.hareket = []
    d.gelir[tur] = (d.gelir[tur] || 0) + m
    d.hareket = d.hareket.concat([{ t: Date.now(), tur: tur, m: m, k: kim }]).slice(-500)
    server.persistentData.putString('hazine_veri', JSON.stringify(d))
  }
  function bildir(server, id, m) { try { var o = server.playerList.getPlayer(JUUID.fromString(id)); if (o != null) o.tell(Text.ofString(m)) } catch (e) { } }
  function profil(server, isim) {
    var o = server.playerList.getPlayerByName(isim)
    if (o != null) return { id: String(o.getUuid()), ad: String(o.username) }
    var p = server.getProfileCache().get(isim)
    return p.isPresent() ? { id: String(p.get().getId()), ad: String(p.get().getName()) } : null
  }
  function ilandaki(d, s, id) { var n = 0; Object.keys(d.ilan).forEach(function (k) { var x = d.ilan[k]; if (x.s === s && x.satan === id) n += x.adet }); return n }
  // Menü (arayuz_komut.js) için özet
  if (global.ortak) global.ortak.put('sirketOzet', function (server) { return yukle(server) })

  ServerEvents.commandRegistry(function (event) {
    var Commands = event.commands
    var Arguments = event.arguments
    function oyuncu(ctx) { var p = ctx.source.player; if (p == null) ctx.source.sendSystemMessage(Text.ofString('Oyun içinden kullan.')); return p }
    function hata(p, m) { p.tell(Text.red(Text.ofString(m))); return 0 }
    function INT(ad) { return Commands.argument(ad, Arguments.INTEGER.create(event)) }
    function WORD(ad) { return Commands.argument(ad, Arguments.WORD.create(event)) }
    function benimki(p, d) { var s = sahipSirketi(d, String(p.getUuid())); if (!s) hata(p, 'Bir şirketin kurucusu veya yöneticisi değilsin.'); return s }

    function kur(ctx) {
      var p = oyuncu(ctx); if (p == null) return 0
      var server = p.server, id = String(p.getUuid())
      var ad = String(Arguments.WORD.getResult(ctx, 'ad'))
      if (!/^[A-Za-z0-9_]{3,16}$/.test(ad)) return hata(p, 'Şirket adı 3-16 harf/rakam/_ olmalı.')
      try { var bd = JSON.parse(server.persistentData.getString('borc_durum') || '{}')[id]; if (bd && bd.a >= 2) return hata(p, '[BORÇLU] damgası varken şirket kuramazsın.') } catch (e) { }
      var d = yukle(server)
      if (Object.keys(d.s).some(function (k) { return d.s[k].sahip === id })) return hata(p, 'Zaten bir şirketin var.')
      if (d.s[anahtar(ad)]) return hata(p, 'Bu adda bir şirket var.')
      var lisans = Math.max(0, Math.floor(oran(server, 'sirket', 10000)))
      var sh = oyuncuHesap(p.getUuid())
      if (sh.getBalance() < lisans) return hata(p, 'Şirket lisansı ' + para(lisans) + '; bankanda yok.')
      if (lisans > 0) { if (!sh.deduct(lisans, ReasonHolder.IGNORED)) return hata(p, 'Para kesilemedi.'); sh.markDirty(); hazineyeYatir(server, lisans, 'sirket_lisans', String(p.username) + ' (' + ad + ')') }
      var s = { ad: ad, sahip: id, hesap: String(JUUID.randomUUID()), kur: Date.now(), yonetici: [], hisse: {}, toplam: AYAR.ILK_HISSE, fiyat: 0, islem: [], temettu: [], donuk: false }
      s.hisse[id] = AYAR.ILK_HISSE
      var h = hesap(s)
      h.setLabel(ad + ' Şirketi')
      h.updateTrustList(function (l) { if (!l.contains(p.getUuid())) l.add(p.getUuid()) })
      h.markDirty()
      d.s[anahtar(ad)] = s
      kaydet(server, d)
      p.give(CardItem.set(Item.of(AYAR.KART), JUUID.fromString(s.hesap)).withCustomName(Text.ofString(ad + ' Şirket Kartı').aqua()))
      p.tell(Text.green(Text.ofString(ad + ' şirketi kuruldu. ' + AYAR.ILK_HISSE + ' hissenin hepsi senin. Şirket kartı verildi (kasaya para koymak/çekmek için Bank Terminal). Menü > Şirketler.')))
      server.tell(Text.gold(Text.ofString('[Şirket] ' + p.username + ', ' + ad + ' şirketini kurdu.')))
      return 1
    }

    // Hissedar kendi hissesini satışa çıkarır
    function sat(ctx) {
      var p = oyuncu(ctx); if (p == null) return 0
      var server = p.server, id = String(p.getUuid())
      var d = yukle(server)
      var s = d.s[anahtar(Arguments.WORD.getResult(ctx, 'sirket'))]
      if (!s) return hata(p, 'Böyle bir şirket yok.')
      if (s.donuk) return hata(p, s.ad + ' dondurulmuş.')
      var adet = Arguments.INTEGER.getResult(ctx, 'adet'), fiyat = Arguments.INTEGER.getResult(ctx, 'fiyat')
      if (adet < 1 || fiyat < 1 || fiyat > 10000000) return hata(p, 'Adet en az 1, birim fiyat 1 ile 10.000.000 arasında olmalı.')
      if ((s.hisse[id] || 0) < adet) return hata(p, 'Elinde ' + (s.hisse[id] || 0) + ' serbest ' + s.ad + ' hissesi var.')
      if (Object.keys(d.ilan).filter(function (k) { return d.ilan[k].satan === id }).length >= AYAR.ILAN_MAX) return hata(p, 'En fazla ' + AYAR.ILAN_MAX + ' ilanın olabilir.')
      s.hisse[id] -= adet
      if (s.hisse[id] <= 0) delete s.hisse[id]
      d.n = (d.n || 0) + 1
      d.ilan[String(d.n)] = { s: anahtar(s.ad), satan: id, ad: String(p.username), adet: adet, fiyat: fiyat, t: Date.now() }
      kaydet(server, d)
      p.tell(Text.green(Text.ofString(adet + ' ' + s.ad + ' hissesi tanesi ' + para(fiyat) + ' fiyatla satışa çıktı (ilan #' + d.n + ').')))
      return 1
    }

    // Şirket yeni hisse ihraç eder (para kasaya)
    function ihrac(ctx) {
      var p = oyuncu(ctx); if (p == null) return 0
      var server = p.server
      var d = yukle(server); var s = benimki(p, d); if (!s) return 0
      if (s.donuk) return hata(p, s.ad + ' dondurulmuş.')
      var adet = Arguments.INTEGER.getResult(ctx, 'adet'), fiyat = Arguments.INTEGER.getResult(ctx, 'fiyat')
      if (adet < 1 || adet > s.toplam || fiyat < 1 || fiyat > 10000000) return hata(p, 'Bir seferde en fazla mevcut hisse sayısı (' + s.toplam + ') kadar ihraç edilir; fiyat 1-10.000.000.')
      if (Object.keys(d.ilan).filter(function (k) { return d.ilan[k].s === anahtar(s.ad) && d.ilan[k].satan === 'sirket' }).length >= 3) return hata(p, 'Aynı anda en fazla 3 ihraç ilanı olabilir.')
      d.n = (d.n || 0) + 1
      d.ilan[String(d.n)] = { s: anahtar(s.ad), satan: 'sirket', ad: s.ad + ' (ihraç)', adet: adet, fiyat: fiyat, t: Date.now() }
      kaydet(server, d)
      p.tell(Text.green(Text.ofString(s.ad + ': ' + adet + ' yeni hisse tanesi ' + para(fiyat) + ' fiyatla ihraç ilanında. Satıldıkça para şirket kasasına girer.')))
      server.tell(Text.aqua(Text.ofString('[Şirket] ' + s.ad + ' ' + adet + ' yeni hisse ihraç etti (tanesi ' + para(fiyat) + '). Menü > Şirketler')))
      return 1
    }

    function al(ctx) {
      var p = oyuncu(ctx); if (p == null) return 0
      var server = p.server, id = String(p.getUuid())
      var d = yukle(server)
      var no = String(Arguments.INTEGER.getResult(ctx, 'ilan'))
      var x = d.ilan[no]
      if (!x) return hata(p, 'Böyle bir ilan yok (satılmış ya da iptal edilmiş olabilir).')
      var s = d.s[x.s]
      if (!s || s.donuk) return hata(p, 'Şirket yok ya da dondurulmuş.')
      if (x.satan === id) return hata(p, 'Kendi ilanını alamazsın; iptal et.')
      var adet = Math.min(Arguments.INTEGER.getResult(ctx, 'adet'), x.adet)
      if (adet < 1) return hata(p, 'Adet en az 1 olmalı.')
      var tutar = adet * x.fiyat
      var kom = Math.floor(tutar * oran(server, 'borsa', 1) / 100)
      var ah = oyuncuHesap(p.getUuid())
      if (ah.getBalance() < tutar + kom) return hata(p, 'Bakiye yetersiz: ' + para(tutar) + ' + komisyon ' + para(kom) + '.')
      if (!ah.deduct(tutar + kom, ReasonHolder.IGNORED)) return hata(p, 'Para kesilemedi.')
      ah.markDirty()
      hazineyeYatir(server, kom, 'borsa', String(p.username) + ' (' + s.ad + ' hissesi)')
      if (x.satan === 'sirket') { var hk = hesap(s); hk.deposit(tutar); hk.markDirty(); s.toplam += adet }
      else { var sh = oyuncuHesap(x.satan); sh.deposit(tutar); sh.markDirty() }
      s.hisse[id] = (s.hisse[id] || 0) + adet
      x.adet -= adet
      if (x.adet <= 0) delete d.ilan[no]
      s.fiyat = x.fiyat
      s.islem = (s.islem || []).concat([{ t: Date.now(), n: adet, f: x.fiyat, al: String(p.username), sat: x.ad }]).slice(-AYAR.ISLEM_MAX)
      kaydet(server, d)
      p.tell(Text.green(Text.ofString(adet + ' ' + s.ad + ' hissesi alındı: ' + para(tutar) + ' (+komisyon ' + para(kom) + '). Artık ' + s.hisse[id] + ' hissen var (%' + (Math.round(s.hisse[id] / s.toplam * 1000) / 10) + ').')))
      if (x.satan !== 'sirket') bildir(server, x.satan, '[Şirket] ' + p.username + ' ' + adet + ' ' + s.ad + ' hisseni aldı: +' + para(tutar))
      else [s.sahip].concat(s.yonetici || []).forEach(function (u) { bildir(server, u, '[Şirket] ' + p.username + ' ' + adet + ' ihraç hissesi aldı; kasaya +' + para(tutar)) })
      return 1
    }

    function iptal(ctx) {
      var p = oyuncu(ctx); if (p == null) return 0
      var server = p.server, id = String(p.getUuid())
      var d = yukle(server)
      var no = String(Arguments.INTEGER.getResult(ctx, 'ilan'))
      var x = d.ilan[no]
      if (!x) return hata(p, 'Böyle bir ilan yok.')
      var s = d.s[x.s]
      var benim = x.satan === id || (x.satan === 'sirket' && s && yetkili(s, id))
      if (!benim && !p.createCommandSourceStack().hasPermission(2)) return hata(p, 'Bu ilan senin değil.')
      if (s && x.satan !== 'sirket') s.hisse[x.satan] = (s.hisse[x.satan] || 0) + x.adet
      delete d.ilan[no]
      kaydet(server, d)
      p.tell(Text.ofString('İlan #' + no + ' iptal edildi' + (x.satan !== 'sirket' ? '; ' + x.adet + ' hisse geri döndü.' : '.')))
      return 1
    }

    function temettu(ctx) {
      var p = oyuncu(ctx); if (p == null) return 0
      var server = p.server
      var d = yukle(server); var s = benimki(p, d); if (!s) return 0
      if (s.donuk) return hata(p, s.ad + ' dondurulmuş.')
      var m = Arguments.INTEGER.getResult(ctx, 'miktar')
      if (m < 1) return hata(p, 'Miktar en az 1 olmalı.')
      var h = hesap(s)
      if (h.getBalance() < m) return hata(p, 'Şirket kasasında ' + para(h.getBalance()) + ' var.')
      // ilandaki hisseler de sahibine sayılır
      var pay = {}
      Object.keys(s.hisse).forEach(function (u) { pay[u] = s.hisse[u] })
      Object.keys(d.ilan).forEach(function (k) { var x = d.ilan[k]; if (x.s === anahtar(s.ad) && x.satan !== 'sirket') pay[x.satan] = (pay[x.satan] || 0) + x.adet })
      var top = 0
      Object.keys(pay).forEach(function (u) { top += pay[u] })
      if (top <= 0) return hata(p, 'Hissedar yok.')
      var dagitilan = 0
      Object.keys(pay).forEach(function (u) {
        var v = Math.floor(m * pay[u] / top)
        if (v <= 0) return
        if (!h.deduct(v, ReasonHolder.IGNORED)) return
        var oh = oyuncuHesap(u); oh.deposit(v); oh.markDirty()
        dagitilan += v
        bildir(server, u, '[Temettü] ' + s.ad + ': ' + pay[u] + ' hissene +' + para(v))
      })
      h.markDirty()
      s.temettu = (s.temettu || []).concat([{ t: Date.now(), m: dagitilan, hisse: top }]).slice(-AYAR.TEMETTU_MAX)
      kaydet(server, d)
      p.tell(Text.green(Text.ofString(s.ad + ' temettü dağıttı: ' + para(dagitilan) + ' (hisse başı ' + (Math.floor(dagitilan / top * 100) / 100) + ' spur).')))
      server.tell(Text.aqua(Text.ofString('[Şirket] ' + s.ad + ' hissedarlarına ' + para(dagitilan) + ' temettü dağıttı.')))
      return 1
    }

    function yonetici(ctx, ekle) {
      var p = oyuncu(ctx); if (p == null) return 0
      var server = p.server
      var d = yukle(server)
      var s = Object.keys(d.s).map(function (k) { return d.s[k] }).filter(function (x) { return x.sahip === String(p.getUuid()) })[0]
      if (!s) return hata(p, 'Sadece kurucu yönetici atayabilir.')
      var m = profil(server, String(Arguments.WORD.getResult(ctx, 'oyuncu')))
      if (!m || m.id === s.sahip) return hata(p, 'Oyuncu bulunamadı.')
      s.yonetici = (s.yonetici || []).filter(function (x) { return x !== m.id })
      if (ekle) s.yonetici.push(m.id)
      var u = JUUID.fromString(m.id)
      hesap(s).updateTrustList(function (l) { if (ekle) { if (!l.contains(u)) l.add(u) } else l.remove(u) })
      hesap(s).markDirty()
      kaydet(server, d)
      p.tell(Text.ofString(m.ad + (ekle ? ' artık ' + s.ad + ' yöneticisi (kart, ihraç, temettü).' : ' yöneticilikten çıkarıldı.')))
      bildir(server, m.id, '[Şirket] ' + s.ad + (ekle ? ' yöneticisi oldun (/sirket kart).' : ' yöneticiliğinden çıkarıldın.'))
      return 1
    }

    function kapat(ctx) {
      var p = oyuncu(ctx); if (p == null) return 0
      var server = p.server, id = String(p.getUuid())
      var d = yukle(server)
      var k = Object.keys(d.s).filter(function (x) { return d.s[x].sahip === id })[0]
      if (!k) return hata(p, 'Sadece kurucu şirketi kapatabilir.')
      var s = d.s[k]
      if (s.donuk) return hata(p, 'Şirket dondurulmuş; yönetimle konuş.')
      var benim = (s.hisse[id] || 0) + ilandaki(d, k, id)
      if (benim * 2 <= s.toplam) return hata(p, 'Kapatmak için hisselerin yarısından fazlası sende olmalı (' + benim + '/' + s.toplam + ').')
      // ilanlar iptal, hisseler sahiplerine
      Object.keys(d.ilan).forEach(function (n) { var x = d.ilan[n]; if (x.s !== k) return; if (x.satan !== 'sirket') s.hisse[x.satan] = (s.hisse[x.satan] || 0) + x.adet; delete d.ilan[n] })
      var h = hesap(s), top = 0, kasaP = h.getBalance(), dagitilan = 0
      Object.keys(s.hisse).forEach(function (u) { top += s.hisse[u] })
      Object.keys(s.hisse).forEach(function (u) {
        var v = top > 0 ? Math.floor(kasaP * s.hisse[u] / top) : 0
        if (v > 0 && h.deduct(v, ReasonHolder.IGNORED)) { var oh = oyuncuHesap(u); oh.deposit(v); oh.markDirty(); dagitilan += v; bildir(server, u, '[Şirket] ' + s.ad + ' kapandı; ' + s.hisse[u] + ' hissene +' + para(v)) }
      })
      var kalan = h.getBalance()
      if (kalan > 0 && h.deduct(kalan, ReasonHolder.IGNORED)) { var sh = oyuncuHesap(id); sh.deposit(kalan); sh.markDirty() }
      h.setLabel('Kapalı şirket (' + s.ad + ')')
      h.updateTrustList(function (l) { l.clear() })
      h.markDirty()
      delete d.s[k]
      kaydet(server, d)
      server.tell(Text.gold(Text.ofString('[Şirket] ' + s.ad + ' kapandı; kasadaki ' + para(dagitilan) + ' hissedarlara dağıtıldı.')))
      return 1
    }

    function dondur(ctx, durum) {
      var d = yukle(ctx.source.server)
      var s = d.s[anahtar(Arguments.WORD.getResult(ctx, 'sirket'))]
      if (!s) { ctx.source.sendSystemMessage(Text.ofString('Böyle bir şirket yok.')); return 0 }
      s.donuk = durum
      kaydet(ctx.source.server, d)
      ctx.source.server.tell(Text.gold(Text.ofString('[Şirket] ' + s.ad + ' ' + (durum ? 'yönetim tarafından DONDURULDU (alım-satım, ihraç, temettü durdu).' : 'çözüldü.'))))
      return 1
    }

    event.register(Commands.literal('sirket')
      .then(Commands.literal('kur').then(WORD('ad').executes(kur)))
      .then(Commands.literal('sat').then(WORD('sirket').then(INT('adet').then(INT('fiyat').executes(sat)))))
      .then(Commands.literal('ihrac').then(INT('adet').then(INT('fiyat').executes(ihrac))))
      .then(Commands.literal('al').then(INT('ilan').then(INT('adet').executes(al))))
      .then(Commands.literal('iptal').then(INT('ilan').executes(iptal)))
      .then(Commands.literal('temettu').then(INT('miktar').executes(temettu)))
      .then(Commands.literal('yonetici')
        .then(Commands.literal('ekle').then(WORD('oyuncu').executes(function (ctx) { return yonetici(ctx, true) })))
        .then(Commands.literal('cikar').then(WORD('oyuncu').executes(function (ctx) { return yonetici(ctx, false) }))))
      .then(Commands.literal('kart').executes(function (ctx) {
        var p = oyuncu(ctx); if (p == null) return 0
        var d = yukle(p.server); var s = benimki(p, d); if (!s) return 0
        p.give(CardItem.set(Item.of(AYAR.KART), JUUID.fromString(s.hesap)).withCustomName(Text.ofString(s.ad + ' Şirket Kartı').aqua()))
        p.tell(Text.ofString('Şirket kartı verildi. Karta shift+sağ tık yapma, bağlantısı silinir.'))
        return 1
      }))
      .then(Commands.literal('kapat').executes(kapat))
      .then(Commands.literal('dondur').requires(function (s) { return s.hasPermission(2) }).then(WORD('sirket').executes(function (ctx) { return dondur(ctx, true) })))
      .then(Commands.literal('coz').requires(function (s) { return s.hasPermission(2) }).then(WORD('sirket').executes(function (ctx) { return dondur(ctx, false) }))))
  })
  console.info('[Sirket] yuklendi')
})()
