// =====================================================================
//  SABAH BİLGİSİ  -  kubejs/server_scripts/sabah_bilgi.js  (2026-11-24)
//  Her yeni Minecraft gününde (uyuyup uyanınca ya da sabah olunca) çevrimiçi herkese ekranın orta
//  altında (aksiyon çubuğu) ~15 saniye kısa bir özet: kaçıncı gün, chunk sayısı, arazi kirasının
//  kaç gün yeteceği, varsa borç. Aksiyon çubuğu ~3 sn'de söner; bu yüzden 2 sn'de bir tazelenir.
//  Kira gerçek zamanla erir (vergi_sistemi.js: rec.kredi / rec.g = kalan gün).
// =====================================================================
;(function () {
  var SURE_TICK = 300        // 15 saniye
  var TAZELE_TICK = 40       // aksiyon çubuğunu 2 sn'de bir yeniden gönder
  var bitis = -1
  var sonGun = null

  var OPAC = null
  function claimSayisi(p) {
    try {
      if (OPAC == null) OPAC = Java.loadClass('xaero.pac.common.server.api.OpenPACServerAPI')
      var m = OPAC.get(p.server).getServerClaimsManager()
      return m.hasPlayerInfo(p.getUuid()) ? m.getPlayerInfo(p.getUuid()).getClaimCount() : 0
    } catch (e) { return 0 }
  }
  function veriOku(server, anahtar) {
    var s = server.persistentData.getString(anahtar)
    if (!s) return {}
    try { return JSON.parse(s) } catch (e) { return {} }
  }
  function kiraYazi(server, id, chunk) {
    var r = (veriOku(server, 'vergi_veri').kayitlar || {})[id]
    if (chunk <= 0 && !(r && r.askida)) return null
    if (!r || !(r.g > 0)) return null
    if (r.askida) return 'kira ödenmedi: arazi askıda'
    if (!(r.kredi > 0)) return 'kira bitti'
    var gun = r.kredi / r.g
    if (gun >= 1) return 'kira ' + (Math.floor(gun * 10) / 10).toString().replace('.', ',') + ' gün yeter'
    return 'kira ' + Math.max(1, Math.floor(gun * 24)) + ' saat yeter'
  }
  function borcYazi(server, id) {
    var r = (veriOku(server, 'borc_veri').o || {})[id]
    return r && r.borc > 0 ? 'borç ' + Math.ceil(r.borc) + ' spur' : null
  }
  function ozet(p, gun) {
    var id = String(p.getUuid())
    var chunk = claimSayisi(p)
    var parcalar = ['Gün ' + gun, chunk + ' chunk']
    var k = kiraYazi(p.server, id, chunk); if (k) parcalar.push(k)
    var b = borcYazi(p.server, id); if (b) parcalar.push(b)
    return parcalar.join('  ·  ')
  }

  ServerEvents.tick(function (event) {
    var server = event.server
    var t = server.tickCount
    try {
      if (t % 20 === 0) {
        var zaman = server.overworld().getDayTime()
        var gun = Math.floor(zaman / 24000)
        if (sonGun == null) {
          var kayitli = server.persistentData.contains('sabah_son_gun') ? server.persistentData.getLong('sabah_son_gun') : -1
          sonGun = kayitli >= 0 ? Number(kayitli) : gun
        }
        // Yeni gün ve sabah (gün içinde ilk ~1 dk): uyku gecesi atlatınca ya da doğal sabahta
        if (gun > sonGun && (zaman % 24000) < 1200) {
          sonGun = gun
          server.persistentData.putLong('sabah_son_gun', gun)
          bitis = t + SURE_TICK
        } else if (gun < sonGun) {
          sonGun = gun   // /time set ile geri alındı
          server.persistentData.putLong('sabah_son_gun', gun)
        }
      }
      if (bitis < 0) return
      if (t > bitis) { bitis = -1; return }
      if ((bitis - t) % TAZELE_TICK !== 0) return
      var gunNo = sonGun + 1
      var oyuncular = server.playerList.getPlayers().toArray()
      for (var i = 0; i < oyuncular.length; i++) {
        var p = oyuncular[i]
        p.setStatusMessage(Text.gold(Text.ofString(ozet(p, gunNo))))
      }
    } catch (err) { console.error('[Sabah] hata: ' + err) }
  })
})()
