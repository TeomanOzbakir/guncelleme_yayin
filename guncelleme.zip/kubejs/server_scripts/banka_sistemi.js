// =====================================================================
//  OYUNCU BANKALARI  -  kubejs/server_scripts/banka_sistemi.js
//  Bankacılık oyuncular arasında ELLE yapılır (para alma, kredi, faiz pazarlığı). Sistem sadece:
//   - bankayı kurar: sadece Tacir; lisans ücreti hazineye, asgari sermaye bankanın hesabına KİLİTLİ
//     (sunucu_piyasa BankaKilit: hesap bu tutarın altına inemez, Bank Terminal'de görünmez)
//   - bankanın kendi Numismatics hesabı + kartı; sahip çalışanlara kart yetkisi verebilir
//   - herkese gösterir: kasa, kilitli sermaye, hareket dökümü (son 50, kim yaptıysa), defter
//     toplamları ve kasa/mevduat oranı, bankacının duyurusu
//   - defter: bankacı her müşterinin mevduatını ve kredi borcunu elle yazar; her değişiklik müşterinin
//     görebildiği geçmişe düşer (sessizce değiştirilemez)
//   - kapatma: defterde mevduat kalmamışsa; kasadaki her şey sahibine döner. OP dondurabilir.
//  Veri: persistentData 'banka_veri' = { b: { <anahtar>: banka } }   (anahtar = küçük harf ad)
//  Komutlar: /banka kur|bilgi|liste|sec|hareket|defterim|kart|calisan|defter|duyuru|kapat  (OP: dondur|coz)
//  !! Gerçek bir oyunda ÇALIŞTIRILARAK TEST EDİLMEDİ.
// =====================================================================
;(function () {
  var AYAR = {
    LISANS: 5000,          // spur, hazineye
    SERMAYE: 20000,        // spur, bankanın hesabına kilitli
    HAREKET_MAX: 50,
    GECMIS_MAX: 20,        // müşteri başına defter geçmişi
    DUYURU_MAX: 200,
    KART: 'numismatics:green_card'
  }
  var HAZINE_UUID = '5f0c2d1e-7a3b-4e9c-8d6f-1b2a3c4d5e6f'
  var JUUID = Java.loadClass('java.util.UUID')
  var Numismatics = Java.loadClass('dev.ithundxr.createnumismatics.Numismatics')
  var ReasonHolder = Java.loadClass('dev.ithundxr.createnumismatics.content.backend.ReasonHolder')
  var BankType = Java.loadClass('dev.ithundxr.createnumismatics.content.backend.BankAccount$Type')
  var CardItem = Java.loadClass('dev.ithundxr.createnumismatics.content.bank.CardItem')
  var BankaKilit = null
  try { BankaKilit = Java.loadClass('tr.sunucu.piyasa.BankaKilit') } catch (e) { console.warn('[Banka] sunucu_piyasa BankaKilit yok, sermaye kilidi calismaz: ' + e) }

  // ----------------------------- VERİ -----------------------------------
  function yukle(server) {
    var s = server.persistentData.getString('banka_veri')
    var d = null
    if (s) { try { d = JSON.parse(s) } catch (e) { d = null } }
    if (!d || !d.b) d = { b: {} }
    return d
  }
  function kaydet(server, d) { server.persistentData.putString('banka_veri', JSON.stringify(d)) }
  function anahtar(ad) { return String(ad).toLowerCase() }
  function adi(server, uuid) {
    var o = server.playerList.getPlayer(uuid)
    if (o != null) return String(o.username)
    var prof = server.getProfileCache().get(uuid)
    return prof.isPresent() ? String(prof.get().getName()) : String(uuid).substring(0, 8)
  }
  function profil(server, isim) {   // çevrimdışı oyuncu da olabilir
    var o = server.playerList.getPlayerByName(isim)
    if (o != null) return { id: String(o.getUuid()), ad: String(o.username) }
    var prof = server.getProfileCache().get(isim)
    return prof.isPresent() ? { id: String(prof.get().getId()), ad: String(prof.get().getName()) } : null
  }
  function hesap(b) { return Numismatics.BANK.getOrCreateAccount(JUUID.fromString(b.hesap), BankType.BLAZE_BANKER) }
  function kasa(b) { try { return hesap(b).getBalance() } catch (e) { return 0 } }
  function sahipBankasi(d, id) { var k = Object.keys(d.b).filter(function (x) { return d.b[x].sahip === id })[0]; return k ? d.b[k] : null }
  function yetkiliMi(b, id) { return b.sahip === id || (b.calisan || []).indexOf(id) >= 0 }
  function toplamlar(b) {
    var m = 0, k = 0, n = 0
    Object.keys(b.defter || {}).forEach(function (u) { var r = b.defter[u]; m += r.m || 0; k += r.k || 0; if ((r.m || 0) > 0 || (r.k || 0) > 0) n++ })
    return { m: m, k: k, n: n }
  }
  function kilitUygula(b) {
    if (BankaKilit == null) return
    try { BankaKilit.ayarla(b.hesap, b.donuk ? 1000000000 : b.sermaye) } catch (e) { console.warn('[Banka] kilit: ' + e) }
  }
  function tacirMi(server, id) {
    try { var y = JSON.parse(server.persistentData.getString('yetenek_veri') || '{}'); var r = (y.o || {})[id] || {}; return r.meslek === 'tacir' || (r.ekMeslekler || []).indexOf('tacir') >= 0 } catch (e) { return false }
  }
  function hazineyeYatir(server, m, tur, kim) {
    var h = Numismatics.BANK.getOrCreateAccount(JUUID.fromString(HAZINE_UUID), BankType.BLAZE_BANKER)
    h.deposit(m); h.markDirty()
    var s = server.persistentData.getString('hazine_veri')
    var d = null
    if (s) { try { d = JSON.parse(s) } catch (e) { d = null } }
    if (!d) d = {}
    if (!d.gelir) d.gelir = {}
    if (!d.hareket) d.hareket = []
    d.gelir[tur] = (d.gelir[tur] || 0) + m
    d.hareket = d.hareket.concat([{ t: Date.now(), tur: tur, m: m, k: kim }]).slice(-500)
    server.persistentData.putString('hazine_veri', JSON.stringify(d))
  }
  function hareketEkle(b, m, bakiye, kim) {
    b.hareket = (b.hareket || []).concat([{ t: Date.now(), m: m, b: bakiye, kim: kim }]).slice(-AYAR.HAREKET_MAX)
  }
  function para(n) { return String(Math.floor(n)).replace(/\B(?=(\d{3})+(?!\d))/g, '.') + ' spur' }
  function oran(b) { var t = toplamlar(b); return t.m > 0 ? Math.round(kasa(b) / t.m * 100) + '%' : '-' }
  function zaman(t) { var d = new Date(t); var i = function (n) { return (n < 10 ? '0' : '') + n }; return i(d.getDate()) + '.' + i(d.getMonth() + 1) + ' ' + i(d.getHours()) + ':' + i(d.getMinutes()) }

  // ----------------------------- HAREKET TAKİBİ ---------------------------
  // Her 5 sn: bankanın hesabı değiştiyse farkı döküme yaz. Kim: o anda bu hesabın Bank Terminal
  // ekranı açık olan oyuncu(lar); yoksa kart ödemesi / aktarım / Vendor ("dış işlem").
  function ekranAcanlar(server, hesapId) {
    var liste = []
    var oyuncular = server.playerList.getPlayers().toArray()
    for (var i = 0; i < oyuncular.length; i++) {
      try {
        var m = oyuncular[i].containerMenu
        var ch = m == null ? null : m.contentHolder
        if (ch != null && ch.id != null && String(ch.id) === hesapId) liste.push(String(oyuncular[i].username))
      } catch (e) { }
    }
    return liste
  }
  ServerEvents.tick(function (event) {
    var server = event.server
    if (server.tickCount % 100 !== 60) return
    try {
      var d = yukle(server)
      var degisti = false
      Object.keys(d.b).forEach(function (k) {
        var b = d.b[k]
        var bal = kasa(b)
        if (b.son == null) { b.son = bal; degisti = true }
        if (bal !== b.son) {
          var acan = ekranAcanlar(server, b.hesap)
          hareketEkle(b, bal - b.son, bal, acan.length ? acan.join(', ') : 'dış işlem (kart/aktarım/Vendor)')
          b.son = bal
          degisti = true
        }
        if (server.tickCount % 1200 === 60) kilitUygula(b)   // dakikada bir kilidi tazele
      })
      if (degisti) kaydet(server, d)
    } catch (err) { console.error('[Banka] takip hatasi: ' + err) }
  })
  ServerEvents.loaded(function (event) {
    try { var d = yukle(event.server); Object.keys(d.b).forEach(function (k) { kilitUygula(d.b[k]) }) } catch (err) { console.error('[Banka] kilit yukleme: ' + err) }
  })

  // ----------------------------- KOMUTLAR ---------------------------------
  ServerEvents.commandRegistry(function (event) {
    var Commands = event.commands
    var Arguments = event.arguments
    function oyuncu(ctx) { var p = ctx.source.player; if (p == null) ctx.source.sendSystemMessage(Text.ofString('Oyun içinden kullan.')); return p }
    function bul(d, ad) { return d.b[anahtar(ad)] || null }
    function benimki(p, d) { var b = sahipBankasi(d, String(p.getUuid())); if (!b) p.tell(Text.red(Text.ofString('Bankan yok. Kurmak: /banka kur <ad> (sadece Tacir)'))); return b }
    function secili(p, d, ad) {
      if (ad) { var b = bul(d, ad); if (!b) p.tell(Text.red(Text.ofString('Böyle bir banka yok: ' + ad))); return b }
      var s = String(p.persistentData.getString('banka_secili') || '')
      var b2 = s ? d.b[s] : null
      if (!b2) b2 = sahipBankasi(d, String(p.getUuid()))
      if (!b2) p.tell(Text.red(Text.ofString('Banka adı yaz: /banka bilgi <ad>  (liste: /banka liste)')))
      return b2
    }
    function bilgiYaz(p, b) {
      var t = toplamlar(b)
      p.tell(Text.gold(Text.ofString('=== ' + b.ad + ' Bankası · sahibi ' + adi(p.server, JUUID.fromString(b.sahip)) + (b.donuk ? ' · DONDURULDU' : '') + ' ===')))
      p.tell(Text.ofString('Kasa: ' + para(kasa(b)) + ' (kilitli sermaye ' + para(b.sermaye) + ') | Defter: mevduat ' + para(t.m) + ', verilen kredi ' + para(t.k) +
        ', ' + t.n + ' müşteri | Kasa/mevduat: ' + oran(b)))
      if (b.duyuru) p.tell(Text.aqua(Text.ofString('Duyuru: ' + b.duyuru)))
      var r = (b.defter || {})[String(p.getUuid())]
      if (r) p.tell(Text.green(Text.ofString('Senin satırın: mevduat ' + para(r.m || 0) + ', kredi borcu ' + para(r.k || 0) + '  (geçmiş: /banka defterim ' + b.ad + ')')))
    }

    var defterAlan = function (alan) {
      return Commands.argument('miktar', Arguments.INTEGER.create(event))
        .executes(function (ctx) { return defterYaz(ctx, alan, '') })
        .then(Commands.argument('not', Arguments.GREEDY_STRING.create(event))
          .executes(function (ctx) { return defterYaz(ctx, alan, String(Arguments.GREEDY_STRING.getResult(ctx, 'not'))) }))
    }
    function defterYaz(ctx, alan, not) {
      var p = oyuncu(ctx); if (p == null) return 0
      var server = p.server
      var d = yukle(server)
      var id = String(p.getUuid())
      var b = sahipBankasi(d, id)
      if (!b) b = Object.keys(d.b).map(function (k) { return d.b[k] }).filter(function (x) { return yetkiliMi(x, id) })[0]
      if (!b) { p.tell(Text.red(Text.ofString('Defter yazmak için bir bankanın sahibi veya çalışanı olmalısın.'))); return 0 }
      var isim = String(Arguments.WORD.getResult(ctx, 'musteri'))
      var m = profil(server, isim)
      if (!m) { p.tell(Text.red(Text.ofString('Oyuncu bulunamadı: ' + isim))); return 0 }
      var deger = Arguments.INTEGER.getResult(ctx, 'miktar')
      if (deger < 0 || deger > 1000000000) { p.tell(Text.red(Text.ofString('Miktar 0 veya daha büyük olmalı.'))); return 0 }
      if (!b.defter) b.defter = {}
      var r = b.defter[m.id] || (b.defter[m.id] = { ad: m.ad, m: 0, k: 0, g: [] })
      var anahtarAlan = alan === 'mevduat' ? 'm' : 'k'
      var eski = r[anahtarAlan] || 0
      r[anahtarAlan] = deger
      r.ad = m.ad
      r.g = (r.g || []).concat([{ t: Date.now(), a: alan, e: eski, y: deger, n: String(not).substring(0, 80), kim: String(p.username) }]).slice(-AYAR.GECMIS_MAX)
      kaydet(server, d)
      p.tell(Text.green(Text.ofString(b.ad + ' defteri · ' + m.ad + ' ' + alan + ': ' + para(eski) + ' → ' + para(deger))))
      var mo = server.playerList.getPlayer(JUUID.fromString(m.id))
      if (mo != null) mo.tell(Text.ofString('[' + b.ad + ' Bankası] defterindeki ' + alan + ': ' + para(eski) + ' → ' + para(deger) + (not ? ' (' + not + ')' : '') + ' · ' + p.username))
      return 1
    }

    event.register(Commands.literal('banka')
      .executes(function (ctx) { var p = oyuncu(ctx); if (p == null) return 0; var d = yukle(p.server); var b = secili(p, d, null); if (b) bilgiYaz(p, b); return 1 })
      // Kurulum
      .then(Commands.literal('kur').then(Commands.argument('ad', Arguments.WORD.create(event)).executes(function (ctx) {
        var p = oyuncu(ctx); if (p == null) return 0
        var server = p.server
        var id = String(p.getUuid())
        var ad = String(Arguments.WORD.getResult(ctx, 'ad'))
        if (!/^[A-Za-z0-9_]{3,16}$/.test(ad)) { p.tell(Text.red(Text.ofString('Banka adı 3-16 harf/rakam/_ olmalı.'))); return 0 }
        if (!tacirMi(server, id)) { p.tell(Text.red(Text.ofString('Banka sadece Tacir mesleğindekiler kurabilir (/meslek sec tacir).'))); return 0 }
        var d = yukle(server)
        if (sahipBankasi(d, id)) { p.tell(Text.red(Text.ofString('Zaten bir bankan var.'))); return 0 }
        if (bul(d, ad)) { p.tell(Text.red(Text.ofString('Bu adda bir banka var.'))); return 0 }
        var toplam = AYAR.LISANS + AYAR.SERMAYE
        var sh = Numismatics.BANK.getAccount(p.getUuid())
        if (!sh || sh.getBalance() < toplam) { p.tell(Text.red(Text.ofString('Bankanda ' + para(toplam) + ' olmalı (lisans ' + para(AYAR.LISANS) + ' + kilitli sermaye ' + para(AYAR.SERMAYE) + ').'))); return 0 }
        if (!sh.deduct(toplam, ReasonHolder.IGNORED)) { p.tell(Text.red(Text.ofString('Para kesilemedi.'))); return 0 }
        sh.markDirty()
        hazineyeYatir(server, AYAR.LISANS, 'banka_lisans', String(p.username) + ' (' + ad + ')')
        var b = { ad: ad, sahip: id, hesap: String(JUUID.randomUUID()), sermaye: AYAR.SERMAYE, kur: Date.now(), duyuru: '', donuk: false, calisan: [], defter: {}, hareket: [] }
        var h = hesap(b)
        h.setLabel(ad + ' Bankası')
        h.updateTrustList(function (liste) { if (!liste.contains(p.getUuid())) liste.add(p.getUuid()) })
        h.deposit(AYAR.SERMAYE); h.markDirty()
        b.son = h.getBalance()
        hareketEkle(b, AYAR.SERMAYE, b.son, 'kuruluş sermayesi')
        d.b[anahtar(ad)] = b
        kaydet(server, d)
        kilitUygula(b)
        p.give(CardItem.set(Item.of(AYAR.KART), JUUID.fromString(b.hesap)).withCustomName(Text.ofString(ad + ' Bankası Kartı').green()))
        p.tell(Text.green(Text.ofString(ad + ' Bankası kuruldu. Kart verildi: Bank Terminal\'e kartla sağ tıkla. ' + para(AYAR.SERMAYE) + ' sermaye kilitli (çekilemez). Defter: /banka defter <oyuncu> mevduat|kredi <miktar> [not]')))
        server.tell(Text.gold(Text.ofString('[Banka] ' + p.username + ', ' + ad + ' Bankası\'nı kurdu.')))
        return 1
      })))
      // Görüntüleme (herkes)
      .then(Commands.literal('liste').executes(function (ctx) {
        var p = oyuncu(ctx); if (p == null) return 0
        var d = yukle(p.server)
        var ks = Object.keys(d.b)
        if (!ks.length) { p.tell(Text.ofString('Henüz banka yok.')); return 1 }
        ks.forEach(function (k) { var b = d.b[k]; var t = toplamlar(b); p.tell(Text.ofString('• ' + b.ad + ' · ' + adi(p.server, JUUID.fromString(b.sahip)) + ' · kasa ' + para(kasa(b)) + ' · mevduat ' + para(t.m) + ' · oran ' + oran(b) + (b.donuk ? ' · DONUK' : ''))) })
        return 1
      }))
      .then(Commands.literal('bilgi')
        .executes(function (ctx) { var p = oyuncu(ctx); if (p == null) return 0; var b = secili(p, yukle(p.server), null); if (b) bilgiYaz(p, b); return b ? 1 : 0 })
        .then(Commands.argument('ad', Arguments.WORD.create(event)).executes(function (ctx) {
          var p = oyuncu(ctx); if (p == null) return 0
          var b = secili(p, yukle(p.server), String(Arguments.WORD.getResult(ctx, 'ad'))); if (b) bilgiYaz(p, b); return b ? 1 : 0
        })))
      // Menüde gösterilecek bankayı seç
      .then(Commands.literal('sec').then(Commands.argument('ad', Arguments.WORD.create(event)).executes(function (ctx) {
        var p = oyuncu(ctx); if (p == null) return 0
        var d = yukle(p.server)
        var b = bul(d, String(Arguments.WORD.getResult(ctx, 'ad')))
        if (!b) { p.tell(Text.red(Text.ofString('Böyle bir banka yok.'))); return 0 }
        p.persistentData.putString('banka_secili', anahtar(b.ad))
        p.tell(Text.ofString('Menüde gösterilen banka: ' + b.ad))
        return 1
      })))
      .then(Commands.literal('hareket')
        .executes(function (ctx) { return hareketYaz(ctx, null) })
        .then(Commands.argument('ad', Arguments.WORD.create(event)).executes(function (ctx) { return hareketYaz(ctx, String(Arguments.WORD.getResult(ctx, 'ad'))) })))
      .then(Commands.literal('defterim')
        .executes(function (ctx) { return defterim(ctx, null) })
        .then(Commands.argument('ad', Arguments.WORD.create(event)).executes(function (ctx) { return defterim(ctx, String(Arguments.WORD.getResult(ctx, 'ad'))) })))
      // Bankacı
      .then(Commands.literal('defter').then(Commands.argument('musteri', Arguments.WORD.create(event))
        .then(Commands.literal('mevduat').then(defterAlan('mevduat')))
        .then(Commands.literal('kredi').then(defterAlan('kredi')))))
      .then(Commands.literal('duyuru').then(Commands.argument('metin', Arguments.GREEDY_STRING.create(event)).executes(function (ctx) {
        var p = oyuncu(ctx); if (p == null) return 0
        var d = yukle(p.server); var b = benimki(p, d); if (!b) return 0
        b.duyuru = String(Arguments.GREEDY_STRING.getResult(ctx, 'metin')).substring(0, AYAR.DUYURU_MAX)
        kaydet(p.server, d)
        p.tell(Text.green(Text.ofString('Duyuru güncellendi.')))
        return 1
      })))
      .then(Commands.literal('kart').executes(function (ctx) {
        var p = oyuncu(ctx); if (p == null) return 0
        var d = yukle(p.server)
        var id = String(p.getUuid())
        var b = sahipBankasi(d, id) || Object.keys(d.b).map(function (k) { return d.b[k] }).filter(function (x) { return yetkiliMi(x, id) })[0]
        if (!b) { p.tell(Text.red(Text.ofString('Bir bankanın sahibi veya çalışanı değilsin.'))); return 0 }
        p.give(CardItem.set(Item.of(AYAR.KART), JUUID.fromString(b.hesap)).withCustomName(Text.ofString(b.ad + ' Bankası Kartı').green()))
        p.tell(Text.ofString('Kart verildi. Karta shift+sağ tıklama yapma, bağlantısı silinir.'))
        return 1
      }))
      .then(Commands.literal('calisan')
        .then(Commands.literal('ekle').then(Commands.argument('oyuncu', Arguments.PLAYER.create(event)).executes(function (ctx) { return calisan(ctx, true) })))
        .then(Commands.literal('cikar').then(Commands.argument('oyuncu', Arguments.PLAYER.create(event)).executes(function (ctx) { return calisan(ctx, false) }))))
      .then(Commands.literal('kapat').executes(function (ctx) {
        var p = oyuncu(ctx); if (p == null) return 0
        var server = p.server
        var d = yukle(server); var b = benimki(p, d); if (!b) return 0
        if (b.donuk) { p.tell(Text.red(Text.ofString('Bankan dondurulmuş; kapatmak için yöneticiyle konuş.'))); return 0 }
        var t = toplamlar(b)
        if (t.m > 0) { p.tell(Text.red(Text.ofString('Defterde ' + para(t.m) + ' mevduat var. Önce müşterilere ödeyip defteri sıfırla.'))); return 0 }
        var h = hesap(b)
        if (BankaKilit != null) BankaKilit.ayarla(b.hesap, 0)
        var tutar = h.getBalance()
        if (tutar > 0 && h.deduct(tutar, ReasonHolder.IGNORED)) {
          h.markDirty()
          var sh = Numismatics.BANK.getOrCreateAccount(p.getUuid(), BankType.PLAYER); sh.deposit(tutar); sh.markDirty()
        }
        h.setLabel('Kapalı banka (' + b.ad + ')')
        h.updateTrustList(function (liste) { liste.clear() })
        h.markDirty()
        delete d.b[anahtar(b.ad)]
        kaydet(server, d)
        p.tell(Text.green(Text.ofString(b.ad + ' Bankası kapandı; kasadaki ' + para(tutar) + ' bankana aktarıldı.')))
        server.tell(Text.gold(Text.ofString('[Banka] ' + b.ad + ' Bankası kapandı.')))
        return 1
      }))
      // OP: dondur / çöz (dolandırıcılık şüphesinde kasa tamamen kilitlenir)
      .then(Commands.literal('dondur').requires(function (s) { return s.hasPermission(2) })
        .then(Commands.argument('ad', Arguments.WORD.create(event)).executes(function (ctx) { return dondur(ctx, true) })))
      .then(Commands.literal('coz').requires(function (s) { return s.hasPermission(2) })
        .then(Commands.argument('ad', Arguments.WORD.create(event)).executes(function (ctx) { return dondur(ctx, false) }))))

    function hareketYaz(ctx, ad) {
      var p = oyuncu(ctx); if (p == null) return 0
      var b = secili(p, yukle(p.server), ad); if (!b) return 0
      var l = (b.hareket || []).slice(-10).reverse()
      p.tell(Text.gold(Text.ofString('=== ' + b.ad + ' Bankası · son hareketler ===')))
      if (!l.length) p.tell(Text.ofString('Henüz hareket yok.'))
      l.forEach(function (x) { p.tell(Text.ofString(zaman(x.t) + '  ' + (x.m >= 0 ? '+' : '') + para(x.m) + '  → kasa ' + para(x.b) + '  · ' + x.kim)) })
      return 1
    }
    function defterim(ctx, ad) {
      var p = oyuncu(ctx); if (p == null) return 0
      var b = secili(p, yukle(p.server), ad); if (!b) return 0
      var r = (b.defter || {})[String(p.getUuid())]
      if (!r) { p.tell(Text.ofString(b.ad + ' defterinde kaydın yok.')); return 1 }
      p.tell(Text.gold(Text.ofString('=== ' + b.ad + ' defteri · ' + r.ad + ' === mevduat ' + para(r.m || 0) + ', kredi borcu ' + para(r.k || 0))))
      ;(r.g || []).slice(-10).reverse().forEach(function (x) { p.tell(Text.ofString(zaman(x.t) + '  ' + x.a + ': ' + para(x.e) + ' → ' + para(x.y) + (x.n ? '  (' + x.n + ')' : '') + '  · ' + x.kim)) })
      return 1
    }
    function calisan(ctx, ekle) {
      var p = oyuncu(ctx); if (p == null) return 0
      var d = yukle(p.server); var b = benimki(p, d); if (!b) return 0
      var h = Arguments.PLAYER.getResult(ctx, 'oyuncu')
      var u = h.getUuid()
      var hid = String(u)
      b.calisan = (b.calisan || []).filter(function (x) { return x !== hid })
      if (ekle) b.calisan.push(hid)
      hesap(b).updateTrustList(function (liste) { if (ekle) { if (!liste.contains(u)) liste.add(u) } else liste.remove(u) })
      hesap(b).markDirty()
      kaydet(p.server, d)
      p.tell(Text.ofString(String(h.username) + (ekle ? ' artık çalışan: kart kullanabilir ve defter yazabilir (/banka kart).' : ' çalışanlıktan çıkarıldı.')))
      h.tell(Text.ofString(b.ad + ' Bankası: ' + (ekle ? 'çalışan oldun (/banka kart ile kart al).' : 'çalışanlıktan çıkarıldın.')))
      return 1
    }
    function dondur(ctx, durum) {
      var d = yukle(ctx.source.server)
      var b = bul(d, String(Arguments.WORD.getResult(ctx, 'ad')))
      if (!b) { ctx.source.sendSystemMessage(Text.ofString('Böyle bir banka yok.')); return 0 }
      b.donuk = durum
      kaydet(ctx.source.server, d)
      kilitUygula(b)
      ctx.source.server.tell(Text.gold(Text.ofString('[Banka] ' + b.ad + ' Bankası ' + (durum ? 'yönetim tarafından DONDURULDU (kasadan para çıkamaz).' : 'çözüldü.'))))
      return 1
    }
  })

  console.info('[Banka] yuklendi: lisans ' + AYAR.LISANS + ', kilitli sermaye ' + AYAR.SERMAYE)
})()
