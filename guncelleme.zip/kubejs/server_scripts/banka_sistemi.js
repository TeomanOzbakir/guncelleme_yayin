// =====================================================================
//  OYUNCU BANKALARI  -  kubejs/server_scripts/banka_sistemi.js
//  Bankacılık oyuncular arasında ELLE yapılır (para alma, kredi, faiz pazarlığı). Sistem sadece:
//   - bankayı kurar: sadece Tacir; lisans ücreti hazineye, asgari sermaye bankanın hesabına KİLİTLİ
//     (sunucu_piyasa BankaKilit: hesap bu tutarın altına inemez, Bank Terminal'de görünmez)
//   - bankanın kendi Numismatics hesabı + kartı; sahip çalışanlara kart yetkisi verebilir
//   - herkese gösterir: kasa, kilitli sermaye, hareket dökümü (son 50, kim yaptıysa), defter
//     toplamları ve kasa/mevduat oranı, bankacının duyurusu
//   - defter: bankacı her müşterinin mevduatını ve kredi borcunu elle yazar; her değişiklik müşterinin
//     görebildiği geçmişe düşer (sessizce değiştirilemez)
//   - kapatma: defterde mevduat kalmamışsa; kasadaki her şey sahibine döner. OP dondurabilir.
//  Veri: persistentData 'banka_veri' = { b: { <anahtar>: banka } }   (anahtar = küçük harf ad)
//  Komutlar: /banka kur|bilgi|liste|sec|hareket|defterim|kart|calisan|defter|duyuru|kapat  (OP: dondur|coz)
//  !! Gerçek bir oyunda ÇALIŞTIRILARAK TEST EDİLMEDİ.
// =====================================================================
;(function () {
  var AYAR = {
    LISANS: 5000,          // spur, hazineye
    SERMAYE: 20000,        // spur, bankanın hesabına kilitli
    HAREKET_MAX: 50,
    GECMIS_MAX: 20,        // müşteri başına defter geçmişi
    DUYURU_MAX: 200,
    KART: 'numismatics:green_card'
  }
  var HAZINE_UUID = '5f0c2d1e-7a3b-4e9c-8d6f-1b2a3c4d5e6f'
  var JUUID = Java.loadClass('java.util.UUID')
  var Numismatics = Java.loadClass('dev.ithundxr.createnumismatics.Numismatics')
  var ReasonHolder = Java.loadClass('dev.ithundxr.createnumismatics.content.backend.ReasonHolder')
  var BankType = Java.loadClass('dev.ithundxr.createnumismatics.content.backend.BankAccount$Type')
  var CardItem = Java.loadClass('dev.ithundxr.createnumismatics.content.bank.CardItem')
  var BankaKilit = null
  try { BankaKilit = Java.loadClass('tr.sunucu.piyasa.BankaKilit') } catch (e) { console.warn('[Banka] sunucu_piyasa BankaKilit yok, sermaye kilidi calismaz: ' + e) }

  // ----------------------------- VERİ -----------------------------------
  function yukle(server) {
    var s = server.persistentData.getString('banka_veri')
    var d = null
    if (s) { try { d = JSON.parse(s) } catch (e) { d = null } }
    if (!d || !d.b) d = { b: {} }
    return d
  }
  function kaydet(server, d) { server.persistentData.putString('banka_veri', JSON.stringify(d)) }
  function anahtar(ad) { return String(ad).toLowerCase() }
  function adi(server, uuid) {
    var o = server.playerList.getPlayer(uuid)
    if (o != null) return String(o.username)
    var prof = server.getProfileCache().get(uuid)
    return prof.isPresent() ? String(prof.get().getName()) : String(uuid).substring(0, 8)
  }
  function profil(server, isim) {   // çevrimdışı oyuncu da olabilir
    var o = server.playerList.getPlayerByName(isim)
    if (o != null) return { id: String(o.getUuid()), ad: String(o.username) }
    var prof = server.getProfileCache().get(isim)
    return prof.isPresent() ? { id: String(prof.get().getId()), ad: String(prof.get().getName()) } : null
  }
  function hesap(b) { return Numismatics.BANK.getOrCreateAccount(JUUID.fromString(b.hesap), BankType.BLAZE_BANKER) }
  function kasa(b) { try { return hesap(b).getBalance() } catch (e) { return 0 } }
  function sahipBankasi(d, id) { var k = Object.keys(d.b).filter(function (x) { return d.b[x].sahip === id })[0]; return k ? d.b[k] : null }
  function yetkiliMi(b, id) { return b.sahip === id || (b.calisan || []).indexOf(id) >= 0 }
  function toplamlar(b) {
    var m = 0, k = 0, n = 0
    Object.keys(b.defter || {}).forEach(function (u) { var r = b.defter[u]; m += r.m || 0; k += r.k || 0; if ((r.m || 0) > 0 || (r.k || 0) > 0) n++ })
    return { m: m, k: k, n: n }
  }
  function kilitUygula(b) {
    if (BankaKilit == null) return
    try { BankaKilit.ayarla(b.hesap, b.donuk ? 1000000000 : b.sermaye) } catch (e) { console.warn('[Banka] kilit: ' + e) }
  }
  function tacirMi(server, id) {
    try { var y = JSON.parse(server.persistentData.getString('yetenek_veri') || '{}'); var r = (y.o || {})[id] || {}; return r.meslek === 'tacir' || (r.ekMeslekler || []).indexOf('tacir') >= 0 } catch (e) { return false }
  }
  function hazineyeYatir(server, m, tur, kim) {
    var h = Numismatics.BANK.getOrCreateAccount(JUUID.fromString(HAZINE_UUID), BankType.BLAZE_BANKER)
    h.deposit(m); h.markDirty()
    var s = server.persistentData.getString('hazine_veri')
    var d = null
    if (s) { try { d = JSON.parse(s) } catch (e) { d = null } }
    if (!d) d = {}
    if (!d.gelir) d.gelir = {}
    if (!d.hareket) d.hareket = []
    d.gelir[tur] = (d.gelir[tur] || 0) + m
    d.hareket = d.hareket.concat([{ t: Date.now(), tur: tur, m: m, k: kim }]).slice(-500)
    server.persistentData.putString('hazine_veri', JSON.stringify(d))
  }
  function hareketEkle(b, m, bakiye, kim) {
    b.hareket = (b.hareket || []).concat([{ t: Date.now(), m: m, b: bakiye, kim: kim }]).slice(-AYAR.HAREKET_MAX)
  }
  function para(n) { return String(Math.floor(n)).replace(/\B(?=(\d{3})+(?!\d))/g, '.') + ' spur' }
  // Transfer günlüğü: 'transfer_veri' = { o: { uuid: [ {t, y:'g'(giden)|'a'(gelen), k: karşı taraf, m, h: harç} ] } } (son 40)
  function transferKaydi(server, uuidStr, e) {
    var s = server.persistentData.getString('transfer_veri')
    var d = null
    if (s) { try { d = JSON.parse(s) } catch (x) { d = null } }
    if (!d || !d.o) d = { o: {} }
    d.o[uuidStr] = (d.o[uuidStr] || []).concat([e]).slice(-40)
    server.persistentData.putString('transfer_veri', JSON.stringify(d))
  }
  function oran(b) { var t = toplamlar(b); return t.m > 0 ? Math.round(kasa(b) / t.m * 100) + '%' : '-' }
  function zaman(t) { var d = new Date(t); var i = function (n) { return (n < 10 ? '0' : '') + n }; return i(d.getDate()) + '.' + i(d.getMonth() + 1) + ' ' + i(d.getHours()) + ':' + i(d.getMinutes()) }

  // ----------------------------- HAREKET TAKİBİ ---------------------------
  // Her 5 sn: bankanın hesabı değiştiyse farkı döküme yaz. Kim: o anda bu hesabın Bank Terminal
  // ekranı açık olan oyuncu(lar); yoksa kart ödemesi / aktarım / Vendor ("dış işlem").
  function ekranAcanlar(server, hesapId) {
    var liste = []
    var oyuncular = server.playerList.getPlayers().toArray()
    for (var i = 0; i < oyuncular.length; i++) {
      try {
        var m = oyuncular[i].containerMenu
        var ch = m == null ? null : m.contentHolder
        if (ch != null && ch.id != null && String(ch.id) === hesapId) liste.push(String(oyuncular[i].username))
      } catch (e) { }
    }
    return liste
  }
  ServerEvents.tick(function (event) {
    var server = event.server
    if (server.tickCount % 100 !== 60) return
    try {
      var d = yukle(server)
      var degisti = false
      Object.keys(d.b).forEach(function (k) {
        var b = d.b[k]
        var bal = kasa(b)
        if (b.son == null) { b.son = bal; degisti = true }
        if (bal !== b.son) {
          var acan = ekranAcanlar(server, b.hesap)
          hareketEkle(b, bal - b.son, bal, acan.length ? acan.join(', ') : 'dış işlem (kart/aktarım/Vendor)')
          b.son = bal
          degisti = true
        }
        if (server.tickCount % 1200 === 60) kilitUygula(b)   // dakikada bir kilidi tazele
      })
      if (degisti) kaydet(server, d)
    } catch (err) { console.error('[Banka] takip hatasi: ' + err) }
  })
  ServerEvents.loaded(function (event) {
    try { var d = yukle(event.server); Object.keys(d.b).forEach(function (k) { kilitUygula(d.b[k]) }) } catch (err) { console.error('[Banka] kilit yukleme: ' + err) }
  })

  // ----------------------------- KOMUTLAR ---------------------------------
  ServerEvents.commandRegistry(function (event) {
    var Commands = event.commands
    var Arguments = event.arguments
    function oyuncu(ctx) { var p = ctx.source.player; if (p == null) ctx.source.sendSystemMessage(Text.ofString('Oyun içinden kullan.')); return p }
    function bul(d, ad) { return d.b[anahtar(ad)] || null }
    function benimki(p, d) { var b = sahipBankasi(d, String(p.getUuid())); if (!b) p.tell(Text.red(Text.ofString('Bankan yok. Kurmak: /banka kur <ad> (sadece Tacir)'))); return b }
    function secili(p, d, ad) {
      if (ad) { var b = bul(d, ad); if (!b) p.tell(Text.red(Text.ofString('Böyle bir banka yok: ' + ad))); return b }
      var s = String(p.persistentData.getString('banka_secili') || '')
      var b2 = s ? d.b[s] : null
      if (!b2) b2 = sahipBankasi(d, String(p.getUuid()))
      if (!b2) p.tell(Text.red(Text.ofString('Banka adı yaz: /banka bilgi <ad>  (liste: /banka liste)')))
      return b2
    }
    function bilgiYaz(p, b) {
      var t = toplamlar(b)
      p.tell(Text.gold(Text.ofString('=== ' + b.ad + ' Bankası · sahibi ' + adi(p.server, JUUID.fromString(b.sahip)) + (b.donuk ? ' · DONDURULDU' : '') + ' ===')))
      p.tell(Text.ofString('Kasa: ' + para(kasa(b)) + ' (kilitli sermaye ' + para(b.sermaye) + ') | Defter: mevduat ' + para(t.m) + ', verilen kredi ' + para(t.k) +
        ', ' + t.n + ' müşteri | Kasa/mevduat: ' + oran(b)))
      if (b.duyuru) p.tell(Text.aqua(Text.ofString('Duyuru: ' + b.duyuru)))
      var r = (b.defter || {})[String(p.getUuid())]
      if (r) p.tell(Text.green(Text.ofString('Senin satırın: mevduat ' + para(r.m || 0) + ', kredi borcu ' + para(r.k || 0) + '  (geçmiş: /banka defterim ' + b.ad + ')')))
    }

    var defterAlan = function (alan) {
      return Commands.argument('miktar', Arguments.INTEGER.create(event))
        .executes(function (ctx) { return defterYaz(ctx, alan, '') })
        .then(Commands.argument('not', Arguments.GREEDY_STRING.create(event))
          .executes(function (ctx) { return defterYaz(ctx, alan, String(Arguments.GREEDY_STRING.getResult(ctx, 'not'))) }))
    }
    function defterYaz(ctx, alan, not) {
      var p = oyuncu(ctx); if (p == null) return 0
      var server = p.server
      var d = yukle(server)
      var id = String(p.getUuid())
      var b = sahipBankasi(d, id)
      if (!b) b = Object.keys(d.b).map(function (k) { return d.b[k] }).filter(function (x) { return yetkiliMi(x, id) })[0]
      if (!b) { p.tell(Text.red(Text.ofString('Defter yazmak için bir bankanın sahibi veya çalışanı olmalısın.'))); return 0 }
      var isim = String(Arguments.WORD.getResult(ctx, 'musteri'))
      var m = profil(server, isim)
      if (!m) { p.tell(Text.red(Text.ofString('Oyuncu bulunamadı: ' + isim))); return 0 }
      var deger = Arguments.INTEGER.getResult(ctx, 'miktar')
      if (deger < 0 || deger > 1000000000) { p.tell(Text.red(Text.ofString('Miktar 0 veya daha büyük olmalı.'))); return 0 }
      if (!b.defter) b.defter = {}
      var r = b.defter[m.id] || (b.defter[m.id] = { ad: m.ad, m: 0, k: 0, g: [] })
      var anahtarAlan = alan === 'mevduat' ? 'm' : 'k'
      var eski = r[anahtarAlan] || 0
      r[anahtarAlan] = deger
      r.ad = m.ad
      r.g = (r.g || []).concat([{ t: Date.now(), a: alan, e: eski, y: deger, n: String(not).substring(0, 80), kim: String(p.username) }]).slice(-AYAR.GECMIS_MAX)
      kaydet(server, d)
      p.tell(Text.green(Text.ofString(b.ad + ' defteri · ' + m.ad + ' ' + alan + ': ' + para(eski) + ' → ' + para(deger))))
      var mo = server.playerList.getPlayer(JUUID.fromString(m.id))
      if (mo != null) mo.tell(Text.ofString('[' + b.ad + ' Bankası] defterindeki ' + alan + ': ' + para(eski) + ' → ' + para(deger) + (not ? ' (' + not + ')' : '') + ' · ' + p.username))
      return 1
    }

    event.register(Commands.literal('banka')
      .executes(function (ctx) { var p = oyuncu(ctx); if (p == null) return 0; var d = yukle(p.server); var b = secili(p, d, null); if (b) bilgiYaz(p, b); return 1 })
      // Kurulum
      .then(Commands.literal('kur').then(Commands.argument('ad', Arguments.WORD.create(event)).executes(function (ctx) {
        var p = oyuncu(ctx); if (p == null) return 0
        var server = p.server
        var id = String(p.getUuid())
        var ad = String(Arguments.WORD.getResult(ctx, 'ad'))
        if (!/^[A-Za-z0-9_]{3,16}$/.test(ad)) { p.tell(Text.red(Text.ofString('Banka adı 3-16 harf/rakam/_ olmalı.'))); return 0 }
        if (!tacirMi(server, id)) { p.tell(Text.red(Text.ofString('Banka sadece Tacir mesleğindekiler kurabilir (/meslek sec tacir).'))); return 0 }
        var d = yukle(server)
        if (sahipBankasi(d, id)) { p.tell(Text.red(Text.ofString('Zaten bir bankan var.'))); return 0 }
        if (bul(d, ad)) { p.tell(Text.red(Text.ofString('Bu adda bir banka var.'))); return 0 }
        var toplam = AYAR.LISANS + AYAR.SERMAYE
        var sh = Numismatics.BANK.getAccount(p.getUuid())
        if (!sh || sh.getBalance() < toplam) { p.tell(Text.red(Text.ofString('Bankanda ' + para(toplam) + ' olmalı (lisans ' + para(AYAR.LISANS) + ' + kilitli sermaye ' + para(AYAR.SERMAYE) + ').'))); return 0 }
        if (!sh.deduct(toplam, ReasonHolder.IGNORED)) { p.tell(Text.red(Text.ofString('Para kesilemedi.'))); return 0 }
        sh.markDirty()
        hazineyeYatir(server, AYAR.LISANS, 'banka_lisans', String(p.username) + ' (' + ad + ')')
        var b = { ad: ad, sahip: id, hesap: String(JUUID.randomUUID()), sermaye: AYAR.SERMAYE, kur: Date.now(), duyuru: '', donuk: false, calisan: [], defter: {}, hareket: [] }
        var h = hesap(b)
        h.setLabel(ad + ' Bankası')
        h.updateTrustList(function (liste) { if (!liste.contains(p.getUuid())) liste.add(p.getUuid()) })
        h.deposit(AYAR.SERMAYE); h.markDirty()
        b.son = h.getBalance()
        hareketEkle(b, AYAR.SERMAYE, b.son, 'kuruluş sermayesi')
        d.b[anahtar(ad)] = b
        kaydet(server, d)
        kilitUygula(b)
        p.give(CardItem.set(Item.of(AYAR.KART), JUUID.fromString(b.hesap)).withCustomName(Text.ofString(ad + ' Bankası Kartı').green()))
        p.tell(Text.green(Text.ofString(ad + ' Bankası kuruldu. Kart verildi: Bank Terminal\'e kartla sağ tıkla. ' + para(AYAR.SERMAYE) + ' sermaye kilitli (çekilemez). Defter: /banka defter <oyuncu> mevduat|kredi <miktar> [not]')))
        server.tell(Text.gold(Text.ofString('[Banka] ' + p.username + ', ' + ad + ' Bankası\'nı kurdu.')))
        return 1
      })))
      // Görüntüleme (herkes)
      .then(Commands.literal('liste').executes(function (ctx) {
        var p = oyuncu(ctx); if (p == null) return 0
        var d = yukle(p.server)
        var ks = Object.keys(d.b)
        if (!ks.length) { p.tell(Text.ofString('Henüz banka yok.')); return 1 }
        ks.forEach(function (k) { var b = d.b[k]; var t = toplamlar(b); p.tell(Text.ofString('• ' + b.ad + ' · ' + adi(p.server, JUUID.fromString(b.sahip)) + ' · kasa ' + para(kasa(b)) + ' · mevduat ' + para(t.m) + ' · oran ' + oran(b) + (b.donuk ? ' · DONUK' : ''))) })
        return 1
      }))
      .then(Commands.literal('bilgi')
        .executes(function (ctx) { var p = oyuncu(ctx); if (p == null) return 0; var b = secili(p, yukle(p.server), null); if (b) bilgiYaz(p, b); return b ? 1 : 0 })
        .then(Commands.argument('ad', Arguments.WORD.create(event)).executes(function (ctx) {
          var p = oyuncu(ctx); if (p == null) return 0
          var b = secili(p, yukle(p.server), String(Arguments.WORD.getResult(ctx, 'ad'))); if (b) bilgiYaz(p, b); return b ? 1 : 0
        })))
      // Menüde gösterilecek bankayı seç
      .then(Commands.literal('sec').then(Commands.argument('ad', Arguments.WORD.create(event)).executes(function (ctx) {
        var p = oyuncu(ctx); if (p == null) return 0
        var d = yukle(p.server)
        var b = bul(d, String(Arguments.WORD.getResult(ctx, 'ad')))
        if (!b) { p.tell(Text.red(Text.ofString('Böyle bir banka yok.'))); return 0 }
        p.persistentData.putString('banka_secili', anahtar(b.ad))
        p.tell(Text.ofString('Menüde gösterilen banka: ' + b.ad))
        return 1
      })))
      .then(Commands.literal('hareket')
        .executes(function (ctx) { return hareketYaz(ctx, null) })
        .then(Commands.argument('ad', Arguments.WORD.create(event)).executes(function (ctx) { return hareketYaz(ctx, String(Arguments.WORD.getResult(ctx, 'ad'))) })))
      .then(Commands.literal('defterim')
        .executes(function (ctx) { return defterim(ctx, null) })
        .then(Commands.argument('ad', Arguments.WORD.create(event)).executes(function (ctx) { return defterim(ctx, String(Arguments.WORD.getResult(ctx, 'ad'))) })))
      // Bankacı
      .then(Commands.literal('defter').then(Commands.argument('musteri', Arguments.WORD.create(event))
        .then(Commands.literal('mevduat').then(defterAlan('mevduat')))
        .then(Commands.literal('kredi').then(defterAlan('kredi')))))
      .then(Commands.literal('duyuru').then(Commands.argument('metin', Arguments.GREEDY_STRING.create(event)).executes(function (ctx) {
        var p = oyuncu(ctx); if (p == null) return 0
        var d = yukle(p.server); var b = benimki(p, d); if (!b) return 0
        b.duyuru = String(Arguments.GREEDY_STRING.getResult(ctx, 'metin')).substring(0, AYAR.DUYURU_MAX)
        kaydet(p.server, d)
        p.tell(Text.green(Text.ofString('Duyuru güncellendi.')))
        return 1
      })))
      .then(Commands.literal('kart').executes(function (ctx) {
        var p = oyuncu(ctx); if (p == null) return 0
        var d = yukle(p.server)
        var id = String(p.getUuid())
        var b = sahipBankasi(d, id) || Object.keys(d.b).map(function (k) { return d.b[k] }).filter(function (x) { return yetkiliMi(x, id) })[0]
        if (!b) { p.tell(Text.red(Text.ofString('Bir bankanın sahibi veya çalışanı değilsin.'))); return 0 }
        p.give(CardItem.set(Item.of(AYAR.KART), JUUID.fromString(b.hesap)).withCustomName(Text.ofString(b.ad + ' Bankası Kartı').green()))
        p.tell(Text.ofString('Kart verildi. Karta shift+sağ tıklama yapma, bağlantısı silinir.'))
        return 1
      }))
      .then(Commands.literal('calisan')
        .then(Commands.literal('ekle').then(Commands.argument('oyuncu', Arguments.PLAYER.create(event)).executes(function (ctx) { return calisan(ctx, true) })))
        .then(Commands.literal('cikar').then(Commands.argument('oyuncu', Arguments.PLAYER.create(event)).executes(function (ctx) { return calisan(ctx, false) }))))
      .then(Commands.literal('kapat').executes(function (ctx) {
        var p = oyuncu(ctx); if (p == null) return 0
        var server = p.server
        var d = yukle(server); var b = benimki(p, d); if (!b) return 0
        if (b.donuk) { p.tell(Text.red(Text.ofString('Bankan dondurulmuş; kapatmak için yöneticiyle konuş.'))); return 0 }
        var t = toplamlar(b)
        if (t.m > 0) { p.tell(Text.red(Text.ofString('Defterde ' + para(t.m) + ' mevduat var. Önce müşterilere ödeyip defteri sıfırla.'))); return 0 }
        var h = hesap(b)
        if (BankaKilit != null) BankaKilit.ayarla(b.hesap, 0)
        var tutar = h.getBalance()
        if (tutar > 0 && h.deduct(tutar, ReasonHolder.IGNORED)) {
          h.markDirty()
          var sh = Numismatics.BANK.getOrCreateAccount(p.getUuid(), BankType.PLAYER); sh.deposit(tutar); sh.markDirty()
        }
        h.setLabel('Kapalı banka (' + b.ad + ')')
        h.updateTrustList(function (liste) { liste.clear() })
        h.markDirty()
        delete d.b[anahtar(b.ad)]
        kaydet(server, d)
        p.tell(Text.green(Text.ofString(b.ad + ' Bankası kapandı; kasadaki ' + para(tutar) + ' bankana aktarıldı.')))
        server.tell(Text.gold(Text.ofString('[Banka] ' + b.ad + ' Bankası kapandı.')))
        return 1
      }))
      // ---- 2026-11-25 (kullanıcı): menüden para transferi, mevduat ve bankadan kredi ----
      // Oyuncudan oyuncuya para: /banka gonder <oyuncu> <miktar>  (harç: /vergi oran transfer, hazineye)
      .then(Commands.literal('gonder').then(Commands.argument('oyuncu', Arguments.WORD.create(event))
        .then(Commands.argument('miktar', Arguments.INTEGER.create(event)).executes(function (ctx) { return paraGonder(ctx) }))))
      // Mevduat: /banka yatir <banka> <miktar>  /banka cek <banka> <miktar>  (defter otomatik güncellenir)
      .then(Commands.literal('yatir').then(Commands.argument('ad', Arguments.WORD.create(event))
        .then(Commands.argument('miktar', Arguments.INTEGER.create(event)).executes(function (ctx) { return mevduat(ctx, true) }))))
      .then(Commands.literal('cek').then(Commands.argument('ad', Arguments.WORD.create(event))
        .then(Commands.argument('miktar', Arguments.INTEGER.create(event)).executes(function (ctx) { return mevduat(ctx, false) }))))
      // Kredi: müşteri başvurur, bankacı onaylar (para bankanın kasasından gelir, deftere faiziyle yazılır)
      .then(Commands.literal('basvur').then(Commands.argument('ad', Arguments.WORD.create(event))
        .then(Commands.argument('miktar', Arguments.INTEGER.create(event)).executes(function (ctx) { return basvur(ctx) }))))
      .then(Commands.literal('onayla').then(Commands.argument('musteri', Arguments.WORD.create(event)).executes(function (ctx) { return basvuruKarar(ctx, true) })))
      .then(Commands.literal('reddet').then(Commands.argument('musteri', Arguments.WORD.create(event)).executes(function (ctx) { return basvuruKarar(ctx, false) })))
      .then(Commands.literal('ode').then(Commands.argument('ad', Arguments.WORD.create(event))
        .then(Commands.argument('miktar', Arguments.INTEGER.create(event)).executes(function (ctx) { return krediOde(ctx) }))))
      .then(Commands.literal('faiz').then(Commands.argument('yuzde', Arguments.INTEGER.create(event)).executes(function (ctx) {
        var p = oyuncu(ctx); if (p == null) return 0
        var d = yukle(p.server); var b = benimki(p, d); if (!b) return 0
        var f = Arguments.INTEGER.getResult(ctx, 'yuzde')
        if (f < 0 || f > 100) { p.tell(Text.red(Text.ofString('Faiz %0 ile %100 arasında olmalı.'))); return 0 }
        b.faiz = f
        kaydet(p.server, d)
        p.tell(Text.green(Text.ofString(b.ad + ' kredi faizi: %' + f + ' (onaylanan kredinin üstüne bir kez eklenir).')))
        return 1
      })))
      // OP: dondur / çöz (dolandırıcılık şüphesinde kasa tamamen kilitlenir)
      .then(Commands.literal('dondur').requires(function (s) { return s.hasPermission(2) })
        .then(Commands.argument('ad', Arguments.WORD.create(event)).executes(function (ctx) { return dondur(ctx, true) })))
      .then(Commands.literal('coz').requires(function (s) { return s.hasPermission(2) })
        .then(Commands.argument('ad', Arguments.WORD.create(event)).executes(function (ctx) { return dondur(ctx, false) }))))

    // ----------------------------- TRANSFER / MEVDUAT / KREDİ ----------------
    function oyuncuHesap(uuid) { return Numismatics.BANK.getOrCreateAccount(uuid, BankType.PLAYER) }
    function aktar(kaynak, hedef, m) {
      if (!kaynak.deduct(m, ReasonHolder.IGNORED)) return false
      kaynak.markDirty(); hedef.deposit(m); hedef.markDirty()
      return true
    }
    function harcOran(server) { try { return global.vergiOrani ? Number(global.vergiOrani(server, 'transfer')) : 1 } catch (e) { return 1 } }
    function bildir(server, uuidStr, mesaj) { var o = server.playerList.getPlayer(JUUID.fromString(uuidStr)); if (o != null) o.tell(Text.ofString(mesaj)) }
    function defterSatiri(b, m) { if (!b.defter) b.defter = {}; return b.defter[m.id] || (b.defter[m.id] = { ad: m.ad, m: 0, k: 0, g: [] }) }
    function gecmis(r, alan, eski, yeni, not, kim) { r.g = (r.g || []).concat([{ t: Date.now(), a: alan, e: eski, y: yeni, n: not, kim: kim }]).slice(-AYAR.GECMIS_MAX) }
    function kasaHareketi(b, m, kim) { var bal = kasa(b); hareketEkle(b, m, bal, kim); b.son = bal }

    function paraGonder(ctx) {
      var p = oyuncu(ctx); if (p == null) return 0
      var server = p.server
      var hedef = profil(server, String(Arguments.WORD.getResult(ctx, 'oyuncu')))
      var m = Arguments.INTEGER.getResult(ctx, 'miktar')
      if (!hedef) { p.tell(Text.red(Text.ofString('Oyuncu bulunamadı.'))); return 0 }
      if (hedef.id === String(p.getUuid())) { p.tell(Text.red(Text.ofString('Kendine para gönderemezsin.'))); return 0 }
      if (m < 1) { p.tell(Text.red(Text.ofString('Miktar en az 1 olmalı.'))); return 0 }
      var harc = Math.floor(m * harcOran(server) / 100)
      var sh = oyuncuHesap(p.getUuid())
      if (sh.getBalance() < m + harc) { p.tell(Text.red(Text.ofString('Bakiye yetersiz: ' + para(m) + ' + harç ' + para(harc) + ' gerekli.'))); return 0 }
      if (!aktar(sh, oyuncuHesap(JUUID.fromString(hedef.id)), m)) { p.tell(Text.red(Text.ofString('Aktarım yapılamadı.'))); return 0 }
      if (harc > 0 && sh.deduct(harc, ReasonHolder.IGNORED)) { sh.markDirty(); hazineyeYatir(server, harc, 'harc', String(p.username) + ' (transfer)') }
      transferKaydi(server, String(p.getUuid()), { t: Date.now(), y: 'g', k: hedef.ad, m: m, h: harc })
      transferKaydi(server, hedef.id, { t: Date.now(), y: 'a', k: String(p.username), m: m, h: 0 })
      p.tell(Text.green(Text.ofString(hedef.ad + ' oyuncusuna ' + para(m) + ' gönderildi' + (harc > 0 ? ' (harç ' + para(harc) + ')' : '') + '.')))
      bildir(server, hedef.id, '[Banka] ' + p.username + ' sana ' + para(m) + ' gönderdi.')
      return 1
    }

    function mevduat(ctx, yatir) {
      var p = oyuncu(ctx); if (p == null) return 0
      var server = p.server
      var d = yukle(server)
      var b = bul(d, String(Arguments.WORD.getResult(ctx, 'ad')))
      if (!b) { p.tell(Text.red(Text.ofString('Böyle bir banka yok.'))); return 0 }
      if (b.donuk) { p.tell(Text.red(Text.ofString(b.ad + ' Bankası dondurulmuş.'))); return 0 }
      var m = Arguments.INTEGER.getResult(ctx, 'miktar')
      if (m < 1) { p.tell(Text.red(Text.ofString('Miktar en az 1 olmalı.'))); return 0 }
      var ben = { id: String(p.getUuid()), ad: String(p.username) }
      var r = defterSatiri(b, ben)
      var eski = r.m || 0
      if (yatir) {
        if (!aktar(oyuncuHesap(p.getUuid()), hesap(b), m)) { p.tell(Text.red(Text.ofString('Bakiye yetersiz.'))); return 0 }
        r.m = eski + m
        kasaHareketi(b, m, ben.ad + ' (mevduat yatırdı)')
      } else {
        if (eski < m) { p.tell(Text.red(Text.ofString('Bu bankadaki mevduatın ' + para(eski) + '; daha fazlasını çekemezsin.'))); return 0 }
        if (!aktar(hesap(b), oyuncuHesap(p.getUuid()), m)) { p.tell(Text.red(Text.ofString(b.ad + ' kasasında yeterli serbest para yok (kilitli sermaye çekilemez). Bankacıyla konuş.'))); return 0 }
        r.m = eski - m
        kasaHareketi(b, -m, ben.ad + ' (mevduat çekti)')
      }
      r.ad = ben.ad
      gecmis(r, 'mevduat', eski, r.m, yatir ? 'yatırma' : 'çekme', ben.ad)
      kaydet(server, d)
      p.tell(Text.green(Text.ofString(b.ad + ' Bankası: ' + para(m) + (yatir ? ' yatırıldı' : ' çekildi') + '. Mevduatın: ' + para(r.m))))
      bildir(server, b.sahip, '[' + b.ad + '] ' + ben.ad + ' ' + para(m) + (yatir ? ' mevduat yatırdı.' : ' mevduat çekti.'))
      return 1
    }

    function basvur(ctx) {
      var p = oyuncu(ctx); if (p == null) return 0
      var server = p.server
      var d = yukle(server)
      var b = bul(d, String(Arguments.WORD.getResult(ctx, 'ad')))
      if (!b) { p.tell(Text.red(Text.ofString('Böyle bir banka yok.'))); return 0 }
      if (b.sahip === String(p.getUuid())) { p.tell(Text.red(Text.ofString('Kendi bankana başvuramazsın.'))); return 0 }
      var m = Arguments.INTEGER.getResult(ctx, 'miktar')
      if (m < 100 || m > 10000000) { p.tell(Text.red(Text.ofString('Kredi 100 ile 10.000.000 spur arasında olmalı.'))); return 0 }
      if (!b.basvuru) b.basvuru = {}
      b.basvuru[String(p.getUuid())] = { ad: String(p.username), m: m, t: Date.now() }
      kaydet(server, d)
      var f = b.faiz == null ? 10 : b.faiz
      p.tell(Text.green(Text.ofString(b.ad + ' Bankası\'na ' + para(m) + ' kredi başvurusu yapıldı (faiz %' + f + ', geri ödeme ' + para(Math.ceil(m * (1 + f / 100))) + '). Bankacı onaylayınca para bankana gelir.')))
      var yetkililer = [b.sahip].concat(b.calisan || [])
      yetkililer.forEach(function (u) { bildir(server, u, '[' + b.ad + '] ' + p.username + ' ' + para(m) + ' kredi başvurusu yaptı. Menü > Banka > Bankacı') })
      return 1
    }

    function basvuruKarar(ctx, onay) {
      var p = oyuncu(ctx); if (p == null) return 0
      var server = p.server
      var d = yukle(server)
      var id = String(p.getUuid())
      var b = sahipBankasi(d, id) || Object.keys(d.b).map(function (k) { return d.b[k] }).filter(function (x) { return yetkiliMi(x, id) })[0]
      if (!b) { p.tell(Text.red(Text.ofString('Bir bankanın sahibi veya çalışanı değilsin.'))); return 0 }
      var m = profil(server, String(Arguments.WORD.getResult(ctx, 'musteri')))
      var bs = m && b.basvuru ? b.basvuru[m.id] : null
      if (!bs) { p.tell(Text.red(Text.ofString('Bu oyuncunun bekleyen başvurusu yok.'))); return 0 }
      if (!onay) {
        delete b.basvuru[m.id]
        kaydet(server, d)
        p.tell(Text.ofString(m.ad + ' başvurusu reddedildi.'))
        bildir(server, m.id, '[' + b.ad + '] ' + para(bs.m) + ' kredi başvurun reddedildi.')
        return 1
      }
      if (b.donuk) { p.tell(Text.red(Text.ofString('Banka dondurulmuş.'))); return 0 }
      if (!aktar(hesap(b), oyuncuHesap(JUUID.fromString(m.id)), bs.m)) { p.tell(Text.red(Text.ofString('Kasada yeterli serbest para yok (kilitli sermaye kullanılamaz).'))); return 0 }
      var f = b.faiz == null ? 10 : b.faiz
      var borc = Math.ceil(bs.m * (1 + f / 100))
      var r = defterSatiri(b, m)
      var eski = r.k || 0
      r.k = eski + borc
      r.ad = m.ad
      gecmis(r, 'kredi', eski, r.k, para(bs.m) + ' kredi, faiz %' + f, String(p.username))
      kasaHareketi(b, -bs.m, m.ad + ' (kredi verildi, onay ' + p.username + ')')
      delete b.basvuru[m.id]
      kaydet(server, d)
      p.tell(Text.green(Text.ofString(m.ad + ' kredisi onaylandı: ' + para(bs.m) + ' verildi, deftere ' + para(borc) + ' borç yazıldı.')))
      bildir(server, m.id, '[' + b.ad + '] ' + para(bs.m) + ' kredin onaylandı ve bankana yattı. Geri ödenecek: ' + para(borc) + ' (Menü > Banka > Kredi & Borç)')
      return 1
    }

    function krediOde(ctx) {
      var p = oyuncu(ctx); if (p == null) return 0
      var server = p.server
      var d = yukle(server)
      var b = bul(d, String(Arguments.WORD.getResult(ctx, 'ad')))
      if (!b) { p.tell(Text.red(Text.ofString('Böyle bir banka yok.'))); return 0 }
      var r = (b.defter || {})[String(p.getUuid())]
      if (!r || !(r.k > 0)) { p.tell(Text.red(Text.ofString(b.ad + ' Bankası\'na kredi borcun yok.'))); return 0 }
      var m = Math.min(Arguments.INTEGER.getResult(ctx, 'miktar'), r.k)
      if (m < 1) { p.tell(Text.red(Text.ofString('Miktar en az 1 olmalı.'))); return 0 }
      if (!aktar(oyuncuHesap(p.getUuid()), hesap(b), m)) { p.tell(Text.red(Text.ofString('Bakiye yetersiz.'))); return 0 }
      var eski = r.k
      r.k = eski - m
      gecmis(r, 'kredi', eski, r.k, 'geri ödeme', String(p.username))
      kasaHareketi(b, m, String(p.username) + ' (kredi ödemesi)')
      kaydet(server, d)
      p.tell(Text.green(Text.ofString(b.ad + ' Bankası\'na ' + para(m) + ' ödendi. Kalan borç: ' + para(r.k))))
      bildir(server, b.sahip, '[' + b.ad + '] ' + p.username + ' ' + para(m) + ' kredi ödedi (kalan ' + para(r.k) + ').')
      return 1
    }

    function hareketYaz(ctx, ad) {
      var p = oyuncu(ctx); if (p == null) return 0
      var b = secili(p, yukle(p.server), ad); if (!b) return 0
      var l = (b.hareket || []).slice(-10).reverse()
      p.tell(Text.gold(Text.ofString('=== ' + b.ad + ' Bankası · son hareketler ===')))
      if (!l.length) p.tell(Text.ofString('Henüz hareket yok.'))
      l.forEach(function (x) { p.tell(Text.ofString(zaman(x.t) + '  ' + (x.m >= 0 ? '+' : '') + para(x.m) + '  → kasa ' + para(x.b) + '  · ' + x.kim)) })
      return 1
    }
    function defterim(ctx, ad) {
      var p = oyuncu(ctx); if (p == null) return 0
      var b = secili(p, yukle(p.server), ad); if (!b) return 0
      var r = (b.defter || {})[String(p.getUuid())]
      if (!r) { p.tell(Text.ofString(b.ad + ' defterinde kaydın yok.')); return 1 }
      p.tell(Text.gold(Text.ofString('=== ' + b.ad + ' defteri · ' + r.ad + ' === mevduat ' + para(r.m || 0) + ', kredi borcu ' + para(r.k || 0))))
      ;(r.g || []).slice(-10).reverse().forEach(function (x) { p.tell(Text.ofString(zaman(x.t) + '  ' + x.a + ': ' + para(x.e) + ' → ' + para(x.y) + (x.n ? '  (' + x.n + ')' : '') + '  · ' + x.kim)) })
      return 1
    }
    function calisan(ctx, ekle) {
      var p = oyuncu(ctx); if (p == null) return 0
      var d = yukle(p.server); var b = benimki(p, d); if (!b) return 0
      var h = Arguments.PLAYER.getResult(ctx, 'oyuncu')
      var u = h.getUuid()
      var hid = String(u)
      b.calisan = (b.calisan || []).filter(function (x) { return x !== hid })
      if (ekle) b.calisan.push(hid)
      hesap(b).updateTrustList(function (liste) { if (ekle) { if (!liste.contains(u)) liste.add(u) } else liste.remove(u) })
      hesap(b).markDirty()
      kaydet(p.server, d)
      p.tell(Text.ofString(String(h.username) + (ekle ? ' artık çalışan: kart kullanabilir ve defter yazabilir (/banka kart).' : ' çalışanlıktan çıkarıldı.')))
      h.tell(Text.ofString(b.ad + ' Bankası: ' + (ekle ? 'çalışan oldun (/banka kart ile kart al).' : 'çalışanlıktan çıkarıldın.')))
      return 1
    }
    function dondur(ctx, durum) {
      var d = yukle(ctx.source.server)
      var b = bul(d, String(Arguments.WORD.getResult(ctx, 'ad')))
      if (!b) { ctx.source.sendSystemMessage(Text.ofString('Böyle bir banka yok.')); return 0 }
      b.donuk = durum
      kaydet(ctx.source.server, d)
      kilitUygula(b)
      ctx.source.server.tell(Text.gold(Text.ofString('[Banka] ' + b.ad + ' Bankası ' + (durum ? 'yönetim tarafından DONDURULDU (kasadan para çıkamaz).' : 'çözüldü.'))))
      return 1
    }
  })

  console.info('[Banka] yuklendi: lisans ' + AYAR.LISANS + ', kilitli sermaye ' + AYAR.SERMAYE)
})()
