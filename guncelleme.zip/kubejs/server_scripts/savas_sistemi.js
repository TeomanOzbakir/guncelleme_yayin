// =====================================================================
//  SAVAŞ SİSTEMİ  -  kubejs/server_scripts/savas_sistemi.js
//  Hedef: NeoForge 1.21.1 | KubeJS 2101.7.2 | Create Numismatics 1.1.0
//         Open Parties and Claims 0.33.0
//
//  Taraflar: oyuncu bir OPAC partisindeyse PARTİSİ, değilse KENDİSİ.
//
//  - /savas ilan <oyuncu>: o oyuncunun tarafına savaş ilan eder. İlan
//    ücreti hazineye gider. Savaş HAZIRLIK_DK sonra başlar, herkese duyurulur.
//    Partide sadece parti sahibi veya yetkilisi ilan edebilir.
//  - Savaş dört yoldan biter:
//      1) Süre dolar (SURE_SAAT)                  -> beraberlik
//      2) İki taraf da /savas baris yazar          -> barış
//      3) Bir taraf /savas teslim yazar            -> teslim olan tazminat öder
//      4) Bir taraf ZAFER_PUANI öldürmeye ulaşır   -> kaybeden tazminat öder
//  - Savaştaki öldürme: ölen normal ölüm vergisini öder, öldürenin
//    tarafına 1 zafer puanı yazılır.
//  - Savaş DIŞI öldürme (hazırlık süresi dahil): ölen hiçbir şey ödemez.
//    Öldüren, ölenin ölüm vergisini (%5) + CINAYET_CEZASI öder.
//    Parası yetmezse bankasında ne varsa kesilir, kalanı borc_kredi.js
//    üzerinden faizli borca yazılır. Para hazineye gider.
//  - İlan ücreti: ILAN_UCRETI + ilan eden tarafın banka toplamının ILAN_ORANI'sı.
//    (Oyuncunun oyuncuyu öldürmediği ölümlerde ölüm vergisini
//     vergi_sistemi.js alır; bu dosya sadece oyuncu-oyuncu ölümlerine bakar.)
//  - Tazminat: kaybedenin liderinden (parti sahibi / oyuncu) kazananın
//    liderine. Para yetmezse ne varsa.
//
//  !! Gerçek bir oyunda ÇALIŞTIRILARAK TEST EDİLMEDİ.
// =====================================================================

;(function () {
  // ----------------------------- AYARLAR -----------------------------
  var SAVAS = {
    ILAN_UCRETI: 5000,        // sabit kısım (spur), ilan edenden hazineye
    ILAN_ORANI: 0.10,         // + ilan eden tarafın banka toplamının bu oranı (partide tüm üyeler)
    HAZIRLIK_DK: 10,          // ilandan sonra savaşın başlaması
    SURE_SAAT: 48,            // savaş bu kadar sürerse beraberlikle biter
    ZAFER_PUANI: 10,          // bu kadar öldürmeye ulaşan taraf kazanır (0 = kapalı)
    TAZMINAT: 3000,           // teslim olan / kaybeden kazanana öder (spur)
    CINAYET_CEZASI: 500,      // savaş dışı öldürmede sabit ceza (spur)
    OLUM_VERGISI_ORAN: 0.05,  // vergi_sistemi.js ile AYNI tutun
    TEKRAR_ILAN_SAAT: 24      // aynı iki taraf arasında savaş bittikten sonra bekleme
  }
  var HAZINE_UUID_STR = '5f0c2d1e-7a3b-4e9c-8d6f-1b2a3c4d5e6f'   // vergi_sistemi.js ile aynı
  var KONTROL_TICK = 1200

  var JUUID = Java.loadClass('java.util.UUID')
  var Numismatics = Java.loadClass('dev.ithundxr.createnumismatics.Numismatics')
  var ReasonHolder = Java.loadClass('dev.ithundxr.createnumismatics.content.backend.ReasonHolder')
  var BankType = Java.loadClass('dev.ithundxr.createnumismatics.content.backend.BankAccount$Type')
  var OpenPACServerAPI = Java.loadClass('xaero.pac.common.server.api.OpenPACServerAPI')
  var HAZINE_UUID = JUUID.fromString(HAZINE_UUID_STR)

  // ----------------------------- VERİ --------------------------------
  function yukle(server) {
    var s = server.persistentData.getString('savas_veri')
    var d = null
    if (s) { try { d = JSON.parse(s) } catch (e) { d = null } }
    if (!d) d = {}
    if (!d.savaslar) d.savaslar = []
    if (!d.gecmis) d.gecmis = []
    if (!d.sayac) d.sayac = 0
    return d
  }
  function kaydet(server, d) { server.persistentData.putString('savas_veri', JSON.stringify(d)) }

  // ----------------------------- BANKA / HAZİNE ----------------------
  function bakiye(uuid) { var h = Numismatics.BANK.getAccount(uuid); return h ? h.getBalance() : 0 }
  function kes(uuid, m) {
    m = Math.floor(m); if (m <= 0) return true
    var h = Numismatics.BANK.getAccount(uuid); if (!h) return false
    var ok = h.deduct(m, ReasonHolder.IGNORED); if (ok) h.markDirty(); return !!ok
  }
  // Yetiyorsa m, yetmiyorsa bakiyenin tamamını keser; kesilen miktarı döner
  function kesEldeki(uuid, m) {
    m = Math.min(Math.floor(m), bakiye(uuid))
    if (m <= 0) return 0
    return kes(uuid, m) ? m : 0
  }
  function yatir(uuid, m, tip) {
    if (m <= 0) return
    var h = Numismatics.BANK.getOrCreateAccount(uuid, tip || BankType.PLAYER)
    h.deposit(m); h.markDirty()
  }
  function ad(server, uuid) {
    var p = server.playerList.getPlayer(uuid)
    if (p != null) return String(p.username)
    var prof = server.getProfileCache().get(uuid)
    return prof.isPresent() ? String(prof.get().getName()) : String(uuid).substring(0, 8)
  }
  function hazineye(server, m, tur, kim) {
    if (m <= 0) return
    yatir(HAZINE_UUID, m, BankType.BLAZE_BANKER)
    var s = server.persistentData.getString('hazine_veri')
    var d = null
    if (s) { try { d = JSON.parse(s) } catch (e) { d = null } }
    if (!d) d = {}
    if (!d.gelir) d.gelir = { arazi: 0, olum: 0, tescil: 0 }
    if (!d.hareket) d.hareket = []
    d.gelir[tur] = (d.gelir[tur] || 0) + m
    d.hareket = d.hareket.concat([{ t: Date.now(), tur: tur, m: m, k: kim }]).slice(-500)
    server.persistentData.putString('hazine_veri', JSON.stringify(d))
  }

  // ----------------------------- TARAFLAR ----------------------------
  function partiYon(server) { return OpenPACServerAPI.get(server).getPartyManager() }
  function taraf(server, uuid) {
    var p = partiYon(server).getPartyByMember(uuid)
    if (p != null) {
      var sahip = p.getOwner()
      return { anahtar: 'parti:' + String(p.getId()), tip: 'parti', id: String(p.getId()),
        ad: String(p.getDefaultName()), lider: sahip ? String(sahip.getUUID()) : String(uuid) }
    }
    return { anahtar: 'oyuncu:' + String(uuid), tip: 'oyuncu', id: String(uuid), ad: ad(server, uuid), lider: String(uuid) }
  }
  // Tarafın banka toplamı: partide tüm üyeler, değilse oyuncunun kendisi
  function tarafServeti(server, t) {
    if (t.tip !== 'parti') return bakiye(JUUID.fromString(t.id))
    var p = partiYon(server).getPartyById(JUUID.fromString(t.id))
    if (p == null) return 0
    var uyeler = p.getMemberInfoStream().toArray()
    var top = 0
    for (var i = 0; i < uyeler.length; i++) top += bakiye(uyeler[i].getUUID())
    return top
  }
  // Ödenemeyen tutarı borc_kredi.js'in kuyruğuna yazar (m = 0 ise sadece kredi notu olayı)
  function borcKuyrugu(server, uuid, m, sebep) {
    var k = []
    try { var s = server.persistentData.getString('borc_kuyruk'); if (s) k = JSON.parse(s) } catch (e) { k = [] }
    k.push({ u: String(uuid), m: m, s: sebep })
    server.persistentData.putString('borc_kuyruk', JSON.stringify(k))
  }

  // ----------------------------- KELLE AVI ---------------------------
  // borc_kredi.js: 7. gününü geçen borçlunun kellesine ödül (borc_durum[uuid].kelle / .odul)
  function borcDurum(server) {
    try { return JSON.parse(server.persistentData.getString('borc_durum') || '{}') } catch (e) { return {} }
  }
  function kelleOde(server, durum, katil, olen) {
    var e = durum[String(olen.getUuid())]
    var h = Numismatics.BANK.getOrCreateAccount(HAZINE_UUID, BankType.BLAZE_BANKER)
    var m = Math.min(Math.floor(e.odul || 0), h.getBalance())
    if (m > 0 && h.deduct(m, ReasonHolder.IGNORED)) { h.markDirty(); yatir(katil.getUuid(), m) } else m = 0
    // Hazine hareketi (gider)
    var s = server.persistentData.getString('hazine_veri')
    var hd = null
    if (s) { try { hd = JSON.parse(s) } catch (x) { hd = null } }
    if (!hd) hd = {}
    if (!hd.gelir) hd.gelir = { arazi: 0, olum: 0, tescil: 0 }
    hd.hareket = (hd.hareket || []).concat([{ t: Date.now(), tur: 'kelle', m: m, k: String(katil.username) + ' > ' + String(olen.username) }]).slice(-500)
    server.persistentData.putString('hazine_veri', JSON.stringify(hd))
    // Ödül borçlunun borcuna eklenir; kelle KELLE_ARA_GUN sonra yeniden açılır (borc_kredi.js)
    borcKuyrugu(server, olen.getUuid(), m, 'kelle')
    e.kelle = false   // aynı dakika içinde ikinci kez ödenmesin
    server.persistentData.putString('borc_durum', JSON.stringify(durum))
    server.tell(Text.gold(Text.ofString('[Kelle Avı] ' + String(katil.username) + ', borçlu ' + String(olen.username) +
      ' oyuncusunun kellesini aldı ve ' + m + ' spur ödül kazandı. Cesedi yağmalanabilir.')))
    if (m <= 0) katil.tell(Text.ofString('Devlet hazinesinde para olmadığı için ödül ödenemedi; yine de ceza almadın.'))
  }
  function liderMi(server, uuid) {
    var p = partiYon(server).getPartyByMember(uuid)
    if (p == null) return true
    var yetkili = p.getStaffInfoStream().toArray()
    for (var i = 0; i < yetkili.length; i++) if (yetkili[i].getUUID().equals(uuid)) return true
    var sahip = p.getOwner()
    return sahip != null && sahip.getUUID().equals(uuid)
  }
  function tarafaYaz(server, t, msg) {
    var c = Text.ofString(msg)
    if (t.tip === 'parti') {
      var p = partiYon(server).getPartyById(JUUID.fromString(t.id))
      if (p != null) { var on = p.getOnlineMemberStream().toArray(); for (var i = 0; i < on.length; i++) on[i].tell(c) }
      return
    }
    var pl = server.playerList.getPlayer(JUUID.fromString(t.id))
    if (pl != null) pl.tell(c)
  }
  function duyur(server, msg) { server.tell(Text.gold(Text.ofString('[Savaş] ' + msg))) }

  // ----------------------------- SAVAŞ YARDIMCILARI -------------------
  function bul(d, k1, k2) {
    for (var i = 0; i < d.savaslar.length; i++) {
      var s = d.savaslar[i]
      if ((s.a.anahtar === k1 && s.b.anahtar === k2) || (s.a.anahtar === k2 && s.b.anahtar === k1)) return s
    }
    return null
  }
  function kalan(ms) {
    var dk = Math.max(0, Math.floor(ms / 60000))
    return Math.floor(dk / 60) + ' saat ' + (dk % 60) + ' dk'
  }
  // Tazminat: kaybedenin liderinden kazananın liderine
  function tazminatOde(server, kaybeden, kazanan) {
    var m = kesEldeki(JUUID.fromString(kaybeden.lider), SAVAS.TAZMINAT)
    yatir(JUUID.fromString(kazanan.lider), m)
    return m
  }
  function bitir(server, d, s, sebep, kazananTaraf) {
    d.savaslar = d.savaslar.filter(function (x) { return x.id !== s.id })
    s.bitis = Date.now(); s.sonuc = sebep
    d.gecmis = d.gecmis.concat([s]).slice(-20)
    var metin = s.a.ad + ' - ' + s.b.ad + ' savaşı bitti: ' + sebep + ' (skor ' + s.skor.a + '-' + s.skor.b + ')'
    if (kazananTaraf) {
      var kaybeden = kazananTaraf === 'a' ? s.b : s.a
      var kazanan = kazananTaraf === 'a' ? s.a : s.b
      var m = tazminatOde(server, kaybeden, kazanan)
      metin += '. Kazanan: ' + kazanan.ad + ', tazminat: ' + m + ' spur'
    }
    duyur(server, metin)
  }

  // ----------------------------- ZAMANLAYICI -------------------------
  ServerEvents.tick(function (event) {
    var server = event.server
    if (server.tickCount % KONTROL_TICK !== 0) return
    try {
      var d = yukle(server)
      var simdi = Date.now()
      var degisti = false
      d.savaslar.slice().forEach(function (s) {
        if (s.durum === 'hazirlik' && simdi >= s.baslangic) {
          s.durum = 'aktif'; degisti = true
          duyur(server, s.a.ad + ' ile ' + s.b.ad + ' arasındaki SAVAŞ BAŞLADI! ' + SAVAS.SURE_SAAT + ' saat sürer' +
            (SAVAS.ZAFER_PUANI > 0 ? ', ' + SAVAS.ZAFER_PUANI + ' öldürmeye ulaşan kazanır.' : '.'))
        } else if (s.durum === 'aktif' && simdi >= s.son) {
          bitir(server, d, s, 'süre doldu, berabere', null); degisti = true
        }
      })
      if (degisti) kaydet(server, d)
    } catch (err) { console.error('[Savas] hata: ' + err) }
  })

  // ----------------------------- ÖLÜMLER -----------------------------
  EntityEvents.death('minecraft:player', function (event) {
    var olen = event.entity
    var katil = event.source.getActual()
    if (!olen || !olen.isPlayer() || katil == null || !katil.isPlayer()) return
    if (katil.getUuid().equals(olen.getUuid())) return
    var server = event.server
    try {
      var d = yukle(server)
      var tk = taraf(server, katil.getUuid())
      var to = taraf(server, olen.getUuid())
      var s = (tk.anahtar !== to.anahtar) ? bul(d, tk.anahtar, to.anahtar) : null
      var olumVergisi = Math.floor(bakiye(olen.getUuid()) * SAVAS.OLUM_VERGISI_ORAN)

      if (s && s.durum === 'aktif') {
        // Savaşta öldürme: ölen normal ölüm vergisini öder, öldürene puan
        if (olumVergisi > 0 && kes(olen.getUuid(), olumVergisi)) {
          hazineye(server, olumVergisi, 'olum', String(olen.username))
          olen.tell(Text.ofString('Ölüm vergisi: bankandan ' + olumVergisi + ' spur kesildi.'))
        }
        var yan = s.a.anahtar === tk.anahtar ? 'a' : 'b'
        s.skor[yan] = (s.skor[yan] || 0) + 1
        var msg = '[Savaş] ' + String(katil.username) + ', ' + String(olen.username) + ' oyuncusunu öldürdü. Skor: ' +
          s.a.ad + ' ' + s.skor.a + ' - ' + s.skor.b + ' ' + s.b.ad
        tarafaYaz(server, s.a, msg); tarafaYaz(server, s.b, msg)
        if (SAVAS.ZAFER_PUANI > 0 && s.skor[yan] >= SAVAS.ZAFER_PUANI) bitir(server, d, s, 'zafer puanına ulaşıldı', yan)
        kaydet(server, d)
        return
      }

      // Kelle avı: 7 gündür borcunu ödemeyen oyuncuyu (kendi partisinden olmayan biri) öldürmek suç değil, ödüllü
      if (tk.anahtar !== to.anahtar) {
        var durum = borcDurum(server)
        var kd = durum[String(olen.getUuid())]
        if (kd && kd.kelle) { kelleOde(server, durum, katil, olen); return }
      }

      // Savaş dışı öldürme: ölen ödemez, öldüren öder
      var ceza = olumVergisi + SAVAS.CINAYET_CEZASI
      var kesilen = kesEldeki(katil.getUuid(), ceza)
      hazineye(server, kesilen, 'cinayet', String(katil.username))
      borcKuyrugu(server, katil.getUuid(), ceza - kesilen, 'cinayet')   // eksik kalan borca, kredi notu -30
      katil.tell(Text.red(Text.ofString('Savaş dışında oyuncu öldürdün: ceza ' + ceza + ' spur. Bankandan ' + kesilen + ' spur kesildi' +
        (kesilen < ceza ? ', kalan ' + (ceza - kesilen) + ' spur borcuna yazılacak (günlük faizli)' : '') + '.')))
      olen.tell(Text.ofString(String(katil.username) + ' seni savaş dışında öldürdü. Ölüm vergisini o ödedi, senden kesinti yapılmadı.'))
    } catch (err) { console.error('[Savas] olum hatasi: ' + err) }
  })

  // ----------------------------- KOMUTLAR ----------------------------
  ServerEvents.commandRegistry(function (event) {
    var Commands = event.commands
    var Arguments = event.arguments
    var oyuncuArg = function () { return Commands.argument('oyuncu', Arguments.PLAYER.create(event)) }
    var hedefAl = function (ctx) { return Arguments.PLAYER.getResult(ctx, 'oyuncu') }

    // Ortak kontroller: komutu yazan lider mi, hedef farklı tarafta mı, aralarında savaş var mı
    function hazirla(ctx, savasGerekli) {
      var p = ctx.source.player
      if (p == null) { ctx.source.sendSystemMessage(Text.ofString('Bu komutu oyun içinden kullanın.')); return null }
      var server = p.server
      var hedef = hedefAl(ctx)
      var t1 = taraf(server, p.getUuid())
      var t2 = taraf(server, hedef.getUuid())
      if (t1.anahtar === t2.anahtar) { p.tell(Text.red(Text.ofString('Bu oyuncu senin tarafında.'))); return null }
      if (!liderMi(server, p.getUuid())) { p.tell(Text.red(Text.ofString('Bunu partinde sadece sahip veya yetkililer yapabilir.'))); return null }
      var d = yukle(server)
      var s = bul(d, t1.anahtar, t2.anahtar)
      if (savasGerekli && !s) { p.tell(Text.red(Text.ofString(t2.ad + ' ile savaşta değilsin.'))); return null }
      return { p: p, server: server, t1: t1, t2: t2, d: d, s: s }
    }

    event.register(Commands.literal('savas')
      .then(Commands.literal('ilan').then(oyuncuArg().executes(function (ctx) {
        var c = hazirla(ctx, false); if (!c) return 0
        if (c.s) { c.p.tell(Text.red(Text.ofString(c.t2.ad + ' ile zaten savaştasın.'))); return 0 }
        var simdi = Date.now()
        for (var i = c.d.gecmis.length - 1; i >= 0; i--) {
          var g = c.d.gecmis[i]
          var ayni = (g.a.anahtar === c.t1.anahtar && g.b.anahtar === c.t2.anahtar) || (g.a.anahtar === c.t2.anahtar && g.b.anahtar === c.t1.anahtar)
          if (ayni && simdi - g.bitis < SAVAS.TEKRAR_ILAN_SAAT * 3600000) {
            c.p.tell(Text.red(Text.ofString('Bu tarafla son savaşın yeni bitti. Tekrar ilan için: ' + kalan(g.bitis + SAVAS.TEKRAR_ILAN_SAAT * 3600000 - simdi))))
            return 0
          }
        }
        var ucret = SAVAS.ILAN_UCRETI + Math.floor(tarafServeti(c.server, c.t1) * SAVAS.ILAN_ORANI)
        if (!kes(c.p.getUuid(), ucret)) {
          c.p.tell(Text.red(Text.ofString('Savaş ilanı için bankanda ' + ucret + ' spur olmalı (' + SAVAS.ILAN_UCRETI + ' + tarafının parasının %' +
            Math.round(SAVAS.ILAN_ORANI * 100) + '\'i).'))); return 0
        }
        hazineye(c.server, ucret, 'savas', String(c.p.username))
        c.d.sayac += 1
        c.d.savaslar.push({ id: c.d.sayac, a: c.t1, b: c.t2, ilan: simdi, baslangic: simdi + SAVAS.HAZIRLIK_DK * 60000,
          son: simdi + SAVAS.HAZIRLIK_DK * 60000 + SAVAS.SURE_SAAT * 3600000, durum: 'hazirlik', skor: { a: 0, b: 0 }, baris: { a: false, b: false } })
        kaydet(c.server, c.d)
        duyur(c.server, c.t1.ad + ', ' + c.t2.ad + ' tarafına SAVAŞ İLAN ETTİ! Savaş ' + SAVAS.HAZIRLIK_DK + ' dakika sonra başlıyor.')
        return 1
      })))
      .then(Commands.literal('baris').then(oyuncuArg().executes(function (ctx) {
        var c = hazirla(ctx, true); if (!c) return 0
        var yan = c.s.a.anahtar === c.t1.anahtar ? 'a' : 'b'
        var karsi = yan === 'a' ? 'b' : 'a'
        c.s.baris[yan] = true
        if (c.s.baris[karsi]) { bitir(c.server, c.d, c.s, 'iki taraf barıştı', null) }
        else {
          tarafaYaz(c.server, c.s[karsi], '[Savaş] ' + c.t1.ad + ' barış teklif ediyor. Kabul için: /savas baris ' + String(c.p.username))
          c.p.tell(Text.ofString('Barış teklifi gönderildi. Karşı taraf da /savas baris yazarsa savaş biter.'))
        }
        kaydet(c.server, c.d)
        return 1
      })))
      .then(Commands.literal('teslim').then(oyuncuArg().executes(function (ctx) {
        var c = hazirla(ctx, true); if (!c) return 0
        var kazanan = c.s.a.anahtar === c.t1.anahtar ? 'b' : 'a'
        bitir(c.server, c.d, c.s, c.t1.ad + ' teslim oldu', kazanan)
        kaydet(c.server, c.d)
        return 1
      })))
      .then(Commands.literal('durum').executes(function (ctx) {
        var server = ctx.source.server
        var d = yukle(server)
        var simdi = Date.now()
        var yaz = function (m) { ctx.source.sendSystemMessage(Text.ofString(m)) }
        if (d.savaslar.length === 0) { yaz('Şu an savaş yok.'); return 1 }
        d.savaslar.forEach(function (s) {
          yaz((s.durum === 'hazirlik' ? '[HAZIRLIK ' + kalan(s.baslangic - simdi) + '] ' : '[AKTİF, kalan ' + kalan(s.son - simdi) + '] ') +
            s.a.ad + ' ' + s.skor.a + ' - ' + s.skor.b + ' ' + s.b.ad +
            (SAVAS.ZAFER_PUANI > 0 ? '  (zafer: ' + SAVAS.ZAFER_PUANI + ')' : ''))
        })
        return 1
      }))
      // OP: savaşı tazminatsız bitirir
      .then(Commands.literal('iptal').requires(function (src) { return src.hasPermission(2) })
        .then(oyuncuArg().executes(function (ctx) {
          var server = ctx.source.server
          var hedef = hedefAl(ctx)
          var d = yukle(server)
          var k = taraf(server, hedef.getUuid()).anahtar
          var liste = d.savaslar.filter(function (s) { return s.a.anahtar === k || s.b.anahtar === k })
          liste.forEach(function (s) { bitir(server, d, s, 'yönetici tarafından iptal edildi', null) })
          kaydet(server, d)
          ctx.source.sendSystemMessage(Text.ofString(liste.length + ' savaş iptal edildi.'))
          return 1
        }))))
  })

  console.info('[Savas] yuklendi: ilan ' + SAVAS.ILAN_UCRETI + ' spur, hazirlik ' + SAVAS.HAZIRLIK_DK + ' dk, sure ' + SAVAS.SURE_SAAT +
    ' saat, zafer ' + SAVAS.ZAFER_PUANI + ', cinayet cezasi ' + SAVAS.CINAYET_CEZASI)
})()
