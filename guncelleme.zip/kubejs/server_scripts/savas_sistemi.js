// =====================================================================
//  SAVAŞ SİSTEMİ  -  kubejs/server_scripts/savas_sistemi.js
//  Hedef: NeoForge 1.21.1 | KubeJS 2101.7.2 | Create Numismatics 1.1.0
//         Open Parties and Claims 0.33.0 | sunucu_piyasa 1.0.5 (yağma kancası)
//
//  Taraflar: oyuncu bir OPAC partisindeyse PARTİSİ, değilse KENDİSİ.
//  Bir savaşın iki YANI vardır: a (ilan eden) ve b (ilan edilen); her yanda
//  ana taraf + müttefikler.
//
//  AKIŞ
//  - /savas ilan <oyuncu>: ilan ücreti kesilir, savaş ONAY bekler. Başkan veya OP
//    /savas onayla <no> ya da /savas reddet <no> der (red: ücret iade). ONAY_SAAT
//    içinde cevap gelmezse otomatik onaylanır. Onaydan HAZIRLIK_DK sonra savaş başlar.
//  - Müttefik: başka bir tarafın lideri /savas katil <no> <oyuncu> ile o oyuncunun
//    yanına katılmak ister; o yanın ana lideri /savas kabul <no> <oyuncu> der.
//    Müttefik tam katılımcıdır: arazisi yağmaya açılır, gider öder, sonucu paylaşır.
//  - Süre sınırı YOK. Savaş şunlarla biter:
//      * Antlaşma: ana liderlerden biri şart hazırlar (para + chunk), karşı ana lider kabul eder
//      * /savas baris (iki ana lider de)        -> şartsız barış
//      * /savas teslim                          -> teslim olan para tazminatı öder (toprak yok)
//      * OP: /savas bitir <no> veya /savas iptal <oyuncu>
//  - Savaş gideri: aktif savaşın her gerçek gününde a yanındaki herkesten bankasının
//    GIDER_SALDIRAN'ı, b yanından GIDER_ORAN'ı hazineye.
//  - Yağma: aktif savaşta bir yanın oyuncuları karşı yanın claim'lerinde her şeyi yapabilir
//    (blok, sandık, kapı, varlık, patlama) - yalnızca o claim'in sahibinin yanından en az bir
//    kişi çevrimiçiyken. Üçüncü kişiler için koruma sürer. (sunucu_piyasa SavasErisim,
//    veri 'savas_erisim'.) Sahiplik savaş sırasında değişmez; sadece antlaşmayla.
//  - Öldürme: aktif savaşta karşı yanlar arasında serbest (ölen ölüm vergisini öder, skor
//    bilgi amaçlı). Savaş dışı (onay/hazırlık dahil) öldüren cinayet cezası öder.
//  - Tazminat (teslimde): savaşı AÇAN yan kaybederse yan servetinin %25'i (3.000-100.000),
//    savunan yan kaybederse sabit 3.000; teslimde %50 indirim; kaybeden üyeler servetle
//    orantılı öder, yetmeyen borca; %10 hazineye, kalanı kazanan üyelere eşit.
//
//  !! Gerçek bir oyunda ÇALIŞTIRILARAK TEST EDİLMEDİ.
// =====================================================================

;(function () {
  // ----------------------------- AYARLAR -----------------------------
  var SAVAS = {
    ILAN_UCRETI: 5000,        // sabit kısım (spur), ilan edenden hazineye (red edilirse iade)
    ILAN_ORANI: 0.10,         // + ilan eden tarafın banka toplamının bu oranı
    ONAY_SAAT: 24,            // başkan/OP bu sürede cevap vermezse otomatik onay
    HAZIRLIK_DK: 10,          // onaydan sonra savaşın başlaması
    GIDER_ORAN: 0.02,         // aktif savaşın her gününde savunan yandan banka %'si
    GIDER_SALDIRAN: 0.03,     // ilan eden yandan
    TAZMINAT: 3000,
    TAZMINAT_ORAN: 0.25,
    TAZMINAT_EN_AZ: 3000,
    TAZMINAT_EN_COK: 100000,
    TESLIM_INDIRIM: 0.5,
    HAZINE_PAYI: 0.10,
    CINAYET_CEZASI: 500,      // savaş dışı öldürmede sabit ceza (spur)
    OLUM_VERGISI_ORAN: 0.05,  // vergi_sistemi.js ile AYNI tutun
    TEKRAR_ILAN_SAAT: 24      // aynı iki taraf arasında savaş bittikten sonra bekleme
  }
  var HAZINE_UUID_STR = '5f0c2d1e-7a3b-4e9c-8d6f-1b2a3c4d5e6f'   // vergi_sistemi.js ile aynı
  var KONTROL_TICK = 1200
  var GUN = 24 * 3600 * 1000

  var JUUID = Java.loadClass('java.util.UUID')
  var RL = Java.loadClass('net.minecraft.resources.ResourceLocation')
  var Numismatics = Java.loadClass('dev.ithundxr.createnumismatics.Numismatics')
  var ReasonHolder = Java.loadClass('dev.ithundxr.createnumismatics.content.backend.ReasonHolder')
  var BankType = Java.loadClass('dev.ithundxr.createnumismatics.content.backend.BankAccount$Type')
  var OpenPACServerAPI = Java.loadClass('xaero.pac.common.server.api.OpenPACServerAPI')
  var HAZINE_UUID = JUUID.fromString(HAZINE_UUID_STR)

  // ----------------------------- VERİ --------------------------------
  function yukle(server) {
    var s = server.persistentData.getString('savas_veri')
    var d = null
    if (s) { try { d = JSON.parse(s) } catch (e) { d = null } }
    if (!d) d = {}
    if (!d.savaslar) d.savaslar = []
    if (!d.gecmis) d.gecmis = []
    if (!d.sayac) d.sayac = 0
    d.savaslar.forEach(function (x) {
      if (!x.ma) x.ma = []
      if (!x.mb) x.mb = []
      if (!x.istek) x.istek = []
      if (!x.skor) x.skor = { a: 0, b: 0 }
      if (!x.baris) x.baris = { a: false, b: false }
      if (!x.teklif) x.teklif = { a: null, b: null }
      if (x.durum === 'aktif' && !x.giderSon) { x.aktifBas = x.aktifBas || Date.now(); x.giderSon = Date.now() }
    })
    return d
  }
  function kaydet(server, d) { server.persistentData.putString('savas_veri', JSON.stringify(d)) }

  // ----------------------------- BANKA / HAZİNE ----------------------
  function bakiye(uuid) { var h = Numismatics.BANK.getAccount(uuid); return h ? h.getBalance() : 0 }
  function kes(uuid, m) {
    m = Math.floor(m); if (m <= 0) return true
    var h = Numismatics.BANK.getAccount(uuid); if (!h) return false
    var ok = h.deduct(m, ReasonHolder.IGNORED); if (ok) h.markDirty(); return !!ok
  }
  // Yetiyorsa m, yetmiyorsa bakiyenin tamamını keser; kesilen miktarı döner
  function kesEldeki(uuid, m) {
    m = Math.min(Math.floor(m), bakiye(uuid))
    if (m <= 0) return 0
    return kes(uuid, m) ? m : 0
  }
  function yatir(uuid, m, tip) {
    m = Math.floor(m)
    if (m <= 0) return
    var h = Numismatics.BANK.getOrCreateAccount(uuid, tip || BankType.PLAYER)
    h.deposit(m); h.markDirty()
  }
  function ad(server, uuid) {
    var p = server.playerList.getPlayer(uuid)
    if (p != null) return String(p.username)
    var prof = server.getProfileCache().get(uuid)
    return prof.isPresent() ? String(prof.get().getName()) : String(uuid).substring(0, 8)
  }
  function hazineKaydi(server, tur, m, kim, gelir) {
    var s = server.persistentData.getString('hazine_veri')
    var d = null
    if (s) { try { d = JSON.parse(s) } catch (e) { d = null } }
    if (!d) d = {}
    if (!d.gelir) d.gelir = { arazi: 0, olum: 0, tescil: 0 }
    if (!d.hareket) d.hareket = []
    if (gelir) d.gelir[tur] = (d.gelir[tur] || 0) + m
    d.hareket = d.hareket.concat([{ t: Date.now(), tur: tur, m: m, k: kim }]).slice(-500)
    server.persistentData.putString('hazine_veri', JSON.stringify(d))
  }
  function hazineye(server, m, tur, kim) {
    if (m <= 0) return
    yatir(HAZINE_UUID, m, BankType.BLAZE_BANKER)
    hazineKaydi(server, tur, m, kim, true)
  }
  // Hazineden öder (yetmezse ne varsa); ödenen miktarı döner
  function hazineden(server, uuid, m, tur, kim) {
    var h = Numismatics.BANK.getOrCreateAccount(HAZINE_UUID, BankType.BLAZE_BANKER)
    m = Math.min(Math.floor(m), h.getBalance())
    if (m <= 0 || !h.deduct(m, ReasonHolder.IGNORED)) return 0
    h.markDirty()
    yatir(uuid, m)
    hazineKaydi(server, tur, m, kim, false)
    return m
  }

  // ----------------------------- TARAFLAR ----------------------------
  function partiYon(server) { return OpenPACServerAPI.get(server).getPartyManager() }
  function taraf(server, uuid) {
    var p = partiYon(server).getPartyByMember(uuid)
    if (p != null) {
      var sahip = p.getOwner()
      return { anahtar: 'parti:' + String(p.getId()), tip: 'parti', id: String(p.getId()),
        ad: String(p.getDefaultName()), lider: sahip ? String(sahip.getUUID()) : String(uuid) }
    }
    return { anahtar: 'oyuncu:' + String(uuid), tip: 'oyuncu', id: String(uuid), ad: ad(server, uuid), lider: String(uuid) }
  }
  // Tarafın üyeleri (uuid string): partide tüm üyeler, değilse oyuncunun kendisi
  function uyeListesi(server, t) {
    if (t.tip !== 'parti') return [t.id]
    var p = partiYon(server).getPartyById(JUUID.fromString(t.id))
    if (p == null) return [t.lider]
    var u = p.getMemberInfoStream().toArray()
    var l = []
    for (var i = 0; i < u.length; i++) l.push(String(u[i].getUUID()))
    if (l.indexOf(t.lider) < 0) l.push(t.lider)
    return l
  }
  function liderMi(server, uuid) {
    var p = partiYon(server).getPartyByMember(uuid)
    if (p == null) return true
    var yetkili = p.getStaffInfoStream().toArray()
    for (var i = 0; i < yetkili.length; i++) if (yetkili[i].getUUID().equals(uuid)) return true
    var sahip = p.getOwner()
    return sahip != null && sahip.getUUID().equals(uuid)
  }
  function tarafaYaz(server, t, msg) {
    var c = Text.ofString(msg)
    if (t.tip === 'parti') {
      var p = partiYon(server).getPartyById(JUUID.fromString(t.id))
      if (p != null) { var on = p.getOnlineMemberStream().toArray(); for (var i = 0; i < on.length; i++) on[i].tell(c) }
      return
    }
    var pl = server.playerList.getPlayer(JUUID.fromString(t.id))
    if (pl != null) pl.tell(c)
  }
  function duyur(server, msg) { server.tell(Text.gold(Text.ofString('[Savaş] ' + msg))) }
  function baskanMi(server, uuid) { var b = server.persistentData.getString('baskan'); return !!b && b === String(uuid) }
  function yetkiliMi(src) {
    if (src.hasPermission(2)) return true
    var p = src.player
    return p != null && baskanMi(p.server, p.getUuid())
  }
  // Başkana ve çevrimiçi OP'lara bildirim
  function yetkililereYaz(server, msg) {
    var on = server.playerList.getPlayers().toArray()
    for (var i = 0; i < on.length; i++) {
      if (on[i].createCommandSourceStack().hasPermission(2) || baskanMi(server, on[i].getUuid())) on[i].tell(Text.yellow(Text.ofString(msg)))
    }
  }

  // ----------------------------- SAVAŞ YARDIMCILARI -------------------
  function karsi(yan) { return yan === 'a' ? 'b' : 'a' }
  function yanTaraflari(s, yan) { return [s[yan]].concat(s['m' + yan] || []) }
  function yanBul(s, anahtar) {
    if (s.a.anahtar === anahtar || s.ma.some(function (t) { return t.anahtar === anahtar })) return 'a'
    if (s.b.anahtar === anahtar || s.mb.some(function (t) { return t.anahtar === anahtar })) return 'b'
    return null
  }
  function yanAdi(s, yan) {
    var m = s['m' + yan] || []
    return s[yan].ad + (m.length ? ' (+' + m.map(function (t) { return t.ad }).join(', ') + ')' : '')
  }
  function yanUyeleri(server, s, yan) {
    var l = []
    yanTaraflari(s, yan).forEach(function (t) { uyeListesi(server, t).forEach(function (u) { if (l.indexOf(u) < 0) l.push(u) }) })
    return l
  }
  function yanaYaz(server, s, yan, msg) { yanTaraflari(s, yan).forEach(function (t) { tarafaYaz(server, t, msg) }) }
  function herkeseYaz(server, s, msg) { yanaYaz(server, s, 'a', msg); yanaYaz(server, s, 'b', msg) }
  // İki taraf arasında (müttefikler dahil, karşı yanlarda) savaş
  function bul(d, k1, k2) {
    for (var i = 0; i < d.savaslar.length; i++) {
      var s = d.savaslar[i]
      var y1 = yanBul(s, k1), y2 = yanBul(s, k2)
      if (y1 && y2 && y1 !== y2) return s
    }
    return null
  }
  function noIle(d, no) {
    for (var i = 0; i < d.savaslar.length; i++) if (d.savaslar[i].id === no) return d.savaslar[i]
    return null
  }
  function kalan(ms) {
    var dk = Math.max(0, Math.floor(ms / 60000))
    return Math.floor(dk / 60) + ' saat ' + (dk % 60) + ' dk'
  }

  // Yağma kancasının verisi: sahip -> [{ d: düşmanlar, s: sahibin yanı }]
  function erisimYaz(server, d) {
    var h = {}
    d.savaslar.forEach(function (s) {
      if (s.durum !== 'aktif') return
      var A = yanUyeleri(server, s, 'a'), B = yanUyeleri(server, s, 'b')
      A.forEach(function (u) { (h[u] = h[u] || []).push({ d: B, s: A }) })
      B.forEach(function (u) { (h[u] = h[u] || []).push({ d: A, s: B }) })
    })
    server.persistentData.putString('savas_erisim', JSON.stringify(h))
  }

  // ----------------------------- BORÇ / KELLE ------------------------
  // Ödenemeyen tutarı borc_kredi.js'in kuyruğuna yazar (m = 0 ise sadece kredi notu olayı)
  function borcKuyrugu(server, uuid, m, sebep) {
    var k = []
    try { var s = server.persistentData.getString('borc_kuyruk'); if (s) k = JSON.parse(s) } catch (e) { k = [] }
    k.push({ u: String(uuid), m: m, s: sebep })
    server.persistentData.putString('borc_kuyruk', JSON.stringify(k))
  }
  // borc_kredi.js: 7. gününü geçen borçlunun kellesine ödül (borc_durum[uuid].kelle / .odul)
  function borcDurum(server) {
    try { return JSON.parse(server.persistentData.getString('borc_durum') || '{}') } catch (e) { return {} }
  }
  function kelleOde(server, durum, katil, olen) {
    var e = durum[String(olen.getUuid())]
    var m = hazineden(server, katil.getUuid(), e.odul || 0, 'kelle', String(katil.username) + ' > ' + String(olen.username))
    // Ödül borçlunun borcuna eklenir; kelle KELLE_ARA_GUN sonra yeniden açılır (borc_kredi.js)
    borcKuyrugu(server, olen.getUuid(), m, 'kelle')
    e.kelle = false   // aynı dakika içinde ikinci kez ödenmesin
    server.persistentData.putString('borc_durum', JSON.stringify(durum))
    server.tell(Text.gold(Text.ofString('[Kelle Avı] ' + String(katil.username) + ', borçlu ' + String(olen.username) +
      ' oyuncusunun kellesini aldı ve ' + m + ' spur ödül kazandı. Cesedi yağmalanabilir.')))
    if (m <= 0) katil.tell(Text.ofString('Devlet hazinesinde para olmadığı için ödül ödenemedi; yine de ceza almadın.'))
  }

  // ----------------------------- PARA AKTARIMI -----------------------
  // Ödeyenler servetleriyle orantılı öder; yetmeyen kısım borca. Alanlar eşit pay alır.
  // Döner: { pesin, borc, hazine, kisiBasi }
  function paraAktar(server, ode, al, tutar, hazinePayi, sebep, kimAdi, alanLider) {
    var servet = ode.map(function (id) { return Math.max(0, bakiye(JUUID.fromString(id))) })
    var top = servet.reduce(function (a, b) { return a + b }, 0)
    var pay = []
    if (top <= tutar) pay = servet.slice()
    else {
      var dag = 0, enZengin = 0
      for (var i = 0; i < ode.length; i++) {
        pay[i] = Math.floor(tutar * servet[i] / top); dag += pay[i]
        if (servet[i] > servet[enZengin]) enZengin = i
      }
      pay[enZengin] = Math.min(servet[enZengin], pay[enZengin] + (tutar - dag))
    }
    var pesin = 0
    var eksikler = []
    for (var j = 0; j < ode.length; j++) {
      var kesilen = kesEldeki(JUUID.fromString(ode[j]), pay[j])
      pesin += kesilen
      eksikler[j] = pay[j] - kesilen
    }
    var acik = Math.max(0, tutar - pesin - eksikler.reduce(function (a, b) { return a + b }, 0))
    var borc = 0
    for (var k = 0; k < ode.length; k++) {
      var b = eksikler[k] + Math.floor(acik / ode.length) + (k === 0 ? acik % ode.length : 0)
      if (b > 0) { borcKuyrugu(server, ode[k], b, sebep); borc += b }
      var pl = server.playerList.getPlayer(JUUID.fromString(ode[k]))
      if (pl != null) pl.tell(Text.red(Text.ofString('[Savaş] Payın: ' + (pay[k] - eksikler[k]) + ' spur bankandan kesildi' +
        (b > 0 ? ', ' + b + ' spur borcuna yazıldı' : '') + '.')))
    }
    var hz = Math.floor(pesin * hazinePayi)
    hazineye(server, hz, 'tazminat', kimAdi)
    var kalanPara = pesin - hz
    var kisiBasi = al.length ? Math.floor(kalanPara / al.length) : 0
    for (var n = 0; n < al.length; n++) {
      yatir(JUUID.fromString(al[n]), kisiBasi + (al[n] === alanLider ? kalanPara - kisiBasi * al.length : 0))
      var ap = server.playerList.getPlayer(JUUID.fromString(al[n]))
      if (ap != null && kisiBasi > 0) ap.tell(Text.green(Text.ofString('[Savaş] Bankana ' + kisiBasi + ' spur yatırıldı.')))
    }
    return { pesin: pesin, borc: borc, hazine: hz, kisiBasi: kisiBasi }
  }
  function tazminatTutari(server, s, yan, teslim) {
    var t
    if (yan === 'a') {
      var top = 0
      yanUyeleri(server, s, 'a').forEach(function (u) { top += Math.max(0, bakiye(JUUID.fromString(u))) })
      t = Math.max(SAVAS.TAZMINAT_EN_AZ, Math.min(SAVAS.TAZMINAT_EN_COK, Math.floor(top * SAVAS.TAZMINAT_ORAN)))
    } else t = SAVAS.TAZMINAT
    if (teslim) t = Math.floor(t * (1 - SAVAS.TESLIM_INDIRIM))
    return t
  }

  function bitir(server, d, s, sebep, kazananYan, teslim) {
    d.savaslar = d.savaslar.filter(function (x) { return x.id !== s.id })
    var g = { id: s.id, a: s.a, b: s.b, ma: s.ma, mb: s.mb, skor: s.skor, ilan: s.ilan, bitis: Date.now(), sonuc: sebep, reddedildi: !!s.reddedildi }
    var metin = '#' + s.id + ' ' + yanAdi(s, 'a') + ' - ' + yanAdi(s, 'b') + ' savaşı bitti: ' + sebep
    if (kazananYan) {
      var yan = karsi(kazananYan)
      var tutar = tazminatTutari(server, s, yan, teslim)
      var r = paraAktar(server, yanUyeleri(server, s, yan), yanUyeleri(server, s, kazananYan), tutar, SAVAS.HAZINE_PAYI,
        'savas_tazminati', s[yan].ad, s[kazananYan].lider)
      g.tazminat = r
      metin += '. Kazanan: ' + yanAdi(s, kazananYan) + ', tazminat: ' + tutar + ' spur' + (teslim ? ' (teslim indirimiyle)' : '') +
        ' - peşin ' + r.pesin + (r.borc > 0 ? ', borca yazılan ' + r.borc : '') + ', hazine payı ' + r.hazine
    }
    d.gecmis = d.gecmis.concat([g]).slice(-20)
    erisimYaz(server, d)
    duyur(server, metin)
  }

  function onayla(server, d, s, kim) {
    s.durum = 'hazirlik'
    s.baslangic = Date.now() + SAVAS.HAZIRLIK_DK * 60000
    duyur(server, '#' + s.id + ' ' + s.a.ad + ' - ' + s.b.ad + ' savaşı onaylandı (' + kim + '). ' + SAVAS.HAZIRLIK_DK +
      ' dakika sonra başlıyor. Savaşta karşı tarafın arazisi, sahibinin tarafından biri oyundayken yağmaya açıktır.')
  }

  // Günlük savaş gideri
  function giderKes(server, s) {
    ['a', 'b'].forEach(function (yan) {
      var oran = yan === 'a' ? SAVAS.GIDER_SALDIRAN : SAVAS.GIDER_ORAN
      var top = 0
      yanUyeleri(server, s, yan).forEach(function (u) {
        var uuid = JUUID.fromString(u)
        var m = kesEldeki(uuid, Math.floor(bakiye(uuid) * oran))
        top += m
        var pl = server.playerList.getPlayer(uuid)
        if (pl != null && m > 0) pl.tell(Text.red(Text.ofString('[Savaş] Günlük savaş gideri: ' + m + ' spur (%' + Math.round(oran * 100) + ').')))
      })
      hazineye(server, top, 'savas_gideri', s[yan].ad)
    })
  }

  // ----------------------------- ANTLAŞMA ----------------------------
  // s.teklif[yan] = { para: { odeyen: 'a'|'b', m }, chunk: [{ d, x, z, sahip, alan, alici }], gonderildi }
  function teklifYazi(s, yan) {
    var t = s.teklif[yan]
    if (!t) return 'Teklif yok.'
    var p = t.para && t.para.m > 0 ? yanAdi(s, t.para.odeyen) + ' -> ' + yanAdi(s, karsi(t.para.odeyen)) + ': ' + t.para.m + ' spur' : 'para yok'
    var ca = t.chunk.filter(function (c) { return c.alan === 'a' }).length
    var cb = t.chunk.length - ca
    return 'Para: ' + p + ' | Toprak: ' + s.a.ad + ' tarafına ' + ca + ' chunk, ' + s.b.ad + ' tarafına ' + cb + ' chunk' +
      (t.gonderildi ? ' (gönderildi)' : ' (taslak)')
  }
  function antlasmaUygula(server, d, s, yan) {
    var t = s.teklif[yan]
    var sonuc = []
    if (t.para && t.para.m > 0) {
      var r = paraAktar(server, yanUyeleri(server, s, t.para.odeyen), yanUyeleri(server, s, karsi(t.para.odeyen)), t.para.m, 0,
        'savas_antlasmasi', s[t.para.odeyen].ad, s[karsi(t.para.odeyen)].lider)
      sonuc.push(t.para.m + ' spur ödendi (peşin ' + r.pesin + (r.borc > 0 ? ', borca ' + r.borc : '') + ')')
    }
    if (t.chunk.length) {
      var m = OpenPACServerAPI.get(server).getServerClaimsManager()
      var ok = 0, atla = 0
      t.chunk.forEach(function (c) {
        try {
          var rl = RL.parse(c.d)
          var cl = m.get(rl, c.x, c.z)
          if (cl == null || String(cl.getPlayerId()) !== c.sahip) { atla++; return }
          var alici = c.alici || s[c.alan].lider
          m.unclaim(rl, c.x, c.z)
          m.claim(rl, JUUID.fromString(alici), -1, c.x, c.z, false)
          ok++
        } catch (e) { atla++ }
      })
      sonuc.push(ok + ' chunk el değiştirdi' + (atla ? ' (' + atla + ' chunk artık aynı sahipte olmadığı için atlandı)' : ''))
    }
    bitir(server, d, s, 'antlaşma imzalandı' + (sonuc.length ? ': ' + sonuc.join(', ') : ' (şartsız)'), null, false)
  }

  // ----------------------------- ZAMANLAYICI -------------------------
  ServerEvents.tick(function (event) {
    var server = event.server
    if (server.tickCount % KONTROL_TICK !== 0) return
    try {
      var d = yukle(server)
      var simdi = Date.now()
      d.savaslar.slice().forEach(function (s) {
        if (s.durum === 'onay' && simdi >= s.onaySon) onayla(server, d, s, 'süre doldu, otomatik')
        else if (s.durum === 'hazirlik' && simdi >= s.baslangic) {
          s.durum = 'aktif'; s.aktifBas = simdi; s.giderSon = simdi
          duyur(server, '#' + s.id + ' ' + yanAdi(s, 'a') + ' ile ' + yanAdi(s, 'b') + ' arasındaki SAVAŞ BAŞLADI! Süre sınırı yok: ' +
            'antlaşma, barış veya teslimle biter. Her gün iki taraftan savaş gideri kesilir.')
        } else if (s.durum === 'aktif') {
          while (simdi - s.giderSon >= GUN) { s.giderSon += GUN; giderKes(server, s) }
        }
      })
      kaydet(server, d)
      erisimYaz(server, d)
    } catch (err) { console.error('[Savas] hata: ' + err) }
  })

  // ----------------------------- ÖLÜMLER -----------------------------
  EntityEvents.death('minecraft:player', function (event) {
    var olen = event.entity
    var katil = event.source.getActual()
    if (!olen || !olen.isPlayer() || katil == null || !katil.isPlayer()) return
    if (katil.getUuid().equals(olen.getUuid())) return
    var server = event.server
    try {
      var d = yukle(server)
      var tk = taraf(server, katil.getUuid())
      var to = taraf(server, olen.getUuid())
      var s = (tk.anahtar !== to.anahtar) ? bul(d, tk.anahtar, to.anahtar) : null
      var olumVergisi = Math.floor(bakiye(olen.getUuid()) * SAVAS.OLUM_VERGISI_ORAN)

      if (s && s.durum === 'aktif') {
        // Savaşta öldürme: ölen normal ölüm vergisini öder; skor bilgi amaçlı
        if (olumVergisi > 0 && kes(olen.getUuid(), olumVergisi)) {
          hazineye(server, olumVergisi, 'olum', String(olen.username))
          olen.tell(Text.ofString('Ölüm vergisi: bankandan ' + olumVergisi + ' spur kesildi.'))
        }
        var yan = yanBul(s, tk.anahtar)
        s.skor[yan] = (s.skor[yan] || 0) + 1
        herkeseYaz(server, s, '[Savaş] ' + String(katil.username) + ', ' + String(olen.username) + ' oyuncusunu öldürdü. Skor: ' +
          s.a.ad + ' ' + s.skor.a + ' - ' + s.skor.b + ' ' + s.b.ad)
        kaydet(server, d)
        return
      }

      // Kelle avı: 7 gündür borcunu ödemeyen oyuncuyu (kendi partisinden olmayan biri) öldürmek suç değil, ödüllü
      if (tk.anahtar !== to.anahtar) {
        var durum = borcDurum(server)
        var kd = durum[String(olen.getUuid())]
        if (kd && kd.kelle) { kelleOde(server, durum, katil, olen); return }
      }

      // Savaş dışı öldürme: ölen ödemez, öldüren öder
      var ceza = olumVergisi + SAVAS.CINAYET_CEZASI
      var kesilen = kesEldeki(katil.getUuid(), ceza)
      hazineye(server, kesilen, 'cinayet', String(katil.username))
      borcKuyrugu(server, katil.getUuid(), ceza - kesilen, 'cinayet')   // eksik kalan borca, kredi notu -30
      katil.tell(Text.red(Text.ofString('Savaş dışında oyuncu öldürdün: ceza ' + ceza + ' spur. Bankandan ' + kesilen + ' spur kesildi' +
        (kesilen < ceza ? ', kalan ' + (ceza - kesilen) + ' spur borcuna yazılacak (günlük faizli)' : '') + '.')))
      olen.tell(Text.ofString(String(katil.username) + ' seni savaş dışında öldürdü. Ölüm vergisini o ödedi, senden kesinti yapılmadı.'))
    } catch (err) { console.error('[Savas] olum hatasi: ' + err) }
  })

  // ----------------------------- KOMUTLAR ----------------------------
  ServerEvents.commandRegistry(function (event) {
    var Commands = event.commands
    var Arguments = event.arguments
    var oyuncuArg = function () { return Commands.argument('oyuncu', Arguments.PLAYER.create(event)) }
    var noArg = function () { return Commands.argument('no', Arguments.INTEGER.create(event)) }
    var hedefAl = function (ctx) { return Arguments.PLAYER.getResult(ctx, 'oyuncu') }
    var noAl = function (ctx) { return Arguments.INTEGER.getResult(ctx, 'no') }
    var kirmizi = function (p, m) { p.tell(Text.red(Text.ofString(m))) }
    var yaz = function (ctx, m) { ctx.source.sendSystemMessage(Text.ofString(m)) }
    var opMu = function (src) { return src.hasPermission(2) }

    // Barış/teslim: komutu yazan ANA taraf lideri mi, hedef karşı yanda mı
    function hazirla(ctx) {
      var p = ctx.source.player
      if (p == null) { yaz(ctx, 'Bu komutu oyun içinden kullanın.'); return null }
      var server = p.server
      var t1 = taraf(server, p.getUuid())
      var t2 = taraf(server, hedefAl(ctx).getUuid())
      if (t1.anahtar === t2.anahtar) { kirmizi(p, 'Bu oyuncu senin tarafında.'); return null }
      if (!liderMi(server, p.getUuid())) { kirmizi(p, 'Bunu partinde sadece sahip veya yetkililer yapabilir.'); return null }
      var d = yukle(server)
      var s = bul(d, t1.anahtar, t2.anahtar)
      if (!s) { kirmizi(p, t2.ad + ' ile savaşta değilsin.'); return null }
      var yan = s.a.anahtar === t1.anahtar ? 'a' : (s.b.anahtar === t1.anahtar ? 'b' : null)
      if (!yan) { kirmizi(p, 'Müttefikler barış/teslim kararı veremez; bunu yanının ana lideri yapar.'); return null }
      return { p: p, server: server, t1: t1, t2: t2, d: d, s: s, yan: yan }
    }
    // Antlaşma: no'lu savaşta komutu yazan ana lider
    function anaLider(ctx) {
      var p = ctx.source.player
      if (p == null) { yaz(ctx, 'Bu komutu oyun içinden kullanın.'); return null }
      var server = p.server
      var d = yukle(server)
      var s = noIle(d, noAl(ctx))
      if (!s) { kirmizi(p, 'Böyle bir savaş yok. /savas durum'); return null }
      var t = taraf(server, p.getUuid())
      var yan = s.a.anahtar === t.anahtar ? 'a' : (s.b.anahtar === t.anahtar ? 'b' : null)
      if (!yan || !liderMi(server, p.getUuid())) { kirmizi(p, 'Antlaşmayı sadece savaşın ana taraflarının liderleri yapabilir.'); return null }
      if (s.durum !== 'aktif') { kirmizi(p, 'Antlaşma sadece aktif savaşta yapılır (onay/hazırlıkta /savas baris yeterli).'); return null }
      return { p: p, server: server, d: d, s: s, yan: yan }
    }
    function taslak(c) {
      var t = c.s.teklif[c.yan]
      if (!t || t.gonderildi) t = c.s.teklif[c.yan] = { para: { odeyen: c.yan, m: 0 }, chunk: [], gonderildi: false }
      return t
    }
    function chunkEkle(ctx, alan) {
      var c = anaLider(ctx); if (!c) return 0
      var p = c.p
      var boyut = String(p.level.getDimension())
      var x = Math.floor(p.getX() / 16), z = Math.floor(p.getZ() / 16)
      var cl = OpenPACServerAPI.get(c.server).getServerClaimsManager().get(p.level.getDimension(), x, z)
      if (cl == null) { kirmizi(p, 'Bu chunk kimsenin değil.'); return 0 }
      var sahip = String(cl.getPlayerId())
      var veren = alan === 'kendim' ? karsi(c.yan) : c.yan    // toprağı veren yan
      if (yanUyeleri(c.server, c.s, veren).indexOf(sahip) < 0) {
        kirmizi(p, alan === 'kendim' ? 'Bu chunk karşı yanın bir üyesine ait değil.' : 'Bu chunk senin yanından birine ait değil.'); return 0
      }
      var t = taslak(c)
      if (t.chunk.some(function (k) { return k.d === boyut && k.x === x && k.z === z })) { kirmizi(p, 'Bu chunk zaten teklifte.'); return 0 }
      t.chunk.push({ d: boyut, x: x, z: z, sahip: sahip, alan: alan === 'kendim' ? c.yan : karsi(c.yan), alici: alan === 'kendim' ? String(p.getUuid()) : null })
      kaydet(c.server, c.d)
      p.tell(Text.ofString('Chunk (' + x + ', ' + z + ') teklife eklendi. ' + teklifYazi(c.s, c.yan)))
      return 1
    }
    function paraAyarla(ctx, yon) {
      var c = anaLider(ctx); if (!c) return 0
      var m = Arguments.INTEGER.getResult(ctx, 'miktar')
      if (m < 0) { kirmizi(c.p, 'Miktar 0 veya daha büyük olmalı.'); return 0 }
      var t = taslak(c)
      t.para = { odeyen: yon === 'ver' ? c.yan : karsi(c.yan), m: m }
      kaydet(c.server, c.d)
      c.p.tell(Text.ofString('Teklif güncellendi. ' + teklifYazi(c.s, c.yan)))
      return 1
    }

    var antlasma = Commands.literal('antlasma').then(noArg()
      .then(Commands.literal('para')
        .then(Commands.literal('ver').then(Commands.argument('miktar', Arguments.INTEGER.create(event)).executes(function (ctx) { return paraAyarla(ctx, 'ver') })))
        .then(Commands.literal('al').then(Commands.argument('miktar', Arguments.INTEGER.create(event)).executes(function (ctx) { return paraAyarla(ctx, 'al') }))))
      .then(Commands.literal('chunk')
        .then(Commands.literal('al').executes(function (ctx) { return chunkEkle(ctx, 'kendim') }))
        .then(Commands.literal('ver').executes(function (ctx) { return chunkEkle(ctx, 'karsi') })))
      .then(Commands.literal('goster').executes(function (ctx) {
        var c = anaLider(ctx); if (!c) return 0
        c.p.tell(Text.ofString('Senin teklifin: ' + teklifYazi(c.s, c.yan)))
        c.p.tell(Text.ofString('Karşı tarafın teklifi: ' + teklifYazi(c.s, karsi(c.yan))))
        return 1
      }))
      .then(Commands.literal('temizle').executes(function (ctx) {
        var c = anaLider(ctx); if (!c) return 0
        c.s.teklif[c.yan] = null
        kaydet(c.server, c.d)
        c.p.tell(Text.ofString('Teklifin silindi.'))
        return 1
      }))
      .then(Commands.literal('gonder').executes(function (ctx) {
        var c = anaLider(ctx); if (!c) return 0
        var t = c.s.teklif[c.yan]
        if (!t) { kirmizi(c.p, 'Önce teklif hazırla: /savas antlasma ' + c.s.id + ' para|chunk ...'); return 0 }
        t.gonderildi = true
        kaydet(c.server, c.d)
        var k = karsi(c.yan)
        tarafaYaz(c.server, c.s[k], '[Savaş] ' + c.s[c.yan].ad + ' antlaşma teklif ediyor: ' + teklifYazi(c.s, c.yan) +
          '. Kabul: /savas antlasma ' + c.s.id + ' kabul  |  Red: /savas antlasma ' + c.s.id + ' reddet')
        c.p.tell(Text.ofString('Teklif gönderildi.'))
        return 1
      }))
      .then(Commands.literal('kabul').executes(function (ctx) {
        var c = anaLider(ctx); if (!c) return 0
        var k = karsi(c.yan)
        var t = c.s.teklif[k]
        if (!t || !t.gonderildi) { kirmizi(c.p, 'Karşı taraftan gönderilmiş bir teklif yok.'); return 0 }
        antlasmaUygula(c.server, c.d, c.s, k)
        kaydet(c.server, c.d)
        return 1
      }))
      .then(Commands.literal('reddet').executes(function (ctx) {
        var c = anaLider(ctx); if (!c) return 0
        var k = karsi(c.yan)
        if (!c.s.teklif[k] || !c.s.teklif[k].gonderildi) { kirmizi(c.p, 'Karşı taraftan gönderilmiş bir teklif yok.'); return 0 }
        c.s.teklif[k] = null
        kaydet(c.server, c.d)
        tarafaYaz(c.server, c.s[k], '[Savaş] ' + c.s[c.yan].ad + ' antlaşma teklifini reddetti.')
        c.p.tell(Text.ofString('Teklif reddedildi.'))
        return 1
      })))

    event.register(Commands.literal('savas')
      .then(Commands.literal('ilan').then(oyuncuArg().executes(function (ctx) {
        var p = ctx.source.player
        if (p == null) { yaz(ctx, 'Bu komutu oyun içinden kullanın.'); return 0 }
        var server = p.server
        var t1 = taraf(server, p.getUuid())
        var t2 = taraf(server, hedefAl(ctx).getUuid())
        if (t1.anahtar === t2.anahtar) { kirmizi(p, 'Bu oyuncu senin tarafında.'); return 0 }
        if (!liderMi(server, p.getUuid())) { kirmizi(p, 'Bunu partinde sadece sahip veya yetkililer yapabilir.'); return 0 }
        var d = yukle(server)
        if (bul(d, t1.anahtar, t2.anahtar)) { kirmizi(p, t2.ad + ' ile zaten savaştasın.'); return 0 }
        var simdi = Date.now()
        for (var i = d.gecmis.length - 1; i >= 0; i--) {
          var g = d.gecmis[i]
          var ayni = (g.a.anahtar === t1.anahtar && g.b.anahtar === t2.anahtar) || (g.a.anahtar === t2.anahtar && g.b.anahtar === t1.anahtar)
          if (ayni && !g.reddedildi && simdi - g.bitis < SAVAS.TEKRAR_ILAN_SAAT * 3600000) {
            kirmizi(p, 'Bu tarafla son savaşın yeni bitti. Tekrar ilan için: ' + kalan(g.bitis + SAVAS.TEKRAR_ILAN_SAAT * 3600000 - simdi))
            return 0
          }
        }
        var servet = 0
        uyeListesi(server, t1).forEach(function (u) { servet += Math.max(0, bakiye(JUUID.fromString(u))) })
        var ucret = SAVAS.ILAN_UCRETI + Math.floor(servet * SAVAS.ILAN_ORANI)
        if (!kes(p.getUuid(), ucret)) {
          kirmizi(p, 'Savaş ilanı için bankanda ' + ucret + ' spur olmalı (' + SAVAS.ILAN_UCRETI + ' + tarafının parasının %' + Math.round(SAVAS.ILAN_ORANI * 100) + '\'i).')
          return 0
        }
        hazineye(server, ucret, 'savas', String(p.username))
        d.sayac += 1
        var s = { id: d.sayac, a: t1, b: t2, ma: [], mb: [], istek: [], durum: 'onay', ilan: simdi, onaySon: simdi + SAVAS.ONAY_SAAT * 3600000,
          ilanEden: String(p.getUuid()), ucret: ucret, skor: { a: 0, b: 0 }, baris: { a: false, b: false }, teklif: { a: null, b: null } }
        d.savaslar.push(s)
        kaydet(server, d)
        duyur(server, t1.ad + ', ' + t2.ad + ' tarafına SAVAŞ İLAN ETTİ (#' + s.id + '). Başkan/OP onayı bekleniyor; ' + SAVAS.ONAY_SAAT +
          ' saat içinde cevap gelmezse otomatik onaylanır.')
        yetkililereYaz(server, '[Savaş] #' + s.id + ' onayınızı bekliyor: /savas onayla ' + s.id + '  veya  /savas reddet ' + s.id + ' (ücret iade edilir)')
        return 1
      })))
      .then(Commands.literal('onayla').requires(yetkiliMi).then(noArg().executes(function (ctx) {
        var server = ctx.source.server
        var d = yukle(server)
        var s = noIle(d, noAl(ctx))
        if (!s || s.durum !== 'onay') { yaz(ctx, 'Onay bekleyen böyle bir savaş yok.'); return 0 }
        onayla(server, d, s, ctx.source.player ? String(ctx.source.player.username) : 'yönetim')
        kaydet(server, d)
        return 1
      })))
      .then(Commands.literal('reddet').requires(yetkiliMi).then(noArg().executes(function (ctx) {
        var server = ctx.source.server
        var d = yukle(server)
        var s = noIle(d, noAl(ctx))
        if (!s || (s.durum !== 'onay' && s.durum !== 'hazirlik')) { yaz(ctx, 'Başlamamış böyle bir savaş yok.'); return 0 }
        var iade = hazineden(server, JUUID.fromString(s.ilanEden), s.ucret || 0, 'savas_iade', s.a.ad)
        s.reddedildi = true
        bitir(server, d, s, 'reddedildi (' + (ctx.source.player ? String(ctx.source.player.username) : 'yönetim') + '), ilan ücreti iade: ' + iade + ' spur', null, false)
        kaydet(server, d)
        return 1
      })))
      .then(Commands.literal('katil').then(noArg().then(oyuncuArg().executes(function (ctx) {
        var p = ctx.source.player
        if (p == null) return 0
        var server = p.server
        var d = yukle(server)
        var s = noIle(d, noAl(ctx))
        if (!s) { kirmizi(p, 'Böyle bir savaş yok. /savas durum'); return 0 }
        var t = taraf(server, p.getUuid())
        if (!liderMi(server, p.getUuid())) { kirmizi(p, 'Bunu partinde sadece sahip veya yetkililer yapabilir.'); return 0 }
        if (yanBul(s, t.anahtar)) { kirmizi(p, 'Tarafın zaten bu savaşta.'); return 0 }
        var yan = yanBul(s, taraf(server, hedefAl(ctx).getUuid()).anahtar)
        if (!yan) { kirmizi(p, 'Bu oyuncu bu savaşta değil.'); return 0 }
        s.istek = s.istek.filter(function (x) { return x.t.anahtar !== t.anahtar })
        s.istek.push({ t: t, yan: yan })
        kaydet(server, d)
        tarafaYaz(server, s[yan], '[Savaş] ' + t.ad + ' #' + s.id + ' savaşında sizin yanınızda savaşmak istiyor. Kabul: /savas kabul ' + s.id + ' ' + String(p.username))
        p.tell(Text.ofString('Katılma isteğin ' + s[yan].ad + ' liderine iletildi. Kabul edilirse arazin de yağmaya açılır ve savaş giderini ödersin.'))
        return 1
      }))))
      .then(Commands.literal('kabul').then(noArg().then(oyuncuArg().executes(function (ctx) {
        var p = ctx.source.player
        if (p == null) return 0
        var server = p.server
        var d = yukle(server)
        var s = noIle(d, noAl(ctx))
        if (!s) { kirmizi(p, 'Böyle bir savaş yok.'); return 0 }
        var t = taraf(server, p.getUuid())
        var yan = s.a.anahtar === t.anahtar ? 'a' : (s.b.anahtar === t.anahtar ? 'b' : null)
        if (!yan || !liderMi(server, p.getUuid())) { kirmizi(p, 'Müttefik kabulünü sadece yanın ana lideri yapabilir.'); return 0 }
        var isteyen = taraf(server, hedefAl(ctx).getUuid())
        var ist = s.istek.filter(function (x) { return x.t.anahtar === isteyen.anahtar && x.yan === yan })[0]
        if (!ist) { kirmizi(p, 'Bu tarafın sizin yanınıza katılma isteği yok.'); return 0 }
        if (yanBul(s, isteyen.anahtar)) { kirmizi(p, 'Bu taraf zaten savaşta.'); return 0 }
        s['m' + yan].push(ist.t)
        s.istek = s.istek.filter(function (x) { return x.t.anahtar !== isteyen.anahtar })
        kaydet(server, d)
        erisimYaz(server, d)
        duyur(server, ist.t.ad + ', #' + s.id + ' savaşına ' + s[yan].ad + ' yanında katıldı.')
        return 1
      }))))
      .then(Commands.literal('baris').then(oyuncuArg().executes(function (ctx) {
        var c = hazirla(ctx); if (!c) return 0
        var k = karsi(c.yan)
        c.s.baris[c.yan] = true
        if (c.s.baris[k]) bitir(c.server, c.d, c.s, 'iki taraf şartsız barıştı', null, false)
        else {
          tarafaYaz(c.server, c.s[k], '[Savaş] ' + c.t1.ad + ' şartsız barış teklif ediyor. Kabul için: /savas baris ' + String(c.p.username))
          c.p.tell(Text.ofString('Barış teklifi gönderildi. Karşı taraf da /savas baris yazarsa savaş biter. Şartlı barış için: /savas antlasma ' + c.s.id))
        }
        kaydet(c.server, c.d)
        return 1
      })))
      .then(Commands.literal('teslim').then(oyuncuArg().executes(function (ctx) {
        var c = hazirla(ctx); if (!c) return 0
        bitir(c.server, c.d, c.s, yanAdi(c.s, c.yan) + ' teslim oldu', karsi(c.yan), true)
        kaydet(c.server, c.d)
        return 1
      })))
      .then(antlasma)
      .then(Commands.literal('durum').executes(function (ctx) {
        var server = ctx.source.server
        var d = yukle(server)
        var simdi = Date.now()
        if (d.savaslar.length === 0) { yaz(ctx, 'Şu an savaş yok.'); return 1 }
        d.savaslar.forEach(function (s) {
          var dur = s.durum === 'onay' ? 'ONAY BEKLİYOR (' + kalan(s.onaySon - simdi) + ')' :
            s.durum === 'hazirlik' ? 'HAZIRLIK (' + kalan(s.baslangic - simdi) + ')' : 'AKTİF (' + kalan(simdi - s.aktifBas) + 'dir)'
          yaz(ctx, '#' + s.id + ' [' + dur + '] ' + yanAdi(s, 'a') + ' ' + s.skor.a + ' - ' + s.skor.b + ' ' + yanAdi(s, 'b'))
          if (s.istek.length) yaz(ctx, '   Katılma istekleri: ' + s.istek.map(function (x) { return x.t.ad + ' -> ' + s[x.yan].ad }).join(', '))
        })
        return 1
      }))
      // OP: savaşı tazminatsız bitirir
      .then(Commands.literal('bitir').requires(opMu).then(noArg().executes(function (ctx) {
        var server = ctx.source.server
        var d = yukle(server)
        var s = noIle(d, noAl(ctx))
        if (!s) { yaz(ctx, 'Böyle bir savaş yok.'); return 0 }
        bitir(server, d, s, 'yönetici tarafından bitirildi', null, false)
        kaydet(server, d)
        return 1
      })))
      .then(Commands.literal('iptal').requires(opMu)
        .then(oyuncuArg().executes(function (ctx) {
          var server = ctx.source.server
          var d = yukle(server)
          var k = taraf(server, hedefAl(ctx).getUuid()).anahtar
          var liste = d.savaslar.filter(function (s) { return yanBul(s, k) != null })
          liste.forEach(function (s) { bitir(server, d, s, 'yönetici tarafından iptal edildi', null, false) })
          kaydet(server, d)
          yaz(ctx, liste.length + ' savaş iptal edildi.')
          return 1
        }))))
  })

  console.info('[Savas] yuklendi: ilan ' + SAVAS.ILAN_UCRETI + ' spur, onay ' + SAVAS.ONAY_SAAT + ' sa, hazirlik ' + SAVAS.HAZIRLIK_DK +
    ' dk, sure sinirsiz, gider %' + Math.round(SAVAS.GIDER_ORAN * 100) + '/%' + Math.round(SAVAS.GIDER_SALDIRAN * 100))
})()
