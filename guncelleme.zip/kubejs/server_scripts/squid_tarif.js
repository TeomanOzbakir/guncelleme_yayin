// =====================================================================
//  SQUID -> RAW CALAMARI (crafting table)  -  kubejs/server_scripts/squid_tarif.js
//  Hands-On Delight'ın kesme tahtası squid kesimini yapmıyor; bu yüzden
//  Cultural Delights'ın kesme tarifinin aynısı crafting table'a eklendi:
//    squid (veya glow squid) + knife  ->  2 raw_calamari  (knife 1 hasar alır, kaybolmaz)
//    %50 ihtimalle 3 ink_sac / glow_ink_sac (kesme tahtasındaki gibi), envantere verilir.
// =====================================================================
;(function () {
  ServerEvents.recipes(function (event) {
    event.shapeless(Item.of('culturaldelights:raw_calamari', 2), ['culturaldelights:squid', '#c:tools/knife'])
      .damageIngredient('#c:tools/knife').id('kubejs:raw_calamari_from_squid_crafting')
    event.shapeless(Item.of('culturaldelights:raw_calamari', 2), ['culturaldelights:glow_squid', '#c:tools/knife'])
      .damageIngredient('#c:tools/knife').id('kubejs:raw_calamari_from_glow_squid_crafting')
  })

  // Yan ürün: crafting tek çıktı verebildiği için mürekkep ayrıca verilir.
  ItemEvents.crafted('culturaldelights:raw_calamari', function (event) {
    try {
      var inv = event.inventory
      var parlak = inv != null && inv.count('culturaldelights:glow_squid') > 0
      var normal = inv != null && inv.count('culturaldelights:squid') > 0
      if (!parlak && !normal) return
      if (Math.random() < 0.5) event.player.give(Item.of(parlak ? 'minecraft:glow_ink_sac' : 'minecraft:ink_sac', 3))
    } catch (err) { console.error('[Squid] murekkep verilemedi: ' + err) }
  })
})()
