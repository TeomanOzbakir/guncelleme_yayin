// =====================================================================
//  /menu komutu - arayüz ekranlarını açar
//  Dosya: kubejs/server_scripts/arayuz_komut.js
//  Ekranlar kubejs/startup_scripts/arayuz.js içinde tanımlı.
//    /menu            -> giriş menüsü (sadece bölüm listesi, arayuz:menu)
//    /menu <ekran>    -> ör. /menu kredi  (arayuz:kredi ekranını açar; "ana" = Genel)
// =====================================================================
;(function () {
  var MenuTipleri = Java.loadClass('com.lowdragmc.lowdraglib2.integration.kjs.ui.LDKJSMenuTypes')

  function ac(ctx, ad) {
    var p = ctx.source.player
    if (p == null) { ctx.source.sendSystemMessage(Text.ofString('Bu komutu oyun içinden kullanın.')); return 0 }
    // Ekonomi ekranı sunucu_piyasa modunun kendi ekranıdır
    if (ad === 'ekonomi') { p.runCommandSilent('ekonomi'); return 1 }
    if (ad === 'borsa') { p.runCommandSilent('borsaekran'); return 1 }   // sunucu_piyasa BorsaEkrani
    var id = ad.indexOf(':') >= 0 ? ad : 'arayuz:' + ad
    var ok = false
    try { ok = MenuTipleri.openPlayerUI(p, id) } catch (err) { console.error('[Arayuz] acilamadi ' + id + ': ' + err) }
    if (!ok) p.tell(Text.red(Text.ofString('Ekran açılamadı: ' + id)))
    return ok ? 1 : 0
  }

  // Sunucu Defteri (startup_scripts/menu_defteri.js): sağ tıklayınca menü açılır
  var DEFTER = 'kubejs:sunucu_defteri'
  ItemEvents.rightClicked(DEFTER, function (event) {
    var p = event.player
    if (p == null) return
    try {
      if (!MenuTipleri.openPlayerUI(p, 'arayuz:menu')) p.tell(Text.red(Text.ofString('Menü açılamadı.')))
    } catch (err) { console.error('[Arayuz] defter: ' + err) }
    event.cancel()
  })
  // İlk girişte herkese bir defter
  PlayerEvents.loggedIn(function (event) {
    var p = event.player
    var veri = p.persistentData
    if (veri.getBoolean('sunucu_defteri_verildi')) return
    p.give(Item.of(DEFTER))
    veri.putBoolean('sunucu_defteri_verildi', true)
    p.tell(Text.gold(Text.ofString('Sunucu Defteri verildi: sağ tıkla veya Y tuşuna bas (Kontroller > Sunucu).')))
  })
  ServerEvents.recipes(function (event) {
    event.shapeless(Item.of(DEFTER), ['minecraft:book', 'minecraft:gold_nugget']).id('kubejs:sunucu_defteri')
  })

  ServerEvents.commandRegistry(function (event) {
    var Commands = event.commands
    var Arguments = event.arguments
    // Kayıt sayfaları (menü > Satışlar / Hazine): /menu sayfa <satis|hazine> <-1|0|1>
    function kayitSayisi(server, ad) {
      if (ad === 'guncelleme') {   // satır sayısı kabaca: başlık + maddeler + boşluk (uzun maddeler birkaç satır)
        var n = 0
        try { (global.guncellemeNotlari || []).forEach(function (g) { n += 2; (g.maddeler || []).forEach(function (m) { n += Math.ceil(String(m).length / 55) }) }) } catch (e) { n = 0 }
        return n
      }
      var anahtar = ad === 'satis' ? 'satis_kayit' : 'hazine_veri'
      var s = server.persistentData.getString(anahtar)
      if (!s) return 0
      try { var d = JSON.parse(s); return ad === 'satis' ? (d.length || 0) : ((d.hareket || []).length) } catch (e) { return 0 }
    }
    event.register(Commands.literal('menu')
      .then(Commands.literal('sayfa')
        .then(Commands.argument('liste', Arguments.WORD.create(event))
          .then(Commands.argument('yon', Arguments.INTEGER.create(event)).executes(function (ctx) {
            var p = ctx.source.player
            if (p == null) return 0
            var ad = String(Arguments.WORD.getResult(ctx, 'liste'))
            if (ad !== 'satis' && ad !== 'hazine' && ad !== 'guncelleme') return 0
            var yon = Arguments.INTEGER.getResult(ctx, 'yon')
            var son = Math.max(0, Math.ceil(kayitSayisi(p.server, ad) / 10) - 1)
            var k = 'menu_sayfa_' + ad
            var no = yon === 0 ? 0 : Math.min(son, Math.max(0, p.persistentData.getInt(k) + yon))
            p.persistentData.putInt(k, no)
            return 1
          }))))
      .executes(function (ctx) { return ac(ctx, 'menu') })
      .then(Commands.argument('ekran', Arguments.WORD.create(event)).executes(function (ctx) {
        return ac(ctx, String(Arguments.WORD.getResult(ctx, 'ekran')))
      })))
  })
})()
