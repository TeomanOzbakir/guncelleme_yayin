// =====================================================================
//  SUNUCU MENÜSÜ  -  kubejs/server_scripts/arayuz_komut.js
//  Ekran: sunucu_piyasa modunun genel menü ekranı (istemci/MenuEkrani.java). Ekranın TAMAMI burada,
//  sunucuda JSON olarak kurulur ve gönderilir; menüdeki değişiklikler oyuncu güncellemesi gerektirmez
//  (sunucuda /reload veya yeniden başlatma yeter).
//    /menu [bölüm] [sekme]   -> ekranı açar (Y tuşu, Sunucu Defteri; K = /menu yetenek)
//    /menuveri <bölüm/sekme> -> açık ekranın 2 sn'de bir tazelenmesi (mod gönderir, sessiz)
//    /menuislem kredi|ode <kaynak> [miktar] -> açılır listedeki seçime göre doğru komuta yönlendirir
//  Öğe türleri ve alanları: MenuEkrani.java başındaki açıklama.
//  2026-11-25 (kullanıcı): Banka (hesap/transfer/günlük/kredi/bankalar/bankacı), Arazi sadeleşti,
//  Vergiler ayrı, Savaş sekmeli, Zindan rekorları, OP+başkan tek "Yönetim" bölümünde.
//  !! Gerçek bir oyunda ÇALIŞTIRILARAK TEST EDİLMEDİ.
// =====================================================================
;(function () {
  var HAZINE = '5f0c2d1e-7a3b-4e9c-8d6f-1b2a3c4d5e6f'
  var JUUID = Java.loadClass('java.util.UUID')
  var Numismatics = Java.loadClass('dev.ithundxr.createnumismatics.Numismatics')
  var MenuSunucu = null, OPAC = null, ZindanApi = undefined
  function tasiyici() { if (MenuSunucu == null) MenuSunucu = Java.loadClass('tr.sunucu.piyasa.MenuSunucu'); return MenuSunucu }

  // ----------------------------- VERİ YARDIMCILARI ------------------------
  function veri(server, k) { var s = server.persistentData.getString(k); if (!s) return {}; try { return JSON.parse(s) || {} } catch (e) { return {} } }
  function bakiye(uuid) { try { var h = Numismatics.BANK.getAccount(typeof uuid === 'string' ? JUUID.fromString(uuid) : uuid); return h ? h.getBalance() : 0 } catch (e) { return 0 } }
  function para(n) { return String(Math.floor(n)).replace(/\B(?=(\d{3})+(?!\d))/g, '.') + ' spur' }
  function sayi(n) { return String(Math.floor(n)).replace(/\B(?=(\d{3})+(?!\d))/g, '.') }
  function iki(n) { return (n < 10 ? '0' : '') + n }
  function zaman(t) { var d = new Date(t); return iki(d.getDate()) + '.' + iki(d.getMonth() + 1) + ' ' + iki(d.getHours()) + ':' + iki(d.getMinutes()) }
  function sure(ms) { var dk = Math.max(0, Math.floor(ms / 60000)); var g = Math.floor(dk / 1440); return (g > 0 ? g + ' g ' : '') + Math.floor((dk % 1440) / 60) + ' sa ' + (dk % 60) + ' dk' }
  function dkSn(sn) { sn = Math.max(0, sn || 0); return Math.floor(sn / 60) + ':' + iki(sn % 60) }
  function opMu(p) { return p.createCommandSourceStack().hasPermission(2) }
  function baskanMi(p) { var b = p.server.persistentData.getString('baskan'); return !!b && b === String(p.getUuid()) }
  function yonetici(p) { return opMu(p) || baskanMi(p) }
  var adOnbellek = {}
  function adi(server, id) {
    id = String(id)
    var o = server.playerList.getPlayer(JUUID.fromString(id))
    if (o != null) { adOnbellek[id] = String(o.username); return adOnbellek[id] }
    if (adOnbellek[id]) return adOnbellek[id]
    try { var prof = server.getProfileCache().get(JUUID.fromString(id)); adOnbellek[id] = prof.isPresent() ? String(prof.get().getName()) : id.substring(0, 8) } catch (e) { adOnbellek[id] = id.substring(0, 8) }
    return adOnbellek[id]
  }
  // Açılır liste için oyuncular: çevrimiçiler önce, sonra kayıtlı (borç/yetenek kaydı olan) herkes
  function oyuncular(server, haric, sadeceCevrimici) {
    var on = {}, liste = []
    server.playerList.getPlayers().toArray().forEach(function (o) { on[String(o.getUuid())] = String(o.username) })
    Object.keys(on).forEach(function (id) { if (id !== haric) liste.push({ d: on[id], y: on[id], c: 1 }) })
    if (!sadeceCevrimici) {
      var kayit = {}
      Object.keys(veri(server, 'borc_veri').o || {}).forEach(function (id) { kayit[id] = 1 })
      Object.keys(veri(server, 'yetenek_veri').o || {}).forEach(function (id) { kayit[id] = 1 })
      Object.keys(kayit).forEach(function (id) { if (!on[id] && id !== haric && id.length > 30) { var a = adi(server, id); if (a.length < 17) liste.push({ d: a, y: a + ' (çevrimdışı)', c: 0 }) } })
    }
    liste.sort(function (a, b) { return a.c !== b.c ? b.c - a.c : (a.d.toLowerCase() < b.d.toLowerCase() ? -1 : 1) })
    return liste.map(function (x) { return { d: x.d, y: x.y } })
  }
  function oran(server, ad, vars) { try { return global.vergiOrani ? Number(global.vergiOrani(server, ad)) : vars } catch (e) { return vars } }

  // ----------------------------- ÖĞE KURUCULARI ---------------------------
  function ek(o, x) { if (x) Object.keys(x).forEach(function (k) { o[k] = x[k] }); return o }
  function kart(b, a, d, x) { return ek({ t: 'kart', b: b, a: a || '', d: d == null ? '' : String(d) }, x) }
  function yazi(m, r) { return { t: 'yazi', m: m, r: r || 'gri' } }
  function baslik(m) { return { t: 'baslik', m: m } }
  function satir(m, s, r, sr) { return { t: 'satir', m: m, s: s || '', r: r || 'acik', sr: sr || 'gri' } }
  function giris(ad, i, x) { return ek({ t: 'giris', ad: ad, i: i || '' }, x) }
  function secim(ad, i, sec, x) { return ek({ t: 'secim', ad: ad, i: i || 'Seç...', sec: sec }, x) }
  function dugme(y, k, x) { return ek({ t: 'dugme', y: y, k: k }, x) }
  function sira(o) { return { t: 'sira', o: o } }
  function dugmeler(l) { return { t: 'dugmeler', l: l } }
  var BOSLUK = { t: 'bosluk' }, CIZGI = { t: 'cizgi' }

  // ----------------------------- ORTAK KAYITLAR ---------------------------
  function borcKaydi(p) { return (veri(p.server, 'borc_veri').o || {})[String(p.getUuid())] || null }
  function vergiKaydi(p) { return (veri(p.server, 'vergi_veri').kayitlar || {})[String(p.getUuid())] || null }
  function claimSayisi(p) {
    try {
      if (OPAC == null) OPAC = Java.loadClass('xaero.pac.common.server.api.OpenPACServerAPI')
      var m = OPAC.get(p.server).getServerClaimsManager()
      return m.hasPlayerInfo(p.getUuid()) ? m.getPlayerInfo(p.getUuid()).getClaimCount() : 0
    } catch (e) { return 0 }
  }
  function zindanOzet(p) {
    if (ZindanApi === undefined) { try { ZindanApi = Java.loadClass('tr.sunucu.zindan.ZindanApi') } catch (e) { ZindanApi = null } }
    if (ZindanApi == null) return {}
    try { return JSON.parse(String(ZindanApi.ozet(String(p.getUuid())))) } catch (e) { return {} }
  }
  function bankalar(server) { var b = veri(server, 'banka_veri').b || {}; return Object.keys(b).map(function (k) { var x = b[k]; x.anahtar = k; return x }) }
  function bankaKasa(b) { return bakiye(b.hesap) }
  function bankaToplam(b) { var m = 0, k = 0, n = 0; Object.keys(b.defter || {}).forEach(function (u) { var r = b.defter[u]; m += r.m || 0; k += r.k || 0; if ((r.m || 0) > 0 || (r.k || 0) > 0) n++ }); return { m: m, k: k, n: n } }
  function bankam(p) { var id = String(p.getUuid()); return bankalar(p.server).filter(function (b) { return b.sahip === id || (b.calisan || []).indexOf(id) >= 0 })[0] || null }
  function tacirMi(p) { var r = (veri(p.server, 'yetenek_veri').o || {})[String(p.getUuid())] || {}; return r.meslek === 'tacir' || (r.ekMeslekler || []).indexOf('tacir') >= 0 }

  // ======================================================================
  //  BÖLÜMLER
  // ======================================================================
  var BOLUM = {}
  var SIRA = ['genel', 'ekonomi', 'borsa', 'banka', 'arazi', 'vergiler', 'savas', 'zindan', 'yetenek', '', 'yonetim']

  // ----------------------------- GENEL ------------------------------------
  var HAREKET_AD = { arazi: 'Arazi vergisi', olum: 'Ölüm vergisi', tescil: 'Tescil', cinayet: 'Cinayet cezası',
    savas: 'Savaş ilanı', borc: 'Borç tahsilatı', kredi: 'Kredi verildi', kredi_odeme: 'Kredi ödemesi',
    aktarim: 'Aktarım', cekim: 'Çekim', yatirma: 'Yatırma', zindan: 'Zindan girişi', kelle: 'Kelle ödülü', tazminat: 'Tazminat payı', yetenek: 'Sınıf/meslek ücreti', savas_gideri: 'Savaş gideri', savas_iade: 'Savaş ilanı iadesi',
    kelle_harci: 'Kelle harcı', kelle_emanet: 'Kelle ödülü emaneti', kelle_odeme: 'Kelle ödülü ödendi', kelle_iade: 'Kelle ödülü iadesi',
    kdv: 'Satış vergisi (KDV)', harc: 'Harç', arazi_ceza: 'Arazi beyan cezası', banka_lisans: 'Banka lisansı',
    borsa: 'Borsa komisyonu', borsa_kasa: 'Borsa kasasına', borsa_kasa_iade: 'Borsa kasasından' }
  var GIDER = { aktarim: 1, cekim: 1, kredi: 1, kelle: 1, savas_iade: 1, kelle_odeme: 1, kelle_iade: 1, borsa_kasa: 1 }

  BOLUM.genel = { ad: 'Genel',
    sekmeler: function () { return [{ id: 'ozet', ad: 'Özet' }, { id: 'guncelleme', ad: 'Güncellemeler' }, { id: 'satis', ad: 'Vendor Satışları' }] },
    kur: function (p, s) {
      var server = p.server
      if (s === 'guncelleme') {
        var o = []
        var n = []
        try { n = global.guncellemeNotlari || [] } catch (e) { n = [] }
        n.forEach(function (g) { o.push(baslik('Sürüm ' + g.surum + '  ·  ' + g.tarih)); (g.maddeler || []).forEach(function (m) { o.push(yazi('• ' + m, 'acik')) }); o.push(BOSLUK) })
        if (!o.length) o.push(yazi('Henüz güncelleme notu yok.'))
        return o
      }
      if (s === 'satis') {
        var l = veri(server, 'satis_kayit')
        l = Array.isArray(l) ? l.slice(-120).reverse() : []
        var o2 = [yazi('Tüm Vendor alım-satımları, en yeni üstte.')]
        l.forEach(function (e) { o2.push(satir(zaman(e.t) + '  ' + e.a + (e.y === 'al' ? ' aldı ' : ' sattı ') + e.n + 'x ' + e.i, e.m + ' · ' + e.s)) })
        if (!l.length) o2.push(yazi('Henüz satış yok.'))
        return o2
      }
      var r = borcKaydi(p), v = vergiKaydi(p), z = zindanOzet(p)
      var y = (veri(server, 'yetenek_veri').o || {})[String(p.getUuid())] || {}
      var not = r ? r.not : 500
      return [
        kart('Banka', 'Numismatics hesabındaki para', para(bakiye(p.getUuid()))),
        kart('Kredi Notu', 'Kredi limitini ve faizini belirler', not + ' / 1000', { r: not / 1000 }),
        kart('Borç', 'Ödenmeyen cezalar ve krediler (günlük %2 faiz)', r && r.borc > 0 ? para(Math.ceil(r.borc)) : 'Yok', { dr: r && r.borc > 0 ? 'kirmizi' : 'yesil' }),
        kart('Arazi', 'Kullanılan / kiralanan claim hakkı', claimSayisi(p) + ' / ' + (v && v.kota != null ? v.kota : 1) + ' hak'),
        kart('Zindan', 'Bitirdiğin en yüksek seviye', String(z.enYuksek || 0)),
        kart('Sınıf & Meslek', 'K tuşu', (y.sinif ? y.sinif : 'sınıf yok') + ' · ' + (y.meslek ? y.meslek : 'meslek yok')),
        kart('Savaşlar', 'Aktif ve hazırlıktaki savaşlar', String((veri(server, 'savas_veri').savaslar || []).length)),
        BOSLUK,
        yazi('Y: bu menü · K: Sınıf & Meslek (oradan yetenek ağaçlarına) · Sol listeden bölüm seç.')
      ]
    } }

  BOLUM.ekonomi = { ad: 'Ekonomi', komut: 'ekonomi' }
  BOLUM.borsa = { ad: 'Borsa', komut: 'borsaekran' }

  // ----------------------------- BANKA ------------------------------------
  BOLUM.banka = { ad: 'Banka',
    sekmeler: function (p) {
      var l = [{ id: 'hesap', ad: 'Hesabım' }, { id: 'transfer', ad: 'Transfer' }, { id: 'gunluk', ad: 'Günlük' }, { id: 'kredi', ad: 'Kredi & Borç' }, { id: 'bankalar', ad: 'Bankalar' }]
      if (bankam(p)) l.push({ id: 'bankaci', ad: 'Bankacı' })
      else l.push({ id: 'kur', ad: 'Banka Kur' })
      return l
    },
    kur: function (p, s) {
      var server = p.server, id = String(p.getUuid())
      var hepsi = bankalar(server)
      var bankaSec = hepsi.filter(function (b) { return !b.donuk }).map(function (b) { return { d: b.anahtar, y: b.ad + ' Bankası' } })
      if (s === 'transfer') {
        var h = oran(server, 'transfer', 1)
        return [
          kart('Bakiyen', 'Gönderebileceğin para', para(bakiye(p.getUuid()))),
          yazi('Başka bir oyuncunun bankasına para gönder. Harç: %' + h + ' (gönderenden, hazineye). Çevrimdışı oyuncuya da gider.'),
          sira([secim('alici', 'Alıcı seç', oyuncular(server, id, false), { l: 'Alıcı', w: 1.4 }), giris('miktar', 'spur', { l: 'Miktar', sayi: 1 }),
            dugme('Gönder', 'banka gonder {alici} {miktar}', { r: 'yesil', onay: 'Emin misin?', temizle: 1, w: 0.8 })]),
          BOSLUK,
          yazi('Bankana gelen ve giden transferler "Günlük" sekmesinde.')
        ]
      }
      if (s === 'gunluk') {
        var g = ((veri(server, 'transfer_veri').o || {})[id] || []).slice().reverse()
        var o = [yazi('Son 40 transferin (en yeni üstte).')]
        g.forEach(function (e) {
          if (e.y === 'g') o.push(satir(zaman(e.t) + '  → ' + e.k, '-' + para(e.m) + (e.h ? ' (harç ' + sayi(e.h) + ')' : ''), 'acik', 'kirmizi'))
          else o.push(satir(zaman(e.t) + '  ← ' + e.k, '+' + para(e.m), 'acik', 'yesil'))
        })
        if (!g.length) o.push(yazi('Henüz transfer yok.'))
        return o
      }
      if (s === 'kredi') {
        var r = borcKaydi(p)
        var not = r ? r.not : 500
        var kd = null
        try { kd = global.krediKademe ? global.krediKademe(server, id, not) : null } catch (e) { kd = null }
        var kaynak = [{ d: 'devlet', y: 'Devlet · ' + (kd ? 'limit ' + sayi(kd.limit) + ', faiz %' + Math.round(kd.faiz * 100) + ', 7 gün' : 'kredi notun yetmiyor') }]
        hepsi.forEach(function (b) { if (!b.donuk && b.sahip !== id) kaynak.push({ d: b.anahtar, y: b.ad + ' Bankası · faiz %' + (b.faiz == null ? 10 : b.faiz) + ' (bankacı onaylar)' }) })
        var borclar = []
        if (r && r.borc > 0) borclar.push({ d: 'borc', y: 'Devlet borcu (ceza/vergi) · ' + para(Math.ceil(r.borc)) })
        if (r && r.kredi) borclar.push({ d: 'kredi', y: 'Devlet kredisi · kalan ' + para(r.kredi.kalan) + ' (tamamı kapanır)' })
        hepsi.forEach(function (b) { var x = (b.defter || {})[id]; if (x && x.k > 0) borclar.push({ d: b.anahtar, y: b.ad + ' Bankası kredisi · ' + para(x.k) }) })
        var o3 = [
          kart('Kredi Notu', '300 altı kredi yok · 900+ 50.000 spur, %3', not + ' / 1000', { r: not / 1000 }),
          kart('Devlet Kredisi', '7 günlük taksit, bankadan otomatik', r && r.kredi ? 'Kalan ' + para(r.kredi.kalan) : 'Yok'),
          kart('Devlet Borcu', 'Borç varken devletten kredi çekilemez · günlük %2 faiz', r && r.borc > 0 ? para(Math.ceil(r.borc)) : 'Yok', { dr: r && r.borc > 0 ? 'kirmizi' : 'yesil' }),
          baslik('Kredi çek'),
          sira([secim('kaynak', 'Nereden?', kaynak, { l: 'Kredi kaynağı', v: 'devlet', w: 1.8 }), giris('miktar', 'spur', { l: 'Miktar', sayi: 1 }),
            dugme('Kredi çek', 'menuislem kredi {kaynak} {miktar}', { r: 'yesil', onay: 'Onayla', w: 0.8 })]),
          baslik('Borç öde'),
          borclar.length ? sira([secim('borc', 'Hangi borç?', borclar, { l: 'Borç', v: borclar[0].d, w: 1.8 }), giris('odeme', 'boş = tamamı', { l: 'Miktar', sayi: 1 }),
            dugme('Öde', 'menuislem ode {borc} {odeme?}', { r: 'baslik', temizle: 1, w: 0.8 })]) : yazi('Ödenecek borcun yok.', 'yesil')
        ]
        var bek = []
        hepsi.forEach(function (b) { var x = (b.basvuru || {})[id]; if (x) bek.push(satir(b.ad + ' Bankası · ' + para(x.m), 'onay bekliyor · ' + zaman(x.t), 'acik', 'baslik')) })
        if (bek.length) { o3.push(baslik('Bekleyen başvuruların')); o3 = o3.concat(bek) }
        var d = veri(server, 'borc_durum')[id]
        if (d) o3.push(kart('Yaptırım', '2. gün satış %50 · 3. damga · 5. satış %100 · 7. kelle + haciz', Math.floor(d.g) + '. gün', { dr: 'kirmizi', r: Math.min(1, d.g / 7) }))
        o3.push(dugmeler([dugme('Kredi ayrıntısı (sohbet)', 'kredi durum'), dugme('Borçlular', 'borclular')]))
        return o3
      }
      if (s === 'bankalar') {
        var o4 = [yazi('Bankalar oyuncuların; kasa ve defter herkese açık. Mevduat yatır/çek "Hesabım" sekmesinde, kredi "Kredi & Borç"ta.')]
        if (!hepsi.length) o4.push(yazi('Henüz banka yok. Tacir mesleğindekiler kurabilir.', 'acik'))
        hepsi.forEach(function (b) {
          var t = bankaToplam(b), k = bankaKasa(b)
          o4.push(baslik(b.ad + ' Bankası · ' + adi(server, b.sahip) + (b.donuk ? ' · DONDURULDU' : '')))
          o4.push(kart('Kasa', 'Kilitli sermaye ' + para(b.sermaye) + ' · kredi faizi %' + (b.faiz == null ? 10 : b.faiz), para(k)))
          o4.push(kart('Defter', 'Toplam mevduat · verilen kredi · ' + t.n + ' müşteri', sayi(t.m) + ' · ' + sayi(t.k), t.m > 0 ? { r: Math.min(1, k / t.m) } : null))
          if (b.duyuru) o4.push(yazi('Duyuru: ' + b.duyuru, 'acik'))
          var x = (b.defter || {})[id]
          if (x) o4.push(satir('Senin satırın', 'mevduat ' + sayi(x.m || 0) + ' · kredi ' + sayi(x.k || 0), 'baslik', 'acik'))
          ;(b.hareket || []).slice(-4).reverse().forEach(function (h) { o4.push(satir(zaman(h.t) + '  ' + h.kim, (h.m >= 0 ? '+' : '') + sayi(h.m), 'gri', h.m >= 0 ? 'yesil' : 'kirmizi')) })
        })
        return o4
      }
      if (s === 'bankaci') {
        var b = bankam(p)
        if (!b) return [yazi('Bir bankanın sahibi veya çalışanı değilsin.')]
        var t2 = bankaToplam(b), k2 = bankaKasa(b)
        var sahip = b.sahip === id
        var o5 = [
          kart(b.ad + ' Bankası', sahip ? 'Sahibisin' : 'Çalışansın', para(k2)),
          kart('Serbest Para', 'Kasa - kilitli sermaye (kredi ve çekimler buradan)', para(Math.max(0, k2 - (b.sermaye || 0)))),
          kart('Defter', 'Mevduat · verilen kredi · kasa/mevduat', sayi(t2.m) + ' · ' + sayi(t2.k), t2.m > 0 ? { r: Math.min(1, k2 / t2.m) } : null),
          baslik('Kredi başvuruları')
        ]
        var bs = b.basvuru || {}
        var bk = Object.keys(bs)
        if (!bk.length) o5.push(yazi('Bekleyen başvuru yok.'))
        bk.forEach(function (u) {
          var x = bs[u]
          var not = ((veri(server, 'borc_veri').o || {})[u] || {}).not
          o5.push(satir(x.ad + ' · ' + para(x.m) + ' · kredi notu ' + (not == null ? 500 : not), zaman(x.t), 'acik'))
          o5.push(dugmeler([dugme('Onayla', 'banka onayla ' + x.ad, { r: 'yesil', onay: 'Para kasadan çıkar, onayla' }), dugme('Reddet', 'banka reddet ' + x.ad, { r: 'kirmizi' })]))
        })
        o5.push(baslik('Ayarlar'))
        o5.push(sira([giris('faiz', 'şu an %' + (b.faiz == null ? 10 : b.faiz), { l: 'Kredi faizi (%)', sayi: 1 }), dugme('Faizi kaydet', 'banka faiz {faiz}', { temizle: 1 })]))
        o5.push(sira([giris('duyuru', b.duyuru ? b.duyuru.substring(0, 40) : 'faiz, kurallar...', { l: 'Duyuru (herkes görür)', serbest: 1, w: 2.2 }), dugme('Kaydet', 'banka duyuru {duyuru}', { temizle: 1 })]))
        o5.push(baslik('Defteri elle düzelt'))
        var musteri = Object.keys(b.defter || {}).map(function (u) { var r2 = b.defter[u]; return { d: r2.ad, y: r2.ad + ' · m ' + sayi(r2.m || 0) + ' · k ' + sayi(r2.k || 0) } })
        oyuncular(server, null, false).forEach(function (x) { if (!musteri.some(function (m) { return m.d === x.d })) musteri.push(x) })
        o5.push(sira([secim('musteri', 'Müşteri', musteri, { l: 'Müşteri', w: 1.5 }), secim('alan', 'Alan', [{ d: 'mevduat', y: 'Mevduat' }, { d: 'kredi', y: 'Kredi borcu' }], { l: 'Alan', v: 'mevduat' }),
          giris('tutar', 'yeni tutar', { l: 'Yeni tutar', sayi: 1 }), dugme('Yaz', 'banka defter {musteri} {alan} {tutar}', { onay: 'Deftere yaz?', temizle: 1, w: 0.6 })]))
        Object.keys(b.defter || {}).forEach(function (u) { var r3 = b.defter[u]; if ((r3.m || 0) > 0 || (r3.k || 0) > 0) o5.push(satir(r3.ad, 'mevduat ' + sayi(r3.m || 0) + ' · kredi ' + sayi(r3.k || 0))) })
        if (sahip) {
          o5.push(baslik('Çalışanlar'))
          o5.push(yazi((b.calisan || []).length ? (b.calisan || []).map(function (u) { return adi(server, u) }).join(', ') : 'Çalışan yok.', 'acik'))
          o5.push(sira([secim('calisan', 'Oyuncu (çevrimiçi)', oyuncular(server, id, true), { w: 1.5 }), dugme('Ekle', 'banka calisan ekle {calisan}'), dugme('Çıkar', 'banka calisan cikar {calisan}', { r: 'kirmizi' })]))
        }
        o5.push(BOSLUK)
        o5.push(dugmeler([dugme('Banka kartı al', 'banka kart'), sahip ? dugme('Bankamı kapat', 'banka kapat', { r: 'kirmizi', onay: 'Kapatılsın mı?' }) : dugme('Hareketler (sohbet)', 'banka hareket ' + b.ad)]))
        return o5
      }
      if (s === 'kur') {
        return [
          yazi('Banka sadece Tacir mesleğindekiler kurabilir. Lisans 5.000 spur (hazineye) + 20.000 spur kilitli sermaye (bankanın kasasında kalır, çekilemez).'),
          kart('Tacir', 'Meslek şartı', tacirMi(p) ? 'Uygun' : 'Değil', { dr: tacirMi(p) ? 'yesil' : 'kirmizi' }),
          kart('Bakiyen', '25.000 spur gerekli', para(bakiye(p.getUuid())), { dr: bakiye(p.getUuid()) >= 25000 ? 'yesil' : 'kirmizi' }),
          sira([giris('yeniad', '3-16 harf/rakam', { l: 'Banka adı', w: 2 }), dugme('Banka kur', 'banka kur {yeniad}', { r: 'yesil', onay: '25.000 spur, emin misin?' })])
        ]
      }
      // hesap
      var r0 = borcKaydi(p)
      var mevTop = 0, krTop = 0
      var satirlar = []
      hepsi.forEach(function (b) {
        var x = (b.defter || {})[id]
        if (!x || (!(x.m > 0) && !(x.k > 0))) return
        mevTop += x.m || 0; krTop += x.k || 0
        satirlar.push(satir(b.ad + ' Bankası', 'mevduat ' + sayi(x.m || 0) + ' · kredi ' + sayi(x.k || 0)))
      })
      var o6 = [
        kart('Banka Bakiyen', 'Numismatics hesabın (kart, terminal, transfer)', para(bakiye(p.getUuid()))),
        kart('Kredi Notu', 'Limit ve faizi belirler', (r0 ? r0.not : 500) + ' / 1000', { r: (r0 ? r0.not : 500) / 1000 }),
        kart('Bankalardaki Mevduatın', 'Oyuncu bankalarına yatırdığın', para(mevTop)),
        kart('Toplam Borcun', 'Devlet borcu + devlet kredisi + banka kredileri', para(krTop + (r0 && r0.borc > 0 ? r0.borc : 0) + (r0 && r0.kredi ? r0.kredi.kalan : 0)), { dr: 'kirmizi' })
      ].concat(satirlar)
      o6.push(baslik('Bir bankaya mevduat yatır / çek'))
      if (!bankaSec.length) o6.push(yazi('Henüz açık banka yok.'))
      else o6.push(sira([secim('banka', 'Banka seç', bankaSec, { l: 'Banka', w: 1.5 }), giris('tutar', 'spur', { l: 'Miktar', sayi: 1 }),
        dugme('Yatır', 'banka yatir {banka} {tutar}', { r: 'yesil', temizle: 1, w: 0.6 }), dugme('Çek', 'banka cek {banka} {tutar}', { temizle: 1, w: 0.6 })]))
      o6.push(yazi('Mevduat faizini bankacı belirler ve deftere elle yazar (duyurusuna bak).'))
      return o6
    } }

  // ----------------------------- ARAZİ ------------------------------------
  var KAT_AD = { yerleske: 'Yerleşke', dukkan: 'Dükkan', fabrika: 'Fabrika' }
  BOLUM.arazi = { ad: 'Arazi',
    kur: function (p) {
      var server = p.server
      var r = vergiKaydi(p)
      var n = claimSayisi(p)
      var kota = r && r.kota != null ? r.kota : 1
      var g = r && r.g != null ? r.g : 0
      var kira = oran(server, 'kira', 35)
      var o = [
        kart('Claim Hakkı', '1 hak bedava · fazlası hak başı ' + kira + ' spur/gün', n + ' / ' + kota + ' hak', { r: kota > 0 ? Math.min(1, n / kota) : 0 }),
        kart('Günlük Kira', 'Haklar + dükkan/fabrika farkı + araçlar · her gün bankadan kesilir', para(g) + '/gün'),
        kart('Kategoriler', 'Yerleşke · Dükkan · Fabrika · Araç', r && r.dg ? 'Y ' + r.dg.y + ' · D ' + r.dg.d + ' · F ' + r.dg.f + ' · A ' + (r.dg.a || 0) : 'Yerleşke ' + n)
      ]
      if (r && r.askida) o.push(kart('ASKIDA', r.haciz ? 'Borç haczi: borcu ödeyince geri gelir' : 'Kira ödenmedi: bankana para koy, otomatik geri gelir', 'Askıda', { dr: 'kirmizi' }))
      else if (r && g > 0) o.push(kart('Ödenmiş Süre', 'Sonraki kesime kalan (çubuk = 1 gün)', sure(Math.max(0, r.kredi || 0) / g * 86400000), { r: Math.min(1, Math.max(0, r.kredi || 0) / g) }))
      o.push(baslik('Claim hakkı kirala'))
      o.push(yazi('Toplam hak sayısını yaz (0 = sadece bedava hak). Artırınca eklenen hakların 1 günlük kirası hemen kesilir. Azaltırsan fazla claim\'lerin (sana en uzak olanlar) bırakılır; bunun için iki kez basman gerekir.'))
      o.push(sira([giris('kota', 'şu an ' + kota, { l: 'Toplam hak', sayi: 1 }), dugme('Kirala', 'arazi kota {kota}', { r: 'yesil' })]))
      // Bulunulan chunk
      var x = Math.floor(p.getX() / 16), z = Math.floor(p.getZ() / 16)
      var sahip = null
      try {
        if (OPAC == null) OPAC = Java.loadClass('xaero.pac.common.server.api.OpenPACServerAPI')
        var c = OPAC.get(server).getServerClaimsManager().get(p.level.getDimension(), x, z)
        sahip = c == null ? null : c.getPlayerId()
      } catch (e) { sahip = null }
      var kat = veri(server, 'arazi_kategori')[String(p.level.getDimension()) + '|' + x + '|' + z]
      var kendi = sahip != null && String(sahip) === String(p.getUuid())
      o.push(baslik('Durduğun chunk (' + x + ', ' + z + ')'))
      o.push(kart(sahip == null ? 'Sahipsiz' : 'Sahibi: ' + adi(server, sahip), 'Kategori: dükkan ' + oran(server, 'dukkan', 100) + ', fabrika ' + oran(server, 'fabrika', 150) + ' spur/gün',
        sahip == null ? '-' : KAT_AD[kat && kat.o === String(sahip) ? kat.k : 'yerleske'] || 'Yerleşke'))
      if (kendi) o.push(dugmeler([dugme('Yerleşke yap', 'arazi kategori yerleske'), dugme('Dükkan yap', 'arazi kategori dukkan'), dugme('Fabrika yap', 'arazi kategori fabrika')]))
      else o.push(yazi(sahip == null ? 'Claim için haritayı kullan (Xaero, OPAC).' : 'Kategori sadece kendi chunk\'ında değiştirilir.'))
      return o
    } }

  // ----------------------------- VERGİLER (görüntüleme) -------------------
  var VERGI_AD = [['kira', 'Claim hakkı kirası', 'spur/gün'], ['dukkan', 'Dükkan chunk fiyatı', 'spur/gün'], ['fabrika', 'Fabrika chunk fiyatı', 'spur/gün'],
    ['arac', 'Araç vergisi (aero claim başına)', 'spur/gün'], ['kdv', 'KDV (Selling Bin satışı)', '%'], ['harc', 'Ticaret harcı (Vendor/depozitör)', '%'],
    ['transfer', 'Para transferi harcı', '%'], ['olum', 'Ölüm vergisi (banka bakiyesinden)', '%'], ['tescil', 'Tescil ücreti', 'spur'],
    ['borsa', 'Borsa komisyonu', '%'], ['cinayet', 'Haksız cinayet cezası tabanı', 'spur']]
  var VERGI_VARS = { kira: 35, dukkan: 100, fabrika: 150, arac: 35, kdv: 5, harc: 1, transfer: 1, olum: 5, tescil: 500, borsa: 1, cinayet: 500 }
  function oranYazi(server, k, birim) { var v = oran(server, k, VERGI_VARS[k]); return birim === '%' ? '%' + v : sayi(v) + ' ' + birim }
  BOLUM.vergiler = { ad: 'Vergiler',
    kur: function (p) {
      var server = p.server
      var b = server.persistentData.getString('baskan')
      var o = [yazi('Oranları başkan belirler' + (b ? ' (Başkan: ' + adi(server, b) + ')' : '') + '; her değişiklik sohbete duyurulur.')]
      VERGI_AD.forEach(function (v) { o.push(satir(v[1], oranYazi(server, v[0], v[2]), 'acik', 'baslik')) })
      o.push(baslik('Sana etkisi'))
      var r = vergiKaydi(p)
      o.push(kart('Günlük arazi kiran', 'Claim hakkı + kategori farkları + araçlar', para(r && r.g ? r.g : 0)))
      o.push(kart('Ölürsen ölüm vergisi', 'Bankandaki paranın %' + oran(server, 'olum', 5) + '\'i (savaş dışında öldürülürsen katil öder)', para(Math.floor(bakiye(p.getUuid()) * oran(server, 'olum', 5) / 100))))
      var cz = 500
      try { cz = global.cinayetCezasi ? global.cinayetCezasi(server, p.getUuid()) : 500 } catch (e) { cz = 500 }
      o.push(kart('Haksız cinayet cezan', 'Savaş/kelle dışında öldürürsen · servetin 10.000\'i her ikiye katlayışında ceza da ikiye katlanır', para(cz), { dr: 'kirmizi' }))
      return o
    } }

  // ----------------------------- SAVAŞ ------------------------------------
  function savaslar(server) { return veri(server, 'savas_veri').savaslar || [] }
  function savasDurum(s) {
    if (s.durum === 'onay') return 'Onay bekliyor · otomatik onaya ' + sure(s.onaySon - Date.now())
    if (s.durum === 'hazirlik') return 'Hazırlık · başlamaya ' + sure(s.baslangic - Date.now())
    return 'AKTİF · ' + sure(Date.now() - (s.aktifBas || Date.now())) + 'dir'
  }
  function tl(x) { return (x || []).reduce(function (a, y) { return a + y.m }, 0) }
  function savasSecenek(liste) { return liste.map(function (s) { return { d: String(s.id), y: '#' + s.id + ' ' + s.a.ad + ' vs ' + s.b.ad } }) }
  BOLUM.savas = { ad: 'Savaş',
    sekmeler: function () { return [{ id: 'durum', ad: 'Savaşlar' }, { id: 'ilan', ad: 'İlan & Barış' }, { id: 'antlasma', ad: 'Antlaşma' }, { id: 'muttefik', ad: 'Müttefik' }, { id: 'kelle', ad: 'Kelle Ödülü' }] },
    kur: function (p, s) {
      var server = p.server, id = String(p.getUuid())
      var l = savaslar(server)
      if (s === 'ilan') {
        return [
          yazi('Savaş ilanı: ' + para(5000) + ' + tarafının banka toplamının %10\'u (hazineye; reddedilirse iade). Başkan/OP onaylar, sonra hazırlık süresi başlar. Taraflar OPAC partisidir.'),
          yazi('Süre sınırı yok: antlaşma, barış veya teslimle biter; savaş sürdükçe her gün gider kesilir.'),
          sira([secim('hedef', 'Karşı oyuncu (çevrimiçi)', oyuncular(server, id, true), { l: 'Karşı taraftan bir oyuncu', w: 1.6 })]),
          dugmeler([dugme('Savaş ilan et', 'savas ilan {hedef}', { r: 'kirmizi', onay: 'Ücret kesilecek, emin misin?' }), dugme('Barış teklif et', 'savas baris {hedef}', { r: 'yesil' }),
            dugme('Teslim ol', 'savas teslim {hedef}', { r: 'kirmizi', onay: 'Tazminat ödersin, emin misin?' })])
        ]
      }
      if (s === 'antlasma') {
        var benim = l
        return [
          yazi('Antlaşma teklifi hazırla: para iste/ver, durduğun chunk\'ı iste/ver, sonra gönder. Karşı taraf kabul edince savaş biter.'),
          sira([secim('no', 'Savaş seç', savasSecenek(benim), { l: 'Savaş', w: 1.6 }), giris('miktar', 'spur', { l: 'Para', sayi: 1 })]),
          dugmeler([dugme('Para iste', 'savas antlasma {no} para al {miktar}'), dugme('Para ver', 'savas antlasma {no} para ver {miktar}')]),
          dugmeler([dugme('Bu chunk bize', 'savas antlasma {no} chunk al'), dugme('Bu chunk onlara', 'savas antlasma {no} chunk ver')]),
          dugmeler([dugme('Teklifi gör', 'savas antlasma {no} goster'), dugme('Temizle', 'savas antlasma {no} temizle'), dugme('Gönder', 'savas antlasma {no} gonder', { r: 'yesil' })]),
          dugmeler([dugme('Gelen teklifi kabul et', 'savas antlasma {no} kabul', { r: 'yesil', onay: 'Kabul? Savaş biter' }), dugme('Reddet', 'savas antlasma {no} reddet', { r: 'kirmizi' })])
        ]
      }
      if (s === 'muttefik') {
        return [
          yazi('Bir savaşa müttefik olarak katılmak için o taraftan bir oyuncuyu seç ve başvur; o tarafın lideri kabul eder.'),
          sira([secim('no', 'Savaş seç', savasSecenek(l), { l: 'Savaş', w: 1.3 }), secim('oyuncu', 'Oyuncu (çevrimiçi)', oyuncular(server, id, true), { l: 'Oyuncu', w: 1.3 })]),
          dugmeler([dugme('Yanına katıl', 'savas katil {no} {oyuncu}', { r: 'yesil' }), dugme('Müttefiki kabul et', 'savas kabul {no} {oyuncu}')])
        ]
      }
      if (s === 'kelle') {
        var k = veri(server, 'kelle_odul')
        var o = [yazi('Bir oyuncunun kellesine ödül koy (en az 1.000 spur, 7 gün). Harç: servetinin %5\'i. Koyanın kimliği gizli kalır.'),
          sira([secim('hedef', 'Oyuncu', oyuncular(server, id, false), { l: 'Hedef', w: 1.4 }), giris('miktar', 'en az 1000', { l: 'Ödül', sayi: 1 }),
            dugme('Ödül koy', 'kelle koy {hedef} {miktar}', { r: 'kirmizi', onay: 'Emin misin?', temizle: 1, w: 0.8 })]),
          baslik('Aktif kelle ödülleri')]
        var ids = Object.keys(k)
        ids.sort(function (a, b) { return tl(k[b]) - tl(k[a]) })
        ids.forEach(function (h) { o.push(satir(adi(server, h), para(tl(k[h])) + ' · ' + k[h].length + ' ödül', h === id ? 'kirmizi' : 'acik', 'baslik')) })
        if (!ids.length) o.push(yazi('Kimsenin kellesinde ödül yok.'))
        if (k[id]) o.push(dugme('Kellemi satın al (2 katı öde)', 'kelle temizle', { r: 'kirmizi', onay: 'Emin misin?' }))
        return o
      }
      // durum
      var o2 = []
      if (!l.length) o2.push(yazi('Şu an savaş yok.', 'acik'))
      l.forEach(function (x) {
        var m = function (u) { return u && u.length ? ' +' + u.length : '' }
        o2.push(kart('#' + x.id + '  ' + x.a.ad + m(x.ma) + '  vs  ' + x.b.ad + m(x.mb), savasDurum(x), x.skor.a + ' - ' + x.skor.b, { dr: x.durum === 'aktif' ? 'kirmizi' : 'baslik' }))
      })
      o2.push(BOSLUK)
      o2.push(yazi('Savaş dışında öldürmek suçtur: cezayı öldüren öder (Vergiler bölümünde senin cezan).'))
      o2.push(dugme('Ayrıntılar (sohbet)', 'savas durum'))
      return o2
    } }

  // ----------------------------- ZİNDAN -----------------------------------
  BOLUM.zindan = { ad: 'Zindan',
    sekmeler: function () { return [{ id: 'durum', ad: 'Zindan' }, { id: 'rekor', ad: 'Rekorlar' }, { id: 'siralama', ad: 'Sıralama' }] },
    kur: function (p, s) {
      var z = zindanOzet(p)
      if (s === 'rekor') {
        var o = [yazi('Her seviyenin en hızlı bitirilişi (aynı süredeyse önce bitiren). Sigil isteyen geçiş seviyeleri ◆ ile işaretli.')]
        var gecis = z.gecis || []
        var rk = z.seviyeler || []
        if (!rk.length) o.push(yazi('Henüz bitirilen seviye yok.', 'acik'))
        rk.forEach(function (e) {
          o.push(satir((gecis.indexOf(e.s) >= 0 ? '◆ ' : '') + 'Seviye ' + e.s + '  ·  ' + e.ad, dkSn(e.sure) + ' · ' + zaman(e.t) + (e.n > 1 ? ' · ' + e.n + ' kez' : ''), 'acik', 'baslik'))
        })
        return o
      }
      if (s === 'siralama') {
        var o2 = [yazi('En yüksek seviye, eşitse en kısa süre.')]
        ;(z.liste || []).forEach(function (e, i) { o2.push(satir((i + 1) + '. ' + e.ad, 'Sv.' + e.seviye + ' · ' + dkSn(e.sure), i === 0 ? 'baslik' : 'acik')) })
        if (!(z.liste || []).length) o2.push(yazi('Henüz kimse bitirmedi.'))
        return o2
      }
      var a = z.aktif
      var acik = Math.max(1, z.acik || 1)
      var gecis2 = z.gecis || []
      var sev = []
      for (var i = acik; i >= 1; i--) sev.push({ d: String(i), y: 'Seviye ' + i + (gecis2.indexOf(i) >= 0 ? '  ◆ sigil gerekir' : '') })
      var o3 = [
        a ? kart('Aktif Zindan', 'Ganimet ' + a.ganimet + ' · canavar ' + a.canavar + ' · ' + a.oda + ' oda', 'Sv.' + a.seviye + (a.katSayisi > 1 ? ' · Kat ' + a.kat + '/' + a.katSayisi : '') + ' · Hak ' + a.hak + ' · ' + dkSn(a.kalan), { dr: 'yesil' })
          : kart('Aktif Zindan', 'Giriş ücreti: seviye × ' + (z.ucret || 5) + ' spur', 'Yok'),
        kart('En Yüksek Seviye', 'Bitirilen koşu ' + (z.bitirilen || 0) + (z.enYuksek ? ' · en iyi süre ' + dkSn(z.sure) : ''), String(z.enYuksek || 0)),
        kart('Açık Seviyeler', 'Bir seviyeyi bitiren bir sonrakine kalıcı olarak girebilir', '1 - ' + acik),
        kart('Ganimet Deposu', 'Zindandan kazanılan her şey burada bekler', (z.depo || 0) > 0 ? z.depo + ' eşya' : 'Boş'),
        yazi('◆ Geçiş seviyeleri (' + (gecis2.length ? gecis2.join(', ') : '10, 25, 50...') + ') her girişte o seviyenin sigilini ister; sigili bir önceki seviyenin boss\'u düşürür.'),
        sira([secim('seviye', 'Seviye', sev, { l: 'Seviye', v: String(acik), w: 1.5 }), dugme('Zindana gir', 'zindan baslat {seviye}', { r: 'yesil', kapat: 1 })]),
        dugmeler([dugme('Depoyu aç', 'zindan depo', { kapat: 1 }), dugme('Zindandan ayrıl', 'zindan ayril', { r: 'kirmizi', onay: 'Ayrılırsan ganimetin %25\'i kalır' })])
      ]
      return o3
    } }

  // ----------------------------- SINIF & MESLEK ---------------------------
  BOLUM.yetenek = { ad: 'Sınıf & Meslek',
    sekmeler: function () { return [{ id: 'secim', ad: 'Sınıf & Meslek' }, { id: 'beceri', ad: 'Beceriler (Reskillable)' }] },
    kur: function (p, s) {
      if (s === 'beceri') {
        var bl = []
        try { bl = global.beceriOzet ? global.beceriOzet(p) : [] } catch (e) { bl = [] }
        var o0 = [yazi('Beceriler o işi yaptıkça gelişir (XP harcanmaz). Eşya ve zırh kilitleri bu seviyelere bakar.'),
          yazi('Madencilik: kazmayla taş/cevher · Toplayıcılık: balta/kürek · İnşaat: blok koymak · Çiftçilik: hasat, hayvan üretmek · Saldırı: canavar öldürmek · Savunma: canavardan hasar almak · Çeviklik: koşmak, zıplamak · Büyü: büyüleme, iksir, büyü yapmak. Kendi koyduğun bloğu kırmak sayılmaz.')]
        bl.forEach(function (x) { o0.push(kart(x.ad, x.gerek ? 'Sonraki seviyeye ' + x.puan + ' / ' + x.gerek : 'En üst seviye', 'Seviye ' + x.sv, { r: x.gerek ? x.puan / x.gerek : 1 })) })
        if (!bl.length) o0.push(yazi('Beceri bilgisi yok (Reskillable yüklü değil mi?).', 'kirmizi'))
        return o0
      }
      var y = null
      try { y = global.yetenekOzet ? global.yetenekOzet(p) : null } catch (e) { y = null }
      if (!y) return [yazi('Yetenek sistemi yüklenemedi.', 'kirmizi')]
      var z = zindanOzet(p)
      var o = [
        kart('Sınıf', y.sinif ? 'Seviye ' + y.sinifSv + ' · harcanmamış puan ' + y.sinifBos : (y.sinifAcik ? 'İlk seçim bedava, değiştirmek ' + sayi(y.degisim) + ' spur' : 'Zindanda ' + y.sinifZindan + '. seviyeyi bitirince açılır (sen: ' + (z.enYuksek || 0) + ')'),
          y.sinif ? y.sinifAd : 'Seçilmedi', { dr: y.sinif ? 'baslik' : 'gri' }),
        kart('Meslek', y.meslekler.length ? 'Seviye ' + y.meslekSv + ' · harcanmamış puan ' + y.meslekBos : 'İlk seçim bedava',
          y.meslekler.length ? y.meslekler.join(', ') : 'Seçilmedi', { dr: y.meslekler.length ? 'baslik' : 'gri' }),
        kart('Ek Meslek Hakkı', 'Bir meslek ağacını bitirince bir meslek daha seçebilirsin (ücretsiz)', y.ekHak > 0 ? y.ekHak + ' hak var' : 'Yok', { dr: y.ekHak > 0 ? 'yesil' : 'gri' }),
        BOSLUK,
        dugme('Yetenek ağaçlarını aç (Pufferfish)', 'yetenek ac', { r: 'yesil', kapat: 1 }),
        baslik('Sınıf seç')
      ]
      o.push(sira([secim('sinif', 'Sınıf', y.sinifSecenek, { l: y.sinif ? 'Değiştirirsen eski ağaç silinir (' + sayi(y.degisim) + ' spur)' : 'Her sınıfın 2 dalı var, biri seçilir', w: 2 }),
        dugme('Seç', 'sinif sec {sinif}', { onay: y.sinif ? sayi(y.degisim) + ' spur, emin misin?' : 'Seçilsin mi?' })]))
      o.push(baslik('Meslek seç'))
      o.push(yazi('Tüm meslekler Pufferfish\'te tek ağaçta ("Meslekler"); kökünü açtığın meslek seçilir. Buradan da seçebilirsin.'))
      o.push(sira([secim('meslek', 'Meslek', y.meslekSecenek, { l: y.meslekler.length && !y.ekHak ? 'Değiştirirsen aktif meslek silinir (' + sayi(y.degisim) + ' spur)' : 'Meslek', w: 2 }),
        dugme('Seç', 'meslek sec {meslek}', { onay: 'Seçilsin mi?' })]))
      o.push(baslik('Sıfırlama'))
      o.push(yazi('Harcanan puan × ' + y.puanUcret + ' spur; puanlar geri gelir, dal da değiştirebilirsin.'))
      o.push(dugmeler([dugme('Sınıfı sıfırla', 'yetenek sifirla sinif', { r: 'kirmizi', onay: 'Emin misin?' }), dugme('Meslekleri sıfırla', 'yetenek sifirla meslek', { r: 'kirmizi', onay: 'Emin misin?' })]))
      return o
    } }

  // ----------------------------- YÖNETİM (OP + başkan) --------------------
  BOLUM.yonetim = { ad: 'Yönetim', yetki: yonetici,
    sekmeler: function (p) {
      var l = [{ id: 'hazine', ad: 'Hazine' }, { id: 'vergi', ad: 'Vergi Oranları' }, { id: 'teftis', ad: 'Teftiş' }, { id: 'savas', ad: 'Savaş Onayı' }, { id: 'borsa', ad: 'Borsa Kasası' }]
      if (opMu(p)) l.push({ id: 'op', ad: 'OP' })
      return l
    },
    kur: function (p, s) {
      var server = p.server, id = String(p.getUuid())
      if (s === 'vergi') {
        var o = [yazi('Yüzdeler tam sayı (5 = %5). Kaydedince herkese duyurulur, bir dakika içinde uygulanır.')]
        VERGI_AD.forEach(function (v) {
          o.push(sira([giris('o_' + v[0], 'şu an ' + oranYazi(server, v[0], v[2]), { l: v[1], sayi: 1, w: 2.2 }), dugme('Kaydet', 'vergi oran ' + v[0] + ' {o_' + v[0] + '}', { temizle: 1 })]))
        })
        return o
      }
      if (s === 'teftis') {
        var x = Math.floor(p.getX() / 16), z = Math.floor(p.getZ() / 16)
        var sahip = null
        try {
          if (OPAC == null) OPAC = Java.loadClass('xaero.pac.common.server.api.OpenPACServerAPI')
          var c = OPAC.get(server).getServerClaimsManager().get(p.level.getDimension(), x, z)
          sahip = c == null ? null : c.getPlayerId()
        } catch (e) { sahip = null }
        var kat = veri(server, 'arazi_kategori')[String(p.level.getDimension()) + '|' + x + '|' + z]
        return [
          yazi('Arazinin üstünde dur; yanlış beyan edilmiş kategoriyi düzelt, istersen ceza yaz (ödenmezse borca geçer).'),
          kart('Chunk ' + x + ', ' + z, sahip == null ? 'Sahipsiz' : 'Sahibi ' + adi(server, sahip), sahip == null ? '-' : KAT_AD[kat && kat.o === String(sahip) ? kat.k : 'yerleske']),
          sira([secim('tur', 'Kategori', [{ d: 'yerleske', y: 'Yerleşke' }, { d: 'dukkan', y: 'Dükkan' }, { d: 'fabrika', y: 'Fabrika' }], { l: 'Doğru kategori' }),
            giris('ceza', 'boş = cezasız', { l: 'Ceza (spur)', sayi: 1 }), dugme('Düzelt', 'arazi duzelt {tur} {ceza?}', { onay: 'Emin misin?', temizle: 1 })])
        ]
      }
      if (s === 'savas') {
        var l = savaslar(server).filter(function (x2) { return x2.durum === 'onay' })
        var o2 = [yazi('Onay bekleyen savaşlar. Onaylanmayan savaş süre dolunca kendiliğinden onaylanır; reddedilirse ilan ücreti iade edilir.')]
        if (!l.length) o2.push(yazi('Onay bekleyen savaş yok.', 'acik'))
        l.forEach(function (x2) {
          o2.push(kart('#' + x2.id + '  ' + x2.a.ad + '  vs  ' + x2.b.ad, savasDurum(x2), ''))
          o2.push(dugmeler([dugme('Onayla', 'savas onayla ' + x2.id, { r: 'yesil' }), dugme('Reddet (ücret iade)', 'savas reddet ' + x2.id, { r: 'kirmizi', onay: 'Reddedilsin mi?' })]))
        })
        return o2
      }
      if (s === 'borsa') {
        var oz = {}
        try { oz = JSON.parse(server.persistentData.getString('borsa_ozet') || '{}') } catch (e) { oz = {} }
        return [
          kart('Borsa Kasası', 'Oyuncuların sattığı coin\'leri bu kasa öder', para(oz.kasa || 0)),
          kart('Dolaşımdaki coin değeri', 'Kasanın karşılaması gereken', para(oz.top || 0), oz.top > 0 ? { r: Math.min(1, (oz.kasa || 0) / oz.top) } : null),
          sira([giris('borsa', 'spur', { l: 'Miktar', sayi: 1 }), dugme('Hazineden kasaya', 'borsa kasa yatir {borsa}', { r: 'yesil', temizle: 1 }), dugme('Kasadan hazineye', 'borsa kasa cek {borsa}', { temizle: 1 })])
        ]
      }
      if (s === 'op') {
        if (!opMu(p)) return [yazi('Sadece OP.')]
        var b = server.persistentData.getString('baskan')
        var bk = bankalar(server).map(function (x3) { return { d: x3.ad, y: x3.ad + (x3.donuk ? ' (donuk)' : '') } })
        return [
          kart('Başkan', 'Vergi oranlarını ve hazineyi yönetir, savaşları onaylar', b ? adi(server, b) : 'Yok'),
          sira([secim('baskan', 'Oyuncu (çevrimiçi)', oyuncular(server, null, true), { l: 'Başkan ata', w: 1.6 }), dugme('Ata', 'devlet baskan {baskan}', { r: 'yesil', onay: 'Atansın mı?' }),
            dugme('Görevden al', 'devlet baskan kaldir', { r: 'kirmizi', onay: 'Emin misin?' })]),
          baslik('Bankalar'),
          bk.length ? sira([secim('bk', 'Banka', bk, { w: 1.6 }), dugme('Dondur', 'banka dondur {bk}', { r: 'kirmizi', onay: 'Dondurulsun mu?' }), dugme('Çöz', 'banka coz {bk}')]) : yazi('Banka yok.'),
          baslik('Borç'),
          sira([secim('borclu', 'Oyuncu (çevrimiçi)', oyuncular(server, null, true), { w: 1.6 }), dugme('Ayrıntı', 'kredi bak {borclu}'), dugme('Borcu sil', 'kredi borcsil {borclu}', { r: 'kirmizi', onay: 'Silinsin mi?' })])
        ]
      }
      // hazine
      var hv = veri(server, 'hazine_veri')
      var g = hv.gelir || {}
      var top = 0
      Object.keys(g).forEach(function (k) { if (!GIDER[k] && k !== 'yatirma' && k !== 'kelle_emanet') top += Number(g[k]) || 0 })
      var o3 = [
        kart('Devlet Hazinesi', 'Vergiler, cezalar, harçlar, lisanslar', para(bakiye(HAZINE))),
        kart('Toplam Gelir', 'Bugüne kadar hazineye giren (aktarımlar hariç)', para(top)),
        sira([secim('oyuncu', 'Oyuncu (çevrimiçi)', oyuncular(server, null, true), { l: 'Kime', w: 1.4 }), giris('miktar', 'spur', { l: 'Miktar', sayi: 1 }),
          dugme('Aktar', 'devlet aktar {oyuncu} {miktar}', { onay: 'Hazineden aktarılsın mı?', temizle: 1, w: 0.7 })]),
        dugmeler([dugme('Hazineden bankama çek', 'devlet cek {miktar}', { onay: 'Emin misin?' }), dugme('Bankamdan hazineye yatır', 'devlet yatir {miktar}')]),
        baslik('Son hareketler')
      ]
      ;(hv.hareket || []).slice(-80).reverse().forEach(function (e) {
        var gider = GIDER[e.tur]
        o3.push(satir(zaman(e.t) + '  ' + (HAREKET_AD[e.tur] || e.tur) + '  ' + e.k, (gider ? '-' : '+') + sayi(e.m), 'acik', gider ? 'kirmizi' : 'yesil'))
      })
      return o3
    } }

  // ----------------------------- EKRAN GÖNDERME ---------------------------
  function nav(p) {
    var l = []
    SIRA.forEach(function (id) {
      if (id === '') { l.push({ id: '', ad: '' }); return }
      var b = BOLUM[id]
      if (!b || (b.yetki && !b.yetki(p))) return
      l.push({ id: id, ad: b.ad })
    })
    return l
  }
  function ekranGonder(p, bolumId, sekme, ac) {
    var b = BOLUM[bolumId]
    if (!b || (b.yetki && !b.yetki(p))) { bolumId = 'genel'; b = BOLUM.genel }
    if (b.komut) { p.server.getCommands().performPrefixedCommand(p.createCommandSourceStack(), b.komut); return }
    var sekmeler = b.sekmeler ? b.sekmeler(p) : []
    if (!sekme) sekme = String(p.persistentData.getString('menu_sekme_' + bolumId) || '')
    if (sekmeler.length && !sekmeler.some(function (x) { return x.id === sekme })) sekme = sekmeler[0].id
    if (!sekmeler.length) sekme = ''
    p.persistentData.putString('menu_sekme_' + bolumId, sekme)
    var o
    try { o = b.kur(p, sekme) } catch (err) { console.error('[Menu] ' + bolumId + '/' + sekme + ' kurulamadi: ' + err); o = [yazi('Bu bölüm yüklenemedi: ' + err, 'kirmizi')] }
    var ekran = { b: bolumId, s: sekme, ad: b.ad, para: bakiye(p.getUuid()), nav: nav(p), sekmeler: sekmeler, o: o }
    try { tasiyici().gonder(p, JSON.stringify(ekran), !!ac) } catch (err2) { console.error('[Menu] gonderilemedi: ' + err2); p.tell(Text.red(Text.ofString('Menü açılamadı (sunucu_piyasa modu güncel mi?).'))) }
  }
  global.menuAc = function (p, bolum) { ekranGonder(p, bolum || 'genel', null, true) }

  // Sunucu Defteri (startup_scripts/menu_defteri.js): sağ tıklayınca menü açılır
  var DEFTER = 'kubejs:sunucu_defteri'
  ItemEvents.rightClicked(DEFTER, function (event) {
    var p = event.player
    if (p == null) return
    try { ekranGonder(p, 'genel', null, true) } catch (err) { console.error('[Menu] defter: ' + err) }
    event.cancel()
  })
  // İlk girişte herkese bir defter
  PlayerEvents.loggedIn(function (event) {
    var p = event.player
    var v = p.persistentData
    if (v.getBoolean('sunucu_defteri_verildi')) return
    p.give(Item.of(DEFTER))
    v.putBoolean('sunucu_defteri_verildi', true)
    p.tell(Text.gold(Text.ofString('Sunucu Defteri verildi: sağ tıkla veya Y tuşuna bas. K: Sınıf & Meslek.')))
  })
  ServerEvents.recipes(function (event) {
    event.shapeless(Item.of(DEFTER), ['minecraft:book', 'minecraft:gold_nugget']).id('kubejs:sunucu_defteri')
  })

  ServerEvents.commandRegistry(function (event) {
    var Commands = event.commands
    var Arguments = event.arguments
    function ac(ctx, bolum, sekme) {
      var p = ctx.source.player
      if (p == null) { ctx.source.sendSystemMessage(Text.ofString('Bu komutu oyun içinden kullanın.')); return 0 }
      var b = String(bolum || 'genel').toLowerCase()
      var es = { ana: 'genel', menu: 'genel', bankalar: 'banka', kredi: 'banka', vergi: 'arazi', devlet: 'yonetim', hazine: 'yonetim', teftis: 'yonetim', guncellemeler: 'genel', satislar: 'genel' }
      if (es[b]) b = es[b]
      ekranGonder(p, b, sekme ? String(sekme) : null, true)
      return 1
    }
    event.register(Commands.literal('menu')
      .executes(function (ctx) { return ac(ctx, 'genel', null) })
      .then(Commands.argument('bolum', Arguments.WORD.create(event))
        .executes(function (ctx) { return ac(ctx, Arguments.WORD.getResult(ctx, 'bolum'), null) })
        .then(Commands.argument('sekme', Arguments.WORD.create(event))
          .executes(function (ctx) { return ac(ctx, Arguments.WORD.getResult(ctx, 'bolum'), Arguments.WORD.getResult(ctx, 'sekme')) }))))
    // Açık ekranın tazelenmesi (sunucu_piyasa MenuSunucu, sessiz kaynakla çalıştırır)
    event.register(Commands.literal('menuveri')
      .then(Commands.argument('yol', Arguments.GREEDY_STRING.create(event)).executes(function (ctx) {
        var p = ctx.source.player
        if (p == null) return 0
        var y = String(Arguments.GREEDY_STRING.getResult(ctx, 'yol')).split('/')
        ekranGonder(p, y[0] || 'genel', y[1] || null, false)
        return 1
      })))
    // Açılır listedeki seçime göre yönlendirme
    function calistir(p, k) { p.server.getCommands().performPrefixedCommand(p.createCommandSourceStack(), k) }
    function islem(ctx, miktarVar) {
      var p = ctx.source.player
      if (p == null) return 0
      var tur = String(Arguments.WORD.getResult(ctx, 'islem'))
      var hedef = String(Arguments.WORD.getResult(ctx, 'hedef'))
      var m = miktarVar ? Arguments.INTEGER.getResult(ctx, 'miktar') : 0
      if (tur === 'kredi') {
        if (!miktarVar) { p.tell(Text.red(Text.ofString('Miktar yaz.'))); return 0 }
        calistir(p, hedef === 'devlet' ? 'kredi cek ' + m : 'banka basvur ' + hedef + ' ' + m)
        return 1
      }
      if (tur === 'ode') {
        if (hedef === 'borc') calistir(p, miktarVar ? 'borc ode ' + m : 'borc ode')
        else if (hedef === 'kredi') calistir(p, 'kredi ode')
        else {
          var b = (veri(p.server, 'banka_veri').b || {})[hedef]
          var x = b && b.defter ? b.defter[String(p.getUuid())] : null
          var tutar = miktarVar ? m : (x ? Math.ceil(x.k || 0) : 0)
          if (!(tutar > 0)) { p.tell(Text.red(Text.ofString('Bu bankaya borcun yok.'))); return 0 }
          calistir(p, 'banka ode ' + hedef + ' ' + tutar)
        }
        return 1
      }
      p.tell(Text.red(Text.ofString('Bilinmeyen işlem.')))
      return 0
    }
    event.register(Commands.literal('menuislem')
      .then(Commands.argument('islem', Arguments.WORD.create(event))
        .then(Commands.argument('hedef', Arguments.WORD.create(event))
          .executes(function (ctx) { return islem(ctx, false) })
          .then(Commands.argument('miktar', Arguments.INTEGER.create(event)).executes(function (ctx) { return islem(ctx, true) })))))
  })

  console.info('[Menu] sunucu menusu hazir: ' + SIRA.filter(function (x) { return x }).length + ' bolum')
})()
