// =====================================================================
//  SUNUCU MENÜSÜ  -  kubejs/server_scripts/arayuz_komut.js
//  Ekran: sunucu_piyasa modunun genel menü ekranı (istemci/MenuEkrani.java). Ekranın TAMAMI burada,
//  sunucuda JSON olarak kurulur ve gönderilir; menüdeki değişiklikler oyuncu güncellemesi gerektirmez
//  (sunucuda /reload veya yeniden başlatma yeter).
//    /menu [bölüm] [sekme]   -> ekranı açar (Y tuşu, Sunucu Defteri; K = /menu yetenek)
//    /menuveri <bölüm/sekme> -> açık ekranın 2 sn'de bir tazelenmesi (mod gönderir, sessiz)
//    /menuislem kredi|ode <kaynak> [miktar] -> açılır listedeki seçime göre doğru komuta yönlendirir
//  Öğe türleri ve alanları: MenuEkrani.java başındaki açıklama.
//  2026-11-25 (kullanıcı): Banka (hesap/transfer/günlük/kredi/bankalar/bankacı), Arazi sadeleşti,
//  Vergiler ayrı, Savaş sekmeli, Zindan rekorları, OP+başkan tek "Yönetim" bölümünde.
//  !! Gerçek bir oyunda ÇALIŞTIRILARAK TEST EDİLMEDİ.
// =====================================================================
;(function () {
  function ortak(ad) { try { return global.ortak ? global.ortak.get(ad) : null } catch (e) { return null } }
  var HAZINE = '5f0c2d1e-7a3b-4e9c-8d6f-1b2a3c4d5e6f'
  var JUUID = Java.loadClass('java.util.UUID')
  var Numismatics = Java.loadClass('dev.ithundxr.createnumismatics.Numismatics')
  var MenuSunucu = null, OPAC = null, ZindanApi = undefined
  function tasiyici() { if (MenuSunucu == null) MenuSunucu = Java.loadClass('tr.sunucu.piyasa.MenuSunucu'); return MenuSunucu }

  // ----------------------------- VERİ YARDIMCILARI ------------------------
  function veri(server, k) { var s = server.persistentData.getString(k); if (!s) return {}; try { return JSON.parse(s) || {} } catch (e) { return {} } }
  function bakiye(uuid) { try { var h = Numismatics.BANK.getAccount(typeof uuid === 'string' ? JUUID.fromString(uuid) : uuid); return h ? h.getBalance() : 0 } catch (e) { return 0 } }
  function para(n) { return String(Math.floor(n)).replace(/\B(?=(\d{3})+(?!\d))/g, '.') + ' spur' }
  function sayi(n) { return String(Math.floor(n)).replace(/\B(?=(\d{3})+(?!\d))/g, '.') }
  function iki(n) { return (n < 10 ? '0' : '') + n }
  function zaman(t) { var d = new Date(t); return iki(d.getDate()) + '.' + iki(d.getMonth() + 1) + ' ' + iki(d.getHours()) + ':' + iki(d.getMinutes()) }
  function sure(ms) { var dk = Math.max(0, Math.floor(ms / 60000)); var g = Math.floor(dk / 1440); return (g > 0 ? g + ' g ' : '') + Math.floor((dk % 1440) / 60) + ' sa ' + (dk % 60) + ' dk' }
  function dkSn(sn) { sn = Math.max(0, sn || 0); return Math.floor(sn / 60) + ':' + iki(sn % 60) }
  function opMu(p) { return p.createCommandSourceStack().hasPermission(2) }
  function baskanMi(p) { var b = p.server.persistentData.getString('baskan'); return !!b && b === String(p.getUuid()) }
  function yonetici(p) { return opMu(p) || baskanMi(p) }
  var adOnbellek = {}
  function adi(server, id) {
    id = String(id)
    var o = server.playerList.getPlayer(JUUID.fromString(id))
    if (o != null) { adOnbellek[id] = String(o.username); return adOnbellek[id] }
    if (adOnbellek[id]) return adOnbellek[id]
    try { var prof = server.getProfileCache().get(JUUID.fromString(id)); adOnbellek[id] = prof.isPresent() ? String(prof.get().getName()) : id.substring(0, 8) } catch (e) { adOnbellek[id] = id.substring(0, 8) }
    return adOnbellek[id]
  }
  // Açılır liste için oyuncular: çevrimiçiler önce, sonra kayıtlı (borç/yetenek kaydı olan) herkes
  function oyuncular(server, haric, sadeceCevrimici) {
    var on = {}, liste = []
    server.playerList.getPlayers().toArray().forEach(function (o) { on[String(o.getUuid())] = String(o.username) })
    Object.keys(on).forEach(function (id) { if (id !== haric) liste.push({ d: on[id], y: on[id], c: 1 }) })
    if (!sadeceCevrimici) {
      var kayit = {}
      Object.keys(veri(server, 'borc_veri').o || {}).forEach(function (id) { kayit[id] = 1 })
      Object.keys(veri(server, 'yetenek_veri').o || {}).forEach(function (id) { kayit[id] = 1 })
      Object.keys(kayit).forEach(function (id) { if (!on[id] && id !== haric && id.length > 30) { var a = adi(server, id); if (a.length < 17) liste.push({ d: a, y: a + ' (çevrimdışı)', c: 0 }) } })
    }
    liste.sort(function (a, b) { return a.c !== b.c ? b.c - a.c : (a.d.toLowerCase() < b.d.toLowerCase() ? -1 : 1) })
    return liste.map(function (x) { return { d: x.d, y: x.y } })
  }
  function oran(server, ad, vars) { try { return ortak('vergiOrani') ? Number(ortak('vergiOrani')(server, ad)) : vars } catch (e) { return vars } }

  // ----------------------------- ÖĞE KURUCULARI ---------------------------
  function ek(o, x) { if (x) Object.keys(x).forEach(function (k) { o[k] = x[k] }); return o }
  function kart(b, a, d, x) { return ek({ t: 'kart', b: b, a: a || '', d: d == null ? '' : String(d) }, x) }
  function yazi(m, r) { return { t: 'yazi', m: m, r: r || 'gri' } }
  function baslik(m) { return { t: 'baslik', m: m } }
  function satir(m, s, r, sr) { return { t: 'satir', m: m, s: s || '', r: r || 'acik', sr: sr || 'gri' } }
  function giris(ad, i, x) { return ek({ t: 'giris', ad: ad, i: i || '' }, x) }
  function secim(ad, i, sec, x) { return ek({ t: 'secim', ad: ad, i: i || 'Seç...', sec: sec }, x) }
  function dugme(y, k, x) { return ek({ t: 'dugme', y: y, k: k }, x) }
  function sira(o) { return { t: 'sira', o: o } }
  function dugmeler(l) { return { t: 'dugmeler', l: l } }
  var BOSLUK = { t: 'bosluk' }, CIZGI = { t: 'cizgi' }

  // ----------------------------- ORTAK KAYITLAR ---------------------------
  function borcKaydi(p) { return (veri(p.server, 'borc_veri').o || {})[String(p.getUuid())] || null }
  function vergiKaydi(p) { return (veri(p.server, 'vergi_veri').kayitlar || {})[String(p.getUuid())] || null }
  function claimSayisi(p) {
    try {
      if (OPAC == null) OPAC = Java.loadClass('xaero.pac.common.server.api.OpenPACServerAPI')
      var m = OPAC.get(p.server).getServerClaimsManager()
      return m.hasPlayerInfo(p.getUuid()) ? m.getPlayerInfo(p.getUuid()).getClaimCount() : 0
    } catch (e) { return 0 }
  }
  function zindanOzet(p) {
    if (ZindanApi === undefined) { try { ZindanApi = Java.loadClass('tr.sunucu.zindan.ZindanApi') } catch (e) { ZindanApi = null } }
    if (ZindanApi == null) return {}
    try { return JSON.parse(String(ZindanApi.ozet(String(p.getUuid())))) } catch (e) { return {} }
  }
  function bankalar(server) { var b = veri(server, 'banka_veri').b || {}; return Object.keys(b).map(function (k) { var x = b[k]; x.anahtar = k; return x }) }
  function bankaKasa(b) { return bakiye(b.hesap) }
  function bankaToplam(b) { var m = 0, k = 0, n = 0; Object.keys(b.defter || {}).forEach(function (u) { var r = b.defter[u]; m += r.m || 0; k += r.k || 0; if ((r.m || 0) > 0 || (r.k || 0) > 0) n++ }); return { m: m, k: k, n: n } }
  function bankam(p) { var id = String(p.getUuid()); return bankalar(p.server).filter(function (b) { return b.sahip === id || (b.calisan || []).indexOf(id) >= 0 })[0] || null }
  function tacirMi(p) { var r = (veri(p.server, 'yetenek_veri').o || {})[String(p.getUuid())] || {}; return r.meslek === 'tacir' || (r.ekMeslekler || []).indexOf('tacir') >= 0 }

  // ======================================================================
  //  BÖLÜMLER
  // ======================================================================
  var BOLUM = {}
  var SIRA = ['genel', 'rehber', 'ekonomi', 'borsa', 'banka', 'arazi', 'vergiler', 'savas', 'zindan', 'yetenek', '', 'yonetim']

  // ----------------------------- GENEL ------------------------------------
  var HAREKET_AD = { arazi: 'Arazi vergisi', olum: 'Ölüm vergisi', tescil: 'Tescil', cinayet: 'Cinayet cezası',
    savas: 'Savaş ilanı', borc: 'Borç tahsilatı', kredi: 'Kredi verildi', kredi_odeme: 'Kredi ödemesi',
    aktarim: 'Aktarım', cekim: 'Çekim', yatirma: 'Yatırma', zindan: 'Zindan girişi', kelle: 'Kelle ödülü', tazminat: 'Tazminat payı', yetenek: 'Sınıf/meslek ücreti', savas_gideri: 'Savaş gideri', savas_iade: 'Savaş ilanı iadesi',
    kelle_harci: 'Kelle harcı', kelle_emanet: 'Kelle ödülü emaneti', kelle_odeme: 'Kelle ödülü ödendi', kelle_iade: 'Kelle ödülü iadesi',
    kdv: 'Satış vergisi (KDV)', harc: 'Harç', arazi_ceza: 'Arazi beyan cezası', banka_lisans: 'Banka lisansı',
    borsa: 'Borsa komisyonu', borsa_kasa: 'Borsa kasasına', borsa_kasa_iade: 'Borsa kasasından', zindan_odul: 'Haftalık zindan ödülü' }
  var GIDER = { aktarim: 1, cekim: 1, kredi: 1, kelle: 1, savas_iade: 1, kelle_odeme: 1, kelle_iade: 1, borsa_kasa: 1, zindan_odul: 1 }

  BOLUM.genel = { ad: 'Genel',
    // 2026-11-28 (kullanıcı): Vendor Satışları Yönetim'e taşındı
    sekmeler: function () { return [{ id: 'ozet', ad: 'Özet' }, { id: 'guncelleme', ad: 'Güncellemeler' }] },
    kur: function (p, s) {
      var server = p.server
      if (s === 'guncelleme') {
        var o = []
        var n = []
        try { n = global.guncellemeNotlari || [] } catch (e) { n = [] }
        n.forEach(function (g) { o.push(baslik('Sürüm ' + g.surum + '  ·  ' + g.tarih)); (g.maddeler || []).forEach(function (m) { o.push(yazi('• ' + m, 'acik')) }); o.push(BOSLUK) })
        if (!o.length) o.push(yazi('Henüz güncelleme notu yok.'))
        return o
      }
      var r = borcKaydi(p), v = vergiKaydi(p), z = zindanOzet(p)
      var y = (veri(server, 'yetenek_veri').o || {})[String(p.getUuid())] || {}
      var not = r ? r.not : 500
      return [
        kart('Banka', 'Numismatics hesabındaki para', para(bakiye(p.getUuid()))),
        kart('Kredi Notu', 'Kredi limitini ve faizini belirler', not + ' / 1000', { r: not / 1000 }),
        kart('Borç', 'Ödenmeyen cezalar ve krediler (günlük %2 faiz)', r && r.borc > 0 ? para(Math.ceil(r.borc)) : 'Yok', { dr: r && r.borc > 0 ? 'kirmizi' : 'yesil' }),
        kart('Arazi', 'Kullanılan / kiralanan claim hakkı', claimSayisi(p) + ' / ' + (v && v.kota != null ? v.kota : 1) + ' hak'),
        kart('Zindan', 'Bitirdiğin en yüksek seviye', String(z.enYuksek || 0)),
        kart('Sınıf & Meslek', 'K tuşu', (y.sinif ? y.sinif : 'sınıf yok') + ' · ' + (y.meslek ? y.meslek : 'meslek yok')),
        kart('Savaşlar', 'Aktif ve hazırlıktaki savaşlar', String((veri(server, 'savas_veri').savaslar || []).length)),
        BOSLUK,
        yazi('Y: bu menü · K: Sınıf & Meslek (oradan yetenek ağaçlarına) · Sol listeden bölüm seç.')
      ]
    } }

  BOLUM.ekonomi = { ad: 'Ekonomi', komut: 'ekonomi' }
  BOLUM.borsa = { ad: 'Borsa', komut: 'borsaekran' }

  // ----------------------------- BANKA ------------------------------------
  // 2026-11-28 (kullanıcı): üstte Hesabım / İşlemler (+ bankacıya bankanın adı ve Başvurular). İşlemler'de 4 büyük kare:
  // Kredi, Mevduat, İşlem Geçmişim, Transfer; her biri kendi alt sayfası (gizli sekme, üstte İşlemler seçili kalır).
  // Açılır listede banka seçilince (/menusec) sayfa o bankanın bilgileriyle yeniden kurulur.
  function secimOku(p, k) { return String(p.persistentData.getString('menu_sec_' + k) || '') }
  function vadeYazi(h) { return h > 0 ? h + ' hafta vadeli' : 'vadesiz' }
  function kilitli(x) { var s = Date.now(), t = 0, en = 0; (x.kilit || []).forEach(function (k) { if (k.bit > s) { t += k.m; if (!en || k.bit < en) en = k.bit } }); return { m: t, bit: en } }
  var GERI = dugmeler([dugme('◀ İşlemler', 'menu banka islemler')])
  BOLUM.banka = { ad: 'Banka',
    sekmeler: function (p) {
      var l = [{ id: 'hesap', ad: 'Hesabım' }, { id: 'islemler', ad: 'İşlemler' }]
      var bm = bankam(p)
      if (bm) {
        var nb = Object.keys(bm.basvuru || {}).length + Object.keys(bm.mbasvuru || {}).length
        l.push({ id: 'bankaci', ad: bm.ad + ' Bankası' })
        l.push({ id: 'basvuru', ad: 'Başvurular' + (nb ? ' (' + nb + ')' : '') })
      } else l.push({ id: 'kur', ad: 'Banka Kur' })
      return l
    },
    gizli: ['kredi', 'mevduat', 'gecmis', 'transfer'],
    ust: function (s) { return ['kredi', 'mevduat', 'gecmis', 'transfer'].indexOf(s) >= 0 ? 'islemler' : '' },
    kur: function (p, s) {
      var server = p.server, id = String(p.getUuid())
      var hepsi = bankalar(server)
      var acik = hepsi.filter(function (b) { return !b.donuk })
      var kFaiz = function (b) { return b.faiz == null ? 10 : b.faiz }
      var mFaiz = function (b) { return b.mfaiz || 0 }
      var r0 = borcKaydi(p)

      if (s === 'islemler') {
        var krTop = 0, mevTop = 0, teklif = []
        hepsi.forEach(function (b) {
          var x = (b.defter || {})[id]
          if (x) { krTop += x.k || 0; mevTop += x.m || 0 }
          var bs = (b.basvuru || {})[id]
          if (bs && bs.durum === 'musteri') teklif.push(b.ad)
        })
        krTop += (r0 && r0.borc > 0 ? r0.borc : 0) + (r0 && r0.kredi ? r0.kredi.kalan : 0)
        var o = [{ t: 'kareler', l: [
          { y: 'Kredi', a: krTop > 0 ? 'borç ' + sayi(krTop) : 'çek · öde', k: 'menu banka kredi', r: krTop > 0 ? 'kirmizi' : 'baslik' },
          { y: 'Mevduat', a: mevTop > 0 ? sayi(mevTop) : 'yatır · çek', k: 'menu banka mevduat', r: 'yesil' },
          { y: 'İşlem Geçmişim', a: 'son işlemler', k: 'menu banka gecmis', r: 'mavi' },
          { y: 'Transfer', a: 'para gönder', k: 'menu banka transfer', r: 'acik' }
        ] }]
        if (teklif.length) o.push(yazi(teklif.join(', ') + ' Bankası kredi başvuruna yeni faiz teklif etti: Kredi sayfasında kabul et ya da vazgeç.', 'baslik'))
        return o
      }

      if (s === 'kredi') {
        var o1 = [GERI]
        var notu = r0 ? r0.not : 500
        var kd = null
        try { kd = ortak('krediKademe') ? ortak('krediKademe')(server, id, notu) : null } catch (e) { kd = null }
        // Borçlar
        o1.push(baslik('Borçların'))
        var borclar = []
        if (r0 && r0.borc > 0) { borclar.push({ d: 'borc', y: 'Devlet borcu · ' + para(Math.ceil(r0.borc)) }); o1.push(satir('Devlet borcu (ceza/vergi, günlük %2)', para(Math.ceil(r0.borc)), 'acik', 'kirmizi')) }
        if (r0 && r0.kredi) { borclar.push({ d: 'kredi', y: 'Devlet kredisi · ' + para(r0.kredi.kalan) }); o1.push(satir('Devlet kredisi', para(r0.kredi.kalan), 'acik', 'kirmizi')) }
        hepsi.forEach(function (b) {
          var x = (b.defter || {})[id]
          if (!x || !(x.k > 0)) return
          borclar.push({ d: b.anahtar, y: b.ad + ' Bankası · ' + para(x.k) })
          o1.push(satir(b.ad + ' Bankası', para(x.k) + (x.vd ? ' · günde ' + sayi(x.vd.taksit) : ''), 'acik', 'kirmizi'))
        })
        if (!borclar.length) o1.push(satir('Borcun yok', '', 'yesil'))
        var dz = veri(server, 'borc_durum')[id]
        if (dz) o1.push(kart('Yaptırım', '4. saat gelir %50 · 8. damga · 16. gelir %100 · 24. kelle + haciz', Math.floor(dz.g) + '. saat', { dr: 'kirmizi', r: Math.min(1, dz.g / 24) }))
        if (borclar.length) o1.push(sira([secim('borc', 'Hangi borç?', borclar, { v: borclar[0].d, w: 1.8 }), giris('odeme', 'boş = tamamı', { sayi: 1 }),
          dugme('Öde', 'menuislem ode {borc} {odeme?}', { r: 'yesil', temizle: 1, w: 0.7 })]))
        // Kredi çek: kaynak seçilince altında o kaynağın koşulları
        o1.push(baslik('Kredi çek'))
        var kaynak = [{ d: 'devlet', y: 'Devlet' }]
        acik.forEach(function (b) { if (b.sahip !== id) kaynak.push({ d: b.anahtar, y: b.ad + ' Bankası' }) })
        var sec = secimOku(p, 'banka_kaynak')
        if (!kaynak.some(function (k) { return k.d === sec })) sec = 'devlet'
        o1.push(secim('kaynak', 'Nereden?', kaynak, { l: 'Kredi kaynağı', v: sec, k: 'menusec banka/kredi banka_kaynak {kaynak}' }))
        var dugmeAd = 'Başvur'
        if (sec === 'devlet') {
          dugmeAd = 'Kredi çek'
          if (kd) {
            o1.push(satir('Limit', para(kd.limit)))
            o1.push(satir('Faiz (bir kez)', '%' + Math.round(kd.faiz * 100)))
          } else o1.push(satir('Kredi notun yetmiyor', notu + ' / 1000 (en az 300)', 'kirmizi'))
          o1.push(satir('Geri ödeme', '7 gün, günlük taksit'))
        } else {
          var kb = hepsi.filter(function (b) { return b.anahtar === sec })[0]
          o1.push(satir('Faiz (bir kez)', '%' + kFaiz(kb)))
          o1.push(satir('Limit', kb.klimit > 0 ? para(kb.klimit) : 'sınırsız'))
          o1.push(satir('Bankanın verebileceği', para(Math.max(0, bankaKasa(kb) - (kb.sermaye || 0)))))
          o1.push(satir('Geri ödeme', '7 gün, günlük taksit'))
        }
        o1.push(sira([giris('kmiktar', 'spur', { l: 'Miktar', sayi: 1, w: 1.6 }),
          dugme(dugmeAd, 'menuislem kredi {kaynak} {kmiktar}', { r: 'yesil', onay: 'Onayla', temizle: 1 })]))
        // Başvurular (faiz teklifi gelirse burada kabul edilir)
        var bek = []
        hepsi.forEach(function (b) {
          var x = (b.basvuru || {})[id]
          if (!x) return
          var f0 = x.f0 == null ? x.f : x.f0
          if (x.durum === 'musteri') {
            bek.push(satir(b.ad + ' Bankası · ' + para(x.m), 'faiz %' + f0 + ' → %' + x.f + ' teklif', 'acik', 'baslik'))
            bek.push(dugmeler([dugme('Kabul et (%' + x.f + ')', 'banka kabul ' + b.anahtar, { r: 'yesil', onay: 'Kredi verilsin mi?' }), dugme('Vazgeç', 'banka vazgec ' + b.anahtar, { r: 'kirmizi' })]))
          } else {
            bek.push(satir(b.ad + ' Bankası · ' + para(x.m) + ' · %' + x.f, 'onay bekliyor', 'acik', 'gri'))
            bek.push(dugmeler([dugme('Vazgeç', 'banka vazgec ' + b.anahtar, { r: 'kirmizi' })]))
          }
        })
        if (bek.length) { o1.push(baslik('Başvuruların')); o1 = o1.concat(bek) }
        return o1
      }

      if (s === 'mevduat') {
        var o2 = [GERI]
        var var1 = false
        var cekSec = []
        o2.push(baslik('Mevduatların'))
        hepsi.forEach(function (b) {
          var x = (b.defter || {})[id]
          if (!x || !(x.m > 0)) return
          var1 = true
          var kl = kilitli(x)
          o2.push(satir(b.ad + ' Bankası · %' + mFaiz(b) + '/hafta', sayi(x.m) + (kl.m > 0 ? ' (' + sayi(kl.m) + ' vadeli, ' + zaman(kl.bit) + ')' : ''), 'acik', 'yesil'))
          cekSec.push({ d: b.anahtar, y: b.ad + ' · çekilebilir ' + sayi(Math.max(0, x.m - kl.m)) })
        })
        if (!var1) o2.push(satir('Mevduatın yok', ''))
        o2.push(baslik('Mevduat yatır'))
        if (!acik.length) o2.push(yazi('Henüz açık banka yok.'))
        else {
          var ms = secimOku(p, 'banka_mbanka')
          if (!acik.some(function (b) { return b.anahtar === ms })) ms = acik[0].anahtar
          var mb = acik.filter(function (b) { return b.anahtar === ms })[0]
          o2.push(secim('mbanka', 'Banka', acik.map(function (b) { return { d: b.anahtar, y: b.ad + ' Bankası' } }), { l: 'Banka', v: ms, k: 'menusec banka/mevduat banka_mbanka {mbanka}' }))
          var tm = bankaToplam(mb)
          o2.push(satir('Mevduat faizi', '%' + mFaiz(mb) + ' / hafta'))
          o2.push(satir('Kasa / mevduat', tm.m > 0 ? '%' + Math.round(bankaKasa(mb) / tm.m * 100) : '-'))
          o2.push(sira([giris('mmiktar', 'spur', { l: 'Miktar', sayi: 1 }),
            secim('vade', 'Vade', [{ d: '0', y: 'Vadesiz' }, { d: '1', y: '1 hafta' }, { d: '2', y: '2 hafta' }, { d: '4', y: '4 hafta' }], { l: 'Vade', v: '0' }),
            dugme('Başvur', 'banka yatir {mbanka} {mmiktar} {vade}', { r: 'yesil', temizle: 1, w: 0.7 })]))
        }
        hepsi.forEach(function (b) {
          var x = (b.mbasvuru || {})[id]
          if (!x) return
          o2.push(satir(b.ad + ' Bankası · ' + para(x.m) + ' · ' + vadeYazi(x.v), 'onay bekliyor', 'acik', 'gri'))
          o2.push(dugmeler([dugme('Vazgeç', 'banka mvazgec ' + b.anahtar, { r: 'kirmizi' })]))
        })
        if (cekSec.length) {
          o2.push(baslik('Mevduat çek'))
          o2.push(sira([secim('cbanka', 'Banka', cekSec, { v: cekSec[0].d, w: 1.6 }), giris('cmiktar', 'spur', { sayi: 1 }),
            dugme('Çek', 'banka cek {cbanka} {cmiktar}', { temizle: 1, w: 0.6 })]))
        }
        return o2
      }

      if (s === 'gecmis') {
        var l = []
        ;((veri(server, 'transfer_veri').o || {})[id] || []).forEach(function (e) {
          l.push(e.y === 'g' ? { t: e.t, m: 'Transfer → ' + e.k + (e.h ? ' (harç ' + sayi(e.h) + ')' : ''), d: -e.m } : { t: e.t, m: 'Transfer ← ' + e.k, d: e.m })
        })
        hepsi.forEach(function (b) {
          var x = (b.defter || {})[id]
          ;((x && x.g) || []).forEach(function (e) {
            l.push({ t: e.t, m: b.ad + ' · ' + (e.a === 'kredi' ? 'kredi' : 'mevduat') + (e.n ? ' · ' + e.n : ''), d: (e.y || 0) - (e.e || 0), k: e.a === 'kredi' })
          })
        })
        l.sort(function (a, b) { return b.t - a.t })
        var o3 = [GERI]
        l.slice(0, 60).forEach(function (e) {
          var arti = e.k ? e.d < 0 : e.d >= 0   // kredi borcunun azalması iyi
          o3.push(satir(zaman(e.t) + '  ' + e.m, (e.d >= 0 ? '+' : '') + sayi(e.d), 'acik', arti ? 'yesil' : 'kirmizi'))
        })
        if (!l.length) o3.push(satir('Henüz işlem yok', ''))
        return o3
      }

      if (s === 'transfer') {
        return [GERI,
          baslik('Para gönder'),
          sira([secim('alici', 'Alıcı seç', oyuncular(server, id, false), { l: 'Alıcı', w: 1.4 }), giris('miktar', 'spur', { l: 'Miktar', sayi: 1 }),
            dugme('Gönder', 'banka gonder {alici} {miktar}', { r: 'yesil', onay: 'Emin misin?', temizle: 1, w: 0.8 })]),
          satir('Harç', '%' + oran(server, 'transfer', 1))]
      }

      if (s === 'basvuru') {
        var bb = bankam(p)
        if (!bb) return [yazi('Bir bankanın sahibi veya çalışanı değilsin.')]
        var o7 = [baslik('Kredi başvuruları')]
        var bk = Object.keys(bb.basvuru || {})
        if (!bk.length) o7.push(satir('Bekleyen başvuru yok', ''))
        bk.forEach(function (u, i) {
          var x = bb.basvuru[u]
          var not = ((veri(server, 'borc_veri').o || {})[u] || {}).not
          var eskiK = ((bb.defter || {})[u] || {}).k || 0
          var f = x.f == null ? kFaiz(bb) : x.f
          var bekle = x.durum === 'musteri'
          o7.push(satir(x.ad + ' · ' + para(x.m) + ' · not ' + (not == null ? 500 : not) + (eskiK > 0 ? ' · borcu ' + sayi(eskiK) : ''),
            '%' + f + (bekle ? ' · müşteri onayı bekleniyor' : ''), 'acik', bekle ? 'baslik' : 'gri'))
          o7.push(sira([giris('tf' + i, 'yeni faiz %', { sayi: 1, w: 0.8 }), dugme('Faiz teklif et', 'banka teklif ' + x.ad + ' {tf' + i + '}', { temizle: 1 }),
            dugme('Onayla', 'banka onayla ' + x.ad, { r: 'yesil', onay: 'Para kasadan çıkar', pasif: bekle, w: 0.7 }),
            dugme('Reddet', 'banka reddet ' + x.ad, { r: 'kirmizi', w: 0.7 })]))
        })
        o7.push(baslik('Mevduat başvuruları'))
        var mk = Object.keys(bb.mbasvuru || {})
        if (!mk.length) o7.push(satir('Bekleyen başvuru yok', ''))
        mk.forEach(function (u) {
          var x = bb.mbasvuru[u]
          o7.push(satir(x.ad + ' · ' + para(x.m), vadeYazi(x.v), 'acik'))
          o7.push(dugmeler([dugme('Onayla', 'banka monayla ' + x.ad, { r: 'yesil' }), dugme('Reddet', 'banka mreddet ' + x.ad, { r: 'kirmizi' })]))
        })
        return o7
      }

      if (s === 'bankaci') {
        var b = bankam(p)
        if (!b) return [yazi('Bir bankanın sahibi veya çalışanı değilsin.')]
        var t2 = bankaToplam(b), k2 = bankaKasa(b)
        var sahip = b.sahip === id
        var o5 = [
          kart('Kasa', sahip ? 'sahibisin' : 'çalışansın', para(k2)),
          kart('Serbest Para', 'kasa - kilitli sermaye', para(Math.max(0, k2 - (b.sermaye || 0)))),
          kart('Mevduat · Kredi', t2.n + ' müşteri', sayi(t2.m) + ' · ' + sayi(t2.k), t2.m > 0 ? { r: Math.min(1, k2 / t2.m) } : null)
        ]
        o5.push(baslik('Faiz oranları'))
        if (sahip) {
          o5.push(sira([giris('kfaiz', '%' + kFaiz(b), { l: 'Kredi faizi (bir kez)', sayi: 1, w: 2 }), dugme('Kaydet', 'banka faiz kredi {kfaiz}', { temizle: 1 })]))
          o5.push(sira([giris('mfaiz', '%' + mFaiz(b), { l: 'Mevduat faizi (haftalık)', sayi: 1, w: 2 }), dugme('Kaydet', 'banka faiz mevduat {mfaiz}', { temizle: 1 })]))
          o5.push(sira([giris('klimit', b.klimit > 0 ? sayi(b.klimit) : 'sınırsız', { l: 'Kredi limiti (0 = sınırsız)', sayi: 1, w: 2 }), dugme('Kaydet', 'banka limit {klimit}', { temizle: 1 })]))
        } else {
          o5.push(satir('Kredi faizi', '%' + kFaiz(b)))
          o5.push(satir('Mevduat faizi', '%' + mFaiz(b) + ' / hafta'))
          o5.push(satir('Kredi limiti', b.klimit > 0 ? para(b.klimit) : 'sınırsız'))
        }
        var mus = Object.keys(b.defter || {}).filter(function (u) { var r3 = b.defter[u]; return (r3.m || 0) > 0 || (r3.k || 0) > 0 })
        if (mus.length) {
          o5.push(baslik('Müşteriler'))
          mus.forEach(function (u) { var r3 = b.defter[u]; o5.push(satir(r3.ad, 'mevduat ' + sayi(r3.m || 0) + ' · kredi ' + sayi(r3.k || 0))) })
        }
        if (sahip) {
          o5.push(baslik('Çalışanlar'))
          if ((b.calisan || []).length) o5.push(satir((b.calisan || []).map(function (u) { return adi(server, u) }).join(', '), ''))
          o5.push(sira([secim('calisan', 'Oyuncu (çevrimiçi)', oyuncular(server, id, true), { w: 1.5 }), dugme('Ekle', 'banka calisan ekle {calisan}'), dugme('Çıkar', 'banka calisan cikar {calisan}', { r: 'kirmizi' })]))
        }
        o5.push(BOSLUK)
        o5.push(dugmeler([dugme('Banka kartı al', 'banka kart'), sahip ? dugme('Bankamı kapat', 'banka kapat', { r: 'kirmizi', onay: 'Kapatılsın mı?' }) : dugme('Hareketler (sohbet)', 'banka hareket ' + b.ad)]))
        return o5
      }

      if (s === 'kur') {
        return [
          kart('Tacir', 'meslek şartı', tacirMi(p) ? 'Uygun' : 'Değil', { dr: tacirMi(p) ? 'yesil' : 'kirmizi' }),
          kart('Bakiyen', '5.000 lisans + 20.000 kilitli sermaye', para(bakiye(p.getUuid())), { dr: bakiye(p.getUuid()) >= 25000 ? 'yesil' : 'kirmizi' }),
          sira([giris('yeniad', '3-16 harf/rakam', { l: 'Banka adı', w: 2 }), dugme('Banka kur', 'banka kur {yeniad}', { r: 'yesil', onay: '25.000 spur, emin misin?' })])
        ]
      }

      // hesap
      var mev = 0, kr = 0
      hepsi.forEach(function (b) { var x = (b.defter || {})[id]; if (x) { mev += x.m || 0; kr += x.k || 0 } })
      var toplamBorc = kr + (r0 && r0.borc > 0 ? r0.borc : 0) + (r0 && r0.kredi ? r0.kredi.kalan : 0)
      return [
        kart('Banka Bakiyen', '', para(bakiye(p.getUuid()))),
        kart('Kredi Notu', '', (r0 ? r0.not : 500) + ' / 1000', { r: (r0 ? r0.not : 500) / 1000 }),
        kart('Bankalardaki Mevduatın', '', para(mev)),
        kart('Toplam Borcun', '', para(toplamBorc), { dr: toplamBorc > 0 ? 'kirmizi' : 'yesil' })
      ]
    } }

  // ----------------------------- ARAZİ ------------------------------------
  var KAT_AD = { yerleske: 'Yerleşke', dukkan: 'Dükkan', fabrika: 'Fabrika' }
  BOLUM.arazi = { ad: 'Arazi',
    kur: function (p) {
      var server = p.server
      var r = vergiKaydi(p)
      var n = claimSayisi(p)
      var kota = r && r.kota != null ? r.kota : 1
      var g = r && r.g != null ? r.g : 0
      var kira = oran(server, 'kira', 35)
      var o = [
        kart('Claim Hakkı', '1 hak bedava · fazlası hak başı ' + kira + ' spur/gün', n + ' / ' + kota + ' hak', { r: kota > 0 ? Math.min(1, n / kota) : 0 }),
        kart('Günlük Kira', 'Haklar + dükkan/fabrika farkı + araçlar · her gün bankadan kesilir', para(g) + '/gün'),
        kart('Kategoriler', 'Yerleşke · Dükkan · Fabrika · Araç', r && r.dg ? 'Y ' + r.dg.y + ' · D ' + r.dg.d + ' · F ' + r.dg.f + ' · A ' + (r.dg.a || 0) : 'Yerleşke ' + n)
      ]
      if (r && r.askida) o.push(kart('ASKIDA', r.haciz ? 'Borç haczi: borcu ödeyince geri gelir' : 'Kira ödenmedi: bankana para koy, otomatik geri gelir', 'Askıda', { dr: 'kirmizi' }))
      else if (r && g > 0) o.push(kart('Ödenmiş Süre', 'Sonraki kesime kalan (çubuk = 1 gün)', sure(Math.max(0, r.kredi || 0) / g * 86400000), { r: Math.min(1, Math.max(0, r.kredi || 0) / g) }))
      o.push(baslik('Claim hakkı kirala'))
      o.push(yazi('Toplam hak sayısını yaz (0 = sadece bedava hak). Artırınca eklenen hakların 1 günlük kirası hemen kesilir. Azaltırsan fazla claim\'lerin (sana en uzak olanlar) bırakılır; bunun için iki kez basman gerekir.'))
      o.push(sira([giris('kota', 'şu an ' + kota, { l: 'Toplam hak', sayi: 1 }), dugme('Kirala', 'arazi kota {kota}', { r: 'yesil' })]))
      // Bulunulan chunk
      var x = Math.floor(p.getX() / 16), z = Math.floor(p.getZ() / 16)
      var sahip = null
      try {
        if (OPAC == null) OPAC = Java.loadClass('xaero.pac.common.server.api.OpenPACServerAPI')
        var c = OPAC.get(server).getServerClaimsManager().get(p.level.getDimension(), x, z)
        sahip = c == null ? null : c.getPlayerId()
      } catch (e) { sahip = null }
      var kat = veri(server, 'arazi_kategori')[String(p.level.getDimension()) + '|' + x + '|' + z]
      var kendi = sahip != null && String(sahip) === String(p.getUuid())
      o.push(baslik('Durduğun chunk (' + x + ', ' + z + ')'))
      o.push(kart(sahip == null ? 'Sahipsiz' : 'Sahibi: ' + adi(server, sahip), 'Kategori: dükkan ' + oran(server, 'dukkan', 100) + ', fabrika ' + oran(server, 'fabrika', 150) + ' spur/gün',
        sahip == null ? '-' : KAT_AD[kat && kat.o === String(sahip) ? kat.k : 'yerleske'] || 'Yerleşke'))
      if (kendi) o.push(dugmeler([dugme('Yerleşke yap', 'arazi kategori yerleske'), dugme('Dükkan yap', 'arazi kategori dukkan'), dugme('Fabrika yap', 'arazi kategori fabrika')]))
      else o.push(yazi(sahip == null ? 'Claim için haritayı kullan (Xaero, OPAC).' : 'Kategori sadece kendi chunk\'ında değiştirilir.'))
      return o
    } }

  // ----------------------------- VERGİLER (görüntüleme) -------------------
  var VERGI_AD = [['kira', 'Claim hakkı kirası', 'spur/gün'], ['dukkan', 'Dükkan chunk fiyatı', 'spur/gün'], ['fabrika', 'Fabrika chunk fiyatı', 'spur/gün'],
    ['arac', 'Araç vergisi (aero claim başına)', 'spur/gün'], ['kdv', 'KDV (Selling Bin satışı)', '%'], ['harc', 'Ticaret harcı (Vendor/depozitör)', '%'],
    ['transfer', 'Para transferi harcı', '%'], ['olum', 'Ölüm vergisi (banka bakiyesinden)', '%'],
    ['borsa', 'Borsa komisyonu', '%'], ['cinayet', 'Haksız cinayet cezası tabanı', 'spur'], ['zindan_odul', 'Haftalık zindan ödülü (1. ekip)', 'spur']]
  var VERGI_VARS = { kira: 35, dukkan: 100, fabrika: 150, arac: 35, kdv: 5, harc: 1, transfer: 1, olum: 5, tescil: 500, borsa: 1, cinayet: 500, zindan_odul: 3000 }
  function oranYazi(server, k, birim) { var v = oran(server, k, VERGI_VARS[k]); return birim === '%' ? '%' + v : sayi(v) + ' ' + birim }
  BOLUM.vergiler = { ad: 'Vergiler',
    kur: function (p) {
      var server = p.server
      var b = server.persistentData.getString('baskan')
      var o = [yazi('Oranları başkan belirler' + (b ? ' (Başkan: ' + adi(server, b) + ')' : '') + '; her değişiklik sohbete duyurulur.')]
      VERGI_AD.forEach(function (v) { o.push(satir(v[1], oranYazi(server, v[0], v[2]), 'acik', 'baslik')) })
      o.push(baslik('Sana etkisi'))
      var r = vergiKaydi(p)
      o.push(kart('Günlük arazi kiran', 'Claim hakkı + kategori farkları + araçlar', para(r && r.g ? r.g : 0)))
      o.push(kart('Ölürsen ölüm vergisi', 'Bankandaki paranın %' + oran(server, 'olum', 5) + '\'i (savaş dışında öldürülürsen katil öder)', para(Math.floor(bakiye(p.getUuid()) * oran(server, 'olum', 5) / 100))))
      var cz = 500
      try { cz = ortak('cinayetCezasi') ? ortak('cinayetCezasi')(server, p.getUuid()) : 500 } catch (e) { cz = 500 }
      o.push(kart('Haksız cinayet cezan', 'Savaş/kelle dışında öldürürsen · servetin 10.000\'i her ikiye katlayışında ceza da ikiye katlanır', para(cz), { dr: 'kirmizi' }))
      return o
    } }

  // ----------------------------- SAVAŞ ------------------------------------
  function savaslar(server) { return veri(server, 'savas_veri').savaslar || [] }
  function savasDurum(s) {
    if (s.durum === 'onay') return 'Onay bekliyor · otomatik onaya ' + sure(s.onaySon - Date.now())
    if (s.durum === 'hazirlik') return 'Hazırlık · başlamaya ' + sure(s.baslangic - Date.now())
    return 'AKTİF · ' + sure(Date.now() - (s.aktifBas || Date.now())) + 'dir'
  }
  function tl(x) { return (x || []).reduce(function (a, y) { return a + y.m }, 0) }
  function savasSecenek(liste) { return liste.map(function (s) { return { d: String(s.id), y: '#' + s.id + ' ' + s.a.ad + ' vs ' + s.b.ad } }) }
  BOLUM.savas = { ad: 'Savaş',
    sekmeler: function () { return [{ id: 'durum', ad: 'Savaşlar' }, { id: 'ilan', ad: 'İlan & Barış' }, { id: 'antlasma', ad: 'Antlaşma' }, { id: 'muttefik', ad: 'Müttefik' }, { id: 'kelle', ad: 'Kelle Ödülü' }] },
    kur: function (p, s) {
      var server = p.server, id = String(p.getUuid())
      var l = savaslar(server)
      if (s === 'ilan') {
        return [
          yazi('Savaş ilanı: ' + para(5000) + ' + tarafının banka toplamının %10\'u (hazineye; reddedilirse iade). Başkan/OP onaylar, sonra hazırlık süresi başlar. Taraflar OPAC partisidir.'),
          yazi('Süre sınırı yok: antlaşma, barış veya teslimle biter; savaş sürdükçe her gün gider kesilir.'),
          sira([secim('hedef', 'Karşı oyuncu (çevrimiçi)', oyuncular(server, id, true), { l: 'Karşı taraftan bir oyuncu', w: 1.6 })]),
          dugmeler([dugme('Savaş ilan et', 'savas ilan {hedef}', { r: 'kirmizi', onay: 'Ücret kesilecek, emin misin?' }), dugme('Barış teklif et', 'savas baris {hedef}', { r: 'yesil' }),
            dugme('Teslim ol', 'savas teslim {hedef}', { r: 'kirmizi', onay: 'Tazminat ödersin, emin misin?' })])
        ]
      }
      if (s === 'antlasma') {
        var benim = l
        return [
          yazi('Antlaşma teklifi hazırla: para iste/ver, durduğun chunk\'ı iste/ver, sonra gönder. Karşı taraf kabul edince savaş biter.'),
          sira([secim('no', 'Savaş seç', savasSecenek(benim), { l: 'Savaş', w: 1.6 }), giris('miktar', 'spur', { l: 'Para', sayi: 1 })]),
          dugmeler([dugme('Para iste', 'savas antlasma {no} para al {miktar}'), dugme('Para ver', 'savas antlasma {no} para ver {miktar}')]),
          dugmeler([dugme('Bu chunk bize', 'savas antlasma {no} chunk al'), dugme('Bu chunk onlara', 'savas antlasma {no} chunk ver')]),
          dugmeler([dugme('Teklifi gör', 'savas antlasma {no} goster'), dugme('Temizle', 'savas antlasma {no} temizle'), dugme('Gönder', 'savas antlasma {no} gonder', { r: 'yesil' })]),
          dugmeler([dugme('Gelen teklifi kabul et', 'savas antlasma {no} kabul', { r: 'yesil', onay: 'Kabul? Savaş biter' }), dugme('Reddet', 'savas antlasma {no} reddet', { r: 'kirmizi' })])
        ]
      }
      if (s === 'muttefik') {
        return [
          yazi('Bir savaşa müttefik olarak katılmak için o taraftan bir oyuncuyu seç ve başvur; o tarafın lideri kabul eder.'),
          sira([secim('no', 'Savaş seç', savasSecenek(l), { l: 'Savaş', w: 1.3 }), secim('oyuncu', 'Oyuncu (çevrimiçi)', oyuncular(server, id, true), { l: 'Oyuncu', w: 1.3 })]),
          dugmeler([dugme('Yanına katıl', 'savas katil {no} {oyuncu}', { r: 'yesil' }), dugme('Müttefiki kabul et', 'savas kabul {no} {oyuncu}')])
        ]
      }
      if (s === 'kelle') {
        var k = veri(server, 'kelle_odul')
        var o = [yazi('Bir oyuncunun kellesine ödül koy (en az 1.000 spur, 7 gün). Harç: servetinin %5\'i. Koyanın kimliği gizli kalır.'),
          sira([secim('hedef', 'Oyuncu', oyuncular(server, id, false), { l: 'Hedef', w: 1.4 }), giris('miktar', 'en az 1000', { l: 'Ödül', sayi: 1 }),
            dugme('Ödül koy', 'kelle koy {hedef} {miktar}', { r: 'kirmizi', onay: 'Emin misin?', temizle: 1, w: 0.8 })]),
          baslik('Aktif kelle ödülleri')]
        var ids = Object.keys(k)
        ids.sort(function (a, b) { return tl(k[b]) - tl(k[a]) })
        ids.forEach(function (h) { o.push(satir(adi(server, h), para(tl(k[h])) + ' · ' + k[h].length + ' ödül', h === id ? 'kirmizi' : 'acik', 'baslik')) })
        if (!ids.length) o.push(yazi('Kimsenin kellesinde ödül yok.'))
        if (k[id]) o.push(dugme('Kellemi satın al (2 katı öde)', 'kelle temizle', { r: 'kirmizi', onay: 'Emin misin?' }))
        return o
      }
      // durum
      var o2 = []
      if (!l.length) o2.push(yazi('Şu an savaş yok.', 'acik'))
      l.forEach(function (x) {
        var m = function (u) { return u && u.length ? ' +' + u.length : '' }
        o2.push(kart('#' + x.id + '  ' + x.a.ad + m(x.ma) + '  vs  ' + x.b.ad + m(x.mb), savasDurum(x), x.skor.a + ' - ' + x.skor.b, { dr: x.durum === 'aktif' ? 'kirmizi' : 'baslik' }))
      })
      o2.push(BOSLUK)
      o2.push(yazi('Savaş dışında öldürmek suçtur: cezayı öldüren öder (Vergiler bölümünde senin cezan).'))
      o2.push(dugme('Ayrıntılar (sohbet)', 'savas durum'))
      return o2
    } }

  // ----------------------------- ZİNDAN -----------------------------------
  BOLUM.zindan = { ad: 'Zindan',
    sekmeler: function () { return [{ id: 'durum', ad: 'Zindan' }, { id: 'hafta', ad: 'Bu Hafta' }, { id: 'rekor', ad: 'Rekorlar' }, { id: 'siralama', ad: 'Sıralama' }] },
    kur: function (p, s) {
      var z = zindanOzet(p)
      if (s === 'rekor') {
        var o = [yazi('Her seviyenin en hızlı bitirilişi (aynı süredeyse önce bitiren). Sigil isteyen geçiş seviyeleri ◆ ile işaretli.')]
        var gecis = z.gecis || []
        var rk = z.seviyeler || []
        if (!rk.length) o.push(yazi('Henüz bitirilen seviye yok.', 'acik'))
        rk.forEach(function (e) {
          o.push(satir((gecis.indexOf(e.s) >= 0 ? '◆ ' : '') + 'Seviye ' + e.s + '  ·  ' + e.ad, dkSn(e.sure) + ' · ' + zaman(e.t) + (e.n > 1 ? ' · ' + e.n + ' kez' : ''), 'acik', 'baslik'))
        })
        return o
      }
      if (s === 'hafta') {
        var od = oran(p.server, 'zindan_odul', 3000)
        var oh = [yazi('Her pazartesi haftanın en iyi 3 ekibi ödül alır: en yüksek seviye, eşitse en kısa süre. Ödül ekip üyelerine bölünür ve Devlet Hazinesi\'nden ödenir.'),
          kart('Ödüller', '1. ekibe ayrıca kişi başı 1 Kadim Çekirdek (zindan deposuna)', sayi(od) + ' · ' + sayi(od / 2) + ' · ' + sayi(od / 4))]
        var hl = z.hafta || []
        hl.forEach(function (e, i) { oh.push(satir((i + 1) + '. ' + e.ad, 'Sv.' + e.s + ' · ' + dkSn(e.sure), i < 3 ? 'baslik' : 'acik')) })
        if (!hl.length) oh.push(yazi('Bu hafta henüz bitirilen zindan yok.', 'acik'))
        return oh
      }
      if (s === 'siralama') {
        var o2 = [yazi('En yüksek seviye, eşitse en kısa süre.')]
        ;(z.liste || []).forEach(function (e, i) { o2.push(satir((i + 1) + '. ' + e.ad, 'Sv.' + e.seviye + ' · ' + dkSn(e.sure), i === 0 ? 'baslik' : 'acik')) })
        if (!(z.liste || []).length) o2.push(yazi('Henüz kimse bitirmedi.'))
        return o2
      }
      var a = z.aktif
      var acik = Math.max(1, z.acik || 1)
      var gecis2 = z.gecis || []
      var sev = []
      for (var i = acik; i >= 1; i--) sev.push({ d: String(i), y: 'Seviye ' + i + (gecis2.indexOf(i) >= 0 ? '  ◆ sigil gerekir' : '') })
      var o3 = [
        a ? kart('Aktif Zindan', 'Ganimet ' + a.ganimet + ' · canavar ' + a.canavar + ' · ' + a.oda + ' oda', 'Sv.' + a.seviye + (a.katSayisi > 1 ? ' · Kat ' + a.kat + '/' + a.katSayisi : '') + ' · Hak ' + a.hak + ' · ' + dkSn(a.kalan), { dr: 'yesil' })
          : kart('Aktif Zindan', 'Giriş ücreti: seviye × ' + (z.ucret || 5) + ' spur', 'Yok'),
        kart('En Yüksek Seviye', 'Bitirilen koşu ' + (z.bitirilen || 0) + (z.enYuksek ? ' · en iyi süre ' + dkSn(z.sure) : ''), String(z.enYuksek || 0)),
        kart('Açık Seviyeler', 'Bir seviyeyi bitiren bir sonrakine kalıcı olarak girebilir', '1 - ' + acik),
        kart('Ganimet Deposu', 'Zindandan kazanılan her şey burada bekler', (z.depo || 0) > 0 ? z.depo + ' eşya' : 'Boş'),
        yazi('◆ Geçiş seviyeleri (' + (gecis2.length ? gecis2.join(', ') : '10, 25, 50...') + ') her girişte o seviyenin sigilini ister; sigili bir önceki seviyenin boss\'u düşürür.'),
        sira([secim('seviye', 'Seviye', sev, { l: 'Seviye', v: String(acik), w: 1.5 }), dugme('Zindana gir', 'zindan baslat {seviye}', { r: 'yesil', kapat: 1 })]),
        dugmeler([dugme('Depoyu aç', 'zindan depo', { kapat: 1 }), dugme('Zindandan ayrıl', 'zindan ayril', { r: 'kirmizi', onay: 'Ayrılırsan ganimetin %25\'i kalır' })])
      ]
      return o3
    } }

  // ----------------------------- SINIF & MESLEK ---------------------------
  BOLUM.yetenek = { ad: 'Sınıf & Meslek',
    sekmeler: function () { return [{ id: 'secim', ad: 'Sınıf & Meslek' }, { id: 'beceri', ad: 'Beceriler (Reskillable)' }] },
    kur: function (p, s) {
      if (s === 'beceri') {
        var bl = []
        try { bl = ortak('beceriOzet') ? ortak('beceriOzet')(p) : [] } catch (e) { bl = [] }
        var o0 = [yazi('Beceriler o işi yaptıkça gelişir; seviye atlarken XP seviyesi de harcanır. 10 kademe: bakır 1, demir 2, çelik 3, elmas 4 ... netherite 7, dragonsteel 8, zindan setleri 9-10.'),
          yazi('Madencilik: kazmayla taş/cevher · Toplayıcılık: balta/kürek · İnşaat: blok koymak · Çiftçilik: hasat, hayvan üretmek · Saldırı: canavar öldürmek · Savunma: canavardan hasar almak · Çeviklik: koşmak, zıplamak · Büyü: büyüleme, iksir, büyü yapmak · Silah: ateşli silahla canavar vurmak. Kendi koyduğun bloğu kırmak sayılmaz.')]
        // 2026-11-26: Reskillable'ın kendi ekranı (istemcide açılır; kısayolu G)
        o0.push(dugmeler([dugme('Reskillable ekranını aç (G)', '#ekran net.bandit.reskillable.client.screen.SkillScreen', { r: 'mavi' })]))
        bl.forEach(function (x) {
          var hazir = x.gerek && x.puan >= x.gerek
          o0.push(kart(x.ad, x.gerek
            ? 'Sonraki seviyeye ' + x.puan + ' / ' + x.gerek + ' iş (%' + Math.floor(x.puan / x.gerek * 100) + ') · ' + x.xp + ' XP seviyesi gerekir (sende ' + x.xpVar + ')' +
              (hazir ? (x.xpVar >= x.xp ? ' · bir sonraki işte atlar' : ' · iş tamam, XP bekleniyor') : '')
            : 'En üst seviye', 'Seviye ' + x.sv + ' / 10', hazir ? { r: 1, dr: 'yesil' } : { r: x.gerek ? x.puan / x.gerek : 1 }))
        })
        if (!bl.length) o0.push(yazi('Beceri bilgisi yok (Reskillable yüklü değil mi?).', 'kirmizi'))
        return o0
      }
      var y = null
      try { y = ortak('yetenekOzet') ? ortak('yetenekOzet')(p) : null } catch (e) { y = null }
      if (!y) return [yazi('Yetenek sistemi yüklenemedi.', 'kirmizi')]
      var z = zindanOzet(p)
      var o = [
        kart('Sınıf', y.sinif ? 'Seviye ' + y.sinifSv + ' · harcanmamış puan ' + y.sinifBos : (y.sinifAcik ? 'İlk seçim bedava, değiştirmek ' + sayi(y.degisim) + ' spur' : 'Zindanda ' + y.sinifZindan + '. seviyeyi bitirince açılır (sen: ' + (z.enYuksek || 0) + ')'),
          y.sinif ? y.sinifAd : 'Seçilmedi', { dr: y.sinif ? 'baslik' : 'gri' }),
        kart('Meslek', y.meslekler.length ? 'Seviye ' + y.meslekSv + ' · harcanmamış puan ' + y.meslekBos : 'İlk seçim bedava',
          y.meslekler.length ? y.meslekler.join(', ') : 'Seçilmedi', { dr: y.meslekler.length ? 'baslik' : 'gri' }),
        kart('Ek Meslek Hakkı', 'Bir meslek ağacını bitirince bir meslek daha seçebilirsin (ücretsiz)', y.ekHak > 0 ? y.ekHak + ' hak var' : 'Yok', { dr: y.ekHak > 0 ? 'yesil' : 'gri' }),
        BOSLUK,
        dugme('Yetenek ağaçlarını aç (Pufferfish)', 'yetenek ac', { r: 'yesil', kapat: 1 }),
        baslik('Sınıf seç')
      ]
      o.push(sira([secim('sinif', 'Sınıf', y.sinifSecenek, { l: y.sinif ? 'Değiştirirsen eski ağaç silinir (' + sayi(y.degisim) + ' spur)' : 'Her sınıfın 2 dalı var, biri seçilir', w: 2 }),
        dugme('Seç', 'sinif sec {sinif}', { onay: y.sinif ? sayi(y.degisim) + ' spur, emin misin?' : 'Seçilsin mi?' })]))
      o.push(baslik('Meslek seç'))
      o.push(yazi('Tüm meslekler Pufferfish\'te tek ağaçta ("Meslekler"); kökünü açtığın meslek seçilir. Buradan da seçebilirsin.'))
      o.push(sira([secim('meslek', 'Meslek', y.meslekSecenek, { l: y.meslekler.length && !y.ekHak ? 'Değiştirirsen aktif meslek silinir (' + sayi(y.degisim) + ' spur)' : 'Meslek', w: 2 }),
        dugme('Seç', 'meslek sec {meslek}', { onay: 'Seçilsin mi?' })]))
      o.push(baslik('Sıfırlama'))
      o.push(yazi('Harcanan puan × ' + y.puanUcret + ' spur; puanlar geri gelir, dal da değiştirebilirsin.'))
      o.push(dugmeler([dugme('Sınıfı sıfırla', 'yetenek sifirla sinif', { r: 'kirmizi', onay: 'Emin misin?' }), dugme('Meslekleri sıfırla', 'yetenek sifirla meslek', { r: 'kirmizi', onay: 'Emin misin?' })]))
      return o
    } }

  // ----------------------------- REHBER (2026-11-25) ----------------------
  // Her sistemin oyuncu diliyle kısa anlatımı. Adım adım görev yolu: FTB Quests (görev kitabı).
  var REHBER = {
    baslangic: ['Başlangıç', [
      ['İlk adımlar', 'Y tuşu bu menüyü açar, K tuşu Sınıf & Meslek ekranını. Görev kitabı (FTB Quests) seni adım adım yönlendirir: envanterdeki görev düğmesi.'],
      ['Para (spur)', 'Para Numismatics bankasında durur. Eşyalarını Selling Bin\'e koyarak satarsın (fiyatlar arz-talebe göre değişir). Bankan menünün sağ üstünde görünür.'],
      ['Arazi', 'Haritadan (Xaero / OPAC) claim alırsın. 1 claim hakkı bedava; fazlasını Menü > Arazi\'den kiralarsın, kira her gün bankadan kesilir. Claim\'siz yerler korumasızdır, yağmalanabilir.'],
      ['Ölüm', 'Ölünce bankandaki paranın bir kısmı ölüm vergisi olarak kesilir. Cesedin sadece sana açıktır.'],
      ['Mending ve Elytra yok', 'Eşyaları Demirci tamir eder (Overgeared dövme örsü). Uçmak için Create Aeronautics araçları var.']
    ]],
    // 2026-11-26: kullanıcıyla konuşulan genel sunucu kuralları (Discord: GENEL_KURALLAR_discord.md)
    kurallar: ['Kurallar', [
      ['1. Hile ve açıklar', 'X-ray (texture pack dahil), kill aura, freecam, autoclicker/makro ve yasaklı client modları yasak. Dupe veya bug bulursan yöneticilere bildir: bildirene ödül, kullanana ceza.'],
      ['2. Hesaplar', 'Kişi başı tek hesap. Alt hesapla vergi kaçırmak, para aklamak veya kelle toplamak yasak. Gerçek parayla eşya/spur ticareti yasak.'],
      ['3. Arazi: yarı anarşi', 'Claim\'li arazi korunur (savaş hariç). Claim\'siz her yer yağmaya ve yıkmaya serbesttir: değerli bir şeyin varsa claim al.'],
      ['4. PvP ve savaş', 'Savaş dışında öldürmek yasak değil ama sistem öldürene cinayet cezası keser. Spawn bölgesinde PvP yok. Aktif savaşta düşmanla çatışırken (30 sn) oyundan çıkan ölür, cesedi yerinde kalır. İmzalanan antlaşmaya uyulur; antlaşmadan sonra intikam baskını yasak.'],
      ['5. Anlaşmalar', 'Sistemdeki krediler, borçlar ve antlaşmalar bağlayıcıdır. Sözlü anlaşmalar oyuncuların kendi işidir: kanıtı yoksa yönetim karışmaz.'],
      ['6. Performans', 'Lag makinesi yasak. Contraption, mob farm ve chunk loader makul boyutta olmalı; sunucuyu kasan yapı uyarıdan sonra kaldırılır.'],
      ['7. Başkan', 'Hazine şahsi işlere harcanmaz. Vergi değişiklikleri önceden duyurulur. Başkan, kendi partisinin taraf olduğu savaşın onayını OP\'ye bırakır.'],
      ['8. Zindan', 'Başkasının koşusuna girilemez (sistem engeller). Açık ve exploit kullanmak yasak. Başarısız veya yarıda bırakılan koşudan sonra 10 dakika yeni zindana girilemez.'],
      ['9. Sohbet ve ses', 'Küfür serbest. Birini hedef alıp sürekli taciz etmek, ırkçılık ve gerçek hayattan bilgi ifşası yasak.'],
      ['10. Cezalar', 'Cezaları OP verir: uyarı → para cezası (hazineye) → geçici ban → kalıcı ban. Ağır ihlalde basamak atlanabilir.']
    ]],
    meslek: ['Meslek & Sınıf', [
      ['Meslek', 'K > Sınıf & Meslek. İlk meslek bedava. Meslekler Pufferfish\'te tek ağaçta (Meslekler); kökünü açtığın meslek seçilir. Bir mesleğin ağacını bitirince bir meslek daha açabilirsin.'],
      ['Meslekler', 'Madenci, İnşaatçı, Demirci (tamir ve silah dövme), Simyacı, Çiftçi (hasat ve hayvancılık), Aşçı, Balıkçı, Tacir (satış, banka kurma), Mühendis (Fabrika / Havacılık / Ağır Sanayi).'],
      ['Sınıf', 'Zindanda 5. seviyeyi bitirince açılır: Savaşçı, Avcı, Nişancı, Büyücü, Elementalist, Terbiyeci. Her sınıfın 2 dalı var, biri seçilir.'],
      ['Sınıf silahları', 'Her sınıf kendi silahlarını kullanır: Savaşçı ağır yakın dövüş ve kalkan, Avcı yay ve hançer, Nişancı ateşli silah, Büyücü/Elementalist büyü, Terbiyeci mızrak ve yay. Tabancayı herkes kullanabilir. Sınıfsızken vanilla kılıç, yay, arbalet, kalkan ve tabanca.'],
      ['Beceriler (Reskillable)', 'Madencilik, savaş, inşaat gibi beceriler o işi yaptıkça gelişir; eşya ve zırhlar bu seviyelere kilitlidir. K > Beceriler (oradan Reskillable ekranı da açılır; kısayolu G).']
    ]],
    ekonomi: ['Ekonomi', [
      ['Banka', 'Menü > Banka > İşlemler: Kredi (devletten veya bir bankadan; banka faizi pazarlık edebilir), Mevduat (miktar + vade seçip başvurursun, banka onaylar), İşlem Geçmişim ve Transfer.'],
      ['Borç', 'Ödenmeyen ceza ve kiralar borca yazılır (günlük faiz). Uzun süre ödemezsen satış kesintisi, [BORÇLU] damgası, en sonunda kelle avı ve haciz.'],
      ['Vergiler', 'KDV, harç, kira, araç vergisi gibi oranları başkan belirler. Menü > Vergiler hepsini ve sana etkisini gösterir.'],
      ['Borsa', 'Menü > Borsa: 4 coin al-sat. Fiyatlar her dakika değişir; Madencilik Makinesi Create gücüyle Dişli coin üretir.'],
      ['Başkan', 'Sunucunun başkanı vergileri ve hazineyi yönetir, savaşları onaylar.']
    ]],
    zindan: ['Zindan', [
      ['Giriş', 'Menü > Zindan veya /zindan baslat. Giriş ücreti seviye x 5 spur (hazineye). Partinle birlikte girebilirsin. Bir seviyeyi bitirince sonraki kalıcı açılır. Başarısız ya da yarıda bırakılan koşudan sonra 10 dk beklersin.'],
      ['Temalar', 'Her koşunun bir teması var (Çökmüş Maden, Kemik Mahzeni, Nether, End, Donmuş Hapishane, Firavun Mezarı...). Tema seviyeye göre seçilir ve canavarları ile odaların görünüşü ona göre değişir.'],
      ['Geçiş seviyeleri', '10, 25, 50, 75, 100 her girişte o seviyenin sigilini ister; sigili bir önceki seviyenin boss\'u düşürür.'],
      ['Ganimet', 'Her şey Zindan Deposu\'na gider (/zindan depo). Başarısız olursan ganimetin %25\'i kalır. 3 ölüm hakkın var (ekipçe).'],
      ['Kasa ve anahtar', 'Canavar ve sandıklar sikke ve üretim malzemesi düşürür. Kat bekçisi, boss ve Şans Odası KASA verir (Sıradan, Nadir, Efsane). Kasayı açmak için Kasa Anahtarı gerekir: Sıradan/Nadir 1, Efsane 2. Her kasadan 1 affix\'li silah ya da zırh + biraz sikke çıkar (Nadir ve Efsane daha iyi affix). Gem ve scroll Gizli Dükkân\'da satılır. Kasayı zindan dışında sağ tıklayarak aç; oyuncular arasında satılabilir.'],
      ['Zindan Tüccarı', 'Sikkelerle anahtar, kasa ve her gün değişen sınırlı teklifler satar (bozdurma da yapar). Bazı koşularda zindanın en derin dallarında haritada görünmeyen bir Gizli Dükkân çıkar: daha nadir eşyalar satar, sikkeni yanında getir.'],
      ['Haftalık ödül', 'Her pazartesi haftanın en iyi 3 ekibi hazineden ödül alır. Menü > Zindan > Bu Hafta.']
    ]],
    savas: ['Savaş & PvP', [
      ['Savaş dışında öldürmek', 'Suçtur: cezayı öldüren öder (servetine göre katlanır). Kelle ödülü olan oyuncuyu öldürmek suç değildir.'],
      ['Savaş ilanı', 'Menü > Savaş > İlan & Barış. Ücret ödenir, başkan onaylar, hazırlıktan sonra başlar. Savaşta düşmanın arazisini yağmalayabilirsin.'],
      ['Çatışmadan kaçmak', 'Savaşta düşmanla çatışınca 30 sn geri sayım başlar (ekranın altında). Bu sürede oyundan çıkarsan ölürsün, cesedin yerinde kalır ve karşı tarafa skor yazılır.'],
      ['Bitiş', 'Antlaşma (para ve chunk takası), barış veya teslimle biter. Savaş sürdükçe her gün gider kesilir.']
    ]],
    create: ['Create & Demirci', [
      ['Makine bakımı', 'Create makineleri çalıştıkça yağ ve başlık aşınır (gözlükle % görürsün). Yağ herkes yapar; başlıkları sadece Demirci bitirir.'],
      ['Demirci', 'Overgeared dövme örsünde tamir ve silah parçası dövme. Mini oyunda vuruş kalitesi sonucu belirler.'],
      ['Overgeared', 'Metal aletler: külçe fırında kızdırılır, örste başlık dövülür, başlık + sap = alet.']
    ]]
  }
  BOLUM.rehber = { ad: 'Rehber',
    sekmeler: function () { return Object.keys(REHBER).map(function (k) { return { id: k, ad: REHBER[k][0] } }) },
    kur: function (p, s) {
      var r = REHBER[s] || REHBER.baslangic
      var o = []
      r[1].forEach(function (m) { o.push(baslik(m[0])); o.push(yazi(m[1], 'acik')); o.push(BOSLUK) })
      o.push(yazi('Adım adım görevler ve ödüller için görev kitabını (FTB Quests) aç.'))
      return o
    } }

  // ----------------------------- YÖNETİM (OP + başkan) --------------------
  var BECERI_SEC = [{ d: 'mining', y: 'Madencilik' }, { d: 'gathering', y: 'Toplayıcılık' }, { d: 'attack', y: 'Saldırı' }, { d: 'defense', y: 'Savunma' },
    { d: 'building', y: 'İnşaat' }, { d: 'farming', y: 'Çiftçilik' }, { d: 'agility', y: 'Çeviklik' }, { d: 'magic', y: 'Büyü' }, { d: 'silah', y: 'Silah' }]
  BOLUM.yonetim = { ad: 'Yönetim', yetki: yonetici,
    sekmeler: function (p) {
      var l = [{ id: 'hazine', ad: 'Hazine' }, { id: 'ekonomi', ad: 'Ekonomi Paneli' }, { id: 'vergi', ad: 'Vergi Oranları' }, { id: 'teftis', ad: 'Teftiş' }, { id: 'savas', ad: 'Savaş Onayı' }, { id: 'borsa', ad: 'Borsa Kasası' }, { id: 'satis', ad: 'Vendor Satışları' }]
      if (opMu(p)) l.push({ id: 'op', ad: 'OP' })
      return l
    },
    kur: function (p, s) {
      var server = p.server, id = String(p.getUuid())
      if (s === 'satis') {
        var ls = veri(server, 'satis_kayit')
        ls = Array.isArray(ls) ? ls.slice(-120).reverse() : []
        var os = []
        ls.forEach(function (e) { os.push(satir(zaman(e.t) + '  ' + e.a + (e.y === 'al' ? ' aldı ' : ' sattı ') + e.n + 'x ' + e.i, e.m + ' · ' + e.s)) })
        if (!ls.length) os.push(satir('Henüz satış yok', ''))
        return os
      }
      if (s === 'vergi') {
        var o = [yazi('Yüzdeler tam sayı (5 = %5). Kaydedince herkese duyurulur, bir dakika içinde uygulanır.')]
        VERGI_AD.forEach(function (v) {
          o.push(sira([giris('o_' + v[0], 'şu an ' + oranYazi(server, v[0], v[2]), { l: v[1], sayi: 1, w: 2.2 }), dugme('Kaydet', 'vergi oran ' + v[0] + ' {o_' + v[0] + '}', { temizle: 1 })]))
        })
        return o
      }
      if (s === 'ekonomi') {
        // Başkan ekonomi paneli (2026-11-25): 10 sn önbellek (her tazelemede tüm hesaplar taranmasın)
        var ep = ekonomiOnbellek
        if (!ep || Date.now() - ep.t > 10000) ep = ekonomiOnbellek = ekonomiHesapla(server)
        var oe = [
          kart('Para Arzı', 'Oyuncuların bankalarındaki toplam spur (' + ep.oyuncu + ' oyuncu)', para(ep.arz)),
          kart('Devlet Hazinesi', 'Hazine + Borsa Kasası', para(ep.hazine) + ' + ' + sayi(ep.borsaKasa)),
          kart('Oyuncu Bankaları', ep.bankaSayi + ' banka · kasa · mevduat · verilen kredi', sayi(ep.bankaKasa) + ' · ' + sayi(ep.mevduat) + ' · ' + sayi(ep.bankaKredi)),
          kart('Devlete Borç', 'Ceza/vergi borcu + devlet kredisi (' + ep.borclu + ' borçlu)', para(ep.borc), { dr: ep.borc > 0 ? 'kirmizi' : 'yesil' }),
          kart('Borsa', 'Dolaşımdaki coinlerin değeri', para(ep.borsaTop)),
          baslik('Son 7 gün hazine'),
          kart('Gelir', 'Vergi, ceza, harç, lisans, ücretler', '+' + para(ep.gelir7), { dr: 'yesil' }),
          kart('Gider', 'Aktarımlar, krediler, ödüller, iadeler', '-' + para(ep.gider7), { dr: 'kirmizi' })
        ]
        ep.turler.forEach(function (x) { oe.push(satir('  ' + (HAREKET_AD[x.k] || x.k), (GIDER[x.k] ? '-' : '+') + sayi(x.m), 'gri', GIDER[x.k] ? 'kirmizi' : 'yesil')) })
        oe.push(baslik('En zengin 10'))
        ep.zengin.forEach(function (x, i) { oe.push(satir((i + 1) + '. ' + x.ad, para(x.m), i === 0 ? 'baslik' : 'acik')) })
        return oe
      }      if (s === 'teftis') {
        var x = Math.floor(p.getX() / 16), z = Math.floor(p.getZ() / 16)
        var sahip = null
        try {
          if (OPAC == null) OPAC = Java.loadClass('xaero.pac.common.server.api.OpenPACServerAPI')
          var c = OPAC.get(server).getServerClaimsManager().get(p.level.getDimension(), x, z)
          sahip = c == null ? null : c.getPlayerId()
        } catch (e) { sahip = null }
        var kat = veri(server, 'arazi_kategori')[String(p.level.getDimension()) + '|' + x + '|' + z]
        return [
          yazi('Arazinin üstünde dur; yanlış beyan edilmiş kategoriyi düzelt, istersen ceza yaz (ödenmezse borca geçer).'),
          kart('Chunk ' + x + ', ' + z, sahip == null ? 'Sahipsiz' : 'Sahibi ' + adi(server, sahip), sahip == null ? '-' : KAT_AD[kat && kat.o === String(sahip) ? kat.k : 'yerleske']),
          sira([secim('tur', 'Kategori', [{ d: 'yerleske', y: 'Yerleşke' }, { d: 'dukkan', y: 'Dükkan' }, { d: 'fabrika', y: 'Fabrika' }], { l: 'Doğru kategori' }),
            giris('ceza', 'boş = cezasız', { l: 'Ceza (spur)', sayi: 1 }), dugme('Düzelt', 'arazi duzelt {tur} {ceza?}', { onay: 'Emin misin?', temizle: 1 })])
        ]
      }
      if (s === 'savas') {
        var l = savaslar(server).filter(function (x2) { return x2.durum === 'onay' })
        var o2 = [yazi('Onay bekleyen savaşlar. Onaylanmayan savaş süre dolunca kendiliğinden onaylanır; reddedilirse ilan ücreti iade edilir.')]
        if (!l.length) o2.push(yazi('Onay bekleyen savaş yok.', 'acik'))
        l.forEach(function (x2) {
          o2.push(kart('#' + x2.id + '  ' + x2.a.ad + '  vs  ' + x2.b.ad, savasDurum(x2), ''))
          o2.push(dugmeler([dugme('Onayla', 'savas onayla ' + x2.id, { r: 'yesil' }), dugme('Reddet (ücret iade)', 'savas reddet ' + x2.id, { r: 'kirmizi', onay: 'Reddedilsin mi?' })]))
        })
        return o2
      }
      if (s === 'borsa') {
        var oz = {}
        try { oz = JSON.parse(server.persistentData.getString('borsa_ozet') || '{}') } catch (e) { oz = {} }
        return [
          kart('Borsa Kasası', 'Oyuncuların sattığı coin\'leri bu kasa öder', para(oz.kasa || 0)),
          kart('Dolaşımdaki coin değeri', 'Kasanın karşılaması gereken', para(oz.top || 0), oz.top > 0 ? { r: Math.min(1, (oz.kasa || 0) / oz.top) } : null),
          sira([giris('borsa', 'spur', { l: 'Miktar', sayi: 1 }), dugme('Hazineden kasaya', 'borsa kasa yatir {borsa}', { r: 'yesil', temizle: 1 }), dugme('Kasadan hazineye', 'borsa kasa cek {borsa}', { temizle: 1 })])
        ]
      }
      if (s === 'op') {
        if (!opMu(p)) return [yazi('Sadece OP.')]
        var b = server.persistentData.getString('baskan')
        var bk = bankalar(server).map(function (x3) { return { d: x3.ad, y: x3.ad + (x3.donuk ? ' (donuk)' : '') } })
        return [
          kart('Başkan', 'Vergi oranlarını ve hazineyi yönetir, savaşları onaylar', b ? adi(server, b) : 'Yok'),
          sira([secim('baskan', 'Oyuncu (çevrimiçi)', oyuncular(server, null, true), { l: 'Başkan ata', w: 1.6 }), dugme('Ata', 'devlet baskan {baskan}', { r: 'yesil', onay: 'Atansın mı?' }),
            dugme('Görevden al', 'devlet baskan kaldir', { r: 'kirmizi', onay: 'Emin misin?' })]),
          // 2026-11-28: test için ekonomi zamanını ileri alma (zaman_atla.js)
          baslik('Test: zamanı ileri al'),
          sira([giris('zsaat', 'saat (1-720)', { sayi: 1, w: 1.6 }), dugme('İleri al', 'zamanatla {zsaat}', { r: 'kirmizi', onay: 'Herkese duyurulur, emin misin?', temizle: 1 })]),
          baslik('Bankalar'),
          bk.length ? sira([secim('bk', 'Banka', bk, { w: 1.6 }), dugme('Dondur', 'banka dondur {bk}', { r: 'kirmizi', onay: 'Dondurulsun mu?' }), dugme('Çöz', 'banka coz {bk}')]) : yazi('Banka yok.'),
          baslik('Borç'),
          sira([secim('borclu', 'Oyuncu (çevrimiçi)', oyuncular(server, null, true), { w: 1.6 }), dugme('Ayrıntı', 'kredi bak {borclu}'), dugme('Borcu sil', 'kredi borcsil {borclu}', { r: 'kirmizi', onay: 'Silinsin mi?' })]),
          // 2026-11-27 (kullanıcı): OP Reskillable beceri seviyesi ve perk verip alabilsin (beceri_gelisim.js /beceri)
          baslik('Beceriler (Reskillable)'),
          yazi('Seviye 1-10. Perk = becerinin öznitelik bonusu (seviyeyle gelir); açıp kapatabilirsin. Her işlem oyuncuya bildirilir.'),
          sira([secim('bo', 'Oyuncu (çevrimiçi)', oyuncular(server, null, true), { l: 'Oyuncu', w: 1.4 }),
            secim('bb', 'Beceri', BECERI_SEC, { l: 'Beceri', v: 'attack', w: 1.2 }), giris('bm', '1', { l: 'Miktar', sayi: 1, v: '1', w: 0.6 })]),
          dugmeler([dugme('Ver (+)', 'beceri ver {bo} {bb} {bm}', { r: 'yesil' }), dugme('Al (-)', 'beceri al {bo} {bb} {bm}', { r: 'kirmizi' }),
            dugme('Seviyeyi ayarla', 'beceri ayarla {bo} {bb} {bm}'), dugme('Göster', 'beceri bak {bo}')]),
          dugmeler([dugme('Perk aç', 'beceri perk {bo} {bb} ac', { r: 'yesil' }), dugme('Perk kapat', 'beceri perk {bo} {bb} kapat', { r: 'kirmizi' }),
            dugme('Hepsini sıfırla', 'beceri sifirla {bo}', { r: 'kirmizi', onay: 'Bütün becerileri 1\'e insin mi?' })])
        ]
      }
      // hazine
      var hv = veri(server, 'hazine_veri')
      var g = hv.gelir || {}
      var top = 0
      Object.keys(g).forEach(function (k) { if (!GIDER[k] && k !== 'yatirma' && k !== 'kelle_emanet') top += Number(g[k]) || 0 })
      var o3 = [
        kart('Devlet Hazinesi', 'Vergiler, cezalar, harçlar, lisanslar', para(bakiye(HAZINE))),
        kart('Toplam Gelir', 'Bugüne kadar hazineye giren (aktarımlar hariç)', para(top)),
        sira([secim('oyuncu', 'Oyuncu (çevrimiçi)', oyuncular(server, null, true), { l: 'Kime', w: 1.4 }), giris('miktar', 'spur', { l: 'Miktar', sayi: 1 }),
          dugme('Aktar', 'devlet aktar {oyuncu} {miktar}', { onay: 'Hazineden aktarılsın mı?', temizle: 1, w: 0.7 })]),
        dugmeler([dugme('Hazineden bankama çek', 'devlet cek {miktar}', { onay: 'Emin misin?' }), dugme('Bankamdan hazineye yatır', 'devlet yatir {miktar}')]),
        baslik('Son hareketler')
      ]
      ;(hv.hareket || []).slice(-80).reverse().forEach(function (e) {
        var gider = GIDER[e.tur]
        o3.push(satir(zaman(e.t) + '  ' + (HAREKET_AD[e.tur] || e.tur) + '  ' + e.k, (gider ? '-' : '+') + sayi(e.m), 'acik', gider ? 'kirmizi' : 'yesil'))
      })
      return o3
    } }

  // ----------------------------- EKONOMİ PANELİ HESABI --------------------
  var ekonomiOnbellek = null
  function ekonomiHesapla(server) {
    var idler = {}
    Object.keys(veri(server, 'borc_veri').o || {}).forEach(function (id) { idler[id] = 1 })
    Object.keys(veri(server, 'yetenek_veri').o || {}).forEach(function (id) { idler[id] = 1 })
    server.playerList.getPlayers().toArray().forEach(function (o) { idler[String(o.getUuid())] = 1 })
    var arz = 0, liste = []
    Object.keys(idler).forEach(function (id) { if (id.length < 30) return; var m = bakiye(id); arz += m; liste.push({ ad: adi(server, id), m: m }) })
    liste.sort(function (a, b) { return b.m - a.m })
    var bl = bankalar(server), bk = 0, mev = 0, kr = 0
    bl.forEach(function (b) { bk += bankaKasa(b); var t = bankaToplam(b); mev += t.m; kr += t.k })
    var bv = veri(server, 'borc_veri').o || {}, borc = 0, borclu = 0
    Object.keys(bv).forEach(function (id) { var r = bv[id]; var x = (r.borc > 0 ? r.borc : 0) + (r.kredi ? r.kredi.kalan || 0 : 0); if (x > 0) { borc += x; borclu++ } })
    var oz = {}
    try { oz = JSON.parse(server.persistentData.getString('borsa_ozet') || '{}') } catch (e) { oz = {} }
    var sinir = Date.now() - 7 * 86400000, gelir = 0, gider = 0, tur = {}
    ;(veri(server, 'hazine_veri').hareket || []).forEach(function (e) {
      if (e.t < sinir) return
      tur[e.tur] = (tur[e.tur] || 0) + (Number(e.m) || 0)
      if (GIDER[e.tur]) gider += Number(e.m) || 0; else if (e.tur !== 'yatirma') gelir += Number(e.m) || 0
    })
    var turler = Object.keys(tur).map(function (k) { return { k: k, m: tur[k] } }).sort(function (a, b) { return b.m - a.m }).slice(0, 8)
    return { t: Date.now(), arz: arz, oyuncu: liste.length, zengin: liste.slice(0, 10), hazine: bakiye(HAZINE), borsaKasa: oz.kasa || 0, borsaTop: oz.top || 0,
      bankaSayi: bl.length, bankaKasa: bk, mevduat: mev, bankaKredi: kr, borc: Math.ceil(borc), borclu: borclu, gelir7: gelir, gider7: gider, turler: turler }
  }

  // ----------------------------- EKRAN GÖNDERME ---------------------------
  function nav(p) {
    var l = []
    SIRA.forEach(function (id) {
      if (id === '') { l.push({ id: '', ad: '' }); return }
      var b = BOLUM[id]
      if (!b || (b.yetki && !b.yetki(p))) return
      l.push({ id: id, ad: b.ad })
    })
    return l
  }
  function ekranGonder(p, bolumId, sekme, ac) {
    var b = BOLUM[bolumId]
    if (!b || (b.yetki && !b.yetki(p))) { bolumId = 'genel'; b = BOLUM.genel }
    if (b.komut) { p.server.getCommands().performPrefixedCommand(p.createCommandSourceStack(), b.komut); return }
    var sekmeler = b.sekmeler ? b.sekmeler(p) : []
    if (!sekme) sekme = String(p.persistentData.getString('menu_sekme_' + bolumId) || '')
    // gizli: sekme çubuğunda görünmeyen alt sayfalar (ör. Banka > İşlemler > Kredi); ust: o sırada vurgulanan sekme
    var gizli = b.gizli || []
    if (sekmeler.length && !sekmeler.some(function (x) { return x.id === sekme }) && gizli.indexOf(sekme) < 0) sekme = sekmeler[0].id
    if (!sekmeler.length) sekme = ''
    p.persistentData.putString('menu_sekme_' + bolumId, sekme)
    var o
    try { o = b.kur(p, sekme) } catch (err) { console.error('[Menu] ' + bolumId + '/' + sekme + ' kurulamadi: ' + err); o = [yazi('Bu bölüm yüklenemedi: ' + err, 'kirmizi')] }
    var ekran = { b: bolumId, s: sekme, ss: b.ust ? b.ust(sekme) : '', ad: b.ad, para: bakiye(p.getUuid()), nav: nav(p), sekmeler: sekmeler, o: o }
    try { tasiyici().gonder(p, JSON.stringify(ekran), !!ac) } catch (err2) { console.error('[Menu] gonderilemedi: ' + err2); p.tell(Text.red(Text.ofString('Menü açılamadı (sunucu_piyasa modu güncel mi?).'))) }
  }
  if (global.ortak) global.ortak.put('menuAc', function (p, bolum) { ekranGonder(p, bolum || 'genel', null, true) })

  // Sunucu Defteri (startup_scripts/menu_defteri.js): sağ tıklayınca menü açılır
  var DEFTER = 'kubejs:sunucu_defteri'
  ItemEvents.rightClicked(DEFTER, function (event) {
    var p = event.player
    if (p == null) return
    try { ekranGonder(p, 'genel', null, true) } catch (err) { console.error('[Menu] defter: ' + err) }
    event.cancel()
  })
  // İlk girişte herkese bir defter
  PlayerEvents.loggedIn(function (event) {
    var p = event.player
    var v = p.persistentData
    if (v.getBoolean('sunucu_defteri_verildi')) return
    p.give(Item.of(DEFTER))
    v.putBoolean('sunucu_defteri_verildi', true)
    p.tell(Text.gold(Text.ofString('Sunucu Defteri verildi: sağ tıkla veya Y tuşuna bas. K: Sınıf & Meslek.')))
  })
  ServerEvents.recipes(function (event) {
    event.shapeless(Item.of(DEFTER), ['minecraft:book', 'minecraft:gold_nugget']).id('kubejs:sunucu_defteri')
  })

  ServerEvents.commandRegistry(function (event) {
    var Commands = event.commands
    var Arguments = event.arguments
    function ac(ctx, bolum, sekme) {
      var p = ctx.source.player
      if (p == null) { ctx.source.sendSystemMessage(Text.ofString('Bu komutu oyun içinden kullanın.')); return 0 }
      var b = String(bolum || 'genel').toLowerCase()
      var es = { ana: 'genel', menu: 'genel', bankalar: 'banka', kredi: 'banka', vergi: 'arazi', devlet: 'yonetim', hazine: 'yonetim', teftis: 'yonetim', guncellemeler: 'genel', satislar: 'yonetim' }
      if (es[b]) b = es[b]
      ekranGonder(p, b, sekme ? String(sekme) : null, true)
      return 1
    }
    event.register(Commands.literal('menu')
      .executes(function (ctx) { return ac(ctx, 'genel', null) })
      .then(Commands.argument('bolum', Arguments.WORD.create(event))
        .executes(function (ctx) { return ac(ctx, Arguments.WORD.getResult(ctx, 'bolum'), null) })
        .then(Commands.argument('sekme', Arguments.WORD.create(event))
          .executes(function (ctx) { return ac(ctx, Arguments.WORD.getResult(ctx, 'bolum'), Arguments.WORD.getResult(ctx, 'sekme')) }))))
    // Açık ekranın tazelenmesi (sunucu_piyasa MenuSunucu, sessiz kaynakla çalıştırır)
    event.register(Commands.literal('menuveri')
      .then(Commands.argument('yol', Arguments.GREEDY_STRING.create(event)).executes(function (ctx) {
        var p = ctx.source.player
        if (p == null) return 0
        var y = String(Arguments.GREEDY_STRING.getResult(ctx, 'yol')).split('/')
        ekranGonder(p, y[0] || 'genel', y[1] || null, false)
        return 1
      })))
    // 2026-11-28: açılır listede seçim değişti -> /menusec <bölüm/sekme> <anahtar> <değer>; sayfa seçime göre yeniden kurulur
    event.register(Commands.literal('menusec')
      .then(Commands.argument('girdi', Arguments.GREEDY_STRING.create(event)).executes(function (ctx) {
        var p = ctx.source.player
        if (p == null) return 0
        var a = String(Arguments.GREEDY_STRING.getResult(ctx, 'girdi')).split(' ')
        if (a.length < 3 || !/^[a-z0-9_]{1,32}$/.test(a[1])) return 0
        p.persistentData.putString('menu_sec_' + a[1], a[2].substring(0, 40))
        var y = a[0].split('/')
        ekranGonder(p, y[0] || 'genel', y[1] || null, false)
        return 1
      })))
    // Açılır listedeki seçime göre yönlendirme
    function calistir(p, k) { p.server.getCommands().performPrefixedCommand(p.createCommandSourceStack(), k) }
    function islem(ctx, miktarVar) {
      var p = ctx.source.player
      if (p == null) return 0
      var tur = String(Arguments.WORD.getResult(ctx, 'islem'))
      var hedef = String(Arguments.WORD.getResult(ctx, 'hedef'))
      var m = miktarVar ? Arguments.INTEGER.getResult(ctx, 'miktar') : 0
      if (tur === 'kredi') {
        if (!miktarVar) { p.tell(Text.red(Text.ofString('Miktar yaz.'))); return 0 }
        calistir(p, hedef === 'devlet' ? 'kredi cek ' + m : 'banka basvur ' + hedef + ' ' + m)
        return 1
      }
      if (tur === 'ode') {
        if (hedef === 'borc') calistir(p, miktarVar ? 'borc ode ' + m : 'borc ode')
        else if (hedef === 'kredi') calistir(p, 'kredi ode')
        else {
          var b = (veri(p.server, 'banka_veri').b || {})[hedef]
          var x = b && b.defter ? b.defter[String(p.getUuid())] : null
          var tutar = miktarVar ? m : (x ? Math.ceil(x.k || 0) : 0)
          if (!(tutar > 0)) { p.tell(Text.red(Text.ofString('Bu bankaya borcun yok.'))); return 0 }
          calistir(p, 'banka ode ' + hedef + ' ' + tutar)
        }
        return 1
      }
      p.tell(Text.red(Text.ofString('Bilinmeyen işlem.')))
      return 0
    }
    event.register(Commands.literal('menuislem')
      .then(Commands.argument('islem', Arguments.WORD.create(event))
        .then(Commands.argument('hedef', Arguments.WORD.create(event))
          .executes(function (ctx) { return islem(ctx, false) })
          .then(Commands.argument('miktar', Arguments.INTEGER.create(event)).executes(function (ctx) { return islem(ctx, true) })))))
  })

  console.info('[Menu] sunucu menusu hazir: ' + SIRA.filter(function (x) { return x }).length + ' bolum')
})()
