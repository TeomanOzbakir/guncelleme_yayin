// =====================================================================
//  VERGİ SİSTEMİ  -  kubejs/server_scripts/vergi_sistemi.js
//  Hedef: NeoForge 1.21.1 | KubeJS 2101.7.2 | Create Numismatics 1.1.0
//         Open Parties and Claims 0.33.0
//
//  - Arazi vergisi: günlük, banka hesabından otomatik kesilir (veya
//    oyuncu /vergi ode ile önceden öder). Ödenen para "kredi" olarak
//    durur ve o anki chunk sayısına göre dakika dakika harcanır; chunk
//    eklemek kalan süreyi kısaltır. Ödenmezse 24 gerçek saat ek
//    süre, sonra claim'ler askıya alınır (silinir + kaydedilir),
//    ödeme yapılınca geri yüklenir.
//  - Ölüm vergisi: ölünce banka bakiyesinin %5'i.
//  - Tescil: /tescil komutu ücreti keser, belge verir.
//  - Devlet hazinesi: kesilen tüm vergiler ayrı bir Numismatics hesabına
//    yatar. OP'lar /devlet ile bakiyeyi ve hareketleri görür, oyunculara
//    aktarım yapar; /devlet kart ile Bank Terminal'de hazineyi açar.
//
//  Doğrulama (mod JAR'larına karşı): kullanılan tüm Numismatics, OPAC ve
//  KubeJS sınıf/fonksiyon adları ve parametreleri bu sürümlerde var.
//  Düzeltilenler: tescil belgesi için withName -> withCustomName
//  (KubeJS 2101'de withName yok); askiyaAl içindeki gereksiz
//  Object.assign kaydı kaldırıldı.
//  !! Gerçek bir oyunda ÇALIŞTIRILARAK TEST EDİLMEDİ.
// =====================================================================

// ----------------------------- AYARLAR -------------------------------
// Arazi kategorileri: her claim varsayılan olarak YERLEŞKE'dir. Başkan (veya OP) bir chunk'ı
// teftiş edip /arazi kategori dukkan|fabrika [fiyat] ile (veya menüdeki Teftiş bölümünden)
// DÜKKAN / FABRİKA yapar; fiyat yazılmazsa varsayılan kullanılır. Kayıt: persistentData
// 'arazi_kategori' = { "boyut|x|z": { k, f, o (sahip uuid), b (başkan), t } }.
// Chunk başkasına geçerse kayıt geçersiz sayılır (o != yeni sahip).
const VERGI = {
  YERLESKE: 35,               // spur / chunk / gün (varsayılan kategori)
  DUKKAN_VARSAYILAN: 100,
  FABRIKA_VARSAYILAN: 150,
  FIYAT_MAX: 100000,          // başkanın girebileceği en yüksek günlük fiyat
  OLUM_VERGISI_ORAN: 0.05,    // bankadaki paranın %5'i
  TESCIL_UCRETI: 500,         // spur (YER TUTUCU - istediğiniz değeri yazın)
  EK_SURE_SAAT: 24,           // ödenmezse claim kapanmadan önce bekleme
  MUAF_UUID: []               // vergiden muaf oyuncu UUID'leri (string)
}

const GUN_MS = 24 * 60 * 60 * 1000
const KONTROL_ARALIGI_TICK = 1200   // 1200 tick = 1 dakika

// ----------------------------- SINIFLAR ------------------------------
const JUUID = Java.loadClass('java.util.UUID')
const ResLoc = Java.loadClass('net.minecraft.resources.ResourceLocation')
const Numismatics = Java.loadClass('dev.ithundxr.createnumismatics.Numismatics')
const ReasonHolder = Java.loadClass('dev.ithundxr.createnumismatics.content.backend.ReasonHolder')
const OpenPACServerAPI = Java.loadClass('xaero.pac.common.server.api.OpenPACServerAPI')
const OzelSahipler = Java.loadClass('xaero.pac.common.claims.api.SpecialClaimOwners')

// ----------------------------- VERİ ----------------------------------
function yukle(server) {
  var s = server.persistentData.getString('vergi_veri')
  if (!s) return { kayitlar: {} }
  try { return JSON.parse(s) } catch (e) { return { kayitlar: {} } }
}
function kaydet(server, d) {
  server.persistentData.putString('vergi_veri', JSON.stringify(d))
}
// Arazi vergisi "kredi" ile işler: ödenen para spur olarak rec.kredi'de
// durur ve her dakika O ANKİ günlük ücrete (g) göre eriyerek harcanır.
// g = yerleşke chunk'ları x 35 + dükkan/fabrika chunk'larının fiyatları.
// Chunk eklenirse / kategori değişirse kalan süre aynı oranda değişir.
// İlk gün ücretsiz: yeni kayda, o anki günlük ücret kadar kredi verilir.
// rec.g ve rec.dg (yerleşke/dükkan/fabrika sayıları) menü için saklanır.
const MAX_ADIM_MS = 5 * 60 * 1000   // sunucu kapalıyken geçen süre sayılmaz
function yeniKayit(simdi, g) {
  return { kredi: g || 0, g: g || 0, son: simdi, grace: 0, askida: false, auto: true, snapshot: [], bekleyen: [] }
}
function krediHazirla(rec, g, simdi) {
  if (rec.kredi == null) {   // eski (bitiş zamanlı) kayıttan çevir
    var kalanMs = Math.max(0, (rec.paidUntil || simdi) - simdi)
    rec.kredi = kalanMs / GUN_MS * Math.max(g, VERGI.YERLESKE)
    delete rec.paidUntil
  }
  if (rec.son == null) rec.son = simdi
}
function krediTuket(rec, g, simdi) {
  var gecen = Math.min(Math.max(0, simdi - rec.son), MAX_ADIM_MS)
  rec.son = simdi
  if (g > 0) rec.kredi -= g * gecen / GUN_MS
}
function kalanSure(rec, g) {
  if (g <= 0) return 'claim yok'
  if (!(rec.kredi > 0)) return 'bitti'
  return kalan(rec.kredi / g * GUN_MS)
}

// ----------------------------- ARAZİ KATEGORİLERİ --------------------
const KAT_AD = { yerleske: 'Yerleşke', dukkan: 'Dükkan', fabrika: 'Fabrika' }
function katYukle(server) {
  var s = server.persistentData.getString('arazi_kategori')
  if (!s) return {}
  try { return JSON.parse(s) || {} } catch (e) { return {} }
}
function katKaydet(server, kat) { server.persistentData.putString('arazi_kategori', JSON.stringify(kat)) }
function katAnahtar(d, x, z) { return String(d) + '|' + x + '|' + z }
// Aktif claim'lerin günlük ücreti. n: claim sayısı. Kategori kaydı sadece chunk hâlâ
// aynı sahibindeyse sayılır.
function gunlukUcret(server, uuid, n, kat) {
  var id = String(uuid)
  var m = claimYonetici(server)
  var sonuc = { g: n * VERGI.YERLESKE, dg: { y: n, d: 0, f: 0 } }
  var anahtarlar = Object.keys(kat)
  for (var i = 0; i < anahtarlar.length; i++) {
    var e = kat[anahtarlar[i]]
    if (!e || e.o !== id) continue
    var p = anahtarlar[i].split('|')
    var c = null
    try { c = m.get(ResLoc.parse(p[0]), parseInt(p[1], 10), parseInt(p[2], 10)) } catch (err) { c = null }
    if (c == null || String(c.getPlayerId()) !== id) continue
    sonuc.g += e.f - VERGI.YERLESKE
    sonuc.dg.y--
    if (e.k === 'dukkan') sonuc.dg.d++; else sonuc.dg.f++
  }
  return sonuc
}
// Askıya alınmış (silinmiş) claim'lerin günlük ücreti: kayıtlı kategorileri korunur
function snapshotUcret(id, snap, kat) {
  var t = 0
  for (var i = 0; i < snap.length; i++) {
    var e = kat[katAnahtar(snap[i].d, snap[i].x, snap[i].z)]
    t += (e && e.o === id) ? e.f : VERGI.YERLESKE
  }
  return t
}
// Haritada kategori rengi: dükkan/fabrika chunk'ları sahibinin OPAC "alt claim"ine (sub-config)
// taşınır; alt claim'in kendi rengi ve adı vardır (Xaero haritasında görünür). Yerleşke =
// oyuncunun kendi ana claim rengi. Renk ve ad, OPAC'ın kendi komutuyla ayarlanır
// (API'deki Integer renk alanına KubeJS sayıyı Double gönderebiliyor).
const KAT_RENK = { dukkan: '2E86DE', fabrika: 'E67E22' }   // mavi, turuncu (RRGGBB)
function altClaimIndeksi(server, uuid, tur) {
  var cfg = OpenPACServerAPI.get(server).getPlayerConfigs().getLoadedConfig(uuid)
  if (cfg == null) return null
  if (tur === 'yerleske') return cfg.getSubIndex()   // ana claim
  var isim = ad(server, uuid)
  if (!cfg.subConfigExists(tur)) server.runCommandSilent('opac player-config for ' + isim + ' sub create ' + tur)
  if (!cfg.subConfigExists(tur)) return null   // alt claim sınırı dolu olabilir
  server.runCommandSilent('opac player-config for ' + isim + ' sub ' + tur + ' set claims.name "' + KAT_AD[tur] + '"')
  server.runCommandSilent('opac player-config for ' + isim + ' sub ' + tur + ' set claims.color ' + KAT_RENK[tur])
  return cfg.getSubConfig(tur).getSubIndex()
}
// Chunk'ı (aynı sahipte kalarak) istenen alt claim'e taşır. true: taşındı / zaten oradaydı
function claimRenklendir(server, boyut, x, z, uuid, tur) {
  var m = claimYonetici(server)
  var rl = ResLoc.parse(boyut)
  var c = m.get(rl, x, z)
  if (c == null || !c.getPlayerId().equals(uuid)) return false
  var idx = altClaimIndeksi(server, uuid, tur)
  if (idx == null) return false
  if (Number(c.getSubConfigIndex()) === Number(idx)) return true
  var yuk = c.isForceloadable()
  m.claim(rl, uuid, idx, x, z, yuk)
  var yeni = m.get(rl, x, z)
  if (yeni == null || Number(yeni.getSubConfigIndex()) !== Number(idx)) {   // üzerine yazmadıysa sil + yeniden claim
    m.unclaim(rl, x, z)
    m.claim(rl, uuid, idx, x, z, yuk)
  }
  return true
}
// Her dakika: kategorisi olan chunk'lar doğru renkte mi (ör. silinip yeniden claim edildiyse)
function kategoriRenkleriniEsitle(server, kat) {
  var m = claimYonetici(server)
  var anahtarlar = Object.keys(kat)
  for (var i = 0; i < anahtarlar.length; i++) {
    var e = kat[anahtarlar[i]]
    var p = anahtarlar[i].split('|')
    try {
      var c = m.get(ResLoc.parse(p[0]), parseInt(p[1], 10), parseInt(p[2], 10))
      if (c == null || String(c.getPlayerId()) !== e.o) continue
      var cfg = OpenPACServerAPI.get(server).getPlayerConfigs().getLoadedConfig(c.getPlayerId())
      if (cfg == null || !cfg.subConfigExists(e.k)) { claimRenklendir(server, p[0], parseInt(p[1], 10), parseInt(p[2], 10), c.getPlayerId(), e.k); continue }
      if (Number(c.getSubConfigIndex()) !== Number(cfg.getSubConfig(e.k).getSubIndex())) claimRenklendir(server, p[0], parseInt(p[1], 10), parseInt(p[2], 10), c.getPlayerId(), e.k)
    } catch (err) { console.warn('[Vergi] kategori rengi: ' + err) }
  }
}
function baskanMi(server, p) {
  var b = server.persistentData.getString('baskan')
  return !!b && b === String(p.getUuid())
}

// ----------------------------- BANKA ---------------------------------
function hesap(uuid) { return Numismatics.BANK.getAccount(uuid) }   // hesap yoksa null
function bakiye(uuid) {
  var h = hesap(uuid)
  return h ? h.getBalance() : 0
}
function kes(uuid, miktar) {
  miktar = Math.floor(miktar)
  if (miktar <= 0) return true
  var h = hesap(uuid)
  if (!h) return false
  var ok = h.deduct(miktar, ReasonHolder.IGNORED)   // bakiye yetmezse false
  if (ok) h.markDirty()
  return !!ok
}

// ----------------------------- DEVLET HAZİNESİ -----------------------
// Kesilen tüm vergiler bu Numismatics hesabına yatar. Hesap "Blaze Banker"
// türündedir: başlangıç parası almaz ve yetkili listesi (trust list) vardır.
// /devlet kart ile verilen karta bağlıdır; kartla Bank Terminal'e sağ
// tıklayan yetkili, hazinenin kendi banka ekranını açar.
const HAZINE_UUID = JUUID.fromString('5f0c2d1e-7a3b-4e9c-8d6f-1b2a3c4d5e6f')
const BankType = Java.loadClass('dev.ithundxr.createnumismatics.content.backend.BankAccount$Type')
const CardItem = Java.loadClass('dev.ithundxr.createnumismatics.content.bank.CardItem')
const NumUtils = Java.loadClass('dev.ithundxr.createnumismatics.util.Utils')
const TUR_AD = {
  arazi: 'Arazi vergisi', olum: 'Ölüm vergisi', tescil: 'Tescil',
  cinayet: 'Cinayet cezası', savas: 'Savaş ilanı',
  borc: 'Borç tahsilatı', kredi: 'Kredi verildi', kredi_odeme: 'Kredi ödemesi',
  aktarim: 'Aktarım', cekim: 'Çekim', yatirma: 'Yatırma'
}

function hazine() {
  var h = Numismatics.BANK.getOrCreateAccount(HAZINE_UUID, BankType.BLAZE_BANKER)
  if (h.getLabel() != 'Devlet Hazinesi') { h.setLabel('Devlet Hazinesi'); h.markDirty() }
  return h
}
function ad(server, uuid) {
  var p = server.playerList.getPlayer(uuid)
  if (p != null) return String(p.username)
  var prof = server.getProfileCache().get(uuid)
  return prof.isPresent() ? String(prof.get().getName()) : String(uuid).substring(0, 8)
}
function hazineVeri(server) {
  var s = server.persistentData.getString('hazine_veri')
  var d = null
  if (s) { try { d = JSON.parse(s) } catch (e) { d = null } }
  if (!d) d = {}
  if (!d.gelir) d.gelir = { arazi: 0, olum: 0, tescil: 0 }
  if (!d.hareket) d.hareket = []
  return d
}
function hazineKayit(server, tur, miktar, kim) {
  var d = hazineVeri(server)
  if (d.gelir[tur] != null) d.gelir[tur] += miktar
  // Son 500 hareket tutulur (menü > Hazine bölümünde sayfa sayfa görünür)
  d.hareket = d.hareket.concat([{ t: Date.now(), tur: tur, m: miktar, k: kim }]).slice(-500)
  server.persistentData.putString('hazine_veri', JSON.stringify(d))
}
// Oyuncudan vergi keser ve hazineye yatırır
function vergiKes(server, uuid, miktar, tur) {
  miktar = Math.floor(miktar)
  if (miktar <= 0) return true
  if (!kes(uuid, miktar)) return false
  var h = hazine()
  h.deposit(miktar)
  h.markDirty()
  hazineKayit(server, tur, miktar, ad(server, uuid))
  return true
}

// ----------------------------- CLAIM ---------------------------------
function claimYonetici(server) {
  return OpenPACServerAPI.get(server).getServerClaimsManager()
}
function claimSayisi(server, uuid) {
  var m = claimYonetici(server)
  return m.hasPlayerInfo(uuid) ? m.getPlayerInfo(uuid).getClaimCount() : 0
}
function claimOlcekle(server, uuid) {
  // Oyuncunun tüm claim'lerini [{d,x,z,s,f}] listesi olarak döndürür
  var m = claimYonetici(server)
  var liste = []
  if (!m.hasPlayerInfo(uuid)) return liste
  var info = m.getPlayerInfo(uuid)
  var boyutlar = m.getDimensionStream().toArray()
  for (var i = 0; i < boyutlar.length; i++) {
    var rl = boyutlar[i].getDimension()
    var pd = info.getDimension(rl)
    if (pd == null) continue
    var listeler = pd.getStream().toArray()
    for (var j = 0; j < listeler.length; j++) {
      var durum = listeler[j].getClaimState()
      var s = durum.getSubConfigIndex()
      var f = durum.isForceloadable()
      var pozlar = listeler[j].getStream().toArray()
      for (var k = 0; k < pozlar.length; k++) {
        liste.push({ d: String(rl), x: pozlar[k].x, z: pozlar[k].z, s: s, f: f })
      }
    }
  }
  return liste
}
function askiyaAl(server, id, rec) {
  // rec, cagiran tarafin veri nesnesinin icinde; kayit ana dongunun sonunda yapilir
  var uuid = JUUID.fromString(id)
  var snap = claimOlcekle(server, uuid)
  if (snap.length === 0) return 0
  rec.snapshot = (rec.snapshot || []).concat(snap)
  rec.askida = true
  var m = claimYonetici(server)
  for (var i = 0; i < snap.length; i++) {
    m.unclaim(ResLoc.parse(snap[i].d), snap[i].x, snap[i].z)
  }
  return snap.length
}
function geriYukle(server, id, rec) {
  // Başkası claim ettiyse o chunk'ın üzerine yazmaz, atlar.
  var uuid = JUUID.fromString(id)
  var m = claimYonetici(server)
  var ok = 0, atlanan = 0
  var liste = rec.snapshot || []
  for (var i = 0; i < liste.length; i++) {
    var c = liste[i]
    var rl = ResLoc.parse(c.d)
    if (m.get(rl, c.x, c.z) != null) { atlanan++; continue }
    try { m.claim(rl, uuid, c.s, c.x, c.z, c.f); ok++ } catch (e) { atlanan++ }
  }
  rec.snapshot = []
  rec.askida = false
  return { ok: ok, atlanan: atlanan }
}

// ----------------------------- MESAJ ---------------------------------
function bildir(server, id, rec, mesaj) {
  var p = server.playerList.getPlayer(JUUID.fromString(id))
  if (p != null) { p.tell(mesaj); return }
  rec.bekleyen = (rec.bekleyen || []).concat([mesaj]).slice(-5)
}
function kalan(ms) {
  var dk = Math.max(0, Math.floor(ms / 60000))
  return Math.floor(dk / 60) + ' saat ' + (dk % 60) + ' dk'
}

// ----------------------------- ANA DÖNGÜ -----------------------------
function vergiIsle(server) {
  var d = yukle(server)
  var simdi = Date.now()
  var m = claimYonetici(server)
  var sahipler = {}

  var bilgiler = m.getPlayerInfoStream().toArray()
  for (var i = 0; i < bilgiler.length; i++) {
    var uuid = bilgiler[i].getPlayerId()
    if (uuid.equals(OzelSahipler.SERVER) || uuid.equals(OzelSahipler.EXPIRED)) continue
    var id = String(uuid)
    if (VERGI.MUAF_UUID.indexOf(id) >= 0) continue
    var n = bilgiler[i].getClaimCount()
    if (n > 0) sahipler[id] = n
  }

  var kat = katYukle(server)
  kategoriRenkleriniEsitle(server, kat)

  // 1) Claim'i olan oyuncular
  Object.keys(sahipler).forEach(function (id) {
    var n = sahipler[id]
    var u = gunlukUcret(server, JUUID.fromString(id), n, kat)
    var rec = d.kayitlar[id]
    if (!rec) {
      rec = d.kayitlar[id] = yeniKayit(simdi, u.g)
      rec.dg = u.dg
      bildir(server, id, rec, 'Arazi vergisi başladı: yerleşke chunk başına günlük ' + VERGI.YERLESKE +
        ' spur (dükkan/fabrika fiyatını başkan belirler). İlk gün ücretsiz. Chunk eklersen kalan süren kısalır. Detay: /vergi durum')
      return
    }
    var g = u.g
    rec.g = g
    rec.dg = u.dg
    krediHazirla(rec, g, simdi)
    krediTuket(rec, g, simdi)
    if (rec.kredi > 0) { rec.grace = 0; return }

    var ucret = g
    if (rec.auto !== false && vergiKes(server, JUUID.fromString(id), ucret, 'arazi')) {
      rec.kredi += ucret
      rec.grace = 0
      bildir(server, id, rec, 'Arazi vergisi bankandan kesildi: ' + ucret + ' spur (' + n + ' chunk).')
      return
    }
    if (!rec.grace) {
      rec.grace = simdi + VERGI.EK_SURE_SAAT * 3600 * 1000
      bildir(server, id, rec, 'Arazi vergisi ÖDENEMEDİ (' + ucret + ' spur). ' + VERGI.EK_SURE_SAAT +
        ' saat içinde ödemezsen claim\'ların kapatılacak. Bankana para yatır veya /vergi ode gun')
      return
    }
    if (simdi >= rec.grace) {
      var adet = askiyaAl(server, id, rec)
      rec.grace = 0
      rec.kredi = 0   // arazi elinden alındı, birikmiş borç silinir
      bildir(server, id, rec, 'Vergi ödenmediği için ' + adet + ' chunk claim\'in askıya alındı. ' +
        'Ödeme yapınca geri yüklenir: /vergi ode gun')
    }
  })

  // 2) Askıdaki claim'ler: otomatik ödeme açıksa, para yetince geri yükle
  Object.keys(d.kayitlar).forEach(function (id) {
    var rec = d.kayitlar[id]
    if (!rec.askida || rec.auto === false || sahipler[id]) return
    var ucret = snapshotUcret(id, rec.snapshot || [], kat)
    if (ucret > 0 && vergiKes(server, JUUID.fromString(id), ucret, 'arazi')) {
      var s = geriYukle(server, id, rec)
      rec.kredi = Math.max(rec.kredi || 0, 0) + ucret
      rec.son = simdi
      rec.grace = 0
      bildir(server, id, rec, 'Vergi ödendi, claim\'ler geri yüklendi (' + s.ok + ' chunk, atlanan: ' + s.atlanan + ').')
    }
  })

  kaydet(server, d)
}

ServerEvents.tick(function (event) {
  if (event.server.tickCount % KONTROL_ARALIGI_TICK !== 0) return
  try { vergiIsle(event.server) } catch (err) { console.error('[Vergi] hata: ' + err) }
})

// Giriş yapınca bekleyen mesajları ilet
PlayerEvents.loggedIn(function (event) {
  var server = event.server
  var d = yukle(server)
  var rec = d.kayitlar[String(event.player.uuid)]
  if (!rec || !rec.bekleyen || rec.bekleyen.length === 0) return
  rec.bekleyen.forEach(function (msg) { event.player.tell(msg) })
  rec.bekleyen = []
  kaydet(server, d)
})

// ----------------------------- ÖLÜM VERGİSİ --------------------------
EntityEvents.death('minecraft:player', function (event) {
  var p = event.entity
  if (!p || !p.isPlayer()) return
  // Oyuncuyu başka bir oyuncu öldürdüyse ölüm vergisini savas_sistemi.js ele alır
  var katil = event.source.getActual()
  if (katil != null && katil.isPlayer() && !katil.getUuid().equals(p.getUuid())) return
  var b = bakiye(p.uuid)
  var vergi = Math.floor(b * VERGI.OLUM_VERGISI_ORAN)
  if (vergi < 1) return
  if (vergiKes(event.server, p.uuid, vergi, 'olum')) {
    p.tell('Ölüm vergisi: bankandan ' + vergi + ' spur kesildi (%' + (VERGI.OLUM_VERGISI_ORAN * 100) + ').')
  }
})

// ----------------------------- KOMUTLAR ------------------------------
function ode(server, player, gun) {
  var d = yukle(server)
  var id = String(player.uuid)
  var simdi = Date.now()
  var aktif = claimSayisi(server, player.uuid)
  var kat = katYukle(server)
  var u = gunlukUcret(server, player.uuid, aktif, kat)
  var rec = d.kayitlar[id] || (d.kayitlar[id] = yeniKayit(simdi, u.g))
  var n = aktif + (rec.askida ? (rec.snapshot || []).length : 0)
  if (n === 0) { player.tell('Vergi ödenecek claim\'in yok.'); return 0 }
  var g = u.g + (rec.askida ? snapshotUcret(id, rec.snapshot || [], kat) : 0)
  rec.g = g
  rec.dg = u.dg
  krediHazirla(rec, g, simdi)
  var ucret = g * gun
  if (!vergiKes(server, player.uuid, ucret, 'arazi')) {
    player.tell('Bankanda yeterli para yok. Gerekli: ' + ucret + ' spur.')
    return 0
  }
  if (rec.askida) {
    var s = geriYukle(server, id, rec)
    player.tell('Claim\'ler geri yüklendi (' + s.ok + ' chunk, atlanan: ' + s.atlanan + ').')
    rec.kredi = Math.max(rec.kredi || 0, 0)
    rec.son = simdi
  }
  rec.kredi += ucret
  rec.grace = 0
  kaydet(server, d)
  player.tell(gun + ' günlük vergi ödendi: ' + ucret + ' spur (' + n + ' chunk). Kalan süre: ' + kalanSure(rec, g) +
    '. Chunk eklersen süre kısalır.')
  return 1
}

ServerEvents.commandRegistry(function (event) {
  var Commands = event.commands

  event.register(Commands.literal('vergi')
    .then(Commands.literal('durum').executes(function (ctx) {
      var p = ctx.source.player
      var server = p.server
      var d = yukle(server)
      var rec = d.kayitlar[String(p.uuid)]
      var n = claimSayisi(server, p.uuid)
      var u = gunlukUcret(server, p.uuid, n, katYukle(server))
      p.tell('Claim: ' + n + ' chunk (yerleşke ' + u.dg.y + ', dükkan ' + u.dg.d + ', fabrika ' + u.dg.f + ') | Günlük vergi: ' + u.g + ' spur')
      p.tell('Banka bakiyesi: ' + bakiye(p.uuid) + ' spur')
      if (rec) {
        var simdi = Date.now()
        krediHazirla(rec, u.g, simdi)
        p.tell('Ön ödeme: ' + Math.max(0, Math.floor(rec.kredi)) + ' spur | Bu ücretle kalan süre: ' + kalanSure(rec, u.g) +
          ' | Otomatik ödeme: ' + (rec.auto !== false ? 'açık' : 'kapalı'))
        if (rec.grace) p.tell('Ek süre bitimine: ' + kalan(rec.grace - simdi))
        if (rec.askida) p.tell('Askıdaki chunk: ' + (rec.snapshot || []).length + ' (ödeme yapınca geri gelir)')
      }
      return 1
    }))
    .then(Commands.literal('ode')
      .then(Commands.literal('gun').executes(function (ctx) { var p = ctx.source.player; return ode(p.server, p, 1) }))
      .then(Commands.literal('hafta').executes(function (ctx) { var p = ctx.source.player; return ode(p.server, p, 7) }))
      .then(Commands.literal('ay').executes(function (ctx) { var p = ctx.source.player; return ode(p.server, p, 30) })))
    .then(Commands.literal('otomatik')
      .then(Commands.literal('ac').executes(function (ctx) {
        var p = ctx.source.player
        var d = yukle(p.server)
        var rec = d.kayitlar[String(p.uuid)] || (d.kayitlar[String(p.uuid)] = yeniKayit(Date.now(), claimSayisi(p.server, p.uuid)))
        rec.auto = true; kaydet(p.server, d)
        p.tell('Otomatik ödeme açıldı.'); return 1
      }))
      .then(Commands.literal('kapat').executes(function (ctx) {
        var p = ctx.source.player
        var d = yukle(p.server)
        var rec = d.kayitlar[String(p.uuid)] || (d.kayitlar[String(p.uuid)] = yeniKayit(Date.now(), claimSayisi(p.server, p.uuid)))
        rec.auto = false; kaydet(p.server, d)
        p.tell('Otomatik ödeme kapatıldı. Süre bitmeden /vergi ode ile kendin ödemelisin.'); return 1
      }))))

  event.register(Commands.literal('tescil').executes(function (ctx) {
    var p = ctx.source.player
    if (!vergiKes(p.server, p.uuid, VERGI.TESCIL_UCRETI, 'tescil')) {
      p.tell('Tescil için bankanda ' + VERGI.TESCIL_UCRETI + ' spur olmalı.')
      return 0
    }
    p.give(Item.of('minecraft:paper').withCustomName(Text.of('Tescil Belgesi - ' + p.username).gold()))
    p.tell('Tescil ücreti (' + VERGI.TESCIL_UCRETI + ' spur) kesildi, belgen verildi.')
    return 1
  }))

  var Arguments = event.arguments

  // --------------------------- /arazi (teftiş) ---------------------------
  //   /arazi bilgi                           -> bulunduğun chunk: sahip, kategori, günlük vergi
  //   /arazi kategori <yerleske|dukkan|fabrika> [fiyat]   -> sadece başkan veya OP
  function bulunulanChunk(p) {
    var boyut = String(p.level.getDimension())
    var x = Math.floor(p.getX() / 16), z = Math.floor(p.getZ() / 16)
    var c = claimYonetici(p.server).get(ResLoc.parse(boyut), x, z)
    var sahip = c == null ? null : c.getPlayerId()
    if (sahip != null && (sahip.equals(OzelSahipler.SERVER) || sahip.equals(OzelSahipler.EXPIRED))) sahip = null
    return { d: boyut, x: x, z: z, sahip: sahip, anahtar: katAnahtar(boyut, x, z) }
  }
  function chunkKategori(kat, ch) {
    var e = kat[ch.anahtar]
    if (e && ch.sahip != null && e.o === String(ch.sahip)) return e
    return { k: 'yerleske', f: VERGI.YERLESKE }
  }
  event.register(Commands.literal('arazi')
    .then(Commands.literal('bilgi').executes(function (ctx) {
      var p = ctx.source.player
      if (p == null) return 0
      var ch = bulunulanChunk(p)
      if (ch.sahip == null) { p.tell('Chunk ' + ch.x + ', ' + ch.z + ': kimsenin değil.'); return 1 }
      var e = chunkKategori(katYukle(p.server), ch)
      p.tell('Chunk ' + ch.x + ', ' + ch.z + ' | Sahip: ' + ad(p.server, ch.sahip) + ' | ' + KAT_AD[e.k] + ' | Günlük vergi: ' + e.f + ' spur' +
        (e.b ? ' | Belirleyen: ' + e.b : ''))
      return 1
    }))
    .then(Commands.literal('kategori')
      .then(Commands.argument('tur', Arguments.WORD.create(event))
        .executes(function (ctx) { return kategoriAyarla(ctx, null) })
        .then(Commands.argument('fiyat', Arguments.INTEGER.create(event))
          .executes(function (ctx) { return kategoriAyarla(ctx, Arguments.INTEGER.getResult(ctx, 'fiyat')) })))))

  function kategoriAyarla(ctx, fiyat) {
    var p = ctx.source.player
    if (p == null) return 0
    var server = p.server
    if (!baskanMi(server, p) && !ctx.source.hasPermission(2)) { p.tell('Arazi kategorisini sadece başkan belirleyebilir.'); return 0 }
    var tur = String(Arguments.WORD.getResult(ctx, 'tur')).toLowerCase().replace('ü', 'u').replace('ş', 's')
    if (!KAT_AD[tur]) { p.tell('Kategori: yerleske, dukkan veya fabrika.'); return 0 }
    if (fiyat != null && (fiyat < 1 || fiyat > VERGI.FIYAT_MAX)) { p.tell('Fiyat 1 ile ' + VERGI.FIYAT_MAX + ' arasında olmalı.'); return 0 }
    var ch = bulunulanChunk(p)
    if (ch.sahip == null) { p.tell('Bu chunk kimsenin değil, kategori verilemez.'); return 0 }
    var kat = katYukle(server)
    var sahipId = String(ch.sahip)
    var f = VERGI.YERLESKE
    if (tur === 'yerleske') {
      delete kat[ch.anahtar]
    } else {
      f = fiyat != null ? fiyat : (tur === 'dukkan' ? VERGI.DUKKAN_VARSAYILAN : VERGI.FABRIKA_VARSAYILAN)
      kat[ch.anahtar] = { k: tur, f: f, o: sahipId, b: String(p.username), t: Date.now() }
    }
    katKaydet(server, kat)
    // Haritadaki renk/ad: chunk'ı kategorinin alt claim'ine taşı
    var renk = false
    try { renk = claimRenklendir(server, ch.d, ch.x, ch.z, ch.sahip, tur) } catch (err) { console.warn('[Vergi] renk: ' + err) }
    if (!renk) p.tell('Not: haritadaki renk değiştirilemedi (oyuncunun alt claim sınırı dolu olabilir). Vergi yine uygulanır.')
    // Sahibin günlük ücretini hemen güncelle (menü ve kalan süre için)
    var d = yukle(server)
    var rec = d.kayitlar[sahipId]
    if (rec) {
      var u = gunlukUcret(server, ch.sahip, claimSayisi(server, ch.sahip), kat)
      rec.g = u.g; rec.dg = u.dg
      bildir(server, sahipId, rec, 'Başkan ' + p.username + ', chunk ' + ch.x + ', ' + ch.z + ' için kategoriyi ' + KAT_AD[tur] +
        ' yaptı (' + f + ' spur/gün). Yeni günlük vergin: ' + u.g + ' spur.')
      kaydet(server, d)
    }
    p.tell('Chunk ' + ch.x + ', ' + ch.z + ' (' + ad(server, ch.sahip) + '): ' + KAT_AD[tur] + ', ' + f + ' spur/gün.')
    return 1
  }

  // --------------------------- /devlet (sadece OP) ---------------------
  var yetkili = function (src) { return src.hasPermission(2) }
  var miktarAl = function (ctx) { return Arguments.INTEGER.getResult(ctx, 'miktar') }
  var yaz = function (ctx, msg) { ctx.source.sendSystemMessage(Text.ofString(msg)) }

  // Hazineden bir hesaba para aktarır
  function hazinedenAktar(ctx, hedefUuid, miktar, tur) {
    if (miktar <= 0) { yaz(ctx, 'Miktar 0\'dan büyük olmalı.'); return 0 }
    var h = hazine()
    if (h.getBalance() < miktar) { yaz(ctx, 'Hazinede yeterli para yok. Bakiye: ' + h.getBalance() + ' spur.'); return 0 }
    var hedef = Numismatics.BANK.getOrCreateAccount(hedefUuid, BankType.PLAYER)
    if (!h.deduct(miktar, ReasonHolder.IGNORED)) { yaz(ctx, 'Aktarım yapılamadı.'); return 0 }
    h.markDirty()
    hedef.deposit(miktar)
    hedef.markDirty()
    hazineKayit(ctx.source.server, tur, miktar, ad(ctx.source.server, hedefUuid))
    return 1
  }

  event.register(Commands.literal('devlet').requires(yetkili)
    .then(Commands.literal('durum').executes(function (ctx) {
      var h = hazine()
      var d = hazineVeri(ctx.source.server)
      var simdi = Date.now()
      yaz(ctx, '=== Devlet Hazinesi: ' + h.getBalance() + ' spur ===')
      yaz(ctx, 'Toplam gelir - arazi: ' + (d.gelir.arazi || 0) + ' | ölüm: ' + (d.gelir.olum || 0) + ' | tescil: ' + (d.gelir.tescil || 0) +
        ' | cinayet: ' + (d.gelir.cinayet || 0) + ' | savaş ilanı: ' + (d.gelir.savas || 0))
      var son = d.hareket.slice(-10).reverse()
      if (son.length === 0) yaz(ctx, 'Henüz hareket yok.')
      son.forEach(function (x) {
        var yon = (x.tur === 'aktarim' || x.tur === 'cekim' || x.tur === 'kredi') ? '-' : '+'
        yaz(ctx, yon + x.m + ' spur  ' + (TUR_AD[x.tur] || x.tur) + '  ' + x.k + '  (' + kalan(simdi - x.t) + ' önce)')
      })
      return 1
    }))
    .then(Commands.literal('aktar')
      .then(Commands.argument('oyuncu', Arguments.PLAYER.create(event))
        .then(Commands.argument('miktar', Arguments.INTEGER.create(event)).executes(function (ctx) {
          var hedef = Arguments.PLAYER.getResult(ctx, 'oyuncu')
          var miktar = miktarAl(ctx)
          if (!hazinedenAktar(ctx, hedef.getUuid(), miktar, 'aktarim')) return 0
          yaz(ctx, hedef.getName().getString() + ' oyuncusunun bankasına ' + miktar + ' spur aktarıldı. Hazine: ' + hazine().getBalance())
          hedef.tell('Devlet hazinesinden bankana ' + miktar + ' spur yatırıldı.')
          return 1
        }))))
    .then(Commands.literal('cek')
      .then(Commands.argument('miktar', Arguments.INTEGER.create(event)).executes(function (ctx) {
        var p = ctx.source.player
        if (p == null) { yaz(ctx, 'Bu komutu oyun içinden kullanın.'); return 0 }
        var miktar = miktarAl(ctx)
        if (!hazinedenAktar(ctx, p.uuid, miktar, 'cekim')) return 0
        yaz(ctx, 'Hazineden kendi bankana ' + miktar + ' spur çekildi. Hazine: ' + hazine().getBalance())
        return 1
      })))
    .then(Commands.literal('yatir')
      .then(Commands.argument('miktar', Arguments.INTEGER.create(event)).executes(function (ctx) {
        var p = ctx.source.player
        if (p == null) { yaz(ctx, 'Bu komutu oyun içinden kullanın.'); return 0 }
        var miktar = miktarAl(ctx)
        if (miktar <= 0) { yaz(ctx, 'Miktar 0\'dan büyük olmalı.'); return 0 }
        if (!kes(p.uuid, miktar)) { yaz(ctx, 'Bankanda yeterli para yok.'); return 0 }
        var h = hazine(); h.deposit(miktar); h.markDirty()
        hazineKayit(ctx.source.server, 'yatirma', miktar, p.username)
        yaz(ctx, 'Hazineye ' + miktar + ' spur yatırıldı. Hazine: ' + h.getBalance())
        return 1
      })))
    .then(Commands.literal('ac').executes(function (ctx) {
      var p = ctx.source.player
      if (p == null) { yaz(ctx, 'Bu komutu oyun içinden kullanın.'); return 0 }
      var h = hazine()
      NumUtils.openScreen(p, h, function (buf) { h.sendToMenu(buf) })
      return 1
    }))
    .then(Commands.literal('kart').executes(function (ctx) {
      var p = ctx.source.player
      if (p == null) { yaz(ctx, 'Bu komutu oyun içinden kullanın.'); return 0 }
      var h = hazine()
      var u = p.getUuid()
      h.updateTrustList(function (liste) { if (!liste.contains(u)) liste.add(u) })
      var kart = CardItem.set(Item.of('numismatics:yellow_card'), HAZINE_UUID)
      p.give(kart.withCustomName(Text.ofString('Devlet Hazinesi Kartı').gold()))
      yaz(ctx, 'Hazine kartı verildi. Bank Terminal\'e kartla sağ tıklayınca hazine açılır. Kartı shift+sağ tıklama ile kullanma, bağlantısı silinir.')
      return 1
    }))
    .then(Commands.literal('baskan')
      .executes(function (ctx) {
        var b = ctx.source.server.persistentData.getString('baskan')
        yaz(ctx, b ? 'Başkan: ' + ad(ctx.source.server, JUUID.fromString(b)) : 'Başkan atanmamış. /devlet baskan <oyuncu>')
        return 1
      })
      .then(Commands.literal('kaldir').executes(function (ctx) {
        ctx.source.server.persistentData.remove('baskan')
        yaz(ctx, 'Başkan kaldırıldı.')
        return 1
      }))
      .then(Commands.argument('oyuncu', Arguments.PLAYER.create(event)).executes(function (ctx) {
        var hedef = Arguments.PLAYER.getResult(ctx, 'oyuncu')
        ctx.source.server.persistentData.putString('baskan', String(hedef.getUuid()))
        yaz(ctx, hedef.getName().getString() + ' artık başkan: arazi kategorilerini belirleyebilir (/arazi kategori, menü > Teftiş).')
        hedef.tell('Başkan oldun. Arazileri teftiş edip kategorilerini menüdeki Teftiş bölümünden belirleyebilirsin.')
        return 1
      })))
    .then(Commands.literal('yetki')
      .then(Commands.literal('ekle').then(Commands.argument('oyuncu', Arguments.PLAYER.create(event)).executes(function (ctx) {
        var hedef = Arguments.PLAYER.getResult(ctx, 'oyuncu')
        var u = hedef.getUuid()
        hazine().updateTrustList(function (liste) { if (!liste.contains(u)) liste.add(u) })
        yaz(ctx, hedef.getName().getString() + ' artık hazine kartını Bank Terminal\'de kullanabilir.')
        return 1
      })))
      .then(Commands.literal('kaldir').then(Commands.argument('oyuncu', Arguments.PLAYER.create(event)).executes(function (ctx) {
        var hedef = Arguments.PLAYER.getResult(ctx, 'oyuncu')
        var u = hedef.getUuid()
        hazine().updateTrustList(function (liste) { liste.remove(u) })
        yaz(ctx, hedef.getName().getString() + ' hazine yetkisi kaldırıldı.')
        return 1
      })))))
})

console.info('[Vergi] yuklendi: yerleske ' + VERGI.YERLESKE + ', dukkan ' + VERGI.DUKKAN_VARSAYILAN + ', fabrika ' + VERGI.FABRIKA_VARSAYILAN +
  ' spur/chunk/gun, olum vergisi %' + (VERGI.OLUM_VERGISI_ORAN * 100))
