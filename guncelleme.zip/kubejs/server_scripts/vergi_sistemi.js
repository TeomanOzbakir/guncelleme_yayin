// =====================================================================
//  VERGİ SİSTEMİ  -  kubejs/server_scripts/vergi_sistemi.js
//  Hedef: NeoForge 1.21.1 | KubeJS 2101.7.2 | Create Numismatics 1.1.0
//         Open Parties and Claims 0.33.0
//
//  - Arazi vergisi: günlük, banka hesabından otomatik kesilir (veya
//    oyuncu /vergi ode ile önceden öder). Ödenen para "kredi" olarak
//    durur ve o anki chunk sayısına göre dakika dakika harcanır; chunk
//    eklemek kalan süreyi kısaltır. Ödenmezse 24 gerçek saat ek
//    süre, sonra claim'ler askıya alınır (silinir + kaydedilir),
//    ödeme yapılınca geri yüklenir.
//  - Ölüm vergisi: ölünce banka bakiyesinin %5'i.
//  - Tescil: /tescil komutu ücreti keser, belge verir.
//  - Devlet hazinesi: kesilen tüm vergiler ayrı bir Numismatics hesabına
//    yatar. OP'lar /devlet ile bakiyeyi ve hareketleri görür, oyunculara
//    aktarım yapar; /devlet kart ile Bank Terminal'de hazineyi açar.
//
//  Doğrulama (mod JAR'larına karşı): kullanılan tüm Numismatics, OPAC ve
//  KubeJS sınıf/fonksiyon adları ve parametreleri bu sürümlerde var.
//  Düzeltilenler: tescil belgesi için withName -> withCustomName
//  (KubeJS 2101'de withName yok); askiyaAl içindeki gereksiz
//  Object.assign kaydı kaldırıldı.
//  !! Gerçek bir oyunda ÇALIŞTIRILARAK TEST EDİLMEDİ.
// =====================================================================

// ----------------------------- AYARLAR -------------------------------
// Arazi kategorileri: her claim varsayılan olarak YERLEŞKE'dir. Başkan (veya OP) bir chunk'ı
// teftiş edip /arazi kategori dukkan|fabrika [fiyat] ile (veya menüdeki Teftiş bölümünden)
// DÜKKAN / FABRİKA yapar; fiyat yazılmazsa varsayılan kullanılır. Kayıt: persistentData
// 'arazi_kategori' = { "boyut|x|z": { k, f, o (sahip uuid), b (başkan), t } }.
// Chunk başkasına geçerse kayıt geçersiz sayılır (o != yeni sahip).
const VERGI = {
  YERLESKE: 35,               // spur / kiralanan claim hakkı / gün
  BEDAVA_CLAIM: 1,            // herkesin ücretsiz claim hakkı (OPAC maxPlayerClaims ile AYNI tutun)
  KOTA_MAX: 2000,             // bir oyuncunun kiralayabileceği en çok hak
  DUKKAN_VARSAYILAN: 100,
  FABRIKA_VARSAYILAN: 150,
  ARAC_VARSAYILAN: 35,         // araç kategorisi: fiyatı başkan teftişte girer
  FIYAT_MAX: 100000,          // başkanın girebileceği en yüksek günlük fiyat
  OLUM_VERGISI_ORAN: 0.05,    // bankadaki paranın %5'i
  TESCIL_UCRETI: 500,         // spur (YER TUTUCU - istediğiniz değeri yazın)
  EK_SURE_SAAT: 24,           // ödenmezse claim kapanmadan önce bekleme
  MUAF_UUID: []               // vergiden muaf oyuncu UUID'leri (string)
}

// ----------------------------- ORANLAR (başkan ayarlar) ---------------
// /vergi oran [ad] [değer]: başkan veya OP değiştirir, değişiklik herkese duyurulur.
// Yüzdeler tam sayı (%5 -> 5). Kira/dükkan/fabrika/araç eski anahtarlarında, diğerleri
// 'vergi_oranlari' JSON'unda durur (sunucu_piyasa KDV ve harcı her dakika buradan okur).
const ORANLAR = {
  kira:    { ad: 'Claim hakkı kirası', birim: 'spur/gün', max: 100000, anahtar: 'arazi_fiyat_yerleske', vars: VERGI.YERLESKE },
  dukkan:  { ad: 'Dükkan chunk fiyatı', birim: 'spur/gün', max: 100000, anahtar: 'arazi_fiyat_dukkan', vars: VERGI.DUKKAN_VARSAYILAN },
  fabrika: { ad: 'Fabrika chunk fiyatı', birim: 'spur/gün', max: 100000, anahtar: 'arazi_fiyat_fabrika', vars: VERGI.FABRIKA_VARSAYILAN },
  arac:    { ad: 'Araç vergisi (aero claim başına)', birim: 'spur/gün', max: 100000, anahtar: 'arac_fiyat', vars: VERGI.ARAC_VARSAYILAN },
  kdv:     { ad: 'KDV (Selling Bin satışı)', birim: '%', max: 50, vars: 5 },
  harc:    { ad: 'Ticaret harcı (Vendor/depozitör)', birim: '%', max: 20, vars: 1 },
  olum:    { ad: 'Ölüm vergisi (banka bakiyesi)', birim: '%', max: 50, vars: Math.round(VERGI.OLUM_VERGISI_ORAN * 100) },
  tescil:  { ad: 'Tescil ücreti', birim: 'spur', max: 100000, vars: VERGI.TESCIL_UCRETI }
}
function oranAl(server, ad) {
  var o = ORANLAR[ad]
  if (!o) return 0
  var pd = server.persistentData
  if (o.anahtar) return pd.contains(o.anahtar) ? pd.getInt(o.anahtar) : o.vars
  var j = {}
  try { j = JSON.parse(pd.getString('vergi_oranlari') || '{}') || {} } catch (e) { j = {} }
  return j[ad] != null ? Number(j[ad]) : o.vars
}
function oranYaz(server, ad, v) {
  var o = ORANLAR[ad]
  var pd = server.persistentData
  if (o.anahtar) { pd.putInt(o.anahtar, v); return }
  var j = {}
  try { j = JSON.parse(pd.getString('vergi_oranlari') || '{}') || {} } catch (e) { j = {} }
  j[ad] = v
  pd.putString('vergi_oranlari', JSON.stringify(j))
}
function oranMetin(server, ad) {
  var o = ORANLAR[ad], v = oranAl(server, ad)
  return o.birim === '%' ? '%' + v : v + ' ' + o.birim
}
function kira(server) { return oranAl(server, 'kira') }
// Diğer betikler (savas_sistemi ölüm vergisi vb.) için
global.vergiOrani = function (server, ad) { return oranAl(server, ad) }

const GUN_MS = 24 * 60 * 60 * 1000
const KONTROL_ARALIGI_TICK = 1200   // 1200 tick = 1 dakika

// ----------------------------- SINIFLAR ------------------------------
const JUUID = Java.loadClass('java.util.UUID')
const ResLoc = Java.loadClass('net.minecraft.resources.ResourceLocation')
const Numismatics = Java.loadClass('dev.ithundxr.createnumismatics.Numismatics')
const ReasonHolder = Java.loadClass('dev.ithundxr.createnumismatics.content.backend.ReasonHolder')
const OpenPACServerAPI = Java.loadClass('xaero.pac.common.server.api.OpenPACServerAPI')
const OzelSahipler = Java.loadClass('xaero.pac.common.claims.api.SpecialClaimOwners')

// ----------------------------- VERİ ----------------------------------
function yukle(server) {
  var s = server.persistentData.getString('vergi_veri')
  if (!s) return { kayitlar: {} }
  try { return JSON.parse(s) } catch (e) { return { kayitlar: {} } }
}
function kaydet(server, d) {
  server.persistentData.putString('vergi_veri', JSON.stringify(d))
}
// Arazi vergisi "kredi" ile işler: ödenen para spur olarak rec.kredi'de
// durur ve her dakika O ANKİ günlük ücrete (g) göre eriyerek harcanır.
// g = yerleşke chunk'ları x 35 + dükkan/fabrika chunk'larının fiyatları.
// Chunk eklenirse / kategori değişirse kalan süre aynı oranda değişir.
// İlk gün ücretsiz: yeni kayda, o anki günlük ücret kadar kredi verilir.
// rec.g ve rec.dg (yerleşke/dükkan/fabrika sayıları) menü için saklanır.
const MAX_ADIM_MS = 5 * 60 * 1000   // sunucu kapalıyken geçen süre sayılmaz
function yeniKayit(simdi, g) {
  return { kredi: g || 0, g: g || 0, son: simdi, grace: 0, askida: false, auto: true, snapshot: [], bekleyen: [] }
}
function krediHazirla(rec, g, simdi) {
  if (rec.kredi == null) {   // eski (bitiş zamanlı) kayıttan çevir
    var kalanMs = Math.max(0, (rec.paidUntil || simdi) - simdi)
    rec.kredi = kalanMs / GUN_MS * Math.max(g, VERGI.YERLESKE)
    delete rec.paidUntil
  }
  if (rec.son == null) rec.son = simdi
}
function krediTuket(rec, g, simdi) {
  var gecen = Math.min(Math.max(0, simdi - rec.son), MAX_ADIM_MS)
  rec.son = simdi
  if (g > 0) rec.kredi -= g * gecen / GUN_MS
}
function kalanSure(rec, g) {
  if (g <= 0) return 'claim yok'
  if (!(rec.kredi > 0)) return 'bitti'
  return kalan(rec.kredi / g * GUN_MS)
}

// ----------------------------- ARAZİ KATEGORİLERİ --------------------
const KAT_AD = { yerleske: 'Yerleşke', dukkan: 'Dükkan', fabrika: 'Fabrika', arac: 'Araç' }
function katYukle(server) {
  var s = server.persistentData.getString('arazi_kategori')
  if (!s) return {}
  try { return JSON.parse(s) || {} } catch (e) { return {} }
}
function katKaydet(server, kat) { server.persistentData.putString('arazi_kategori', JSON.stringify(kat)) }
function katAnahtar(d, x, z) { return String(d) + '|' + x + '|' + z }
// KİRALIK CLAIM (2026-11-23): oyuncu claim HAKKI (kota) kiralar; kullanmasa da öder.
//  - Herkesin ilk BEDAVA_CLAIM hakkı ücretsiz (OPAC maxPlayerClaims = 1).
//  - Kiralanan hak OPAC'ta oyuncunun claims.bonusChunkClaims ayarına yazılır (kotaEsitle);
//    OPAC sınırı kendisi uygular. Aeronautics Claims araç slotlarını aynı ayardan düşer, bu yüzden
//    kota araç slotlarını da kapsar; araçta KULLANILAN slot arazi yerine araç fiyatından ücretlenir.
//  - Kategori: sahip kendi chunk'ını dükkan/fabrika işaretler, o chunk için fiyat FARKINI öder;
//    yanlış işaretlemeyi başkan düzeltir + ceza yazar (/arazi duzelt).
// Kategori kaydı sadece chunk hâlâ aynı sahibindeyse sayılır.
function katFiyat(server, tur) {
  return oranAl(server, (tur === 'dukkan' || tur === 'fabrika') ? tur : 'kira')
}
function aracGoc(server, uuid) {   // Aeronautics Claims'e taşınmış (araç için ayrılmış) slot
  aracSlot(server, uuid)
  if (AeroYonetici == null) return 0
  try { return Number(AeroYonetici.getMigratedSlots(server.overworld(), uuid)) || 0 } catch (e) { return 0 }
}
// kota: kiralanan toplam hak (bedava dahil). Verilmezse kayıttan okunur.
function gunlukUcret(server, uuid, n, kat, kota) {
  var id = String(uuid)
  var m = claimYonetici(server)
  if (kota == null) { var vr = yukle(server).kayitlar[id]; kota = vr && vr.kota != null ? vr.kota : VERGI.BEDAVA_CLAIM }
  var slot = aracSlot(server, uuid)
  kota = Math.max(kota, n + aracGoc(server, uuid), VERGI.BEDAVA_CLAIM)
  var ucretli = Math.max(0, kota - VERGI.BEDAVA_CLAIM)
  var sonuc = { g: Math.max(0, ucretli - slot) * kira(server) + slot * aracFiyat(server),
    dg: { y: n, d: 0, f: 0, a: slot, k: kota, n: n } }
  var anahtarlar = Object.keys(kat)
  for (var i = 0; i < anahtarlar.length; i++) {
    var e = kat[anahtarlar[i]]
    if (!e || e.o !== id || (e.k !== 'dukkan' && e.k !== 'fabrika')) continue
    var p = anahtarlar[i].split('|')
    var c = null
    try { c = m.get(ResLoc.parse(p[0]), parseInt(p[1], 10), parseInt(p[2], 10)) } catch (err) { c = null }
    if (c == null || String(c.getPlayerId()) !== id) continue
    sonuc.g += Math.max(0, katFiyat(server, e.k) - kira(server))   // kategori farkı
    sonuc.dg.y--
    if (e.k === 'dukkan') sonuc.dg.d++; else sonuc.dg.f++
  }
  // Tacir mesleği: arazi vergisi indirimi (yetenek_sistemi.js etiket önbelleği; oyuncu çevrimdışıyken de geçerli)
  var ind = tacirVergiIndirimi(server, id)
  if (ind > 0) { sonuc.g = Math.round(sonuc.g * (1 - ind)); sonuc.ind = ind }
  return sonuc
}
function tacirVergiIndirimi(server, id) {
  var et = null
  try { et = JSON.parse(server.persistentData.getString('yetenek_etiket') || '{}')[id] } catch (e) { et = null }
  if (!et) return 0
  var ind = 0
  if (et.indexOf('yt_vergi_1') >= 0) ind += 0.05
  if (et.indexOf('yt_vergi_2') >= 0) ind += 0.05
  if (et.indexOf('yt_vergi_3') >= 0) ind += 0.05
  if (et.indexOf('yt_tacir_doruk') >= 0) ind += 0.10
  return ind
}
// ----------------------------- ARAÇ VERGİSİ ----------------------------
// Aeronautics Claims (aeroclaims) araç claim'leri OPAC chunk'ı almaz, sadece claim hakkı
// kullanır; bu yüzden arazi sayısına girmez. Oyuncunun araçlarda kullandığı aero claim
// sayısı AeroClaimManager.getUsedSlots ile okunur. Fiyat: başkan /arazi aracfiyat <n>
// (persistentData 'arac_fiyat'), girilmezse VERGI.ARAC_VARSAYILAN.
var AeroYonetici = undefined
function aracSlot(server, uuid) {
  if (AeroYonetici === undefined) {
    try { AeroYonetici = Java.loadClass('com.mapter.aeroclaims.claim.AeroClaimManager') } catch (e) { AeroYonetici = null; console.warn('[Vergi] AeroClaims bulunamadi, arac vergisi kapali') }
  }
  if (AeroYonetici == null) return 0
  try { return Number(AeroYonetici.getUsedSlots(server.overworld(), uuid)) || 0 } catch (e) { return 0 }
}
function aracFiyat(server) { return oranAl(server, 'arac') }
// Askıdaki (silinmiş) claim'leri geri almak için bir günlük kira: kota kirası + kayıtlı kategori farkları
function snapshotUcret(server, id, rec, kat) {
  var snap = rec.snapshot || []
  var kota = Math.max(rec.kota != null ? rec.kota : VERGI.BEDAVA_CLAIM, snap.length)
  var t = Math.max(0, kota - VERGI.BEDAVA_CLAIM) * kira(server)
  for (var i = 0; i < snap.length; i++) {
    var e = kat[katAnahtar(snap[i].d, snap[i].x, snap[i].z)]
    if (e && e.o === id && (e.k === 'dukkan' || e.k === 'fabrika')) t += Math.max(0, katFiyat(server, e.k) - kira(server))
  }
  return t
}

// ----------------------------- KOTA (OPAC sınırı) ---------------------
// OPAC'taki ek claim hakkı = kota - temel sınır (maxPlayerClaims) - araçlara taşınan slot.
// Claim + araç slotu kotayı aşmışsa (antlaşma, OP, eski kayıt) kota otomatik yükseltilir.
const PlayerConfigOptions = Java.loadClass('xaero.pac.common.server.player.config.api.PlayerConfigOptions')
function kotaOku(rec) { return rec && rec.kota != null ? rec.kota : VERGI.BEDAVA_CLAIM }
function kotaEsitle(server, id, rec) {
  var uuid = JUUID.fromString(id)
  var n = claimSayisi(server, uuid)
  var goc = aracGoc(server, uuid)
  var kota = kotaOku(rec)
  if (rec && rec.askida) kota = Math.max(kota, (rec.snapshot || []).length)
  if (n + goc > kota) {
    var eski = kota
    kota = n + goc
    if (rec) bildir(server, id, rec, 'Claim hakkın ' + eski + ' → ' + kota + ' yükseltildi (elindeki arazi ve araç slotları kadar). Günlük kira buna göre artar.')
  }
  if (rec) rec.kota = kota
  var m = claimYonetici(server)
  var taban = 0
  try { taban = Number(m.getPlayerBaseClaimLimit(uuid)) || 0 } catch (e) { taban = VERGI.BEDAVA_CLAIM }
  // Askıda/hacizdeyken kira ödenmiyor: ek hak kapalı (kayıtlı kota korunur, ödeyince geri gelir)
  var hedef = (rec && (rec.askida || rec.haciz)) ? 0 : Math.max(0, kota - taban - goc)
  var simdiki = null
  try {
    var cfg = OpenPACServerAPI.get(server).getPlayerConfigs().getLoadedConfig(uuid)
    if (cfg != null) { var r = cfg.getRaw(PlayerConfigOptions.BONUS_CHUNK_CLAIMS); simdiki = r == null ? 0 : Number(r) }
  } catch (e) { simdiki = null }
  if (simdiki === hedef) return kota
  var isim = ad(server, uuid)
  if (isim.length === 8 && isim === id.substring(0, 8)) return kota   // adı bilinmiyor (hiç girmemiş)
  server.runCommandSilent('opac player-config for ' + isim + ' set claims.bonusChunkClaims ' + hedef)
  return kota
}
function kotaHepsiniEsitle(server, d) {
  var m = claimYonetici(server)
  var gorulen = {}
  var bilgiler = m.getPlayerInfoStream().toArray()
  for (var i = 0; i < bilgiler.length; i++) {
    var uuid = bilgiler[i].getPlayerId()
    if (uuid.equals(OzelSahipler.SERVER) || uuid.equals(OzelSahipler.EXPIRED)) continue
    gorulen[String(uuid)] = 1
  }
  Object.keys(d.kayitlar).forEach(function (id) { gorulen[id] = 1 })
  var cevrim = server.playerList.getPlayers().toArray()
  for (var j = 0; j < cevrim.length; j++) gorulen[String(cevrim[j].getUuid())] = 1
  Object.keys(gorulen).forEach(function (id) {
    try {
      var rec = d.kayitlar[id]
      if (!rec && claimSayisi(server, JUUID.fromString(id)) + aracGoc(server, JUUID.fromString(id)) > VERGI.BEDAVA_CLAIM)
        rec = d.kayitlar[id] = yeniKayit(Date.now(), 0)
      kotaEsitle(server, id, rec)
    } catch (err) { console.warn('[Vergi] kota ' + id + ': ' + err) }
  })
}
// Kirayı kim öder: kabul edilmiş sponsor varsa o, yoksa kendisi
function odeyen(rec, id) { return rec && rec.sponsor && rec.sponsorOnay ? rec.sponsor : id }
function kiraKes(server, id, rec, miktar) {
  var o = odeyen(rec, id)
  if (o !== id) {
    if (vergiKes(server, JUUID.fromString(o), miktar, 'arazi')) return { ok: true, kim: o }
    bildir(server, id, rec, 'Sponsorun (' + ad(server, JUUID.fromString(o)) + ') kiranı ödeyemedi, kendi bankandan deneniyor.')
  }
  return { ok: vergiKes(server, JUUID.fromString(id), miktar, 'arazi'), kim: id }
}
// Haritada kategori rengi: dükkan/fabrika chunk'ları sahibinin OPAC "alt claim"ine (sub-config)
// taşınır; alt claim'in kendi rengi ve adı vardır (Xaero haritasında görünür). Yerleşke =
// oyuncunun kendi ana claim rengi. Renk ve ad, OPAC'ın kendi komutuyla ayarlanır
// (API'deki Integer renk alanına KubeJS sayıyı Double gönderebiliyor).
const KAT_RENK = { dukkan: '2E86DE', fabrika: 'E67E22', arac: '9B59B6' }   // mavi, turuncu, mor (RRGGBB)
function altClaimIndeksi(server, uuid, tur) {
  var cfg = OpenPACServerAPI.get(server).getPlayerConfigs().getLoadedConfig(uuid)
  if (cfg == null) return null
  if (tur === 'yerleske') return cfg.getSubIndex()   // ana claim
  var isim = ad(server, uuid)
  if (!cfg.subConfigExists(tur)) server.runCommandSilent('opac player-config for ' + isim + ' sub create ' + tur)
  if (!cfg.subConfigExists(tur)) return null   // alt claim sınırı dolu olabilir
  server.runCommandSilent('opac player-config for ' + isim + ' sub ' + tur + ' set claims.name "' + KAT_AD[tur] + '"')
  server.runCommandSilent('opac player-config for ' + isim + ' sub ' + tur + ' set claims.color ' + KAT_RENK[tur])
  return cfg.getSubConfig(tur).getSubIndex()
}
// Chunk'ı (aynı sahipte kalarak) istenen alt claim'e taşır. true: taşındı / zaten oradaydı
function claimRenklendir(server, boyut, x, z, uuid, tur) {
  var m = claimYonetici(server)
  var rl = ResLoc.parse(boyut)
  var c = m.get(rl, x, z)
  if (c == null || !c.getPlayerId().equals(uuid)) return false
  var idx = altClaimIndeksi(server, uuid, tur)
  if (idx == null) return false
  if (Number(c.getSubConfigIndex()) === Number(idx)) return true
  var yuk = c.isForceloadable()
  m.claim(rl, uuid, idx, x, z, yuk)
  var yeni = m.get(rl, x, z)
  if (yeni == null || Number(yeni.getSubConfigIndex()) !== Number(idx)) {   // üzerine yazmadıysa sil + yeniden claim
    m.unclaim(rl, x, z)
    m.claim(rl, uuid, idx, x, z, yuk)
  }
  return true
}
// Her dakika: kategorisi olan chunk'lar doğru renkte mi (ör. silinip yeniden claim edildiyse)
function kategoriRenkleriniEsitle(server, kat) {
  var m = claimYonetici(server)
  var anahtarlar = Object.keys(kat)
  for (var i = 0; i < anahtarlar.length; i++) {
    var e = kat[anahtarlar[i]]
    var p = anahtarlar[i].split('|')
    try {
      var c = m.get(ResLoc.parse(p[0]), parseInt(p[1], 10), parseInt(p[2], 10))
      if (c == null || String(c.getPlayerId()) !== e.o) continue
      var cfg = OpenPACServerAPI.get(server).getPlayerConfigs().getLoadedConfig(c.getPlayerId())
      if (cfg == null || !cfg.subConfigExists(e.k)) { claimRenklendir(server, p[0], parseInt(p[1], 10), parseInt(p[2], 10), c.getPlayerId(), e.k); continue }
      if (Number(c.getSubConfigIndex()) !== Number(cfg.getSubConfig(e.k).getSubIndex())) claimRenklendir(server, p[0], parseInt(p[1], 10), parseInt(p[2], 10), c.getPlayerId(), e.k)
    } catch (err) { console.warn('[Vergi] kategori rengi: ' + err) }
  }
}
function baskanMi(server, p) {
  var b = server.persistentData.getString('baskan')
  return !!b && b === String(p.getUuid())
}
// [Başkan] unvanı: scoreboard takımı (sohbet, tab listesi, isim etiketi). Başka takımdaysa
// (ör. [BORÇLU] damgası) ona dokunmaz; damga kalkınca unvan geri gelir.
var baskanTakimHazir = false
function baskanUnvanEsitle(server) {
  if (!baskanTakimHazir) {
    baskanTakimHazir = true
    server.runCommandSilent('team add baskan')
    server.runCommandSilent('team modify baskan prefix {"text":"[Başkan] ","color":"gold"}')
  }
  var b = server.persistentData.getString('baskan')
  var sb = server.getScoreboard()
  var on = server.getPlayerList().getPlayers()
  for (var i = 0; i < on.size(); i++) {
    var p = on.get(i)
    var isim = String(p.username)
    var takim = sb.getPlayersTeam(isim)
    var olmali = !!b && String(p.getUuid()) === b
    if (olmali && takim == null) server.runCommandSilent('team join baskan ' + isim)
    else if (!olmali && takim != null && String(takim.getName()) === 'baskan') server.runCommandSilent('team leave ' + isim)
  }
}
// Başkan değişti: unvanı eşitle, eski ve yeni başkanın komut listesini tazele (/devlet görünür/gizlenir)
function baskanDegisti(server, eski) {
  baskanUnvanEsitle(server)
  var liste = [eski, server.persistentData.getString('baskan')]
  for (var i = 0; i < liste.length; i++) {
    if (!liste[i]) continue
    try {
      var pl = server.getPlayerList().getPlayer(JUUID.fromString(liste[i]))
      if (pl != null) server.getCommands().sendCommands(pl)
    } catch (e) { console.warn('[Vergi] komut tazeleme: ' + e) }
  }
}
ServerEvents.tick(function (event) {
  if (event.server.tickCount % 200 !== 57) return
  try { baskanUnvanEsitle(event.server) } catch (err) { console.error('[Vergi] baskan unvani: ' + err) }
})

// ----------------------------- BANKA ---------------------------------
function hesap(uuid) { return Numismatics.BANK.getAccount(uuid) }   // hesap yoksa null
function bakiye(uuid) {
  var h = hesap(uuid)
  return h ? h.getBalance() : 0
}
function kes(uuid, miktar) {
  miktar = Math.floor(miktar)
  if (miktar <= 0) return true
  var h = hesap(uuid)
  if (!h) return false
  var ok = h.deduct(miktar, ReasonHolder.IGNORED)   // bakiye yetmezse false
  if (ok) h.markDirty()
  return !!ok
}

// ----------------------------- DEVLET HAZİNESİ -----------------------
// Kesilen tüm vergiler bu Numismatics hesabına yatar. Hesap "Blaze Banker"
// türündedir: başlangıç parası almaz ve yetkili listesi (trust list) vardır.
// /devlet kart ile verilen karta bağlıdır; kartla Bank Terminal'e sağ
// tıklayan yetkili, hazinenin kendi banka ekranını açar.
const HAZINE_UUID = JUUID.fromString('5f0c2d1e-7a3b-4e9c-8d6f-1b2a3c4d5e6f')
const BankType = Java.loadClass('dev.ithundxr.createnumismatics.content.backend.BankAccount$Type')
const CardItem = Java.loadClass('dev.ithundxr.createnumismatics.content.bank.CardItem')
const NumUtils = Java.loadClass('dev.ithundxr.createnumismatics.util.Utils')
const TUR_AD = {
  arazi: 'Arazi vergisi', olum: 'Ölüm vergisi', tescil: 'Tescil',
  cinayet: 'Cinayet cezası', savas: 'Savaş ilanı',
  borc: 'Borç tahsilatı', kredi: 'Kredi verildi', kredi_odeme: 'Kredi ödemesi', zindan: 'Zindan girişi',
  aktarim: 'Aktarım', cekim: 'Çekim', yatirma: 'Yatırma'
}

function hazine() {
  var h = Numismatics.BANK.getOrCreateAccount(HAZINE_UUID, BankType.BLAZE_BANKER)
  if (h.getLabel() != 'Devlet Hazinesi') { h.setLabel('Devlet Hazinesi'); h.markDirty() }
  return h
}
function ad(server, uuid) {
  var p = server.playerList.getPlayer(uuid)
  if (p != null) return String(p.username)
  var prof = server.getProfileCache().get(uuid)
  return prof.isPresent() ? String(prof.get().getName()) : String(uuid).substring(0, 8)
}
function hazineVeri(server) {
  var s = server.persistentData.getString('hazine_veri')
  var d = null
  if (s) { try { d = JSON.parse(s) } catch (e) { d = null } }
  if (!d) d = {}
  if (!d.gelir) d.gelir = { arazi: 0, olum: 0, tescil: 0 }
  if (!d.hareket) d.hareket = []
  return d
}
function hazineKayit(server, tur, miktar, kim) {
  var d = hazineVeri(server)
  if (d.gelir[tur] != null) d.gelir[tur] += miktar
  // Son 500 hareket tutulur (menü > Hazine bölümünde sayfa sayfa görünür)
  d.hareket = d.hareket.concat([{ t: Date.now(), tur: tur, m: miktar, k: kim }]).slice(-500)
  server.persistentData.putString('hazine_veri', JSON.stringify(d))
}
// Oyuncudan vergi keser ve hazineye yatırır
function vergiKes(server, uuid, miktar, tur) {
  miktar = Math.floor(miktar)
  if (miktar <= 0) return true
  if (!kes(uuid, miktar)) return false
  var h = hazine()
  h.deposit(miktar)
  h.markDirty()
  hazineKayit(server, tur, miktar, ad(server, uuid))
  return true
}

// ----------------------------- CLAIM ---------------------------------
function claimYonetici(server) {
  return OpenPACServerAPI.get(server).getServerClaimsManager()
}
function claimSayisi(server, uuid) {
  var m = claimYonetici(server)
  return m.hasPlayerInfo(uuid) ? m.getPlayerInfo(uuid).getClaimCount() : 0
}
function claimOlcekle(server, uuid) {
  // Oyuncunun tüm claim'lerini [{d,x,z,s,f}] listesi olarak döndürür
  var m = claimYonetici(server)
  var liste = []
  if (!m.hasPlayerInfo(uuid)) return liste
  var info = m.getPlayerInfo(uuid)
  var boyutlar = m.getDimensionStream().toArray()
  for (var i = 0; i < boyutlar.length; i++) {
    var rl = boyutlar[i].getDimension()
    var pd = info.getDimension(rl)
    if (pd == null) continue
    var listeler = pd.getStream().toArray()
    for (var j = 0; j < listeler.length; j++) {
      var durum = listeler[j].getClaimState()
      var s = durum.getSubConfigIndex()
      var f = durum.isForceloadable()
      var pozlar = listeler[j].getStream().toArray()
      for (var k = 0; k < pozlar.length; k++) {
        liste.push({ d: String(rl), x: pozlar[k].x, z: pozlar[k].z, s: s, f: f })
      }
    }
  }
  return liste
}
function askiyaAl(server, id, rec) {
  // rec, cagiran tarafin veri nesnesinin icinde; kayit ana dongunun sonunda yapilir
  var uuid = JUUID.fromString(id)
  var snap = claimOlcekle(server, uuid)
  if (snap.length === 0) return 0
  rec.snapshot = (rec.snapshot || []).concat(snap)
  rec.askida = true
  var m = claimYonetici(server)
  for (var i = 0; i < snap.length; i++) {
    m.unclaim(ResLoc.parse(snap[i].d), snap[i].x, snap[i].z)
  }
  return snap.length
}
function geriYukle(server, id, rec) {
  // Başkası claim ettiyse o chunk'ın üzerine yazmaz, atlar.
  var uuid = JUUID.fromString(id)
  var m = claimYonetici(server)
  var ok = 0, atlanan = 0
  var liste = rec.snapshot || []
  for (var i = 0; i < liste.length; i++) {
    var c = liste[i]
    var rl = ResLoc.parse(c.d)
    if (m.get(rl, c.x, c.z) != null) { atlanan++; continue }
    try { m.claim(rl, uuid, c.s, c.x, c.z, c.f); ok++ } catch (e) { atlanan++ }
  }
  rec.snapshot = []
  rec.askida = false
  return { ok: ok, atlanan: atlanan }
}

// ----------------------------- MESAJ ---------------------------------
function bildir(server, id, rec, mesaj) {
  var p = server.playerList.getPlayer(JUUID.fromString(id))
  if (p != null) { p.tell(mesaj); return }
  rec.bekleyen = (rec.bekleyen || []).concat([mesaj]).slice(-5)
}
function kalan(ms) {
  var dk = Math.max(0, Math.floor(ms / 60000))
  return Math.floor(dk / 60) + ' saat ' + (dk % 60) + ' dk'
}

// ----------------------------- BORÇ YAPTIRIMLARI ---------------------
// borc_kredi.js her dakika 'borc_durum' yazar: { uuid: { a: aşama 0-4, ... } }
//  a >= 2 (3. gün): borç kapanana kadar yeni claim yok (izinli liste dışındakiler geri alınır)
//  a >= 4 (7. gün): ARAZİ HACZİ - claim'ler askıya alınır; borç kapanınca ücretsiz geri yüklenir
//                   (haciz öncesi zaten vergi yüzünden askıdaysa vergi ödenince döner)
function borcDurumOku(server) {
  try { return JSON.parse(server.persistentData.getString('borc_durum') || '{}') } catch (e) { return {} }
}
function hacizIsle(server, d) {
  var durum = borcDurumOku(server)
  // Haciz uygula
  Object.keys(durum).forEach(function (id) {
    if (durum[id].a < 4) return
    var rec = d.kayitlar[id]
    if (rec && rec.haciz) return
    var adet = claimSayisi(server, JUUID.fromString(id))
    if (!rec) {
      if (adet === 0) return
      rec = d.kayitlar[id] = yeniKayit(Date.now(), 0)
    }
    rec.hacizOnceAskida = !!rec.askida
    var n = askiyaAl(server, id, rec)
    rec.haciz = true
    rec.askida = (rec.snapshot || []).length > 0
    rec.grace = 0
    bildir(server, id, rec, 'BORÇ HACZİ: borcun ' + Math.floor(durum[id].g) + ' gündür ödenmediği için ' + n +
      ' chunk claim\'in askıya alındı. Borcunu kapatınca geri yüklenir: /borc ode')
  })
  // Borcu kapananların haczini kaldır
  Object.keys(d.kayitlar).forEach(function (id) {
    var rec = d.kayitlar[id]
    if (!rec.haciz || (durum[id] && durum[id].a >= 4)) return
    rec.haciz = false
    if (!rec.hacizOnceAskida && rec.askida) {
      var s = geriYukle(server, id, rec)
      rec.son = Date.now()
      bildir(server, id, rec, 'Borcun kapandı, haciz kalktı: claim\'lerin geri yüklendi (' + s.ok + ' chunk, atlanan: ' + s.atlanan + ').')
    } else if (rec.askida) {
      bildir(server, id, rec, 'Borcun kapandı, haciz kalktı. Claim\'lerin vergi ödenmediği için hâlâ askıda: /vergi ode gun')
    }
    rec.hacizOnceAskida = false
  })
}
// 3. günden itibaren yeni claim yasağı: damga anındaki claim'ler (ve askıdakiler) izinli, gerisi geri alınır
function borcClaimKontrol(server) {
  var durum = borcDurumOku(server)
  var izinS = server.persistentData.getString('borc_claim_izin')
  var izin = {}
  if (izinS) { try { izin = JSON.parse(izinS) } catch (e) { izin = {} } }
  var degisti = false
  var vd = null
  Object.keys(izin).forEach(function (id) { if (!durum[id] || durum[id].a < 2) { delete izin[id]; degisti = true } })
  Object.keys(durum).forEach(function (id) {
    if (durum[id].a < 2) return
    var uuid = JUUID.fromString(id)
    var liste = claimOlcekle(server, uuid)
    if (!vd) vd = yukle(server)
    var rec = vd.kayitlar[id]
    if (!izin[id]) {
      var k = {}
      liste.forEach(function (c) { k[c.d + '|' + c.x + '|' + c.z] = 1 })
      if (rec && rec.snapshot) rec.snapshot.forEach(function (c) { k[c.d + '|' + c.x + '|' + c.z] = 1 })
      izin[id] = k
      degisti = true
      return
    }
    var haciz = rec && rec.haciz
    var m = claimYonetici(server)
    var geri = 0
    liste.forEach(function (c) {
      if (!haciz && izin[id][c.d + '|' + c.x + '|' + c.z]) return
      m.unclaim(ResLoc.parse(c.d), c.x, c.z)
      geri++
    })
    if (geri > 0) {
      var p = server.playerList.getPlayer(uuid)
      if (p != null) p.tell(Text.red(Text.ofString('Borcun kapanana kadar yeni arazi alamazsın: ' + geri + ' chunk claim geri alındı. (/borc)')))
    }
  })
  if (degisti) server.persistentData.putString('borc_claim_izin', JSON.stringify(izin))
}
ServerEvents.tick(function (event) {
  if (event.server.tickCount % 200 !== 100) return
  try { borcClaimKontrol(event.server) } catch (err) { console.error('[Vergi] borc claim hatasi: ' + err) }
})

// ----------------------------- ANA DÖNGÜ -----------------------------
function vergiIsle(server) {
  var d = yukle(server)
  var simdi = Date.now()
  var m = claimYonetici(server)
  var sahipler = {}
  hacizIsle(server, d)

  // Kota <-> OPAC sınırı (ve eski kayıtların kotaya geçişi)
  kotaHepsiniEsitle(server, d)

  var bilgiler = m.getPlayerInfoStream().toArray()
  for (var i = 0; i < bilgiler.length; i++) {
    var uuid = bilgiler[i].getPlayerId()
    if (uuid.equals(OzelSahipler.SERVER) || uuid.equals(OzelSahipler.EXPIRED)) continue
    var id = String(uuid)
    if (VERGI.MUAF_UUID.indexOf(id) >= 0) continue
    sahipler[id] = bilgiler[i].getClaimCount()
  }
  // Kira kiralanan haktan alınır: claim'i olmasa da bedava haktan fazlasını kiralamış olan da öder
  Object.keys(d.kayitlar).forEach(function (id) {
    if (sahipler[id] == null && kotaOku(d.kayitlar[id]) > VERGI.BEDAVA_CLAIM && VERGI.MUAF_UUID.indexOf(id) < 0) sahipler[id] = 0
  })

  var kat = katYukle(server)
  kategoriRenkleriniEsitle(server, kat)

  // 1) Kira ödeyen oyuncular (askıdakiler 2. adımda)
  Object.keys(sahipler).forEach(function (id) {
    var n = sahipler[id]
    var rec = d.kayitlar[id]
    if (rec && rec.askida) return
    var u = gunlukUcret(server, JUUID.fromString(id), n, kat, kotaOku(rec))
    if (u.g <= 0) { if (rec) { rec.g = 0; rec.dg = u.dg; rec.grace = 0; rec.son = simdi } return }   // sadece bedava hak
    if (!rec) {
      rec = d.kayitlar[id] = yeniKayit(simdi, u.g)
      rec.dg = u.dg
      bildir(server, id, rec, 'Arazi kirası başladı: kiraladığın her claim hakkı günlük ' + kira(server) +
        ' spur (ilk ' + VERGI.BEDAVA_CLAIM + ' hak bedava; dükkan/fabrika işaretlediğin chunk\'lar fiyat farkı öder). İlk gün ücretsiz. Detay: /vergi durum')
      return
    }
    var g = u.g
    rec.g = g
    rec.dg = u.dg
    krediHazirla(rec, g, simdi)
    krediTuket(rec, g, simdi)
    if (rec.kredi > 0) { rec.grace = 0; return }

    var ucret = g
    var ks = rec.auto !== false ? kiraKes(server, id, rec, ucret) : { ok: false }
    if (ks.ok) {
      rec.kredi += ucret
      rec.grace = 0
      bildir(server, id, rec, 'Arazi kirası ' + (ks.kim !== id ? 'sponsorundan (' + ad(server, JUUID.fromString(ks.kim)) + ')' : 'bankandan') +
        ' kesildi: ' + ucret + ' spur (' + rec.dg.k + ' hak, ' + n + ' chunk kullanılıyor).')
      return
    }
    if (!rec.grace) {
      rec.grace = simdi + VERGI.EK_SURE_SAAT * 3600 * 1000
      bildir(server, id, rec, 'Arazi kirası ÖDENEMEDİ (' + ucret + ' spur). ' + VERGI.EK_SURE_SAAT +
        ' saat içinde ödemezsen claim\'ların kapatılacak. Bankana para yatır, /vergi ode gun veya kotanı azalt: /arazi kota <sayı>')
      return
    }
    if (simdi >= rec.grace) {
      var adet = askiyaAl(server, id, rec)
      // Araçlar askıya alınmaz; ödenmeyen bir günlük araç vergisi borç sistemine yazılır
      var aracBorc = aracSlot(server, JUUID.fromString(id)) * aracFiyat(server)
      if (aracBorc > 0) {
        var bk = []
        try { var bs = server.persistentData.getString('borc_kuyruk'); if (bs) bk = JSON.parse(bs) } catch (e) { bk = [] }
        bk.push({ u: id, m: aracBorc, s: 'arac_vergisi' })
        server.persistentData.putString('borc_kuyruk', JSON.stringify(bk))
        bildir(server, id, rec, 'Ödenmeyen araç vergisi (' + aracBorc + ' spur) borcuna yazıldı.')
      }
      rec.grace = 0
      rec.kredi = 0   // arazi elinden alındı, birikmiş borç silinir
      bildir(server, id, rec, 'Vergi ödenmediği için ' + adet + ' chunk claim\'in askıya alındı. ' +
        'Ödeme yapınca geri yüklenir: /vergi ode gun')
    }
  })

  // 1b) Claim'i kalmayan oyuncular: menüdeki günlük ücret ve dağılım sıfırlanır
  //     (ön ödeme kredisi korunur; yeni claim alınca kullanılır)
  Object.keys(d.kayitlar).forEach(function (id) {
    var rec = d.kayitlar[id]
    if (sahipler[id] != null || rec.askida) return
    rec.g = 0
    rec.dg = { y: 0, d: 0, f: 0, a: 0 }
    rec.grace = 0
  })

  // 2) Askıdaki claim'ler: otomatik ödeme açıksa, para yetince geri yükle
  Object.keys(d.kayitlar).forEach(function (id) {
    var rec = d.kayitlar[id]
    if (!rec.askida || rec.haciz || rec.auto === false || (sahipler[id] || 0) > 0) return
    var ucret = snapshotUcret(server, id, rec, kat)
    if (ucret > 0 && kiraKes(server, id, rec, ucret).ok) {
      var s = geriYukle(server, id, rec)
      rec.kredi = Math.max(rec.kredi || 0, 0) + ucret
      rec.son = simdi
      rec.grace = 0
      bildir(server, id, rec, 'Vergi ödendi, claim\'ler geri yüklendi (' + s.ok + ' chunk, atlanan: ' + s.atlanan + ').')
    }
  })

  kaydet(server, d)
}

ServerEvents.tick(function (event) {
  if (event.server.tickCount % KONTROL_ARALIGI_TICK !== 0) return
  try { vergiIsle(event.server) } catch (err) { console.error('[Vergi] hata: ' + err) }
  try { satisVergileriniKaydet(event.server) } catch (err) { console.error('[Vergi] kdv/harc kaydi: ' + err) }
})

// KDV (%5, Selling Bin) ve harç (%1, Vendor/depozitör): sunucu_piyasa modu parayı hazineye
// kendisi yatırır, toplamları 'vergi_kayit'e yazar; burada hazine kayıtlarına işlenir.
function satisVergileriniKaydet(server) {
  var s = server.persistentData.getString('vergi_kayit')
  if (!s) return
  var v = {}
  try { v = JSON.parse(s) } catch (e) { v = {} }
  server.persistentData.putString('vergi_kayit', '{}')
  if (v.kdv > 0) hazineKayit(server, 'kdv', v.kdv, 'Selling Bin satışları')
  if (v.harc > 0) hazineKayit(server, 'harc', v.harc, 'Vendor/depozitör')
}

// Giriş yapınca bekleyen mesajları ilet
PlayerEvents.loggedIn(function (event) {
  var server = event.server
  var d = yukle(server)
  var rec = d.kayitlar[String(event.player.uuid)]
  if (!rec || !rec.bekleyen || rec.bekleyen.length === 0) return
  rec.bekleyen.forEach(function (msg) { event.player.tell(msg) })
  rec.bekleyen = []
  kaydet(server, d)
})

// ----------------------------- ÖLÜM VERGİSİ --------------------------
EntityEvents.death('minecraft:player', function (event) {
  var p = event.entity
  if (!p || !p.isPlayer()) return
  // Zindanda ölüm vergisi yok (sunucu_zindan modu ölümü zaten iptal eder; bu ek güvence)
  if (String(p.level.getDimension()) === 'sunucu_zindan:zindan') return
  // Oyuncuyu başka bir oyuncu öldürdüyse ölüm vergisini savas_sistemi.js ele alır
  var katil = event.source.getActual()
  if (katil != null && katil.isPlayer() && !katil.getUuid().equals(p.getUuid())) return
  var b = bakiye(p.uuid)
  var vergi = Math.floor(b * oranAl(event.server, 'olum') / 100)
  if (vergi < 1) return
  if (vergiKes(event.server, p.uuid, vergi, 'olum')) {
    p.tell('Ölüm vergisi: bankandan ' + vergi + ' spur kesildi (%' + oranAl(event.server, 'olum') + ').')
  }
})

// ----------------------------- KOMUTLAR ------------------------------
function ode(server, player, gun) {
  var d = yukle(server)
  var id = String(player.uuid)
  var simdi = Date.now()
  var aktif = claimSayisi(server, player.uuid)
  var kat = katYukle(server)
  var rec = d.kayitlar[id] || (d.kayitlar[id] = yeniKayit(simdi, 0))
  var u = gunlukUcret(server, player.uuid, aktif, kat, kotaOku(rec))
  if (rec.haciz) { player.tell('Arazilerin borç haczinde. Önce borcunu kapat (/borc ode); haciz kalkınca claim\'lerin geri gelir.'); return 0 }
  var n = aktif + (rec.askida ? (rec.snapshot || []).length : 0)
  var g = rec.askida ? snapshotUcret(server, id, rec, kat) : u.g
  if (g <= 0) { player.tell('Ödenecek kiran yok (sadece bedava claim hakkın var). Kota kiralamak için: /arazi kota <sayı>'); return 0 }
  rec.g = g
  rec.dg = u.dg
  krediHazirla(rec, g, simdi)
  var ucret = g * gun
  if (!vergiKes(server, player.uuid, ucret, 'arazi')) {
    player.tell('Bankanda yeterli para yok. Gerekli: ' + ucret + ' spur.')
    return 0
  }
  if (rec.askida) {
    var s = geriYukle(server, id, rec)
    player.tell('Claim\'ler geri yüklendi (' + s.ok + ' chunk, atlanan: ' + s.atlanan + ').')
    rec.kredi = Math.max(rec.kredi || 0, 0)
    rec.son = simdi
  }
  rec.kredi += ucret
  rec.grace = 0
  kaydet(server, d)
  player.tell(gun + ' günlük kira ödendi: ' + ucret + ' spur (' + kotaOku(rec) + ' hak, ' + n + ' chunk). Kalan süre: ' + kalanSure(rec, g) +
    '. Kota artırırsan süre kısalır.')
  return 1
}

ServerEvents.commandRegistry(function (event) {
  var Commands = event.commands

  event.register(Commands.literal('vergi')
    .then(Commands.literal('durum').executes(function (ctx) {
      var p = ctx.source.player
      var server = p.server
      var d = yukle(server)
      var rec = d.kayitlar[String(p.uuid)]
      var n = claimSayisi(server, p.uuid)
      var u = gunlukUcret(server, p.uuid, n, katYukle(server), kotaOku(rec))
      p.tell('Claim hakkı: ' + u.dg.k + ' (' + VERGI.BEDAVA_CLAIM + ' bedava) | Kullanılan: ' + n + ' chunk (yerleşke ' + u.dg.y + ', dükkan ' + u.dg.d + ', fabrika ' + u.dg.f + ') + araç slotu ' + (u.dg.a || 0) + ' | Günlük kira: ' + u.g + ' spur')
      if (rec && rec.sponsor) p.tell('Sponsor: ' + ad(server, JUUID.fromString(rec.sponsor)) + (rec.sponsorOnay ? ' (kiranı ödüyor)' : ' (teklif bekliyor: /arazi sponsor kabul)'))
      p.tell('Banka bakiyesi: ' + bakiye(p.uuid) + ' spur')
      if (rec) {
        var simdi = Date.now()
        krediHazirla(rec, u.g, simdi)
        p.tell('Ön ödeme: ' + Math.max(0, Math.floor(rec.kredi)) + ' spur | Bu ücretle kalan süre: ' + kalanSure(rec, u.g) +
          ' | Otomatik ödeme: ' + (rec.auto !== false ? 'açık' : 'kapalı'))
        if (rec.grace) p.tell('Ek süre bitimine: ' + kalan(rec.grace - simdi))
        if (rec.askida) p.tell('Askıdaki chunk: ' + (rec.snapshot || []).length + (rec.haciz ? ' (BORÇ HACZİ: borç kapanınca geri gelir)' : ' (ödeme yapınca geri gelir)'))
      }
      return 1
    }))
    .then(Commands.literal('ode')
      .then(Commands.literal('gun').executes(function (ctx) { var p = ctx.source.player; return ode(p.server, p, 1) }))
      .then(Commands.literal('hafta').executes(function (ctx) { var p = ctx.source.player; return ode(p.server, p, 7) }))
      .then(Commands.literal('ay').executes(function (ctx) { var p = ctx.source.player; return ode(p.server, p, 30) })))
    .then(Commands.literal('otomatik')
      .then(Commands.literal('ac').executes(function (ctx) {
        var p = ctx.source.player
        var d = yukle(p.server)
        var rec = d.kayitlar[String(p.uuid)] || (d.kayitlar[String(p.uuid)] = yeniKayit(Date.now(), claimSayisi(p.server, p.uuid)))
        rec.auto = true; kaydet(p.server, d)
        p.tell('Otomatik ödeme açıldı.'); return 1
      }))
      .then(Commands.literal('kapat').executes(function (ctx) {
        var p = ctx.source.player
        var d = yukle(p.server)
        var rec = d.kayitlar[String(p.uuid)] || (d.kayitlar[String(p.uuid)] = yeniKayit(Date.now(), claimSayisi(p.server, p.uuid)))
        rec.auto = false; kaydet(p.server, d)
        p.tell('Otomatik ödeme kapatıldı. Süre bitmeden /vergi ode ile kendin ödemelisin.'); return 1
      }))))

  event.register(Commands.literal('tescil').executes(function (ctx) {
    var p = ctx.source.player
    var tescilUcret = oranAl(p.server, 'tescil')
    if (tescilUcret > 0 && !vergiKes(p.server, p.uuid, tescilUcret, 'tescil')) {
      p.tell('Tescil için bankanda ' + tescilUcret + ' spur olmalı.')
      return 0
    }
    p.give(Item.of('minecraft:paper').withCustomName(Text.of('Tescil Belgesi - ' + p.username).gold()))
    p.tell('Tescil ücreti (' + tescilUcret + ' spur) kesildi, belgen verildi.')
    return 1
  }))

  var Arguments = event.arguments

  // --------------------------- /arazi ------------------------------------
  //   /arazi bilgi                               -> bulunduğun chunk: sahip, kategori, günlük fark
  //   /arazi kategori <yerleske|dukkan|fabrika>  -> SAHİP kendi chunk'ını işaretler (fark öder)
  //   /arazi kota [sayı]                         -> claim hakkını gör / toplam hakkı ayarla (kira)
  //   /arazi sponsor <oyuncu> | kabul | birak | iptal <oyuncu>  -> kira sponsorluğu
  //   /arazi duzelt <tur> [ceza]                 -> BAŞKAN/OP: yanlış kategoriyi düzeltir + ceza
  //   /arazi fiyat [dukkan|fabrika] [fiyat]       -> BAŞKAN/OP: kategori günlük fiyatı
  function bulunulanChunk(p) {
    var boyut = String(p.level.getDimension())
    var x = Math.floor(p.getX() / 16), z = Math.floor(p.getZ() / 16)
    var c = claimYonetici(p.server).get(ResLoc.parse(boyut), x, z)
    var sahip = c == null ? null : c.getPlayerId()
    if (sahip != null && (sahip.equals(OzelSahipler.SERVER) || sahip.equals(OzelSahipler.EXPIRED))) sahip = null
    return { d: boyut, x: x, z: z, sahip: sahip, anahtar: katAnahtar(boyut, x, z) }
  }
  function chunkKategori(kat, ch) {
    var e = kat[ch.anahtar]
    if (e && ch.sahip != null && e.o === String(ch.sahip)) return e
    return { k: 'yerleske' }
  }
  function turOku(ctx) {
    var t = String(Arguments.WORD.getResult(ctx, 'tur')).toLowerCase().replace('ü', 'u').replace('ş', 's').replace('ç', 'c')
    return (t === 'yerleske' || t === 'dukkan' || t === 'fabrika') ? t : null
  }
  // Kategoriyi yazar, haritayı boyar, sahibin günlük kirasını tazeler. Dönüş: sahibin yeni günlük kirası
  function kategoriYaz(server, ch, tur, kim) {
    var kat = katYukle(server)
    var sahipId = String(ch.sahip)
    if (tur === 'yerleske') delete kat[ch.anahtar]
    else kat[ch.anahtar] = { k: tur, f: katFiyat(server, tur), o: sahipId, b: kim, t: Date.now() }
    katKaydet(server, kat)
    try { claimRenklendir(server, ch.d, ch.x, ch.z, ch.sahip, tur) } catch (err) { console.warn('[Vergi] renk: ' + err) }
    var d = yukle(server)
    var rec = d.kayitlar[sahipId]
    var u = gunlukUcret(server, ch.sahip, claimSayisi(server, ch.sahip), kat, kotaOku(rec))
    if (rec) { rec.g = u.g; rec.dg = u.dg; kaydet(server, d) }
    return u.g
  }
  function fark(server, tur) { return tur === 'yerleske' ? 0 : Math.max(0, katFiyat(server, tur) - kira(server)) }
  function yetkiliMi(ctx) { var p = ctx.source.player; return ctx.source.hasPermission(2) || (p != null && baskanMi(p.server, p)) }

  event.register(Commands.literal('arazi')
    .then(Commands.literal('bilgi').executes(function (ctx) {
      var p = ctx.source.player
      if (p == null) return 0
      var ch = bulunulanChunk(p)
      if (ch.sahip == null) { p.tell('Chunk ' + ch.x + ', ' + ch.z + ': kimsenin değil.'); return 1 }
      var e = chunkKategori(katYukle(p.server), ch)
      p.tell('Chunk ' + ch.x + ', ' + ch.z + ' | Sahip: ' + ad(p.server, ch.sahip) + ' | ' + KAT_AD[e.k] +
        (e.k !== 'yerleske' ? ' | Günlük fark: +' + fark(p.server, e.k) + ' spur' : '') + (e.b ? ' | İşaretleyen: ' + e.b : ''))
      return 1
    }))
    // Sahip kendi chunk'ını işaretler
    .then(Commands.literal('kategori')
      .then(Commands.argument('tur', Arguments.WORD.create(event)).executes(function (ctx) {
        var p = ctx.source.player
        if (p == null) return 0
        var tur = turOku(ctx)
        if (!tur) { p.tell('Kategori: yerleske, dukkan veya fabrika.'); return 0 }
        var ch = bulunulanChunk(p)
        if (ch.sahip == null || !ch.sahip.equals(p.getUuid())) { p.tell('Sadece kendi claim\'ini işaretleyebilirsin (üstünde dur). Başkan düzeltmesi: /arazi duzelt'); return 0 }
        var g = kategoriYaz(p.server, ch, tur, String(p.username))
        p.tell('Chunk ' + ch.x + ', ' + ch.z + ': ' + KAT_AD[tur] + (tur !== 'yerleske' ? ' (günlük +' + fark(p.server, tur) + ' spur fark)' : '') +
          '. Günlük kiran: ' + g + ' spur. Yanlış işaretlenen arazilere başkan ceza yazabilir.')
        return 1
      })))
    // Kota (claim hakkı) kiralama
    .then(Commands.literal('kota')
      .executes(function (ctx) {
        var p = ctx.source.player
        if (p == null) return 0
        var rec = yukle(p.server).kayitlar[String(p.getUuid())]
        var n = claimSayisi(p.server, p.getUuid()), goc = aracGoc(p.server, p.getUuid())
        p.tell('Claim hakkın: ' + kotaOku(rec) + ' (' + VERGI.BEDAVA_CLAIM + ' bedava) | Kullanılan: ' + n + ' chunk + ' + goc + ' araç slotu | Hak başı ' +
          kira(p.server) + ' spur/gün. Değiştirmek: /arazi kota <toplam>')
        return 1
      })
      .then(Commands.argument('sayi', Arguments.INTEGER.create(event)).executes(function (ctx) {
        var p = ctx.source.player
        if (p == null) return 0
        var server = p.server
        var id = String(p.getUuid())
        // 0 (veya 1) = sadece bedava hak. Artırınca eklenen hakların 1 günlük kirası HEMEN kesilir.
        // Azaltınca hak elindeki claim'in altına inerse fazla claim'ler (sana en uzak olanlar) bırakılır;
        // bunun için 30 sn içinde komutun tekrarlanması (onay) gerekir.
        var yeni = Math.max(VERGI.BEDAVA_CLAIM, Arguments.INTEGER.getResult(ctx, 'sayi'))
        var n = claimSayisi(server, p.getUuid()), goc = aracGoc(server, p.getUuid())
        var simdi = Date.now()
        var d = yukle(server)
        var rec = d.kayitlar[id] || (d.kayitlar[id] = yeniKayit(simdi, 0))
        var eski = kotaOku(rec)
        if (rec.haciz || rec.askida) { p.tell('Arazilerin askıda/hacizde; önce kirayı veya borcu öde.'); return 0 }
        if (yeni > VERGI.KOTA_MAX) { p.tell('En fazla ' + VERGI.KOTA_MAX + ' hak kiralanabilir.'); return 0 }
        if (yeni < goc) { p.tell(goc + ' hakkın araçlarda (Aeronautics Claims). Önce araç slotlarını geri al, sonra hakkını ' + goc + '\'in altına indirebilirsin.'); return 0 }
        if (yeni === eski) { p.tell('Claim hakkın zaten ' + yeni + '.'); return 0 }
        var kat = katYukle(server)
        var birak = n + goc - yeni
        if (birak > 0) {
          var o = rec.kotaOnay
          if (!o || o.n !== yeni || simdi - o.t > 30000) {
            rec.kotaOnay = { n: yeni, t: simdi }
            kaydet(server, d)
            p.tell(Text.gold(Text.ofString('Hakkını ' + yeni + ' yaparsan ' + birak + ' chunk claim\'in BIRAKILACAK (sana en uzak olanlar). Onaylamak için 30 saniye içinde aynı işlemi tekrarla.')))
            return 1
          }
          delete rec.kotaOnay
          var px = Math.floor(p.getX() / 16), pz = Math.floor(p.getZ() / 16), pb = String(p.level.getDimension())
          var liste = claimOlcekle(server, p.getUuid())
          liste.forEach(function (c) { c.uz = c.d !== pb ? 1e12 : (c.x - px) * (c.x - px) + (c.z - pz) * (c.z - pz) })
          liste.sort(function (a, b) { return b.uz - a.uz })
          var m = claimYonetici(server)
          var gitti = 0
          for (var i = 0; i < liste.length && gitti < birak; i++) {
            m.unclaim(ResLoc.parse(liste[i].d), liste[i].x, liste[i].z)
            delete kat[katAnahtar(liste[i].d, liste[i].x, liste[i].z)]
            gitti++
          }
          katKaydet(server, kat)
          n = claimSayisi(server, p.getUuid())
          p.tell(Text.yellow(Text.ofString(gitti + ' chunk claim\'in bırakıldı.')))
        }
        var gEski = gunlukUcret(server, p.getUuid(), n, kat, eski).g
        var u = gunlukUcret(server, p.getUuid(), n, kat, yeni)
        var odenen = 0
        krediHazirla(rec, gEski, simdi)
        if (yeni > eski) {
          var bd = borcDurumOku(server)[id]
          if (bd && bd.a >= 2) { p.tell('Borcun varken yeni arazi hakkı kiralayamazsın (/borc).'); return 0 }
          odenen = Math.max(0, u.g - gEski)   // eklenen hakların 1 günlük kirası
          if (odenen > 0) {
            var ks = kiraKes(server, id, rec, odenen)
            if (!ks.ok) { p.tell(Text.red(Text.ofString('Kiralamak için bankanda ' + odenen + ' spur olmalı (eklenen ' + (yeni - eski) + ' hakkın 1 günlük kirası).'))); return 0 }
            rec.kredi = Math.max(0, rec.kredi || 0) + odenen
          }
        }
        rec.kota = yeni
        rec.g = u.g; rec.dg = u.dg
        rec.son = rec.son || simdi
        if (odenen > 0) rec.grace = 0
        kotaEsitle(server, id, rec)
        kaydet(server, d)
        p.tell(Text.green(Text.ofString('Claim hakkın ' + eski + ' → ' + yeni + (odenen > 0 ? '. Ödenen: ' + odenen + ' spur (1 gün)' : '') +
          '. Günlük kiran: ' + u.g + ' spur' + (u.g > 0 ? ' (ön ödeme bitince bankadan kesilir).' : '.'))))
        return 1
      })))
    // Kira sponsorluğu: biri başkasının kirasını (onun onayıyla) öder
    .then(Commands.literal('sponsor')
      .then(Commands.literal('kabul').executes(function (ctx) {
        var p = ctx.source.player
        if (p == null) return 0
        var d = yukle(p.server)
        var rec = d.kayitlar[String(p.getUuid())]
        if (!rec || !rec.sponsor) { p.tell('Bekleyen sponsorluk teklifi yok.'); return 0 }
        rec.sponsorOnay = true
        kaydet(p.server, d)
        p.tell('Artık arazi kiranı ' + ad(p.server, JUUID.fromString(rec.sponsor)) + ' ödüyor. Bırakmak: /arazi sponsor birak')
        var s = p.server.playerList.getPlayer(JUUID.fromString(rec.sponsor))
        if (s != null) s.tell(String(p.username) + ' sponsorluğunu kabul etti; kirası bankandan kesilecek.')
        return 1
      }))
      .then(Commands.literal('birak').executes(function (ctx) {
        var p = ctx.source.player
        if (p == null) return 0
        var d = yukle(p.server)
        var rec = d.kayitlar[String(p.getUuid())]
        if (!rec || !rec.sponsor) { p.tell('Sponsorun yok.'); return 0 }
        delete rec.sponsor; delete rec.sponsorOnay
        kaydet(p.server, d)
        p.tell('Sponsorluk bitti; kiran yine kendi bankandan kesilir.')
        return 1
      }))
      .then(Commands.literal('iptal')
        .then(Commands.argument('oyuncu', Arguments.PLAYER.create(event)).executes(function (ctx) {
          var p = ctx.source.player
          if (p == null) return 0
          var h = Arguments.PLAYER.getResult(ctx, 'oyuncu')
          var d = yukle(p.server)
          var rec = d.kayitlar[String(h.getUuid())]
          if (!rec || rec.sponsor !== String(p.getUuid())) { p.tell(String(h.username) + ' oyuncusunun sponsoru değilsin.'); return 0 }
          delete rec.sponsor; delete rec.sponsorOnay
          kaydet(p.server, d)
          p.tell(String(h.username) + ' oyuncusunun kirasını artık ödemiyorsun.')
          h.tell(String(p.username) + ' kira sponsorluğunu bitirdi; kiran kendi bankandan kesilecek.')
          return 1
        })))
      .then(Commands.argument('oyuncu', Arguments.PLAYER.create(event)).executes(function (ctx) {
        var p = ctx.source.player
        if (p == null) return 0
        var h = Arguments.PLAYER.getResult(ctx, 'oyuncu')
        if (h.getUuid().equals(p.getUuid())) { p.tell('Kendine sponsor olamazsın.'); return 0 }
        var d = yukle(p.server)
        var hid = String(h.getUuid())
        var rec = d.kayitlar[hid] || (d.kayitlar[hid] = yeniKayit(Date.now(), 0))
        rec.sponsor = String(p.getUuid())
        rec.sponsorOnay = false
        kaydet(p.server, d)
        p.tell(String(h.username) + ' oyuncusuna kira sponsorluğu teklif ettin; kabul ederse kirası senin bankandan kesilir.')
        h.tell(String(p.username) + ' arazi kiranı ödemeyi teklif ediyor. Kabul: /arazi sponsor kabul')
        return 1
      })))
    // Başkan/OP: yanlış kategoriyi düzelt + ceza
    .then(Commands.literal('duzelt')
      .then(Commands.argument('tur', Arguments.WORD.create(event))
        .executes(function (ctx) { return duzelt(ctx, 0) })
        .then(Commands.argument('ceza', Arguments.INTEGER.create(event))
          .executes(function (ctx) { return duzelt(ctx, Arguments.INTEGER.getResult(ctx, 'ceza')) }))))
    // Başkan/OP: kategori fiyatları
    .then(Commands.literal('fiyat')
      .executes(function (ctx) {
        var s = ctx.source.server
        ctx.source.sendSystemMessage(Text.ofString('Hak başı ' + kira(s) + ' · dükkan ' + katFiyat(s, 'dukkan') + ' (fark +' + fark(s, 'dukkan') +
          ') · fabrika ' + katFiyat(s, 'fabrika') + ' (fark +' + fark(s, 'fabrika') + ') spur/gün'))
        return 1
      })
      .then(Commands.argument('tur', Arguments.WORD.create(event))
        .then(Commands.argument('fiyat', Arguments.INTEGER.create(event)).executes(function (ctx) {
          if (!yetkiliMi(ctx)) { ctx.source.sendSystemMessage(Text.ofString('Fiyatları sadece başkan belirleyebilir.')); return 0 }
          var tur = turOku(ctx)
          if (tur !== 'dukkan' && tur !== 'fabrika') { ctx.source.sendSystemMessage(Text.ofString('Tür: dukkan veya fabrika.')); return 0 }
          var f = Arguments.INTEGER.getResult(ctx, 'fiyat')
          if (f < kira(ctx.source.server) || f > VERGI.FIYAT_MAX) { ctx.source.sendSystemMessage(Text.ofString('Fiyat ' + kira(ctx.source.server) + ' ile ' + VERGI.FIYAT_MAX + ' arasında olmalı.')); return 0 }
          ctx.source.server.persistentData.putInt('arazi_fiyat_' + tur, f)
          ctx.source.sendSystemMessage(Text.ofString(KAT_AD[tur] + ' fiyatı: ' + f + ' spur/gün (fark +' + (f - kira(ctx.source.server)) + '). Bir dakika içinde herkese uygulanır.'))
          return 1
        })))))

  function duzelt(ctx, ceza) {
    var p = ctx.source.player
    if (p == null) return 0
    var server = p.server
    if (!yetkiliMi(ctx)) { p.tell('Kategori düzeltmeyi sadece başkan yapabilir.'); return 0 }
    var tur = turOku(ctx)
    if (!tur) { p.tell('Kategori: yerleske, dukkan veya fabrika.'); return 0 }
    if (ceza < 0 || ceza > VERGI.FIYAT_MAX * 10) { p.tell('Ceza 0 ile ' + (VERGI.FIYAT_MAX * 10) + ' arasında olmalı.'); return 0 }
    var ch = bulunulanChunk(p)
    if (ch.sahip == null) { p.tell('Bu chunk kimsenin değil.'); return 0 }
    var eski = chunkKategori(katYukle(server), ch).k
    var g = kategoriYaz(server, ch, tur, 'Başkan ' + p.username)
    var sid = String(ch.sahip)
    var mesaj = 'Başkan ' + p.username + ', chunk ' + ch.x + ', ' + ch.z + ' kategorisini ' + KAT_AD[eski] + ' → ' + KAT_AD[tur] + ' düzeltti. Yeni günlük kiran: ' + g + ' spur.'
    if (ceza > 0) {
      if (vergiKes(server, ch.sahip, ceza, 'arazi_ceza')) mesaj += ' Yanlış beyan cezası: ' + ceza + ' spur bankandan kesildi.'
      else {
        var bk = []
        try { var bs = server.persistentData.getString('borc_kuyruk'); if (bs) bk = JSON.parse(bs) } catch (e) { bk = [] }
        bk.push({ u: sid, m: ceza, s: 'arazi_cezasi' })
        server.persistentData.putString('borc_kuyruk', JSON.stringify(bk))
        mesaj += ' Yanlış beyan cezası (' + ceza + ' spur) bankan yetmediği için borcuna yazıldı.'
      }
    }
    var d = yukle(server)
    var rec = d.kayitlar[sid] || (d.kayitlar[sid] = yeniKayit(Date.now(), 0))
    bildir(server, sid, rec, mesaj)
    kaydet(server, d)
    p.tell('Chunk ' + ch.x + ', ' + ch.z + ' (' + ad(server, ch.sahip) + '): ' + KAT_AD[tur] + (ceza > 0 ? ', ceza ' + ceza + ' spur' : '') + '.')
    return 1
  }

  // /devlet_kayit <tur> <miktar> <kim>  -> başka modların (ör. sunucu_zindan giriş ücreti) hazineye
  // yatırdığı parayı hareket listesine ve gelir toplamına yazar. Parayı kendisi aktarmaz. Sadece OP/sunucu.
  event.register(Commands.literal('devlet_kayit').requires(function (s) { return s.hasPermission(2) })
    .then(Commands.argument('tur', Arguments.WORD.create(event))
      .then(Commands.argument('miktar', Arguments.INTEGER.create(event))
        .then(Commands.argument('kim', Arguments.GREEDY_STRING.create(event)).executes(function (ctx) {
          var server = ctx.source.server
          var tur = String(Arguments.WORD.getResult(ctx, 'tur'))
          var m = Arguments.INTEGER.getResult(ctx, 'miktar')
          var d = hazineVeri(server)
          if (d.gelir[tur] == null) d.gelir[tur] = 0
          server.persistentData.putString('hazine_veri', JSON.stringify(d))
          hazineKayit(server, tur, m, String(Arguments.GREEDY_STRING.getResult(ctx, 'kim')))
          return 1
        })))))

  // /vergi oran              -> tüm vergi oranları (herkes görür)
  // /vergi oran <ad> <değer> -> BAŞKAN/OP değiştirir; herkese duyurulur
  event.register(Commands.literal('vergi')
    .then(Commands.literal('oran')
      .executes(function (ctx) {
        var s = ctx.source.server
        var b = s.persistentData.getString('baskan')
        ctx.source.sendSystemMessage(Text.gold(Text.ofString('=== Vergi oranları' + (b ? ' (Başkan: ' + ad(s, JUUID.fromString(b)) + ')' : '') + ' ===')))
        Object.keys(ORANLAR).forEach(function (k) {
          ctx.source.sendSystemMessage(Text.ofString(' ' + k + ' — ' + ORANLAR[k].ad + ': ' + oranMetin(s, k)))
        })
        ctx.source.sendSystemMessage(Text.gray(Text.ofString('Başkan değiştirir: /vergi oran <ad> <değer> (yüzdeler tam sayı: 5 = %5)')))
        return 1
      })
      .then(Commands.argument('ad', Arguments.WORD.create(event))
        .then(Commands.argument('deger', Arguments.INTEGER.create(event)).executes(function (ctx) {
          var s = ctx.source.server
          if (!yetkiliMi(ctx)) { ctx.source.sendSystemMessage(Text.red(Text.ofString('Vergi oranlarını sadece başkan değiştirebilir.'))); return 0 }
          var k = String(Arguments.WORD.getResult(ctx, 'ad')).toLowerCase().replace('ç', 'c').replace('ü', 'u').replace('ö', 'o').replace('ı', 'i').replace('ş', 's')
          if (k === 'yerleske' || k === 'claim') k = 'kira'
          var o = ORANLAR[k]
          if (!o) { ctx.source.sendSystemMessage(Text.red(Text.ofString('Bilinmeyen vergi. Seçenekler: ' + Object.keys(ORANLAR).join(', ')))); return 0 }
          var v = Arguments.INTEGER.getResult(ctx, 'deger')
          if (v < 0 || v > o.max) { ctx.source.sendSystemMessage(Text.red(Text.ofString(o.ad + ' 0 ile ' + o.max + ' arasında olmalı.'))); return 0 }
          var eski = oranMetin(s, k)
          oranYaz(s, k, v)
          var kim = ctx.source.player != null ? 'Başkan ' + ctx.source.player.username : 'Yönetim'
          s.tell(Text.gold(Text.ofString('[Devlet] ' + kim + ': ' + o.ad + ' ' + eski + ' → ' + oranMetin(s, k) + ' (bir dakika içinde uygulanır)')))
          return 1
        })))))

  // /arazi aracfiyat <fiyat>  -> araç vergisi (aero claim başına günlük), sadece başkan veya OP
  event.register(Commands.literal('arazi')
    .then(Commands.literal('aracfiyat')
      .executes(function (ctx) {
        ctx.source.sendSystemMessage(Text.ofString('Araç vergisi: aero claim (250 blok) başına günde ' + aracFiyat(ctx.source.server) + ' spur.'))
        return 1
      })
      .then(Commands.argument('fiyat', Arguments.INTEGER.create(event)).executes(function (ctx) {
        var p = ctx.source.player
        var server = ctx.source.server
        if (!(p != null && baskanMi(server, p)) && !ctx.source.hasPermission(2)) { ctx.source.sendSystemMessage(Text.ofString('Araç vergisini sadece başkan belirleyebilir.')); return 0 }
        var fiyat = Arguments.INTEGER.getResult(ctx, 'fiyat')
        if (fiyat < 1 || fiyat > VERGI.FIYAT_MAX) { ctx.source.sendSystemMessage(Text.ofString('Fiyat 1 ile ' + VERGI.FIYAT_MAX + ' arasında olmalı.')); return 0 }
        server.persistentData.putInt('arac_fiyat', fiyat)
        ctx.source.sendSystemMessage(Text.ofString('Araç vergisi: aero claim başına günde ' + fiyat + ' spur. (Bir dakika içinde herkese uygulanır.)'))
        return 1
      }))))

  // --------------------------- /devlet (OP + başkan) --------------------
  // Hazineyi başkan yönetir (durum/aktar/cek/yatir/ac/kart). Başkan atama ve hazine yetkisi sadece OP.
  var opMu = function (src) { return src.hasPermission(2) }
  var yetkili = function (src) { return src.hasPermission(2) || (src.player != null && baskanMi(src.server, src.player)) }
  var miktarAl = function (ctx) { return Arguments.INTEGER.getResult(ctx, 'miktar') }
  var yaz = function (ctx, msg) { ctx.source.sendSystemMessage(Text.ofString(msg)) }

  // Hazineden bir hesaba para aktarır
  function hazinedenAktar(ctx, hedefUuid, miktar, tur) {
    if (miktar <= 0) { yaz(ctx, 'Miktar 0\'dan büyük olmalı.'); return 0 }
    var h = hazine()
    if (h.getBalance() < miktar) { yaz(ctx, 'Hazinede yeterli para yok. Bakiye: ' + h.getBalance() + ' spur.'); return 0 }
    var hedef = Numismatics.BANK.getOrCreateAccount(hedefUuid, BankType.PLAYER)
    if (!h.deduct(miktar, ReasonHolder.IGNORED)) { yaz(ctx, 'Aktarım yapılamadı.'); return 0 }
    h.markDirty()
    hedef.deposit(miktar)
    hedef.markDirty()
    hazineKayit(ctx.source.server, tur, miktar, ad(ctx.source.server, hedefUuid))
    return 1
  }

  event.register(Commands.literal('devlet').requires(yetkili)
    .then(Commands.literal('durum').executes(function (ctx) {
      var h = hazine()
      var d = hazineVeri(ctx.source.server)
      var simdi = Date.now()
      yaz(ctx, '=== Devlet Hazinesi: ' + h.getBalance() + ' spur ===')
      yaz(ctx, 'Toplam gelir - arazi: ' + (d.gelir.arazi || 0) + ' | ölüm: ' + (d.gelir.olum || 0) + ' | tescil: ' + (d.gelir.tescil || 0) +
        ' | cinayet: ' + (d.gelir.cinayet || 0) + ' | savaş ilanı: ' + (d.gelir.savas || 0))
      var son = d.hareket.slice(-10).reverse()
      if (son.length === 0) yaz(ctx, 'Henüz hareket yok.')
      son.forEach(function (x) {
        var yon = (x.tur === 'aktarim' || x.tur === 'cekim' || x.tur === 'kredi') ? '-' : '+'
        yaz(ctx, yon + x.m + ' spur  ' + (TUR_AD[x.tur] || x.tur) + '  ' + x.k + '  (' + kalan(simdi - x.t) + ' önce)')
      })
      return 1
    }))
    .then(Commands.literal('aktar')
      .then(Commands.argument('oyuncu', Arguments.PLAYER.create(event))
        .then(Commands.argument('miktar', Arguments.INTEGER.create(event)).executes(function (ctx) {
          var hedef = Arguments.PLAYER.getResult(ctx, 'oyuncu')
          var miktar = miktarAl(ctx)
          if (!hazinedenAktar(ctx, hedef.getUuid(), miktar, 'aktarim')) return 0
          yaz(ctx, hedef.getName().getString() + ' oyuncusunun bankasına ' + miktar + ' spur aktarıldı. Hazine: ' + hazine().getBalance())
          hedef.tell('Devlet hazinesinden bankana ' + miktar + ' spur yatırıldı.')
          return 1
        }))))
    .then(Commands.literal('cek')
      .then(Commands.argument('miktar', Arguments.INTEGER.create(event)).executes(function (ctx) {
        var p = ctx.source.player
        if (p == null) { yaz(ctx, 'Bu komutu oyun içinden kullanın.'); return 0 }
        var miktar = miktarAl(ctx)
        if (!hazinedenAktar(ctx, p.uuid, miktar, 'cekim')) return 0
        yaz(ctx, 'Hazineden kendi bankana ' + miktar + ' spur çekildi. Hazine: ' + hazine().getBalance())
        return 1
      })))
    .then(Commands.literal('yatir')
      .then(Commands.argument('miktar', Arguments.INTEGER.create(event)).executes(function (ctx) {
        var p = ctx.source.player
        if (p == null) { yaz(ctx, 'Bu komutu oyun içinden kullanın.'); return 0 }
        var miktar = miktarAl(ctx)
        if (miktar <= 0) { yaz(ctx, 'Miktar 0\'dan büyük olmalı.'); return 0 }
        if (!kes(p.uuid, miktar)) { yaz(ctx, 'Bankanda yeterli para yok.'); return 0 }
        var h = hazine(); h.deposit(miktar); h.markDirty()
        hazineKayit(ctx.source.server, 'yatirma', miktar, p.username)
        yaz(ctx, 'Hazineye ' + miktar + ' spur yatırıldı. Hazine: ' + h.getBalance())
        return 1
      })))
    .then(Commands.literal('ac').executes(function (ctx) {
      var p = ctx.source.player
      if (p == null) { yaz(ctx, 'Bu komutu oyun içinden kullanın.'); return 0 }
      var h = hazine()
      NumUtils.openScreen(p, h, function (buf) { h.sendToMenu(buf) })
      return 1
    }))
    .then(Commands.literal('kart').executes(function (ctx) {
      var p = ctx.source.player
      if (p == null) { yaz(ctx, 'Bu komutu oyun içinden kullanın.'); return 0 }
      var h = hazine()
      var u = p.getUuid()
      h.updateTrustList(function (liste) { if (!liste.contains(u)) liste.add(u) })
      var kart = CardItem.set(Item.of('numismatics:yellow_card'), HAZINE_UUID)
      p.give(kart.withCustomName(Text.ofString('Devlet Hazinesi Kartı').gold()))
      yaz(ctx, 'Hazine kartı verildi. Bank Terminal\'e kartla sağ tıklayınca hazine açılır. Kartı shift+sağ tıklama ile kullanma, bağlantısı silinir.')
      return 1
    }))
    .then(Commands.literal('baskan').requires(opMu)
      .executes(function (ctx) {
        var b = ctx.source.server.persistentData.getString('baskan')
        yaz(ctx, b ? 'Başkan: ' + ad(ctx.source.server, JUUID.fromString(b)) : 'Başkan atanmamış. /devlet baskan <oyuncu>')
        return 1
      })
      .then(Commands.literal('kaldir').executes(function (ctx) {
        var s = ctx.source.server
        var eski = s.persistentData.getString('baskan')
        s.persistentData.remove('baskan')
        baskanDegisti(s, eski)
        yaz(ctx, 'Başkan kaldırıldı.')
        if (eski) s.tell(Text.gold(Text.ofString('[Devlet] ' + ad(s, JUUID.fromString(eski)) + ' artık başkan değil.')))
        return 1
      }))
      .then(Commands.argument('oyuncu', Arguments.PLAYER.create(event)).executes(function (ctx) {
        var s = ctx.source.server
        var hedef = Arguments.PLAYER.getResult(ctx, 'oyuncu')
        var eski = s.persistentData.getString('baskan')
        s.persistentData.putString('baskan', String(hedef.getUuid()))
        baskanDegisti(s, eski)
        yaz(ctx, hedef.getName().getString() + ' artık başkan.')
        s.tell(Text.gold(Text.ofString('[Devlet] Yeni başkan: ' + hedef.getName().getString() + '!')))
        hedef.tell(Text.gold(Text.ofString('Başkan oldun. Yetkilerin: vergi oranları (/vergi oran), hazine (/devlet durum|aktar|cek|yatir|kart), ' +
          'arazi teftişi ve cezalar (menü > Teftiş, /arazi duzelt), savaş onayı.')))
        return 1
      })))
    .then(Commands.literal('yetki').requires(opMu)
      .then(Commands.literal('ekle').then(Commands.argument('oyuncu', Arguments.PLAYER.create(event)).executes(function (ctx) {
        var hedef = Arguments.PLAYER.getResult(ctx, 'oyuncu')
        var u = hedef.getUuid()
        hazine().updateTrustList(function (liste) { if (!liste.contains(u)) liste.add(u) })
        yaz(ctx, hedef.getName().getString() + ' artık hazine kartını Bank Terminal\'de kullanabilir.')
        return 1
      })))
      .then(Commands.literal('kaldir').then(Commands.argument('oyuncu', Arguments.PLAYER.create(event)).executes(function (ctx) {
        var hedef = Arguments.PLAYER.getResult(ctx, 'oyuncu')
        var u = hedef.getUuid()
        hazine().updateTrustList(function (liste) { liste.remove(u) })
        yaz(ctx, hedef.getName().getString() + ' hazine yetkisi kaldırıldı.')
        return 1
      })))))
})

console.info('[Vergi] yuklendi: yerleske ' + VERGI.YERLESKE + ', dukkan ' + VERGI.DUKKAN_VARSAYILAN + ', fabrika ' + VERGI.FABRIKA_VARSAYILAN + ', arac ' + VERGI.ARAC_VARSAYILAN +
  ' spur/chunk/gun, olum vergisi %' + (VERGI.OLUM_VERGISI_ORAN * 100))
