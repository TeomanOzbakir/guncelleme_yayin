// =====================================================================
//  SINIF SİLAH KISITLARI  -  kubejs/server_scripts/sinif_silah.js
//  2026-11-25 (kullanıcı onayladı): her sınıf sadece kendi silah türlerini kullanır ("okçu greatsword / AK47 kullanmasın").
//   Savaşçı     : kılıç, balta, greatsword, çekiç, gürz, halberd, glaive, mızrak, kalkan
//   Avcı        : yay, arbalet, longbow, hançer, fırlatma bıçağı, javelin, bumerang
//   Nişancı     : tüm TaCZ silahları + hançer
//   Büyücü / Elementalist : Iron's asa ve büyüleri, hançer, quarterstaff
//   Terbiyeci   : mızrak, pike, lance, yay (+ büyü: Necromancer dalı Iron's büyüsü kullanır)
//   Sınıfsız    : vanilla kılıç / yay / arbalet / kalkan + TaCZ tabancaları
//   Herkes      : TaCZ tabancaları (2026-11-26, kullanıcı: 'herkesin kullanabilmesi lazım'), aletler (kazma, kürek, balta, çapa, mutfak bıçağı) ve silah olmayan her şey
//  Engellenen: yakın dövüş vuruşu, yay/arbalet/kalkan/fırlatma kullanımı, TaCZ ateşi, Iron's büyüsü.
//  Sınıf: oyuncu etiketi yt_sinif_<ad> (yetenek_sistemi.js 5 sn'de bir eşitler).
//  !! Gerçek bir oyunda ÇALIŞTIRILARAK TEST EDİLMEDİ.
// =====================================================================
;(function () {
  var ServerPlayer = Java.loadClass('net.minecraft.server.level.ServerPlayer')
  var DataComponents = Java.loadClass('net.minecraft.core.component.DataComponents')
  var SINIFLAR = ['savasci', 'avci', 'nisanci', 'buyucu', 'elementalist', 'terbiyeci']
  var SINIF_AD = { savasci: 'Savaşçı', avci: 'Avcı', nisanci: 'Nişancı', buyucu: 'Büyücü', elementalist: 'Elementalist', terbiyeci: 'Terbiyeci', yok: 'Sınıfsız' }
  var IZIN = {
    savasci: { kilic: 1, kilic_temel: 1, agir: 1, mizrak: 1, kalkan: 1, kalkan_temel: 1, tabanca: 1 },
    avci: { yay: 1, yay_temel: 1, hancer: 1, firlatma: 1, tabanca: 1 },
    nisanci: { silah: 1, tabanca: 1, hancer: 1 },
    buyucu: { buyu: 1, hancer: 1, tabanca: 1 },
    elementalist: { buyu: 1, hancer: 1, tabanca: 1 },
    terbiyeci: { mizrak: 1, yay: 1, yay_temel: 1, buyu: 1, tabanca: 1 },
    yok: { kilic_temel: 1, yay_temel: 1, kalkan_temel: 1, tabanca: 1 }
  }
  var TUR_AD = { kilic: 'kılıç', kilic_temel: 'kılıç', agir: 'ağır yakın dövüş silahı', mizrak: 'mızrak', kalkan: 'kalkan', kalkan_temel: 'kalkan',
    yay: 'yay/arbalet', yay_temel: 'yay/arbalet', hancer: 'hançer', firlatma: 'fırlatma silahı', silah: 'ateşli silah', tabanca: 'tabanca', buyu: 'büyü eşyası' }
  var KIMIN = {}   // tür -> izinli sınıflar (mesaj için)
  Object.keys(IZIN).forEach(function (s) { Object.keys(IZIN[s]).forEach(function (t) { (KIMIN[t] = KIMIN[t] || []).push(SINIF_AD[s]) }) })
  var TABANCA = {}
  'b93r,cz75,deagle,deagle_golden,glock_17,hk_mk23,lonetrail,m1911,m9a4,p320,rhino357,taurus500,taurus943,tec_9,timeless50'.split(',').forEach(function (g) { TABANCA['tacz:' + g] = 1 })
  var MUTFAK = { farmersdelight: 1, kaleidoscope_cookery: 1, culturaldelights: 1, handson_delight: 1, youkaisfeasts: 1, starcatcher: 1, starcatcher_delight: 1 }
  var ARAC_DISI = /(smithing_hammer|oil_hammer|pumpjack_hammer|wrench|gadget)/

  var onbellek = {}
  function tur(st) {
    if (st == null || st.isEmpty()) return null
    var id = String(st.id)
    if (id === 'tacz:modern_kinetic_gun') {
      var gid = ''
      try { var cd = st.get(DataComponents.CUSTOM_DATA); gid = cd == null ? '' : String(cd.copyTag().getString('GunId')) } catch (e) { gid = '' }
      return TABANCA[gid] ? 'tabanca' : 'silah'
    }
    if (onbellek[id] !== undefined) return onbellek[id]
    var ns = id.split(':')[0], y = id.split(':')[1] || ''
    var t = null
    if (MUTFAK[ns] || ARAC_DISI.test(y) || /(pickaxe|shovel|hoe|paxel|_axe$|^axe$|sickle)/.test(y) && !/battle_?axe|great_?axe|war_?axe|double_axe/.test(y)) t = null
    else if (/shield/.test(y)) t = id === 'minecraft:shield' ? 'kalkan_temel' : 'kalkan'
    else if (/(heavy_crossbow|longbow|crossbow|(^|_)bow$)/.test(y)) t = ns === 'minecraft' ? 'yay_temel' : 'yay'
    else if (/(javelin|boomerang|tomahawk|throwing_knife)/.test(y)) t = 'firlatma'
    else if (/(dagger|knife|athame|fang|stiletto)/.test(y)) t = 'hancer'
    else if (/(quarterstaff|staff|wand|sceptre|spell_book|spellbook)/.test(y) || (ns === 'irons_spellbooks' && /(staff|book|wand)/.test(y))) t = 'buyu'
    else if (/(spear|pike|lance|trident|halberd|glaive)/.test(y)) t = /(halberd|glaive)/.test(y) ? 'agir' : 'mizrak'
    else if (/(great_?sword|claymore|war_?hammer|battle_?hammer|hammer|mace|battleaxe|battle_axe|great_?axe|maul|flail|club|scythe)/.test(y)) t = 'agir'
    else if (/(sword|katana|saber|sabre|cutlass|rapier|longsword|blade|scimitar)/.test(y)) t = (ns === 'minecraft' && /_sword$/.test(y)) ? 'kilic_temel' : 'kilic'
    onbellek[id] = t
    return t
  }
  function sinifi(p) {
    var it = p.getTags().iterator()
    while (it.hasNext()) { var t = String(it.next()); if (t.indexOf('yt_sinif_') === 0) { var s = t.substring(9); if (IZIN[s]) return s } }
    return 'yok'
  }
  function izinli(p, st) {
    var t = tur(st)
    if (t == null) return true
    if (p.isCreative()) return true
    return IZIN[sinifi(p)][t] === 1
  }
  var sonUyari = {}
  function uyar(p, st) {
    var id = String(p.getUuid()), simdi = Date.now()
    if (sonUyari[id] && simdi - sonUyari[id] < 1500) return
    sonUyari[id] = simdi
    var t = tur(st)
    p.setStatusMessage(Text.red(Text.ofString(SINIF_AD[sinifi(p)] + ' bu ' + (TUR_AD[t] || 'silahı') + ' kullanamaz. Kullanabilen: ' + (KIMIN[t] || []).join(', '))))
  }

  // Yakın dövüş vuruşu
  NativeEvents.onEvent('net.neoforged.neoforge.event.entity.player.AttackEntityEvent', function (event) {
    try {
      var p = event.entity
      if (!(p instanceof ServerPlayer)) return
      var st = p.getMainHandItem()
      if (izinli(p, st)) return
      event.setCanceled(true)
      uyar(p, st)
    } catch (err) { console.error('[SinifSilah] vurus: ' + err) }
  })
  // Yay / arbalet / kalkan / mızrak fırlatma / asa: kullanmaya başlama
  NativeEvents.onEvent('net.neoforged.neoforge.event.entity.living.LivingEntityUseItemEvent$Start', function (event) {
    try {
      var p = event.entity
      if (!(p instanceof ServerPlayer)) return
      var st = event.getItem()
      if (izinli(p, st)) return
      event.setCanceled(true)
      uyar(p, st)
    } catch (err) { console.error('[SinifSilah] kullanim: ' + err) }
  })
  // Sağ tıkla fırlatılanlar (javelin, bumerang, fırlatma bıçağı)
  NativeEvents.onEvent('net.neoforged.neoforge.event.entity.player.PlayerInteractEvent$RightClickItem', function (event) {
    try {
      var p = event.entity
      if (!(p instanceof ServerPlayer)) return
      var st = event.getItemStack()
      var t = tur(st)
      if (t !== 'firlatma' && t !== 'buyu') return
      if (izinli(p, st)) return
      event.setCanceled(true)
      uyar(p, st)
    } catch (err) { console.error('[SinifSilah] firlatma: ' + err) }
  })
  // TaCZ ateş
  NativeEvents.onEvent('com.tacz.guns.api.event.common.GunShootEvent', function (event) {
    try {
      if (!event.getLogicalSide().isServer()) return
      var p = event.getShooter()
      if (!(p instanceof ServerPlayer)) return
      var st = event.getGunItemStack()
      if (izinli(p, st)) return
      event.setCanceled(true)
      uyar(p, st)
    } catch (err) { console.error('[SinifSilah] silah: ' + err) }
  })
  // Iron's Spellbooks büyüsü: Büyücü, Elementalist, Terbiyeci (Necromancer)
  NativeEvents.onEvent('io.redspace.ironsspellbooks.api.events.SpellPreCastEvent', function (event) {
    try {
      var p = event.entity
      if (!(p instanceof ServerPlayer) || p.isCreative()) return
      if (IZIN[sinifi(p)].buyu === 1) return
      event.setCanceled(true)
      var id = String(p.getUuid())
      if (!sonUyari[id] || Date.now() - sonUyari[id] > 1500) { sonUyari[id] = Date.now(); p.setStatusMessage(Text.red(Text.ofString('Büyü yapmak için Büyücü, Elementalist veya Terbiyeci (Necromancer) olmalısın.'))) }
    } catch (err) { console.error('[SinifSilah] buyu: ' + err) }
  })

  console.info('[SinifSilah] sinif silah kisitlari hazir')
})()
