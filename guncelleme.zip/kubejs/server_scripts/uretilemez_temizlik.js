// =====================================================================
//  ÜRETİLEMEYEN EŞYALAR  -  kubejs/server_scripts/uretilemez_temizlik.js
//  2026-11-25 (kullanıcı, "üretilemediği gözüküyor ... değeri olan bir eşya yoksa kaldıralım"):
//  Tarifi pakette OLMAYAN malzeme isteyen eşyalar (tüm modların tarifleri tarandı, boş c: tag'leri):
//   - KALDIRILDI: Spartan Weaponry tin / electrum / invar silahları (bu metaller pakette yok)
//                 Spartan Fire myrmex silahları (Ice and Fire CE 2.2'de myrmex yok)
//     -> tarifleri silinir; JEI'den client_scripts/uretilemez_gizle.js gizler (AYNI desenler).
//   - DÜZELTİLDİ (malzeme var, tag boştu): c:crops/ginger <- culturaldelights:ginger (zencefil içecekleri),
//                 c:plates/plastic <- tfmg:plastic_sheet (plastik boru)
// =====================================================================
;(function () {
  var KALDIR = [
    /^spartan_weaponry_unofficial:(tin|electrum|invar)_/,
    /^spartan_weaponry_unofficial:[a-z_]+_(tin|electrum|invar)$/,
    /^spartanfire:(desert|jungle)_myrmex_/
  ]

  ServerEvents.recipes(function (event) {
    KALDIR.forEach(function (d) {
      try { event.remove({ output: d }) } catch (e) { console.warn('[Uretilemez] tarif silinemedi ' + d + ': ' + e) }
    })
  })

  ServerEvents.tags('item', function (event) {
    event.add('c:crops/ginger', 'culturaldelights:ginger')
    event.add('c:crops', 'culturaldelights:ginger')
    event.add('c:plates/plastic', 'tfmg:plastic_sheet')
    event.add('c:plates', 'tfmg:plastic_sheet')
  })
})()
