// Create: Metallurgy dökümhanesi (Foundry) - kullanıcı kararları (2026-11-24)
//  Bağlananlar: Brass (bakır + çinko -> Create pirinci), Constantan (bakır + nikel -> TFMG constantan),
//               Bronze (3 bakır + 1 alüminyum -> CBC bronzu; pakette kalay yok. Bakır + çinko Brass ile
//               çakışacağı için alüminyum bronzu seçildi).
//  Kalanlar: Tungsten (Wolframite cevheri) ve Obdurium.
//  Kapatılanlar: ucuz Netherite (2 scrap + 120 mB altın), Steel alaşımı (çelik TFMG yüksek fırınında kalır),
//               külçesi pakette olmayan Electrum, Invar, Necromium, Void Steel.
//  Metallurgy'nin kendi steel_ingot/steel_block'u Almost Unified ile TFMG çeliğine birleşir; tariflerde
//  doğrudan istenen yerler de c:ingots/steel etiketine çevrilir. JEI gizleme: client_scripts/metallurgy_gizle.js
ServerEvents.recipes(function (event) {
  var KAPALI = ['electrum', 'invar', 'necromium', 'void_steel', 'netherite', 'steel', 'bronze']
  KAPALI.forEach(function (ad) { event.remove({ id: 'createmetallurgy:alloying/' + ad }) })

  event.custom({
    type: 'createmetallurgy:alloying',
    heat_requirement: 'heated',
    ingredients: [
      { type: 'neoforge:single', amount: 30, fluid: 'createmetallurgy:molten_copper' },
      { type: 'neoforge:single', amount: 10, fluid: 'createmetallurgy:molten_aluminum' }
    ],
    processing_time: 40,
    results: [{ amount: 40, id: 'createmetallurgy:molten_bronze' }]
  }).id('kubejs:metallurgy/bronze_aluminyum')

  // Metallurgy'nin kendi çeliğini isteyen tarifler her çeliği kabul etsin
  try {
    event.replaceInput({ mod: 'createmetallurgy' }, 'createmetallurgy:steel_ingot', '#c:ingots/steel')
    event.replaceInput({ mod: 'createmetallurgy' }, 'createmetallurgy:steel_block', '#c:storage_blocks/steel')
  } catch (err) { console.warn('[Metallurgy] celik girdisi degistirilemedi: ' + err) }
})
