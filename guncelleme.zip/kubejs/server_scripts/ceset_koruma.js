// =====================================================================
//  CESET KORUMASI  -  kubejs/server_scripts/ceset_koruma.js
//  Hedef: NeoForge 1.21.1 | KubeJS 2101.7.2 | Corpse 1.1.22
//
//  - Cesedi sadece sahibi (ve OP) açabilir: Corpse ayarı only_owner = true,
//    iskelet aşamasında da açılmaz (skeleton = false). Sunucu açılınca ayarlanır.
//  - İSTİSNALAR (bu script ceset ekranını kendisi açar):
//      * Aktif savaşta karşı yandaki oyuncular (savas_sistemi.js 'savas_erisim')
//      * Kellesi alınan oyuncunun cesedi KELLE_CESET_DK boyunca herkese açık
//        ('kelle_ceset' = { uuid: bitiş ms }, savas_sistemi.js yazar)
//
//  !! Gerçek bir oyunda ÇALIŞTIRILARAK TEST EDİLMEDİ.
// =====================================================================

;(function () {
  var CorpseMain = null, Guis = null, CorpseEntity = null
  try {
    CorpseMain = Java.loadClass('de.maxhenkel.corpse.Main')
    Guis = Java.loadClass('de.maxhenkel.corpse.gui.Guis')
    CorpseEntity = Java.loadClass('de.maxhenkel.corpse.entities.CorpseEntity')
  } catch (e) { console.warn('[Ceset] Corpse modu bulunamadi: ' + e) }
  var ServerPlayer = Java.loadClass('net.minecraft.server.level.ServerPlayer')
  var InteractionResult = Java.loadClass('net.minecraft.world.InteractionResult')
  var InteractionHand = Java.loadClass('net.minecraft.world.InteractionHand')

  ServerEvents.loaded(function (event) {
    if (CorpseMain == null) return
    try {
      var c = CorpseMain.SERVER_CONFIG
      c.onlyOwnerAccess.set(true)
      c.skeletonAccess.set(false)
      console.info('[Ceset] Cesetler sadece sahibine acik (savas ve kelle istisnalari script ile)')
    } catch (e) { console.error('[Ceset] ayar yazilamadi: ' + e) }
  })

  function izinliMi(server, sahip, eden) {
    // Aktif savaşta karşı yan
    try {
      var h = JSON.parse(server.persistentData.getString('savas_erisim') || '{}')[sahip] || []
      for (var i = 0; i < h.length; i++) if (h[i].d.indexOf(eden) >= 0) return 'savas'
    } catch (e) { }
    // Kellesi alınmış oyuncu
    try {
      var k = JSON.parse(server.persistentData.getString('kelle_ceset') || '{}')[sahip]
      if (k && Date.now() < k) return 'kelle'
    } catch (e) { }
    return null
  }

  // NativeEvents hatayı yakalamaz: her şey try içinde
  NativeEvents.onEvent('net.neoforged.neoforge.event.entity.player.PlayerInteractEvent$EntityInteract', function (event) {
    try {
      if (CorpseEntity == null) return
      var hedef = event.getTarget()
      if (!(hedef instanceof CorpseEntity)) return
      var p = event.getEntity()
      if (!(p instanceof ServerPlayer)) return
      if (event.getHand() !== InteractionHand.MAIN_HAND) return
      var o = hedef.getCorpseUUID()
      if (!o.isPresent()) return
      var sahip = String(o.get())
      var eden = String(p.getUuid())
      if (sahip === eden || p.createCommandSourceStack().hasPermission(2)) return   // Corpse kendisi açar
      var neden = izinliMi(p.server, sahip, eden)
      if (!neden) {
        p.setStatusMessage(Text.red(Text.ofString('Bu ceset korumalı. Sadece savaştaki düşman veya kelle avcısı yağmalayabilir.')))
        return
      }
      Guis.openCorpseGUI(p, hedef)
      event.setCanceled(true)
      event.setCancellationResult(InteractionResult.SUCCESS)
    } catch (err) { console.error('[Ceset] hata: ' + err) }
  })
})()
