// Apotheosis altın yükseltme şablonu kaldırıldı (server_scripts/apotheosis_sablon.js): JEI'de görünmesin
RecipeViewerEvents.removeEntries('item', function (event) {
  try { event.remove('apotheosis:gold_upgrade_smithing_template') } catch (err) { console.warn('[ApotheosisSablon] ' + err) }
})
