// Apotheosis yükseltme şablonları kaldırıldı (server_scripts/apotheosis_sablon.js): JEI'de görünmesin
RecipeViewerEvents.removeEntries('item', function (event) {
  ;['iron', 'gold', 'diamond'].forEach(function (m) {
    try { event.remove('apotheosis:' + m + '_upgrade_smithing_template') } catch (err) { console.warn('[ApotheosisSablon] ' + err) }
  })
})