// Sunucu menüsü tuşu (kayıt: startup_scripts/menu_defteri.js, varsayılan Y). Basınca /menu gönderilir.
KeyBindEvents.pressed('sunucu_menu_ac', function (event) {
  try {
    var mc = Java.loadClass('net.minecraft.client.Minecraft').getInstance()
    if (mc.player == null || mc.screen != null) return
    mc.player.connection.sendCommand('menu')
  } catch (err) { console.error('[Menu] tus hatasi: ' + err) }
})
