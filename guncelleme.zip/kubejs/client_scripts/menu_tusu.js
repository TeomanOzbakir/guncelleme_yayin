// Sunucu menüsü tuşu (kayıt: startup_scripts/menu_defteri.js, varsayılan Y). Basınca /menu gönderilir.
KeyBindEvents.pressed('sunucu_menu_ac', function (event) {
  try {
    var mc = Java.loadClass('net.minecraft.client.Minecraft').getInstance()
    if (mc.player == null || mc.screen != null) return
    mc.player.connection.sendCommand('menu')
  } catch (err) { console.error('[Menu] tus hatasi: ' + err) }
})

// Menü ekranları arasında geçerken imleç ortaya gelmesin: arayuz.js tıklamada konumu
// global.sunucuImlec'e yazar; yeni ekran açılınca (en geç 1,5 sn içinde) imleç oraya konur.
var MenuImlec = { mc: null, girdi: null }
ClientEvents.tick(function (event) {
  if (typeof global === 'undefined') return
  try {
    var k = global.sunucuImlec
    if (!k) return
    if (Date.now() - k.t > 1500) { global.sunucuImlec = null; return }   // komut ekran açmadıysa bırak
    if (MenuImlec.mc == null) {
      MenuImlec.mc = Java.loadClass('net.minecraft.client.Minecraft').getInstance()
      MenuImlec.girdi = Java.loadClass('com.mojang.blaze3d.platform.InputConstants')
    }
    var mc = MenuImlec.mc
    if (mc.screen == null) return   // eski ekran kapandı, yenisi henüz gelmedi
    global.sunucuImlec = null
    MenuImlec.girdi.grabOrReleaseMouse(mc.getWindow().getWindow(), 212993, k.x, k.y)   // 212993 = GLFW_CURSOR_NORMAL
  } catch (err) { global.sunucuImlec = null; console.warn('[Menu] imlec: ' + err) }
})
