// Sunucu menüsü tuşu (kayıt: startup_scripts/menu_defteri.js, varsayılan Y). Basınca /menu gönderilir.
KeyBindEvents.pressed('sunucu_menu_ac', function (event) {
  try {
    var mc = Java.loadClass('net.minecraft.client.Minecraft').getInstance()
    if (mc.player == null || mc.screen != null) return
    mc.player.connection.sendCommand('menu')
  } catch (err) { console.error('[Menu] tus hatasi: ' + err) }
})

// Menü ekranları arasında geçerken imleç ortaya gelmesin: arayuz.js tıklamada konumu global.sunucuImlec
// haritasına yazar (x, y, t, bekliyor); yeni ekran açılınca (en geç 1,5 sn içinde) imleç oraya konur.
// Client betikleri global'e ATAMA yapamaz; harita startup'ta kurulur, burada sadece put/get yapılır.
var MenuImlec = { mc: null, girdi: null }
ClientEvents.tick(function (event) {
  if (typeof global === 'undefined') return
  var k = global.sunucuImlec
  if (!k) return
  try {
    if (String(k.getOrDefault('bekliyor', 'hayir')) !== 'evet') return
    if (Date.now() - Number(k.get('t')) > 1500) { k.put('bekliyor', 'hayir'); return }   // komut ekran açmadıysa bırak
    if (MenuImlec.mc == null) {
      MenuImlec.mc = Java.loadClass('net.minecraft.client.Minecraft').getInstance()
      MenuImlec.girdi = Java.loadClass('com.mojang.blaze3d.platform.InputConstants')
    }
    var mc = MenuImlec.mc
    if (mc.screen == null) return   // eski ekran kapandı, yenisi henüz gelmedi
    k.put('bekliyor', 'hayir')
    MenuImlec.girdi.grabOrReleaseMouse(mc.getWindow().getWindow(), 212993, Number(k.get('x')), Number(k.get('y')))   // 212993 = GLFW_CURSOR_NORMAL
  } catch (err) { try { k.put('bekliyor', 'hayir') } catch (e2) { } console.warn('[Menu] imlec: ' + err) }
})
