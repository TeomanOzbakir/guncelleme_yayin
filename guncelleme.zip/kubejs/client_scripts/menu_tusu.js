// Sunucu menüsü tuşu (kayıt: startup_scripts/menu_defteri.js). Basınca /menu gönderilir.
KeyBindEvents.pressed('sunucu_menusu', function (event) {
  try {
    var mc = Java.loadClass('net.minecraft.client.Minecraft').getInstance()
    if (mc.player == null || mc.screen != null) return
    mc.player.connection.sendCommand('menu')
  } catch (err) { console.error('[Menu] tus hatasi: ' + err) }
})
