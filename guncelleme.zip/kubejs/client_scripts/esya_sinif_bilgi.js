// =====================================================================
//  EŞYA ALTINDA SINIF / BECERİ BİLGİSİ  -  kubejs/client_scripts/esya_sinif_bilgi.js
//  2026-11-27 (kullanıcı): "hangi itemin hangi class/skill ile kullanılabileceği itemin altında yazsın".
//  - Sınıf satırı: sunucudaki sinif_silah.js ile AYNI sınıflandırma (değiştirirsen ikisini birlikte değiştir).
//  - Beceri satırı: config/reskillable/skill_locks.json (Reskillable'ın kendi İngilizce "Skill Requirements"
//    satırı da durur; o satır şartı karşılayıp karşılamadığını yeşil/kırmızı gösterir).
//  Tooltip'ler oyun açılırken bir kez hesaplanır.
// =====================================================================
;(function () {
  var SINIF_AD = { savasci: 'Savaşçı', avci: 'Avcı', nisanci: 'Nişancı', buyucu: 'Büyücü', elementalist: 'Elementalist', terbiyeci: 'Terbiyeci', yok: 'Sınıfsız' }
  var IZIN = {
    savasci: { kilic: 1, kilic_temel: 1, agir: 1, mizrak: 1, kalkan: 1, kalkan_temel: 1, tabanca: 1 },
    avci: { yay: 1, yay_temel: 1, hancer: 1, firlatma: 1, tabanca: 1 },
    nisanci: { silah: 1, tabanca: 1, hancer: 1 },
    buyucu: { buyu: 1, hancer: 1, tabanca: 1 },
    elementalist: { buyu: 1, hancer: 1, tabanca: 1 },
    terbiyeci: { mizrak: 1, yay: 1, yay_temel: 1, buyu: 1, tabanca: 1 },
    yok: { kilic_temel: 1, yay_temel: 1, kalkan_temel: 1, tabanca: 1 }
  }
  var KIMIN = {}
  Object.keys(IZIN).forEach(function (s) { Object.keys(IZIN[s]).forEach(function (t) { (KIMIN[t] = KIMIN[t] || []).push(SINIF_AD[s]) }) })
  var BECERI = { mining: 'Madencilik', gathering: 'Toplayıcılık', attack: 'Saldırı', defense: 'Savunma', building: 'İnşaat', farming: 'Çiftçilik', agility: 'Çeviklik', magic: 'Büyü', silah: 'Silah' }
  var MUTFAK = { farmersdelight: 1, kaleidoscope_cookery: 1, culturaldelights: 1, handson_delight: 1, youkaisfeasts: 1, starcatcher: 1, starcatcher_delight: 1 }
  var ARAC_DISI = /(smithing_hammer|oil_hammer|pumpjack_hammer|wrench|gadget)/

  function tur(id) {
    if (id === 'tacz:modern_kinetic_gun') return 'silah'
    var ns = id.split(':')[0], y = id.split(':')[1] || ''
    if (MUTFAK[ns] || ARAC_DISI.test(y) || /(pickaxe|shovel|hoe|paxel|_axe$|^axe$|sickle)/.test(y) && !/battle_?axe|great_?axe|war_?axe|double_axe/.test(y)) return null
    if (/shield/.test(y)) return id === 'minecraft:shield' ? 'kalkan_temel' : 'kalkan'
    if (/(heavy_crossbow|longbow|crossbow|(^|_)bow$)/.test(y)) return ns === 'minecraft' ? 'yay_temel' : 'yay'
    if (/(javelin|boomerang|tomahawk|throwing_knife)/.test(y)) return 'firlatma'
    if (/(dagger|knife|athame|fang|stiletto)/.test(y)) return 'hancer'
    if (/(quarterstaff|staff|wand|sceptre|spell_book|spellbook)/.test(y) || (ns === 'irons_spellbooks' && /(staff|book|wand)/.test(y))) return 'buyu'
    if (/(spear|pike|lance|trident|halberd|glaive)/.test(y)) return /(halberd|glaive)/.test(y) ? 'agir' : 'mizrak'
    if (/(great_?sword|claymore|war_?hammer|battle_?hammer|hammer|mace|battleaxe|battle_axe|great_?axe|maul|flail|club|scythe)/.test(y)) return 'agir'
    if (/(sword|katana|saber|sabre|cutlass|rapier|longsword|blade|scimitar)/.test(y)) return (ns === 'minecraft' && /_sword$/.test(y)) ? 'kilic_temel' : 'kilic'
    return null
  }

  var kilit = {}
  try {
    var j = JSON.parse(String(JsonIO.readString('config/reskillable/skill_locks.json')))
    kilit = (j && j.skillLocks) || {}
  } catch (e) { console.warn('[EsyaBilgi] skill_locks okunamadi: ' + e) }

  ItemEvents.modifyTooltips(function (event) {
    try {
      var BuiltInRegistries = Java.loadClass('net.minecraft.core.registries.BuiltInRegistries')
      var gruplar = {}   // satır anahtarı -> { ids: [], satir: [Component] }
      var it = BuiltInRegistries.ITEM.keySet().iterator()
      while (it.hasNext()) {
        var id = String(it.next())
        var t = tur(id)
        var k = kilit[id]
        if (t == null && !k) continue
        var sinif = ''
        if (t === 'silah') sinif = 'Nişancı (tabancalar: herkes)'
        else if (t != null) sinif = (KIMIN[t] || []).join(', ')
        var bec = ''
        if (k && k.length) bec = k.map(function (x) { var p = String(x).split(':'); return (BECERI[p[0]] || p[0]) + ' ' + p[1] }).join(', ')
        var anahtar = sinif + '|' + bec
        var g = gruplar[anahtar]
        if (!g) {
          var satir = []
          if (sinif) satir.push(Text.gold('Sınıf: ').append(Text.yellow(sinif)))
          if (bec) satir.push(Text.gold('Beceri: ').append(Text.yellow(bec)))
          g = gruplar[anahtar] = { ids: [], satir: satir }
        }
        g.ids.push(id)
      }
      var n = 0
      Object.keys(gruplar).forEach(function (a) { var g = gruplar[a]; event.add(g.ids, g.satir); n += g.ids.length })
      console.info('[EsyaBilgi] sinif/beceri satiri eklenen esya: ' + n)
    } catch (err) { console.error('[EsyaBilgi] ' + err) }
  })
})()
