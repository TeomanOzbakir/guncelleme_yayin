// Create: Metallurgy'de kullanılmayan içerikleri JEI'den gizler (tarifleri: server_scripts/metallurgy.js).
// Kalay ve osmiyum pakette yok; Electrum, Invar, Necromium, Void Steel alaşımları kapalı; çelik TFMG'ninki.
var METALLURGY_GIZLI = ['electrum', 'invar', 'necromium', 'void_steel', 'tin', 'osmium']

RecipeViewerEvents.removeEntries('item', function (event) {
  try {
    METALLURGY_GIZLI.forEach(function (m) { event.remove('createmetallurgy:molten_' + m + '_bucket') })
    event.remove('createmetallurgy:steel_ingot')
    event.remove('createmetallurgy:steel_block')
  } catch (err) { console.warn('[Metallurgy] JEI esya gizleme: ' + err) }
})

RecipeViewerEvents.removeEntries('fluid', function (event) {
  try {
    METALLURGY_GIZLI.forEach(function (m) { event.remove('createmetallurgy:molten_' + m) })
  } catch (err) { console.warn('[Metallurgy] JEI sivi gizleme: ' + err) }
})
