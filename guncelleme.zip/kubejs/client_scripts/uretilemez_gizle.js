// Üretilemeyen eşyaları JEI/EMI'den gizler. Tarifleri sunucuda silinir:
// server_scripts/uretilemez_temizlik.js içindeki KALDIR desenleri ile AYNI olmalı.
var URETILEMEZ = [
  /^spartan_weaponry_unofficial:(tin|electrum|invar)_/,
  /^spartan_weaponry_unofficial:[a-z_]+_(tin|electrum|invar)$/,
  /^spartanfire:(desert|jungle)_myrmex_/
]
RecipeViewerEvents.removeEntries('item', function (event) {
  URETILEMEZ.forEach(function (d) {
    try { event.remove(d) } catch (err) { console.warn('[Uretilemez] gizlenemedi ' + d + ': ' + err) }
  })
})
