// Oyundan kaldırılan TaCZ silahlarını JEI'den gizler. Tarifleri sunucuda kapalı:
// server_scripts/silah_uretim_tacz.js içindeki KALDIRILAN_SILAHLAR ile AYNI liste olmalı.
// TaCZ silah kimliğini eşyanın custom_data içinde "GunId" olarak tutar (ör. tacz:cz75).
var KALDIRILAN_SILAHLAR = [
  'cz75', 'b93r', 'timeless50', 'taurus943', 'lonetrail', 'hk_mk23', 'taurus500', 'm9a4',
  'm107', 'svd', 'hm50b', 'mrad',
  'scar_mk20', 'spr15hb', 'm1866',
  'hk_g3', 'type_81', 'qbz_95', 'g36k', 'fn_fal', 'hcar', 'qr_24', 'ak74m', 'mk18', 'ak12', 'urgi',
  'aa12', 'spas_12'
]

RecipeViewerEvents.removeEntries('item', function (event) {
  try {
    var DataComponents = Java.loadClass('net.minecraft.core.component.DataComponents')
    var gizli = {}
    KALDIRILAN_SILAHLAR.forEach(function (id) { gizli['tacz:' + id] = true })
    event.remove(function (stack) {
      try {
        if (String(stack.getItem().getDescriptionId()).indexOf('tacz') < 0) return false
        var cd = stack.get(DataComponents.CUSTOM_DATA)
        if (cd == null) return false
        return gizli[String(cd.copyTag().getString('GunId'))] === true
      } catch (e) { return false }
    })
  } catch (err) { console.warn('[SilahGizle] JEI gizleme yapilamadi: ' + err) }
})
