// =====================================================================
//  ARAYÜZ ÇATISI  -  kubejs/startup_scripts/arayuz.js
//  LDLib2 (paketteki ldlib2-neoforge-1.21.1-2.2.46) arayüz sistemi üzerine.
//  Ayrı bir mod gerekmez; LDLib2 zaten hem sunucuda hem oyuncularda var.
//
//  NASIL ÇALIŞIR
//  - Bu dosya startup_scripts'te, çünkü LDLib2 aynı ekranı hem sunucuda
//    (menü/veri) hem oyuncunun bilgisayarında (görüntü) kurar. Bu yüzden
//    DOSYA OYUNCULARDA DA AYNI OLMALI (oyuncu paketinde var).
//  - Ekran açmak: sunucuda  /menu  veya  /menu <ekran>  (server_scripts/arayuz_komut.js)
//  - Değişiklikler için oyunu/sunucuyu YENİDEN BAŞLATMAK gerekir
//    (startup script'leri /reload ile yenilenmez).
//
//  YENİ EKRAN EKLEMEK
//    ekran('arayuz:kimlik', 'Başlık', [
//      { t: 'yazi',  metin: 'Sabit yazı' },
//      { t: 'veri',  f: function (oyuncu) { return 'sunucudan gelen canlı yazı' } },
//      { t: 'giris', ad: 'miktar', min: 1, max: 1000000 },     // sayı kutusu (min yoksa serbest yazı)
//      { t: 'buton', yazi: 'Kredi çek', komut: 'kredi cek {miktar}' },  // oyuncunun yetkisiyle komut
//      { t: 'git',   yazi: 'Geri', ekran: 'arayuz:ana' }       // başka ekrana geç
//    ])
//  - 'veri' fonksiyonları SADECE sunucuda çalışır; her tick güncellenir.
//  - 'buton' komutları oyuncunun kendi yetkisiyle çalışır (OP komutları OP'lara açık kalır).
//  - Ekranın yapısı iki tarafta aynı olmalı: oyeler listesini oyuncuya göre
//    değiştirmeyin (yetkiye göre farklı yazı göstermek 'veri' içinde yapılır).
//
//  !! Gerçek bir oyunda ÇALIŞTIRILARAK TEST EDİLMEDİ.
// =====================================================================

;(function () {
  const ModularUI = Java.loadClass('com.lowdragmc.lowdraglib2.gui.ui.ModularUI')
  const UI = Java.loadClass('com.lowdragmc.lowdraglib2.gui.ui.UI')
  const UIElement = Java.loadClass('com.lowdragmc.lowdraglib2.gui.ui.UIElement')
  const Label = Java.loadClass('com.lowdragmc.lowdraglib2.gui.ui.elements.Label')
  const Button = Java.loadClass('com.lowdragmc.lowdraglib2.gui.ui.elements.Button')
  const TextField = Java.loadClass('com.lowdragmc.lowdraglib2.gui.ui.elements.TextField')
  const DataBindingBuilder = Java.loadClass('com.lowdragmc.lowdraglib2.gui.sync.bindings.impl.DataBindingBuilder')
  // Görsel sınıfları ekran açılırken yüklenir (oyun açılışında kaynaklar henüz hazır değil)
  let StylesheetManager = null, MCSprites = null
  function gorseller() {
    if (StylesheetManager == null) {
      StylesheetManager = Java.loadClass('com.lowdragmc.lowdraglib2.gui.ui.style.StylesheetManager')
      MCSprites = Java.loadClass('com.lowdragmc.lowdraglib2.gui.ui.styletemplate.MCSprites')
    }
  }
  const MenuTipleri = Java.loadClass('com.lowdragmc.lowdraglib2.integration.kjs.ui.LDKJSMenuTypes')
  const Component = Java.loadClass('net.minecraft.network.chat.Component')
  const JUUID = Java.loadClass('java.util.UUID')

  const GENISLIK = 240
  const EKRANLAR = {}
  function ekran(id, baslik, ogeler) { EKRANLAR[id] = { baslik: baslik, ogeler: ogeler } }

  // ----------------------------- SUNUCU VERİ YARDIMCILARI -----------------
  // (Sadece 'veri' fonksiyonlarının içinden, yani sunucuda çağrılır.)
  const HAZINE = '5f0c2d1e-7a3b-4e9c-8d6f-1b2a3c4d5e6f'
  let Numismatics = null
  function banka(uuid) {
    if (Numismatics == null) Numismatics = Java.loadClass('dev.ithundxr.createnumismatics.Numismatics')
    const h = Numismatics.BANK.getAccount(uuid)
    return h ? h.getBalance() : 0
  }
  function veriOku(oyuncu, anahtar) {
    const s = oyuncu.server.persistentData.getString(anahtar)
    if (!s) return {}
    try { return JSON.parse(s) } catch (e) { return {} }
  }
  function borcKaydi(oyuncu) { const d = veriOku(oyuncu, 'borc_veri'); return (d.o || {})[String(oyuncu.getUUID())] || null }
  function kalanYazi(ms) { const dk = Math.max(0, Math.floor(ms / 60000)); return Math.floor(dk / 60) + ' sa ' + (dk % 60) + ' dk' }

  // ----------------------------- EKRANLAR ---------------------------------
  ekran('arayuz:ana', 'Sunucu Menüsü', [
    { t: 'veri', f: function (p) { return 'Banka: ' + banka(p.getUUID()) + ' spur' } },
    { t: 'veri', f: function (p) { const r = borcKaydi(p); return 'Kredi notu: ' + (r ? r.not : 500) + '/1000   Borç: ' + (r && r.borc > 0 ? Math.ceil(r.borc) + ' spur' : 'yok') } },
    { t: 'git', yazi: 'Kredi ve Borç', ekran: 'arayuz:kredi' },
    { t: 'git', yazi: 'Arazi Vergisi', ekran: 'arayuz:vergi' },
    { t: 'git', yazi: 'Savaş', ekran: 'arayuz:savas' },
    { t: 'git', yazi: 'Devlet Hazinesi (yetkili)', ekran: 'arayuz:devlet' }
  ])

  ekran('arayuz:kredi', 'Kredi ve Borç', [
    { t: 'veri', f: function (p) { const r = borcKaydi(p); return 'Kredi notu: ' + (r ? r.not : 500) + '/1000' } },
    { t: 'veri', f: function (p) { const r = borcKaydi(p); return r && r.borc > 0 ? 'Borç: ' + Math.ceil(r.borc) + ' spur (günlük %2 faiz)' : 'Borcun yok.' } },
    { t: 'veri', f: function (p) { const r = borcKaydi(p); return r && r.kredi ? 'Aktif kredi: kalan ' + r.kredi.kalan + ', günlük taksit ' + r.kredi.taksit : 'Aktif kredin yok.' } },
    { t: 'yazi', metin: 'Çekilecek miktar (spur):' },
    { t: 'giris', ad: 'miktar', min: 1, max: 1000000 },
    { t: 'buton', yazi: 'Kredi çek', komut: 'kredi cek {miktar}' },
    { t: 'buton', yazi: 'Krediyi şimdi kapat', komut: 'kredi ode' },
    { t: 'buton', yazi: 'Limitimi sohbete yaz', komut: 'kredi durum' },
    { t: 'git', yazi: '< Geri', ekran: 'arayuz:ana' }
  ])

  ekran('arayuz:vergi', 'Arazi Vergisi', [
    { t: 'veri', f: function (p) {
      const r = (veriOku(p, 'vergi_veri').kayitlar || {})[String(p.getUUID())]
      if (!r) return 'Henüz vergi kaydın yok (claim yapınca başlar).'
      return 'Ön ödeme: ' + Math.max(0, Math.floor(r.kredi || 0)) + ' spur' + (r.askida ? '  |  CLAIM\'LER ASKIDA' : '') +
        (r.grace ? '  |  ek süre: ' + kalanYazi(r.grace - Date.now()) : '')
    } },
    { t: 'buton', yazi: '1 gün öde', komut: 'vergi ode gun' },
    { t: 'buton', yazi: '1 hafta öde', komut: 'vergi ode hafta' },
    { t: 'buton', yazi: '1 ay öde', komut: 'vergi ode ay' },
    { t: 'buton', yazi: 'Otomatik ödemeyi aç', komut: 'vergi otomatik ac' },
    { t: 'buton', yazi: 'Otomatik ödemeyi kapat', komut: 'vergi otomatik kapat' },
    { t: 'buton', yazi: 'Ayrıntılı durum (sohbet)', komut: 'vergi durum' },
    { t: 'git', yazi: '< Geri', ekran: 'arayuz:ana' }
  ])

  function savasSatiri(i) {
    return function (p) {
      const s = (veriOku(p, 'savas_veri').savaslar || [])[i]
      if (!s) return i === 0 ? 'Şu an savaş yok.' : ''
      return (s.durum === 'hazirlik' ? '[Hazırlık] ' : '[Aktif] ') + s.a.ad + ' ' + s.skor.a + ' - ' + s.skor.b + ' ' + s.b.ad
    }
  }
  ekran('arayuz:savas', 'Savaş', [
    { t: 'veri', f: savasSatiri(0) }, { t: 'veri', f: savasSatiri(1) }, { t: 'veri', f: savasSatiri(2) },
    { t: 'yazi', metin: 'Karşı oyuncunun adı:' },
    { t: 'giris', ad: 'oyuncu' },
    { t: 'buton', yazi: 'Savaş ilan et', komut: 'savas ilan {oyuncu}' },
    { t: 'buton', yazi: 'Barış teklif et / kabul et', komut: 'savas baris {oyuncu}' },
    { t: 'buton', yazi: 'Teslim ol', komut: 'savas teslim {oyuncu}' },
    { t: 'git', yazi: '< Geri', ekran: 'arayuz:ana' }
  ])

  ekran('arayuz:devlet', 'Devlet Hazinesi', [
    { t: 'veri', f: function (p) { return p.createCommandSourceStack().hasPermission(2) ?'Hazine: ' + banka(JUUID.fromString(HAZINE)) + ' spur' : 'Bu ekran sadece yetkililer içindir.' } },
    { t: 'yazi', metin: 'Oyuncu adı ve miktar:' },
    { t: 'giris', ad: 'oyuncu' },
    { t: 'giris', ad: 'miktar', min: 1, max: 100000000 },
    { t: 'buton', yazi: 'Oyuncuya aktar', komut: 'devlet aktar {oyuncu} {miktar}' },
    { t: 'buton', yazi: 'Kendi bankama çek', komut: 'devlet cek {miktar}' },
    { t: 'buton', yazi: 'Hareketler (sohbet)', komut: 'devlet durum' },
    { t: 'git', yazi: '< Geri', ekran: 'arayuz:ana' }
  ])

  // ----------------------------- ÇATI -------------------------------------
  function komutCalistir(oyuncu, sablon, durum, ogeler) {
    // {ad} yer tutucularını doldur, sayı kutularını doğrula
    let hata = null
    const komut = sablon.replace(/\{(\w+)\}/g, function (m, ad) {
      const v = String(durum[ad] == null ? '' : durum[ad]).trim()
      const tanim = ogeler.filter(function (o) { return o.t === 'giris' && o.ad === ad })[0]
      if (v === '') { hata = 'Önce kutuyu doldur.'; return '' }
      if (tanim && tanim.min != null && !/^\d+$/.test(v)) { hata = 'Kutuya sadece sayı yaz.'; return '' }
      if (!/^[A-Za-z0-9_]+$/.test(v)) { hata = 'Geçersiz karakter.'; return '' }
      return v
    })
    oyuncu.closeContainer()
    if (hata) { oyuncu.tell(Component.literal(hata)); return }
    oyuncu.server.getCommands().performPrefixedCommand(oyuncu.createCommandSourceStack(), komut)
  }

  Object.keys(EKRANLAR).forEach(function (id) {
    LDLib2UI.player(id, function (e) {
      const tanim = EKRANLAR[id]
      const sunucuda = !e.level.isClientSide()
      const oyuncu = e.player
      const durum = {}
      gorseller()

      const kok = new UIElement()
      kok.layout(function (l) { l.width(GENISLIK).paddingAll(8).gapAll(4) })
      kok.style(function (s) { s.background(MCSprites.RECT) })
      kok.addChild(new Label().setText(Component.literal(tanim.baslik)))

      tanim.ogeler.forEach(function (o) {
        if (o.t === 'yazi') {
          kok.addChild(new Label().setText(Component.literal(o.metin)))
        } else if (o.t === 'veri') {
          const lbl = new Label()
          lbl.bind(DataBindingBuilder.componentS2C(function () {
            if (!sunucuda) return Component.literal('')
            try { return Component.literal(String(o.f(oyuncu))) } catch (err) { return Component.literal('(hata: ' + err + ')') }
          }).build())
          kok.addChild(lbl)
        } else if (o.t === 'giris') {
          durum[o.ad] = ''
          const tf = new TextField()
          if (o.min != null) tf.setNumbersOnlyInt(o.min, o.max); else tf.setAnyString()
          tf.bind(DataBindingBuilder.string(function () { return durum[o.ad] }, function (v) { durum[o.ad] = String(v) }).build())
          kok.addChild(tf)
        } else if (o.t === 'buton') {
          const b = new Button().setText(o.yazi)
          b.setOnServerClick(function (ev) { komutCalistir(oyuncu, o.komut, durum, tanim.ogeler) })
          kok.addChild(b)
        } else if (o.t === 'git') {
          const b = new Button().setText(o.yazi)
          b.setOnServerClick(function (ev) { MenuTipleri.openPlayerUI(oyuncu, o.ekran) })
          kok.addChild(b)
        }
      })

      e.modularUI = ModularUI.of(UI.of(kok, StylesheetManager.MC), oyuncu)
    })
  })

  console.info('[Arayuz] ' + Object.keys(EKRANLAR).length + ' ekran kaydedildi: ' + Object.keys(EKRANLAR).join(', '))
})()
