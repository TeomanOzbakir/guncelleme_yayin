// =====================================================================
//  /menu komutu - arayüz ekranlarını açar
//  Dosya: kubejs/server_scripts/arayuz_komut.js
//  Ekranlar kubejs/startup_scripts/arayuz.js içinde tanımlı.
//    /menu            -> ana menü
//    /menu <ekran>    -> ör. /menu kredi  (arayuz:kredi ekranını açar)
// =====================================================================
;(function () {
  const MenuTipleri = Java.loadClass('com.lowdragmc.lowdraglib2.integration.kjs.ui.LDKJSMenuTypes')

  function ac(ctx, ad) {
    const p = ctx.source.player
    if (p == null) { ctx.source.sendSystemMessage(Text.ofString('Bu komutu oyun içinden kullanın.')); return 0 }
    const id = ad.indexOf(':') >= 0 ? ad : 'arayuz:' + ad
    let ok = false
    try { ok = MenuTipleri.openPlayerUI(p, id) } catch (err) { console.error('[Arayuz] acilamadi ' + id + ': ' + err) }
    if (!ok) p.tell(Text.red(Text.ofString('Ekran açılamadı: ' + id)))
    return ok ? 1 : 0
  }

  ServerEvents.commandRegistry(function (event) {
    const Commands = event.commands
    const Arguments = event.arguments
    event.register(Commands.literal('menu')
      .executes(function (ctx) { return ac(ctx, 'ana') })
      .then(Commands.argument('ekran', Arguments.WORD.create(event)).executes(function (ctx) {
        return ac(ctx, String(Arguments.WORD.getResult(ctx, 'ekran')))
      })))
  })
})()
